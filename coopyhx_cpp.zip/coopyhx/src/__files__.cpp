#include <hxcpp.h>

namespace hx {
const char *__hxcpp_all_files[] = {
#ifdef HXCPP_DEBUGGER
	"Lambda.hx",
	"List.hx",
	"Std.hx",
	"StringBuf.hx",
	"StringTools.hx",
	"coopy/Alignment.hx",
	"coopy/CellInfo.hx",
	"coopy/CompareFlags.hx",
	"coopy/CompareTable.hx",
	"coopy/Coopy.hx",
	"coopy/CrossMatch.hx",
	"coopy/Csv.hx",
	"coopy/DiffRender.hx",
	"coopy/FlatCellBuilder.hx",
	"coopy/HighlightPatch.hx",
	"coopy/HighlightPatchUnit.hx",
	"coopy/Index.hx",
	"coopy/IndexItem.hx",
	"coopy/IndexPair.hx",
	"coopy/Mover.hx",
	"coopy/NestedCellBuilder.hx",
	"coopy/Ordering.hx",
	"coopy/SimpleCell.hx",
	"coopy/SimpleTable.hx",
	"coopy/SimpleView.hx",
	"coopy/SparseSheet.hx",
	"coopy/SqlColumn.hx",
	"coopy/SqlCompare.hx",
	"coopy/SqlTable.hx",
	"coopy/SqlTableName.hx",
	"coopy/TableComparisonState.hx",
	"coopy/TableDiff.hx",
	"coopy/TableIO.hx",
	"coopy/TableModifier.hx",
	"coopy/Unit.hx",
	"coopy/Viterbi.hx",
	"haxe/Log.hx",
	"haxe/ds/IntMap.hx",
	"haxe/ds/StringMap.hx",
#endif
 0 };
const char *__hxcpp_class_path[] = {
#ifdef HXCPP_DEBUGGER
	"src/",
	"./",
	"/usr/share/haxe/std/cpp/_std/",
	"/usr/share/haxe/std/",
	"/usr/share/haxe/std/",
#endif
 0 };
} // namespace hx

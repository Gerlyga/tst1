#include <hxcpp.h>

#ifndef INCLUDED_coopy_CellBuilder
#include <coopy/CellBuilder.h>
#endif
#ifndef INCLUDED_coopy_FlatCellBuilder
#include <coopy/FlatCellBuilder.h>
#endif
#ifndef INCLUDED_coopy_Unit
#include <coopy/Unit.h>
#endif
#ifndef INCLUDED_coopy_View
#include <coopy/View.h>
#endif
namespace coopy{

Void FlatCellBuilder_obj::__construct()
{
HX_STACK_PUSH("FlatCellBuilder::new","coopy/FlatCellBuilder.hx",13);
{
}
;
	return null();
}

FlatCellBuilder_obj::~FlatCellBuilder_obj() { }

Dynamic FlatCellBuilder_obj::__CreateEmpty() { return  new FlatCellBuilder_obj; }
hx::ObjectPtr< FlatCellBuilder_obj > FlatCellBuilder_obj::__new()
{  hx::ObjectPtr< FlatCellBuilder_obj > result = new FlatCellBuilder_obj();
	result->__construct();
	return result;}

Dynamic FlatCellBuilder_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< FlatCellBuilder_obj > result = new FlatCellBuilder_obj();
	result->__construct();
	return result;}

hx::Object *FlatCellBuilder_obj::__ToInterface(const hx::type_info &inType) {
	if (inType==typeid( ::coopy::CellBuilder_obj)) return operator ::coopy::CellBuilder_obj *();
	return super::__ToInterface(inType);
}

Dynamic FlatCellBuilder_obj::links( ::coopy::Unit unit){
	HX_STACK_PUSH("FlatCellBuilder::links","coopy/FlatCellBuilder.hx",49);
	HX_STACK_THIS(this);
	HX_STACK_ARG(unit,"unit");
	HX_STACK_LINE(49)
	return this->view->toDatum(unit->toString());
}


HX_DEFINE_DYNAMIC_FUNC1(FlatCellBuilder_obj,links,return )

Dynamic FlatCellBuilder_obj::marker( ::String label){
	HX_STACK_PUSH("FlatCellBuilder::marker","coopy/FlatCellBuilder.hx",45);
	HX_STACK_THIS(this);
	HX_STACK_ARG(label,"label");
	HX_STACK_LINE(45)
	return this->view->toDatum(label);
}


HX_DEFINE_DYNAMIC_FUNC1(FlatCellBuilder_obj,marker,return )

Dynamic FlatCellBuilder_obj::conflict( Dynamic parent,Dynamic local,Dynamic remote){
	HX_STACK_PUSH("FlatCellBuilder::conflict","coopy/FlatCellBuilder.hx",39);
	HX_STACK_THIS(this);
	HX_STACK_ARG(parent,"parent");
	HX_STACK_ARG(local,"local");
	HX_STACK_ARG(remote,"remote");
	HX_STACK_LINE(39)
	return ((((this->view->toString(parent) + this->conflict_separator) + this->view->toString(local)) + this->conflict_separator) + this->view->toString(remote));
}


HX_DEFINE_DYNAMIC_FUNC3(FlatCellBuilder_obj,conflict,return )

Dynamic FlatCellBuilder_obj::update( Dynamic local,Dynamic remote){
	HX_STACK_PUSH("FlatCellBuilder::update","coopy/FlatCellBuilder.hx",32);
	HX_STACK_THIS(this);
	HX_STACK_ARG(local,"local");
	HX_STACK_ARG(remote,"remote");
	HX_STACK_LINE(32)
	return this->view->toDatum(((::coopy::FlatCellBuilder_obj::quoteForDiff(this->view,local) + this->separator) + ::coopy::FlatCellBuilder_obj::quoteForDiff(this->view,remote)));
}


HX_DEFINE_DYNAMIC_FUNC2(FlatCellBuilder_obj,update,return )

Void FlatCellBuilder_obj::setView( ::coopy::View view){
{
		HX_STACK_PUSH("FlatCellBuilder::setView","coopy/FlatCellBuilder.hx",28);
		HX_STACK_THIS(this);
		HX_STACK_ARG(view,"view");
		HX_STACK_LINE(28)
		this->view = view;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(FlatCellBuilder_obj,setView,(void))

Void FlatCellBuilder_obj::setConflictSeparator( ::String separator){
{
		HX_STACK_PUSH("FlatCellBuilder::setConflictSeparator","coopy/FlatCellBuilder.hx",24);
		HX_STACK_THIS(this);
		HX_STACK_ARG(separator,"separator");
		HX_STACK_LINE(24)
		this->conflict_separator = separator;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(FlatCellBuilder_obj,setConflictSeparator,(void))

Void FlatCellBuilder_obj::setSeparator( ::String separator){
{
		HX_STACK_PUSH("FlatCellBuilder::setSeparator","coopy/FlatCellBuilder.hx",20);
		HX_STACK_THIS(this);
		HX_STACK_ARG(separator,"separator");
		HX_STACK_LINE(20)
		this->separator = separator;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(FlatCellBuilder_obj,setSeparator,(void))

bool FlatCellBuilder_obj::needSeparator( ){
	HX_STACK_PUSH("FlatCellBuilder::needSeparator","coopy/FlatCellBuilder.hx",16);
	HX_STACK_THIS(this);
	HX_STACK_LINE(16)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC0(FlatCellBuilder_obj,needSeparator,return )

::String FlatCellBuilder_obj::quoteForDiff( ::coopy::View v,Dynamic d){
	HX_STACK_PUSH("FlatCellBuilder::quoteForDiff","coopy/FlatCellBuilder.hx",53);
	HX_STACK_ARG(v,"v");
	HX_STACK_ARG(d,"d");
	HX_STACK_LINE(54)
	::String nil = HX_CSTRING("NULL");		HX_STACK_VAR(nil,"nil");
	HX_STACK_LINE(55)
	if ((v->equals(d,null()))){
		HX_STACK_LINE(55)
		return nil;
	}
	HX_STACK_LINE(58)
	::String str = v->toString(d);		HX_STACK_VAR(str,"str");
	HX_STACK_LINE(59)
	int score = (int)0;		HX_STACK_VAR(score,"score");
	HX_STACK_LINE(60)
	{
		HX_STACK_LINE(60)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = str.length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(60)
		while(((_g1 < _g))){
			HX_STACK_LINE(60)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(61)
			if (((str.charCodeAt(score) != (int)95))){
				HX_STACK_LINE(61)
				break;
			}
			HX_STACK_LINE(62)
			(score)++;
		}
	}
	HX_STACK_LINE(64)
	if (((str.substr(score,null()) == nil))){
		HX_STACK_LINE(64)
		str = (HX_CSTRING("_") + str);
	}
	HX_STACK_LINE(67)
	return str;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(FlatCellBuilder_obj,quoteForDiff,return )


FlatCellBuilder_obj::FlatCellBuilder_obj()
{
}

void FlatCellBuilder_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(FlatCellBuilder);
	HX_MARK_MEMBER_NAME(conflict_separator,"conflict_separator");
	HX_MARK_MEMBER_NAME(separator,"separator");
	HX_MARK_MEMBER_NAME(view,"view");
	HX_MARK_END_CLASS();
}

void FlatCellBuilder_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(conflict_separator,"conflict_separator");
	HX_VISIT_MEMBER_NAME(separator,"separator");
	HX_VISIT_MEMBER_NAME(view,"view");
}

Dynamic FlatCellBuilder_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"view") ) { return view; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"links") ) { return links_dyn(); }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"marker") ) { return marker_dyn(); }
		if (HX_FIELD_EQ(inName,"update") ) { return update_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"setView") ) { return setView_dyn(); }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"conflict") ) { return conflict_dyn(); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"separator") ) { return separator; }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"quoteForDiff") ) { return quoteForDiff_dyn(); }
		if (HX_FIELD_EQ(inName,"setSeparator") ) { return setSeparator_dyn(); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"needSeparator") ) { return needSeparator_dyn(); }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"conflict_separator") ) { return conflict_separator; }
		break;
	case 20:
		if (HX_FIELD_EQ(inName,"setConflictSeparator") ) { return setConflictSeparator_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic FlatCellBuilder_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"view") ) { view=inValue.Cast< ::coopy::View >(); return inValue; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"separator") ) { separator=inValue.Cast< ::String >(); return inValue; }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"conflict_separator") ) { conflict_separator=inValue.Cast< ::String >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void FlatCellBuilder_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("conflict_separator"));
	outFields->push(HX_CSTRING("separator"));
	outFields->push(HX_CSTRING("view"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	HX_CSTRING("quoteForDiff"),
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("links"),
	HX_CSTRING("marker"),
	HX_CSTRING("conflict"),
	HX_CSTRING("update"),
	HX_CSTRING("setView"),
	HX_CSTRING("setConflictSeparator"),
	HX_CSTRING("setSeparator"),
	HX_CSTRING("needSeparator"),
	HX_CSTRING("conflict_separator"),
	HX_CSTRING("separator"),
	HX_CSTRING("view"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(FlatCellBuilder_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(FlatCellBuilder_obj::__mClass,"__mClass");
};

Class FlatCellBuilder_obj::__mClass;

void FlatCellBuilder_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.FlatCellBuilder"), hx::TCanCast< FlatCellBuilder_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void FlatCellBuilder_obj::__boot()
{
}

} // end namespace coopy

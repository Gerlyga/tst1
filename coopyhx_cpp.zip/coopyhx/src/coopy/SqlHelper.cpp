#include <hxcpp.h>

#ifndef INCLUDED_coopy_SqlDatabase
#include <coopy/SqlDatabase.h>
#endif
#ifndef INCLUDED_coopy_SqlHelper
#include <coopy/SqlHelper.h>
#endif
#ifndef INCLUDED_coopy_SqlTableName
#include <coopy/SqlTableName.h>
#endif
namespace coopy{

HX_DEFINE_DYNAMIC_FUNC2(SqlHelper_obj,getRowIDs,return )

HX_DEFINE_DYNAMIC_FUNC2(SqlHelper_obj,countRows,return )

HX_DEFINE_DYNAMIC_FUNC1(SqlHelper_obj,getTableNames,return )


static ::String sMemberFields[] = {
	HX_CSTRING("getRowIDs"),
	HX_CSTRING("countRows"),
	HX_CSTRING("getTableNames"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(SqlHelper_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(SqlHelper_obj::__mClass,"__mClass");
};

Class SqlHelper_obj::__mClass;

void SqlHelper_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.SqlHelper"), hx::TCanCast< SqlHelper_obj> ,0,sMemberFields,
	0, 0,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void SqlHelper_obj::__boot()
{
}

} // end namespace coopy

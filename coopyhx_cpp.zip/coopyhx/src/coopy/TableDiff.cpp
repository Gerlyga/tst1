#include <hxcpp.h>

#ifndef INCLUDED_IMap
#include <IMap.h>
#endif
#ifndef INCLUDED_coopy_Alignment
#include <coopy/Alignment.h>
#endif
#ifndef INCLUDED_coopy_CellBuilder
#include <coopy/CellBuilder.h>
#endif
#ifndef INCLUDED_coopy_CompareFlags
#include <coopy/CompareFlags.h>
#endif
#ifndef INCLUDED_coopy_FlatCellBuilder
#include <coopy/FlatCellBuilder.h>
#endif
#ifndef INCLUDED_coopy_Mover
#include <coopy/Mover.h>
#endif
#ifndef INCLUDED_coopy_NestedCellBuilder
#include <coopy/NestedCellBuilder.h>
#endif
#ifndef INCLUDED_coopy_Ordering
#include <coopy/Ordering.h>
#endif
#ifndef INCLUDED_coopy_Table
#include <coopy/Table.h>
#endif
#ifndef INCLUDED_coopy_TableDiff
#include <coopy/TableDiff.h>
#endif
#ifndef INCLUDED_coopy_Unit
#include <coopy/Unit.h>
#endif
#ifndef INCLUDED_coopy_View
#include <coopy/View.h>
#endif
#ifndef INCLUDED_haxe_ds_IntMap
#include <haxe/ds/IntMap.h>
#endif
#ifndef INCLUDED_haxe_ds_StringMap
#include <haxe/ds/StringMap.h>
#endif
namespace coopy{

Void TableDiff_obj::__construct(::coopy::Alignment align,::coopy::CompareFlags flags)
{
HX_STACK_PUSH("TableDiff::new","coopy/TableDiff.hx",26);
{
	HX_STACK_LINE(27)
	this->align = align;
	HX_STACK_LINE(28)
	this->flags = flags;
	HX_STACK_LINE(29)
	this->builder = null();
}
;
	return null();
}

TableDiff_obj::~TableDiff_obj() { }

Dynamic TableDiff_obj::__CreateEmpty() { return  new TableDiff_obj; }
hx::ObjectPtr< TableDiff_obj > TableDiff_obj::__new(::coopy::Alignment align,::coopy::CompareFlags flags)
{  hx::ObjectPtr< TableDiff_obj > result = new TableDiff_obj();
	result->__construct(align,flags);
	return result;}

Dynamic TableDiff_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< TableDiff_obj > result = new TableDiff_obj();
	result->__construct(inArgs[0],inArgs[1]);
	return result;}

bool TableDiff_obj::hilite( ::coopy::Table output){
	HX_STACK_PUSH("TableDiff::hilite","coopy/TableDiff.hx",203);
	HX_STACK_THIS(this);
	HX_STACK_ARG(output,"output");
	HX_STACK_LINE(204)
	if ((!(output->isResizable()))){
		HX_STACK_LINE(204)
		return false;
	}
	HX_STACK_LINE(205)
	if (((this->builder == null()))){
		HX_STACK_LINE(205)
		if ((this->flags->allow_nested_cells)){
			HX_STACK_LINE(206)
			this->builder = ::coopy::NestedCellBuilder_obj::__new();
		}
		else{
			HX_STACK_LINE(208)
			this->builder = ::coopy::FlatCellBuilder_obj::__new();
		}
	}
	HX_STACK_LINE(212)
	output->resize((int)0,(int)0);
	HX_STACK_LINE(213)
	output->clear();
	HX_STACK_LINE(215)
	::haxe::ds::IntMap row_map = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(row_map,"row_map");
	HX_STACK_LINE(216)
	::haxe::ds::IntMap col_map = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(col_map,"col_map");
	HX_STACK_LINE(218)
	::coopy::Ordering order = this->align->toOrder();		HX_STACK_VAR(order,"order");
	HX_STACK_LINE(219)
	Array< ::Dynamic > units = order->getList();		HX_STACK_VAR(units,"units");
	HX_STACK_LINE(220)
	bool has_parent = (this->align->reference != null());		HX_STACK_VAR(has_parent,"has_parent");
	HX_STACK_LINE(221)
	::coopy::Table a;		HX_STACK_VAR(a,"a");
	HX_STACK_LINE(222)
	::coopy::Table b;		HX_STACK_VAR(b,"b");
	HX_STACK_LINE(223)
	::coopy::Table p;		HX_STACK_VAR(p,"p");
	HX_STACK_LINE(224)
	int rp_header = (int)0;		HX_STACK_VAR(rp_header,"rp_header");
	HX_STACK_LINE(225)
	int ra_header = (int)0;		HX_STACK_VAR(ra_header,"ra_header");
	HX_STACK_LINE(226)
	int rb_header = (int)0;		HX_STACK_VAR(rb_header,"rb_header");
	HX_STACK_LINE(227)
	::haxe::ds::IntMap is_index_p = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(is_index_p,"is_index_p");
	HX_STACK_LINE(228)
	::haxe::ds::IntMap is_index_a = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(is_index_a,"is_index_a");
	HX_STACK_LINE(229)
	::haxe::ds::IntMap is_index_b = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(is_index_b,"is_index_b");
	HX_STACK_LINE(230)
	if ((has_parent)){
		HX_STACK_LINE(231)
		p = this->align->getSource();
		HX_STACK_LINE(232)
		a = this->align->reference->getTarget();
		HX_STACK_LINE(233)
		b = this->align->getTarget();
		HX_STACK_LINE(234)
		rp_header = this->align->reference->meta->getSourceHeader();
		HX_STACK_LINE(235)
		ra_header = this->align->reference->meta->getTargetHeader();
		HX_STACK_LINE(236)
		rb_header = this->align->meta->getTargetHeader();
		HX_STACK_LINE(237)
		if (((this->align->getIndexColumns() != null()))){
			HX_STACK_LINE(238)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			Array< ::Dynamic > _g1 = this->align->getIndexColumns();		HX_STACK_VAR(_g1,"_g1");
			HX_STACK_LINE(238)
			while(((_g < _g1->length))){
				HX_STACK_LINE(238)
				::coopy::Unit p2b = _g1->__get(_g).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(p2b,"p2b");
				HX_STACK_LINE(238)
				++(_g);
				HX_STACK_LINE(239)
				if (((p2b->l >= (int)0))){
					HX_STACK_LINE(239)
					is_index_p->set(p2b->l,true);
				}
				HX_STACK_LINE(240)
				if (((p2b->r >= (int)0))){
					HX_STACK_LINE(240)
					is_index_b->set(p2b->r,true);
				}
			}
		}
		HX_STACK_LINE(243)
		if (((this->align->reference->getIndexColumns() != null()))){
			HX_STACK_LINE(244)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			Array< ::Dynamic > _g1 = this->align->reference->getIndexColumns();		HX_STACK_VAR(_g1,"_g1");
			HX_STACK_LINE(244)
			while(((_g < _g1->length))){
				HX_STACK_LINE(244)
				::coopy::Unit p2a = _g1->__get(_g).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(p2a,"p2a");
				HX_STACK_LINE(244)
				++(_g);
				HX_STACK_LINE(245)
				if (((p2a->l >= (int)0))){
					HX_STACK_LINE(245)
					is_index_p->set(p2a->l,true);
				}
				HX_STACK_LINE(246)
				if (((p2a->r >= (int)0))){
					HX_STACK_LINE(246)
					is_index_a->set(p2a->r,true);
				}
			}
		}
	}
	else{
		HX_STACK_LINE(250)
		a = this->align->getSource();
		HX_STACK_LINE(251)
		b = this->align->getTarget();
		HX_STACK_LINE(252)
		p = a;
		HX_STACK_LINE(253)
		ra_header = this->align->meta->getSourceHeader();
		HX_STACK_LINE(254)
		rp_header = ra_header;
		HX_STACK_LINE(255)
		rb_header = this->align->meta->getTargetHeader();
		HX_STACK_LINE(256)
		if (((this->align->getIndexColumns() != null()))){
			HX_STACK_LINE(257)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			Array< ::Dynamic > _g1 = this->align->getIndexColumns();		HX_STACK_VAR(_g1,"_g1");
			HX_STACK_LINE(257)
			while(((_g < _g1->length))){
				HX_STACK_LINE(257)
				::coopy::Unit a2b = _g1->__get(_g).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(a2b,"a2b");
				HX_STACK_LINE(257)
				++(_g);
				HX_STACK_LINE(258)
				if (((a2b->l >= (int)0))){
					HX_STACK_LINE(258)
					is_index_a->set(a2b->l,true);
				}
				HX_STACK_LINE(259)
				if (((a2b->r >= (int)0))){
					HX_STACK_LINE(259)
					is_index_b->set(a2b->r,true);
				}
			}
		}
	}
	HX_STACK_LINE(264)
	::coopy::Ordering column_order = this->align->meta->toOrder();		HX_STACK_VAR(column_order,"column_order");
	HX_STACK_LINE(265)
	Array< ::Dynamic > column_units = column_order->getList();		HX_STACK_VAR(column_units,"column_units");
	HX_STACK_LINE(267)
	::haxe::ds::IntMap p_ignore = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(p_ignore,"p_ignore");
	HX_STACK_LINE(268)
	::haxe::ds::IntMap a_ignore = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(a_ignore,"a_ignore");
	HX_STACK_LINE(269)
	::haxe::ds::IntMap b_ignore = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(b_ignore,"b_ignore");
	HX_STACK_LINE(270)
	::haxe::ds::StringMap ignore = this->flags->getIgnoredColumns();		HX_STACK_VAR(ignore,"ignore");
	HX_STACK_LINE(271)
	if (((ignore != null()))){
		HX_STACK_LINE(272)
		this->setIgnore(ignore,p_ignore,p,rp_header);
		HX_STACK_LINE(273)
		this->setIgnore(ignore,a_ignore,a,ra_header);
		HX_STACK_LINE(274)
		this->setIgnore(ignore,b_ignore,b,rb_header);
		HX_STACK_LINE(276)
		Array< ::Dynamic > ncolumn_units = Array_obj< ::Dynamic >::__new();		HX_STACK_VAR(ncolumn_units,"ncolumn_units");
		HX_STACK_LINE(277)
		{
			HX_STACK_LINE(277)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = column_units->length;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(277)
			while(((_g1 < _g))){
				HX_STACK_LINE(277)
				int j = (_g1)++;		HX_STACK_VAR(j,"j");
				HX_STACK_LINE(278)
				::coopy::Unit cunit = column_units->__get(j).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(cunit,"cunit");
				HX_STACK_LINE(279)
				if (((bool((bool(p_ignore->exists(cunit->p)) || bool(a_ignore->exists(cunit->l)))) || bool(b_ignore->exists(cunit->r))))){
					HX_STACK_LINE(281)
					continue;
				}
				HX_STACK_LINE(282)
				ncolumn_units->push(cunit);
			}
		}
		HX_STACK_LINE(284)
		column_units = ncolumn_units;
	}
	HX_STACK_LINE(287)
	bool show_rc_numbers = false;		HX_STACK_VAR(show_rc_numbers,"show_rc_numbers");
	HX_STACK_LINE(288)
	::haxe::ds::IntMap row_moves = null();		HX_STACK_VAR(row_moves,"row_moves");
	HX_STACK_LINE(289)
	::haxe::ds::IntMap col_moves = null();		HX_STACK_VAR(col_moves,"col_moves");
	HX_STACK_LINE(290)
	if ((this->flags->ordered)){
		HX_STACK_LINE(291)
		row_moves = ::haxe::ds::IntMap_obj::__new();
		HX_STACK_LINE(292)
		Array< int > moves = ::coopy::Mover_obj::moveUnits(units);		HX_STACK_VAR(moves,"moves");
		HX_STACK_LINE(293)
		{
			HX_STACK_LINE(293)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = moves->length;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(293)
			while(((_g1 < _g))){
				HX_STACK_LINE(293)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(294)
				{
					HX_STACK_LINE(294)
					row_moves->set(moves->__get(i),i);
					HX_STACK_LINE(294)
					i;
				}
			}
		}
		HX_STACK_LINE(296)
		col_moves = ::haxe::ds::IntMap_obj::__new();
		HX_STACK_LINE(297)
		moves = ::coopy::Mover_obj::moveUnits(column_units);
		HX_STACK_LINE(298)
		{
			HX_STACK_LINE(298)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = moves->length;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(298)
			while(((_g1 < _g))){
				HX_STACK_LINE(298)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(299)
				{
					HX_STACK_LINE(299)
					col_moves->set(moves->__get(i),i);
					HX_STACK_LINE(299)
					i;
				}
			}
		}
	}
	HX_STACK_LINE(303)
	Array< int > active = Array_obj< int >::__new();		HX_STACK_VAR(active,"active");
	HX_STACK_LINE(304)
	Array< int > active_column = null();		HX_STACK_VAR(active_column,"active_column");
	HX_STACK_LINE(305)
	if ((!(this->flags->show_unchanged))){
		HX_STACK_LINE(306)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = units->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(306)
		while(((_g1 < _g))){
			HX_STACK_LINE(306)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(308)
			active[((units->length - (int)1) - i)] = (int)0;
		}
	}
	HX_STACK_LINE(312)
	bool allow_insert = this->flags->allowInsert();		HX_STACK_VAR(allow_insert,"allow_insert");
	HX_STACK_LINE(313)
	bool allow_delete = this->flags->allowDelete();		HX_STACK_VAR(allow_delete,"allow_delete");
	HX_STACK_LINE(314)
	bool allow_update = this->flags->allowUpdate();		HX_STACK_VAR(allow_update,"allow_update");
	HX_STACK_LINE(316)
	if ((!(this->flags->show_unchanged_columns))){
		HX_STACK_LINE(317)
		active_column = Array_obj< int >::__new();
		HX_STACK_LINE(318)
		{
			HX_STACK_LINE(318)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = column_units->length;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(318)
			while(((_g1 < _g))){
				HX_STACK_LINE(318)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(319)
				int v = (int)0;		HX_STACK_VAR(v,"v");
				HX_STACK_LINE(320)
				::coopy::Unit unit = column_units->__get(i).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(unit,"unit");
				HX_STACK_LINE(321)
				if (((bool((unit->l >= (int)0)) && bool(is_index_a->get(unit->l))))){
					HX_STACK_LINE(321)
					v = (int)1;
				}
				HX_STACK_LINE(322)
				if (((bool((unit->r >= (int)0)) && bool(is_index_b->get(unit->r))))){
					HX_STACK_LINE(322)
					v = (int)1;
				}
				HX_STACK_LINE(323)
				if (((bool((unit->p >= (int)0)) && bool(is_index_p->get(unit->p))))){
					HX_STACK_LINE(323)
					v = (int)1;
				}
				HX_STACK_LINE(324)
				active_column[i] = v;
			}
		}
	}
	HX_STACK_LINE(328)
	::coopy::View v = a->getCellView();		HX_STACK_VAR(v,"v");
	HX_STACK_LINE(329)
	this->builder->setView(v);
	HX_STACK_LINE(331)
	int outer_reps_needed = (  (((bool(this->flags->show_unchanged) && bool(this->flags->show_unchanged_columns)))) ? int((int)1) : int((int)2) );		HX_STACK_VAR(outer_reps_needed,"outer_reps_needed");
	HX_STACK_LINE(334)
	::String sep = HX_CSTRING("");		HX_STACK_VAR(sep,"sep");
	HX_STACK_LINE(335)
	::String conflict_sep = HX_CSTRING("");		HX_STACK_VAR(conflict_sep,"conflict_sep");
	HX_STACK_LINE(337)
	Array< ::String > schema = Array_obj< ::String >::__new();		HX_STACK_VAR(schema,"schema");
	HX_STACK_LINE(338)
	bool have_schema = false;		HX_STACK_VAR(have_schema,"have_schema");
	HX_STACK_LINE(339)
	{
		HX_STACK_LINE(339)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = column_units->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(339)
		while(((_g1 < _g))){
			HX_STACK_LINE(339)
			int j = (_g1)++;		HX_STACK_VAR(j,"j");
			HX_STACK_LINE(340)
			::coopy::Unit cunit = column_units->__get(j).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(cunit,"cunit");
			HX_STACK_LINE(341)
			bool reordered = false;		HX_STACK_VAR(reordered,"reordered");
			HX_STACK_LINE(343)
			if ((this->flags->ordered)){
				HX_STACK_LINE(344)
				if ((col_moves->exists(j))){
					HX_STACK_LINE(344)
					reordered = true;
				}
				HX_STACK_LINE(347)
				if ((reordered)){
					HX_STACK_LINE(347)
					show_rc_numbers = true;
				}
			}
			HX_STACK_LINE(350)
			::String act = HX_CSTRING("");		HX_STACK_VAR(act,"act");
			HX_STACK_LINE(351)
			if (((bool((cunit->r >= (int)0)) && bool((cunit->lp() == (int)-1))))){
				HX_STACK_LINE(352)
				have_schema = true;
				HX_STACK_LINE(353)
				act = HX_CSTRING("+++");
				HX_STACK_LINE(354)
				if (((active_column != null()))){
					HX_STACK_LINE(354)
					if ((allow_update)){
						HX_STACK_LINE(355)
						active_column[j] = (int)1;
					}
				}
			}
			HX_STACK_LINE(358)
			if (((bool((cunit->r < (int)0)) && bool((cunit->lp() >= (int)0))))){
				HX_STACK_LINE(359)
				have_schema = true;
				HX_STACK_LINE(360)
				act = HX_CSTRING("---");
				HX_STACK_LINE(361)
				if (((active_column != null()))){
					HX_STACK_LINE(361)
					if ((allow_update)){
						HX_STACK_LINE(362)
						active_column[j] = (int)1;
					}
				}
			}
			HX_STACK_LINE(365)
			if (((bool((cunit->r >= (int)0)) && bool((cunit->lp() >= (int)0))))){
				HX_STACK_LINE(365)
				if (((bool((p->get_height() >= rp_header)) && bool((b->get_height() >= rb_header))))){
					HX_STACK_LINE(367)
					Dynamic pp = p->getCell(cunit->lp(),rp_header);		HX_STACK_VAR(pp,"pp");
					HX_STACK_LINE(368)
					Dynamic bb = b->getCell(cunit->r,rb_header);		HX_STACK_VAR(bb,"bb");
					HX_STACK_LINE(369)
					if ((!(v->equals(pp,bb)))){
						HX_STACK_LINE(370)
						have_schema = true;
						HX_STACK_LINE(371)
						act = HX_CSTRING("(");
						HX_STACK_LINE(372)
						hx::AddEq(act,v->toString(pp));
						HX_STACK_LINE(373)
						hx::AddEq(act,HX_CSTRING(")"));
						HX_STACK_LINE(374)
						if (((active_column != null()))){
							HX_STACK_LINE(374)
							active_column[j] = (int)1;
						}
					}
				}
			}
			HX_STACK_LINE(378)
			if ((reordered)){
				HX_STACK_LINE(379)
				act = (HX_CSTRING(":") + act);
				HX_STACK_LINE(380)
				have_schema = true;
				HX_STACK_LINE(381)
				if (((active_column != null()))){
					HX_STACK_LINE(381)
					active_column = null();
				}
			}
			HX_STACK_LINE(384)
			schema->push(act);
		}
	}
	HX_STACK_LINE(386)
	if ((have_schema)){
		HX_STACK_LINE(387)
		int at = output->get_height();		HX_STACK_VAR(at,"at");
		HX_STACK_LINE(388)
		output->resize((column_units->length + (int)1),(at + (int)1));
		HX_STACK_LINE(389)
		output->setCell((int)0,at,this->builder->marker(HX_CSTRING("!")));
		HX_STACK_LINE(390)
		{
			HX_STACK_LINE(390)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = column_units->length;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(390)
			while(((_g1 < _g))){
				HX_STACK_LINE(390)
				int j = (_g1)++;		HX_STACK_VAR(j,"j");
				HX_STACK_LINE(391)
				output->setCell((j + (int)1),at,v->toDatum(schema->__get(j)));
			}
		}
	}
	HX_STACK_LINE(395)
	bool top_line_done = false;		HX_STACK_VAR(top_line_done,"top_line_done");
	HX_STACK_LINE(396)
	if ((this->flags->always_show_header)){
		HX_STACK_LINE(397)
		int at = output->get_height();		HX_STACK_VAR(at,"at");
		HX_STACK_LINE(398)
		output->resize((column_units->length + (int)1),(at + (int)1));
		HX_STACK_LINE(399)
		output->setCell((int)0,at,this->builder->marker(HX_CSTRING("@@")));
		HX_STACK_LINE(400)
		{
			HX_STACK_LINE(400)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = column_units->length;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(400)
			while(((_g1 < _g))){
				HX_STACK_LINE(400)
				int j = (_g1)++;		HX_STACK_VAR(j,"j");
				HX_STACK_LINE(401)
				::coopy::Unit cunit = column_units->__get(j).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(cunit,"cunit");
				HX_STACK_LINE(402)
				if (((cunit->r >= (int)0))){
					HX_STACK_LINE(402)
					if (((b->get_height() != (int)0))){
						HX_STACK_LINE(403)
						output->setCell((j + (int)1),at,b->getCell(cunit->r,rb_header));
					}
				}
				else{
					HX_STACK_LINE(407)
					if (((cunit->lp() >= (int)0))){
						HX_STACK_LINE(407)
						if (((p->get_height() != (int)0))){
							HX_STACK_LINE(408)
							output->setCell((j + (int)1),at,p->getCell(cunit->lp(),rp_header));
						}
					}
				}
				HX_STACK_LINE(413)
				col_map->set((j + (int)1),cunit);
			}
		}
		HX_STACK_LINE(415)
		top_line_done = true;
	}
	HX_STACK_LINE(425)
	int output_height = output->get_height();		HX_STACK_VAR(output_height,"output_height");
	HX_STACK_LINE(426)
	int output_height_init = output->get_height();		HX_STACK_VAR(output_height_init,"output_height_init");
	HX_STACK_LINE(428)
	{
		HX_STACK_LINE(428)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(428)
		while(((_g < outer_reps_needed))){
			HX_STACK_LINE(428)
			int out = (_g)++;		HX_STACK_VAR(out,"out");
			HX_STACK_LINE(429)
			if (((out == (int)1))){
				HX_STACK_LINE(430)
				this->spreadContext(units,this->flags->unchanged_context,active);
				HX_STACK_LINE(431)
				this->spreadContext(column_units,this->flags->unchanged_column_context,active_column);
				HX_STACK_LINE(433)
				if (((active_column != null()))){
					HX_STACK_LINE(434)
					int _g2 = (int)0;		HX_STACK_VAR(_g2,"_g2");
					int _g1 = column_units->length;		HX_STACK_VAR(_g1,"_g1");
					HX_STACK_LINE(434)
					while(((_g2 < _g1))){
						HX_STACK_LINE(434)
						int i = (_g2)++;		HX_STACK_VAR(i,"i");
						HX_STACK_LINE(435)
						if (((active_column->__get(i) == (int)3))){
							HX_STACK_LINE(435)
							active_column[i] = (int)0;
						}
					}
				}
				HX_STACK_LINE(440)
				int rows = (this->countActive(active) + output_height_init);		HX_STACK_VAR(rows,"rows");
				HX_STACK_LINE(441)
				if ((top_line_done)){
					HX_STACK_LINE(441)
					(rows)--;
				}
				HX_STACK_LINE(442)
				output_height = output_height_init;
				HX_STACK_LINE(443)
				if (((rows > output->get_height()))){
					HX_STACK_LINE(443)
					output->resize((column_units->length + (int)1),rows);
				}
			}
			HX_STACK_LINE(448)
			bool showed_dummy = false;		HX_STACK_VAR(showed_dummy,"showed_dummy");
			HX_STACK_LINE(449)
			int l = (int)-1;		HX_STACK_VAR(l,"l");
			HX_STACK_LINE(450)
			int r = (int)-1;		HX_STACK_VAR(r,"r");
			HX_STACK_LINE(451)
			{
				HX_STACK_LINE(451)
				int _g2 = (int)0;		HX_STACK_VAR(_g2,"_g2");
				int _g1 = units->length;		HX_STACK_VAR(_g1,"_g1");
				HX_STACK_LINE(451)
				while(((_g2 < _g1))){
					HX_STACK_LINE(451)
					int i = (_g2)++;		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(452)
					::coopy::Unit unit = units->__get(i).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(unit,"unit");
					HX_STACK_LINE(453)
					bool reordered = false;		HX_STACK_VAR(reordered,"reordered");
					HX_STACK_LINE(455)
					if ((this->flags->ordered)){
						HX_STACK_LINE(456)
						if ((row_moves->exists(i))){
							HX_STACK_LINE(456)
							reordered = true;
						}
						HX_STACK_LINE(459)
						if ((reordered)){
							HX_STACK_LINE(459)
							show_rc_numbers = true;
						}
					}
					HX_STACK_LINE(462)
					if (((bool((unit->r < (int)0)) && bool((unit->l < (int)0))))){
						HX_STACK_LINE(462)
						continue;
					}
					HX_STACK_LINE(464)
					if (((bool((bool((unit->r == (int)0)) && bool((unit->lp() == (int)0)))) && bool(top_line_done)))){
						HX_STACK_LINE(464)
						continue;
					}
					HX_STACK_LINE(466)
					::String act = HX_CSTRING("");		HX_STACK_VAR(act,"act");
					HX_STACK_LINE(468)
					if ((reordered)){
						HX_STACK_LINE(468)
						act = HX_CSTRING(":");
					}
					HX_STACK_LINE(470)
					bool publish = this->flags->show_unchanged;		HX_STACK_VAR(publish,"publish");
					HX_STACK_LINE(471)
					bool dummy = false;		HX_STACK_VAR(dummy,"dummy");
					HX_STACK_LINE(472)
					if (((out == (int)1))){
						HX_STACK_LINE(473)
						publish = (active->__get(i) > (int)0);
						HX_STACK_LINE(474)
						dummy = (active->__get(i) == (int)3);
						HX_STACK_LINE(475)
						if (((bool(dummy) && bool(showed_dummy)))){
							HX_STACK_LINE(475)
							continue;
						}
						HX_STACK_LINE(476)
						if ((!(publish))){
							HX_STACK_LINE(476)
							continue;
						}
					}
					HX_STACK_LINE(479)
					if ((!(dummy))){
						HX_STACK_LINE(479)
						showed_dummy = false;
					}
					HX_STACK_LINE(481)
					int at = output_height;		HX_STACK_VAR(at,"at");
					HX_STACK_LINE(482)
					if ((publish)){
						HX_STACK_LINE(483)
						(output_height)++;
						HX_STACK_LINE(484)
						if (((output->get_height() < output_height))){
							HX_STACK_LINE(484)
							output->resize((column_units->length + (int)1),output_height);
						}
					}
					HX_STACK_LINE(488)
					if ((dummy)){
						HX_STACK_LINE(489)
						{
							HX_STACK_LINE(489)
							int _g4 = (int)0;		HX_STACK_VAR(_g4,"_g4");
							int _g3 = (column_units->length + (int)1);		HX_STACK_VAR(_g3,"_g3");
							HX_STACK_LINE(489)
							while(((_g4 < _g3))){
								HX_STACK_LINE(489)
								int j = (_g4)++;		HX_STACK_VAR(j,"j");
								HX_STACK_LINE(490)
								output->setCell(j,at,v->toDatum(HX_CSTRING("...")));
							}
						}
						HX_STACK_LINE(492)
						showed_dummy = true;
						HX_STACK_LINE(493)
						continue;
					}
					HX_STACK_LINE(496)
					bool have_addition = false;		HX_STACK_VAR(have_addition,"have_addition");
					HX_STACK_LINE(497)
					bool skip = false;		HX_STACK_VAR(skip,"skip");
					HX_STACK_LINE(499)
					if (((bool((bool((unit->p < (int)0)) && bool((unit->l < (int)0)))) && bool((unit->r >= (int)0))))){
						HX_STACK_LINE(500)
						if ((!(allow_insert))){
							HX_STACK_LINE(500)
							skip = true;
						}
						HX_STACK_LINE(501)
						act = HX_CSTRING("+++");
					}
					HX_STACK_LINE(503)
					if (((bool((bool(((bool((unit->p >= (int)0)) || bool(!(has_parent))))) && bool((unit->l >= (int)0)))) && bool((unit->r < (int)0))))){
						HX_STACK_LINE(504)
						if ((!(allow_delete))){
							HX_STACK_LINE(504)
							skip = true;
						}
						HX_STACK_LINE(505)
						act = HX_CSTRING("---");
					}
					HX_STACK_LINE(508)
					if ((skip)){
						HX_STACK_LINE(509)
						if ((!(publish))){
							HX_STACK_LINE(509)
							if (((active != null()))){
								HX_STACK_LINE(510)
								active[i] = (int)-3;
							}
						}
						HX_STACK_LINE(514)
						continue;
					}
					HX_STACK_LINE(517)
					{
						HX_STACK_LINE(517)
						int _g4 = (int)0;		HX_STACK_VAR(_g4,"_g4");
						int _g3 = column_units->length;		HX_STACK_VAR(_g3,"_g3");
						HX_STACK_LINE(517)
						while(((_g4 < _g3))){
							HX_STACK_LINE(517)
							int j = (_g4)++;		HX_STACK_VAR(j,"j");
							HX_STACK_LINE(518)
							::coopy::Unit cunit = column_units->__get(j).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(cunit,"cunit");
							HX_STACK_LINE(519)
							Dynamic pp = null();		HX_STACK_VAR(pp,"pp");
							HX_STACK_LINE(520)
							Dynamic ll = null();		HX_STACK_VAR(ll,"ll");
							HX_STACK_LINE(521)
							Dynamic rr = null();		HX_STACK_VAR(rr,"rr");
							HX_STACK_LINE(522)
							Dynamic dd = null();		HX_STACK_VAR(dd,"dd");
							HX_STACK_LINE(523)
							Dynamic dd_to = null();		HX_STACK_VAR(dd_to,"dd_to");
							HX_STACK_LINE(524)
							bool have_dd_to = false;		HX_STACK_VAR(have_dd_to,"have_dd_to");
							HX_STACK_LINE(525)
							Dynamic dd_to_alt = null();		HX_STACK_VAR(dd_to_alt,"dd_to_alt");
							HX_STACK_LINE(526)
							bool have_dd_to_alt = false;		HX_STACK_VAR(have_dd_to_alt,"have_dd_to_alt");
							HX_STACK_LINE(527)
							bool have_pp = false;		HX_STACK_VAR(have_pp,"have_pp");
							HX_STACK_LINE(528)
							bool have_ll = false;		HX_STACK_VAR(have_ll,"have_ll");
							HX_STACK_LINE(529)
							bool have_rr = false;		HX_STACK_VAR(have_rr,"have_rr");
							HX_STACK_LINE(530)
							if (((bool((cunit->p >= (int)0)) && bool((unit->p >= (int)0))))){
								HX_STACK_LINE(531)
								pp = p->getCell(cunit->p,unit->p);
								HX_STACK_LINE(532)
								have_pp = true;
							}
							HX_STACK_LINE(534)
							if (((bool((cunit->l >= (int)0)) && bool((unit->l >= (int)0))))){
								HX_STACK_LINE(535)
								ll = a->getCell(cunit->l,unit->l);
								HX_STACK_LINE(536)
								have_ll = true;
							}
							HX_STACK_LINE(538)
							if (((bool((cunit->r >= (int)0)) && bool((unit->r >= (int)0))))){
								HX_STACK_LINE(539)
								rr = b->getCell(cunit->r,unit->r);
								HX_STACK_LINE(540)
								have_rr = true;
								HX_STACK_LINE(541)
								if (((((  ((have_pp)) ? int(cunit->p) : int(cunit->l) )) < (int)0))){
									HX_STACK_LINE(541)
									if (((rr != null()))){
										HX_STACK_LINE(542)
										if (((v->toString(rr) != HX_CSTRING("")))){
											HX_STACK_LINE(543)
											if ((this->flags->allowUpdate())){
												HX_STACK_LINE(544)
												have_addition = true;
											}
										}
									}
								}
							}
							HX_STACK_LINE(553)
							if ((have_pp)){
								HX_STACK_LINE(553)
								if ((!(have_rr))){
									HX_STACK_LINE(554)
									dd = pp;
								}
								else{
									HX_STACK_LINE(556)
									if ((v->equals(pp,rr))){
										HX_STACK_LINE(558)
										dd = pp;
									}
									else{
										HX_STACK_LINE(562)
										dd = pp;
										HX_STACK_LINE(563)
										dd_to = rr;
										HX_STACK_LINE(564)
										have_dd_to = true;
										HX_STACK_LINE(566)
										if ((!(v->equals(pp,ll)))){
											HX_STACK_LINE(566)
											if ((!(v->equals(pp,rr)))){
												HX_STACK_LINE(568)
												dd_to_alt = ll;
												HX_STACK_LINE(569)
												have_dd_to_alt = true;
											}
										}
									}
								}
							}
							else{
								HX_STACK_LINE(574)
								if ((have_ll)){
									HX_STACK_LINE(574)
									if ((!(have_rr))){
										HX_STACK_LINE(575)
										dd = ll;
									}
									else{
										HX_STACK_LINE(577)
										if ((v->equals(ll,rr))){
											HX_STACK_LINE(578)
											dd = ll;
										}
										else{
											HX_STACK_LINE(582)
											dd = ll;
											HX_STACK_LINE(583)
											dd_to = rr;
											HX_STACK_LINE(584)
											have_dd_to = true;
										}
									}
								}
								else{
									HX_STACK_LINE(587)
									dd = rr;
								}
							}
							HX_STACK_LINE(591)
							Dynamic cell = dd;		HX_STACK_VAR(cell,"cell");
							HX_STACK_LINE(592)
							if (((bool(have_dd_to) && bool(allow_update)))){
								HX_STACK_LINE(593)
								if (((active_column != null()))){
									HX_STACK_LINE(593)
									active_column[j] = (int)1;
								}
								HX_STACK_LINE(597)
								if (((sep == HX_CSTRING("")))){
									HX_STACK_LINE(597)
									if ((this->builder->needSeparator())){
										HX_STACK_LINE(601)
										sep = this->getSeparator(a,b,HX_CSTRING("->"));
										HX_STACK_LINE(602)
										this->builder->setSeparator(sep);
									}
									else{
										HX_STACK_LINE(603)
										sep = HX_CSTRING("->");
									}
								}
								HX_STACK_LINE(607)
								bool is_conflict = false;		HX_STACK_VAR(is_conflict,"is_conflict");
								HX_STACK_LINE(608)
								if ((have_dd_to_alt)){
									HX_STACK_LINE(608)
									if ((!(v->equals(dd_to,dd_to_alt)))){
										HX_STACK_LINE(609)
										is_conflict = true;
									}
								}
								HX_STACK_LINE(613)
								if ((!(is_conflict))){
									HX_STACK_LINE(614)
									cell = this->builder->update(dd,dd_to);
									HX_STACK_LINE(615)
									if (((sep.length > act.length))){
										HX_STACK_LINE(615)
										act = sep;
									}
								}
								else{
									HX_STACK_LINE(619)
									if (((conflict_sep == HX_CSTRING("")))){
										HX_STACK_LINE(619)
										if ((this->builder->needSeparator())){
											HX_STACK_LINE(622)
											conflict_sep = (this->getSeparator(p,a,HX_CSTRING("!")) + sep);
											HX_STACK_LINE(623)
											this->builder->setConflictSeparator(conflict_sep);
										}
										else{
											HX_STACK_LINE(624)
											conflict_sep = HX_CSTRING("!->");
										}
									}
									HX_STACK_LINE(628)
									cell = this->builder->conflict(dd,dd_to_alt,dd_to);
									HX_STACK_LINE(629)
									act = conflict_sep;
								}
							}
							HX_STACK_LINE(632)
							if (((bool((act == HX_CSTRING(""))) && bool(have_addition)))){
								HX_STACK_LINE(632)
								act = HX_CSTRING("+");
							}
							HX_STACK_LINE(635)
							if (((act == HX_CSTRING("+++")))){
								HX_STACK_LINE(635)
								if ((have_rr)){
									HX_STACK_LINE(636)
									if (((active_column != null()))){
										HX_STACK_LINE(637)
										active_column[j] = (int)1;
									}
								}
							}
							HX_STACK_LINE(642)
							if ((publish)){
								HX_STACK_LINE(642)
								if (((bool((active_column == null())) || bool((active_column->__get(j) > (int)0))))){
									HX_STACK_LINE(643)
									output->setCell((j + (int)1),at,cell);
								}
							}
						}
					}
					HX_STACK_LINE(649)
					if ((publish)){
						HX_STACK_LINE(650)
						output->setCell((int)0,at,this->builder->marker(act));
						HX_STACK_LINE(651)
						row_map->set(at,unit);
					}
					HX_STACK_LINE(653)
					if (((act != HX_CSTRING("")))){
						HX_STACK_LINE(653)
						if ((!(publish))){
							HX_STACK_LINE(654)
							if (((active != null()))){
								HX_STACK_LINE(655)
								active[i] = (int)1;
							}
						}
					}
				}
			}
		}
	}
	HX_STACK_LINE(664)
	if ((!(show_rc_numbers))){
		HX_STACK_LINE(664)
		if ((this->flags->always_show_order)){
			HX_STACK_LINE(665)
			show_rc_numbers = true;
		}
		else{
			HX_STACK_LINE(667)
			if ((this->flags->ordered)){
				HX_STACK_LINE(668)
				show_rc_numbers = this->isReordered(row_map,output->get_height());
				HX_STACK_LINE(669)
				if ((!(show_rc_numbers))){
					HX_STACK_LINE(669)
					show_rc_numbers = this->isReordered(col_map,output->get_width());
				}
			}
		}
	}
	HX_STACK_LINE(675)
	int admin_w = (int)1;		HX_STACK_VAR(admin_w,"admin_w");
	HX_STACK_LINE(676)
	if (((bool(show_rc_numbers) && bool(!(this->flags->never_show_order))))){
		HX_STACK_LINE(677)
		(admin_w)++;
		HX_STACK_LINE(678)
		Array< int > target = Array_obj< int >::__new();		HX_STACK_VAR(target,"target");
		HX_STACK_LINE(679)
		{
			HX_STACK_LINE(679)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = output->get_width();		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(679)
			while(((_g1 < _g))){
				HX_STACK_LINE(679)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(680)
				target->push((i + (int)1));
			}
		}
		HX_STACK_LINE(682)
		output->insertOrDeleteColumns(target,(output->get_width() + (int)1));
		HX_STACK_LINE(684)
		{
			HX_STACK_LINE(684)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = output->get_height();		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(684)
			while(((_g1 < _g))){
				HX_STACK_LINE(684)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(685)
				::coopy::Unit unit = row_map->get(i);		HX_STACK_VAR(unit,"unit");
				HX_STACK_LINE(686)
				if (((unit == null()))){
					HX_STACK_LINE(687)
					output->setCell((int)0,i,HX_CSTRING(""));
					HX_STACK_LINE(688)
					continue;
				}
				HX_STACK_LINE(690)
				output->setCell((int)0,i,this->builder->links(unit));
			}
		}
		HX_STACK_LINE(692)
		target = Array_obj< int >::__new();
		HX_STACK_LINE(693)
		{
			HX_STACK_LINE(693)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = output->get_height();		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(693)
			while(((_g1 < _g))){
				HX_STACK_LINE(693)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(694)
				target->push((i + (int)1));
			}
		}
		HX_STACK_LINE(696)
		output->insertOrDeleteRows(target,(output->get_height() + (int)1));
		HX_STACK_LINE(697)
		{
			HX_STACK_LINE(697)
			int _g1 = (int)1;		HX_STACK_VAR(_g1,"_g1");
			int _g = output->get_width();		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(697)
			while(((_g1 < _g))){
				HX_STACK_LINE(697)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(698)
				::coopy::Unit unit = col_map->get((i - (int)1));		HX_STACK_VAR(unit,"unit");
				HX_STACK_LINE(699)
				if (((unit == null()))){
					HX_STACK_LINE(700)
					output->setCell(i,(int)0,HX_CSTRING(""));
					HX_STACK_LINE(701)
					continue;
				}
				HX_STACK_LINE(703)
				output->setCell(i,(int)0,this->builder->links(unit));
			}
		}
		HX_STACK_LINE(705)
		output->setCell((int)0,(int)0,this->builder->marker(HX_CSTRING("@:@")));
	}
	HX_STACK_LINE(708)
	if (((active_column != null()))){
		HX_STACK_LINE(709)
		bool all_active = true;		HX_STACK_VAR(all_active,"all_active");
		HX_STACK_LINE(710)
		{
			HX_STACK_LINE(710)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = active_column->length;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(710)
			while(((_g1 < _g))){
				HX_STACK_LINE(710)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(711)
				if (((active_column->__get(i) == (int)0))){
					HX_STACK_LINE(712)
					all_active = false;
					HX_STACK_LINE(713)
					break;
				}
			}
		}
		HX_STACK_LINE(716)
		if ((!(all_active))){
			HX_STACK_LINE(717)
			Array< int > fate = Array_obj< int >::__new();		HX_STACK_VAR(fate,"fate");
			HX_STACK_LINE(718)
			{
				HX_STACK_LINE(718)
				int _g = (int)0;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(718)
				while(((_g < admin_w))){
					HX_STACK_LINE(718)
					int i = (_g)++;		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(719)
					fate->push(i);
				}
			}
			HX_STACK_LINE(721)
			int at = admin_w;		HX_STACK_VAR(at,"at");
			HX_STACK_LINE(722)
			int ct = (int)0;		HX_STACK_VAR(ct,"ct");
			HX_STACK_LINE(723)
			Array< int > dots = Array_obj< int >::__new();		HX_STACK_VAR(dots,"dots");
			HX_STACK_LINE(724)
			{
				HX_STACK_LINE(724)
				int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
				int _g = active_column->length;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(724)
				while(((_g1 < _g))){
					HX_STACK_LINE(724)
					int i = (_g1)++;		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(725)
					bool off = (active_column->__get(i) == (int)0);		HX_STACK_VAR(off,"off");
					HX_STACK_LINE(726)
					ct = (  ((off)) ? int((ct + (int)1)) : int((int)0) );
					HX_STACK_LINE(727)
					if (((bool(off) && bool((ct > (int)1))))){
						HX_STACK_LINE(727)
						fate->push((int)-1);
					}
					else{
						HX_STACK_LINE(730)
						if ((off)){
							HX_STACK_LINE(730)
							dots->push(at);
						}
						HX_STACK_LINE(731)
						fate->push(at);
						HX_STACK_LINE(732)
						(at)++;
					}
				}
			}
			HX_STACK_LINE(735)
			output->insertOrDeleteColumns(fate,at);
			HX_STACK_LINE(736)
			{
				HX_STACK_LINE(736)
				int _g = (int)0;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(736)
				while(((_g < dots->length))){
					HX_STACK_LINE(736)
					int d = dots->__get(_g);		HX_STACK_VAR(d,"d");
					HX_STACK_LINE(736)
					++(_g);
					HX_STACK_LINE(737)
					{
						HX_STACK_LINE(737)
						int _g2 = (int)0;		HX_STACK_VAR(_g2,"_g2");
						int _g1 = output->get_height();		HX_STACK_VAR(_g1,"_g1");
						HX_STACK_LINE(737)
						while(((_g2 < _g1))){
							HX_STACK_LINE(737)
							int j = (_g2)++;		HX_STACK_VAR(j,"j");
							HX_STACK_LINE(738)
							output->setCell(d,j,this->builder->marker(HX_CSTRING("...")));
						}
					}
				}
			}
		}
	}
	HX_STACK_LINE(743)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC1(TableDiff_obj,hilite,return )

int TableDiff_obj::countActive( Array< int > active){
	HX_STACK_PUSH("TableDiff::countActive","coopy/TableDiff.hx",181);
	HX_STACK_THIS(this);
	HX_STACK_ARG(active,"active");
	HX_STACK_LINE(182)
	int ct = (int)0;		HX_STACK_VAR(ct,"ct");
	HX_STACK_LINE(183)
	bool showed_dummy = false;		HX_STACK_VAR(showed_dummy,"showed_dummy");
	HX_STACK_LINE(184)
	{
		HX_STACK_LINE(184)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = active->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(184)
		while(((_g1 < _g))){
			HX_STACK_LINE(184)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(185)
			bool publish = (active->__get(i) > (int)0);		HX_STACK_VAR(publish,"publish");
			HX_STACK_LINE(186)
			bool dummy = (active->__get(i) == (int)3);		HX_STACK_VAR(dummy,"dummy");
			HX_STACK_LINE(187)
			if (((bool(dummy) && bool(showed_dummy)))){
				HX_STACK_LINE(187)
				continue;
			}
			HX_STACK_LINE(188)
			if ((!(publish))){
				HX_STACK_LINE(188)
				continue;
			}
			HX_STACK_LINE(189)
			showed_dummy = dummy;
			HX_STACK_LINE(190)
			(ct)++;
		}
	}
	HX_STACK_LINE(192)
	return ct;
}


HX_DEFINE_DYNAMIC_FUNC1(TableDiff_obj,countActive,return )

Void TableDiff_obj::setIgnore( ::haxe::ds::StringMap ignore,::haxe::ds::IntMap idx_ignore,::coopy::Table tab,int r_header){
{
		HX_STACK_PUSH("TableDiff::setIgnore","coopy/TableDiff.hx",170);
		HX_STACK_THIS(this);
		HX_STACK_ARG(ignore,"ignore");
		HX_STACK_ARG(idx_ignore,"idx_ignore");
		HX_STACK_ARG(tab,"tab");
		HX_STACK_ARG(r_header,"r_header");
		HX_STACK_LINE(171)
		::coopy::View v = tab->getCellView();		HX_STACK_VAR(v,"v");
		HX_STACK_LINE(172)
		if (((tab->get_height() >= r_header))){
			HX_STACK_LINE(173)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = tab->get_width();		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(173)
			while(((_g1 < _g))){
				HX_STACK_LINE(173)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(174)
				::String name = v->toString(tab->getCell(i,r_header));		HX_STACK_VAR(name,"name");
				HX_STACK_LINE(175)
				if ((!(ignore->exists(name)))){
					HX_STACK_LINE(175)
					continue;
				}
				HX_STACK_LINE(176)
				idx_ignore->set(i,true);
			}
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC4(TableDiff_obj,setIgnore,(void))

Void TableDiff_obj::spreadContext( Array< ::Dynamic > units,int del,Array< int > active){
{
		HX_STACK_PUSH("TableDiff::spreadContext","coopy/TableDiff.hx",120);
		HX_STACK_THIS(this);
		HX_STACK_ARG(units,"units");
		HX_STACK_ARG(del,"del");
		HX_STACK_ARG(active,"active");
		HX_STACK_LINE(120)
		if (((bool((del > (int)0)) && bool((active != null()))))){
			HX_STACK_LINE(123)
			int mark = (-(del) - (int)1);		HX_STACK_VAR(mark,"mark");
			HX_STACK_LINE(124)
			int skips = (int)0;		HX_STACK_VAR(skips,"skips");
			HX_STACK_LINE(125)
			{
				HX_STACK_LINE(125)
				int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
				int _g = units->length;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(125)
				while(((_g1 < _g))){
					HX_STACK_LINE(125)
					int i = (_g1)++;		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(126)
					if (((active->__get(i) == (int)-3))){
						HX_STACK_LINE(128)
						(skips)++;
						HX_STACK_LINE(129)
						continue;
					}
					HX_STACK_LINE(131)
					if (((bool((active->__get(i) == (int)0)) || bool((active->__get(i) == (int)3))))){
						HX_STACK_LINE(131)
						if ((((i - mark) <= (del + skips)))){
							HX_STACK_LINE(132)
							active[i] = (int)2;
						}
						else{
							HX_STACK_LINE(134)
							if ((((i - mark) == ((del + (int)1) + skips)))){
								HX_STACK_LINE(134)
								active[i] = (int)3;
							}
						}
					}
					else{
						HX_STACK_LINE(137)
						if (((active->__get(i) == (int)1))){
							HX_STACK_LINE(138)
							mark = i;
							HX_STACK_LINE(139)
							skips = (int)0;
						}
					}
				}
			}
			HX_STACK_LINE(144)
			mark = ((units->length + del) + (int)1);
			HX_STACK_LINE(145)
			skips = (int)0;
			HX_STACK_LINE(146)
			{
				HX_STACK_LINE(146)
				int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
				int _g = units->length;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(146)
				while(((_g1 < _g))){
					HX_STACK_LINE(146)
					int j = (_g1)++;		HX_STACK_VAR(j,"j");
					HX_STACK_LINE(147)
					int i = ((units->length - (int)1) - j);		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(148)
					if (((active->__get(i) == (int)-3))){
						HX_STACK_LINE(150)
						(skips)++;
						HX_STACK_LINE(151)
						continue;
					}
					HX_STACK_LINE(153)
					if (((bool((active->__get(i) == (int)0)) || bool((active->__get(i) == (int)3))))){
						HX_STACK_LINE(153)
						if ((((mark - i) <= (del + skips)))){
							HX_STACK_LINE(154)
							active[i] = (int)2;
						}
						else{
							HX_STACK_LINE(156)
							if ((((mark - i) == ((del + (int)1) + skips)))){
								HX_STACK_LINE(156)
								active[i] = (int)3;
							}
						}
					}
					else{
						HX_STACK_LINE(159)
						if (((active->__get(i) == (int)1))){
							HX_STACK_LINE(160)
							mark = i;
							HX_STACK_LINE(161)
							skips = (int)0;
						}
					}
				}
			}
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(TableDiff_obj,spreadContext,(void))

bool TableDiff_obj::isReordered( ::haxe::ds::IntMap m,int ct){
	HX_STACK_PUSH("TableDiff::isReordered","coopy/TableDiff.hx",92);
	HX_STACK_THIS(this);
	HX_STACK_ARG(m,"m");
	HX_STACK_ARG(ct,"ct");
	HX_STACK_LINE(93)
	bool reordered = false;		HX_STACK_VAR(reordered,"reordered");
	HX_STACK_LINE(94)
	int l = (int)-1;		HX_STACK_VAR(l,"l");
	HX_STACK_LINE(95)
	int r = (int)-1;		HX_STACK_VAR(r,"r");
	HX_STACK_LINE(96)
	{
		HX_STACK_LINE(96)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(96)
		while(((_g < ct))){
			HX_STACK_LINE(96)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(97)
			::coopy::Unit unit = m->get(i);		HX_STACK_VAR(unit,"unit");
			HX_STACK_LINE(98)
			if (((unit == null()))){
				HX_STACK_LINE(98)
				continue;
			}
			HX_STACK_LINE(99)
			if (((unit->l >= (int)0))){
				HX_STACK_LINE(100)
				if (((unit->l < l))){
					HX_STACK_LINE(101)
					reordered = true;
					HX_STACK_LINE(102)
					break;
				}
				HX_STACK_LINE(104)
				l = unit->l;
			}
			HX_STACK_LINE(106)
			if (((unit->r >= (int)0))){
				HX_STACK_LINE(107)
				if (((unit->r < r))){
					HX_STACK_LINE(108)
					reordered = true;
					HX_STACK_LINE(109)
					break;
				}
				HX_STACK_LINE(111)
				r = unit->r;
			}
		}
	}
	HX_STACK_LINE(114)
	return reordered;
}


HX_DEFINE_DYNAMIC_FUNC2(TableDiff_obj,isReordered,return )

::String TableDiff_obj::quoteForDiff( ::coopy::View v,Dynamic d){
	HX_STACK_PUSH("TableDiff::quoteForDiff","coopy/TableDiff.hx",75);
	HX_STACK_THIS(this);
	HX_STACK_ARG(v,"v");
	HX_STACK_ARG(d,"d");
	HX_STACK_LINE(76)
	::String nil = HX_CSTRING("NULL");		HX_STACK_VAR(nil,"nil");
	HX_STACK_LINE(77)
	if ((v->equals(d,null()))){
		HX_STACK_LINE(77)
		return nil;
	}
	HX_STACK_LINE(80)
	::String str = v->toString(d);		HX_STACK_VAR(str,"str");
	HX_STACK_LINE(81)
	int score = (int)0;		HX_STACK_VAR(score,"score");
	HX_STACK_LINE(82)
	{
		HX_STACK_LINE(82)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = str.length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(82)
		while(((_g1 < _g))){
			HX_STACK_LINE(82)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(83)
			if (((str.charCodeAt(score) != (int)95))){
				HX_STACK_LINE(83)
				break;
			}
			HX_STACK_LINE(84)
			(score)++;
		}
	}
	HX_STACK_LINE(86)
	if (((str.substr(score,null()) == nil))){
		HX_STACK_LINE(86)
		str = (HX_CSTRING("_") + str);
	}
	HX_STACK_LINE(89)
	return str;
}


HX_DEFINE_DYNAMIC_FUNC2(TableDiff_obj,quoteForDiff,return )

::String TableDiff_obj::getSeparator( ::coopy::Table t,::coopy::Table t2,::String root){
	HX_STACK_PUSH("TableDiff::getSeparator","coopy/TableDiff.hx",45);
	HX_STACK_THIS(this);
	HX_STACK_ARG(t,"t");
	HX_STACK_ARG(t2,"t2");
	HX_STACK_ARG(root,"root");
	HX_STACK_LINE(46)
	::String sep = root;		HX_STACK_VAR(sep,"sep");
	HX_STACK_LINE(47)
	int w = t->get_width();		HX_STACK_VAR(w,"w");
	HX_STACK_LINE(48)
	int h = t->get_height();		HX_STACK_VAR(h,"h");
	HX_STACK_LINE(49)
	::coopy::View view = t->getCellView();		HX_STACK_VAR(view,"view");
	HX_STACK_LINE(50)
	{
		HX_STACK_LINE(50)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(50)
		while(((_g < h))){
			HX_STACK_LINE(50)
			int y = (_g)++;		HX_STACK_VAR(y,"y");
			HX_STACK_LINE(51)
			{
				HX_STACK_LINE(51)
				int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
				HX_STACK_LINE(51)
				while(((_g1 < w))){
					HX_STACK_LINE(51)
					int x = (_g1)++;		HX_STACK_VAR(x,"x");
					HX_STACK_LINE(52)
					::String txt = view->toString(t->getCell(x,y));		HX_STACK_VAR(txt,"txt");
					HX_STACK_LINE(53)
					if (((txt == null()))){
						HX_STACK_LINE(53)
						continue;
					}
					HX_STACK_LINE(54)
					while(((txt.indexOf(sep,null()) >= (int)0))){
						HX_STACK_LINE(54)
						sep = (HX_CSTRING("-") + sep);
					}
				}
			}
		}
	}
	HX_STACK_LINE(59)
	if (((t2 != null()))){
		HX_STACK_LINE(60)
		w = t2->get_width();
		HX_STACK_LINE(61)
		h = t2->get_height();
		HX_STACK_LINE(62)
		{
			HX_STACK_LINE(62)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(62)
			while(((_g < h))){
				HX_STACK_LINE(62)
				int y = (_g)++;		HX_STACK_VAR(y,"y");
				HX_STACK_LINE(63)
				{
					HX_STACK_LINE(63)
					int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
					HX_STACK_LINE(63)
					while(((_g1 < w))){
						HX_STACK_LINE(63)
						int x = (_g1)++;		HX_STACK_VAR(x,"x");
						HX_STACK_LINE(64)
						::String txt = view->toString(t2->getCell(x,y));		HX_STACK_VAR(txt,"txt");
						HX_STACK_LINE(65)
						if (((txt == null()))){
							HX_STACK_LINE(65)
							continue;
						}
						HX_STACK_LINE(66)
						while(((txt.indexOf(sep,null()) >= (int)0))){
							HX_STACK_LINE(66)
							sep = (HX_CSTRING("-") + sep);
						}
					}
				}
			}
		}
	}
	HX_STACK_LINE(72)
	return sep;
}


HX_DEFINE_DYNAMIC_FUNC3(TableDiff_obj,getSeparator,return )

Void TableDiff_obj::setCellBuilder( ::coopy::CellBuilder builder){
{
		HX_STACK_PUSH("TableDiff::setCellBuilder","coopy/TableDiff.hx",40);
		HX_STACK_THIS(this);
		HX_STACK_ARG(builder,"builder");
		HX_STACK_LINE(40)
		this->builder = builder;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(TableDiff_obj,setCellBuilder,(void))


TableDiff_obj::TableDiff_obj()
{
}

void TableDiff_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(TableDiff);
	HX_MARK_MEMBER_NAME(builder,"builder");
	HX_MARK_MEMBER_NAME(flags,"flags");
	HX_MARK_MEMBER_NAME(align,"align");
	HX_MARK_END_CLASS();
}

void TableDiff_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(builder,"builder");
	HX_VISIT_MEMBER_NAME(flags,"flags");
	HX_VISIT_MEMBER_NAME(align,"align");
}

Dynamic TableDiff_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 5:
		if (HX_FIELD_EQ(inName,"flags") ) { return flags; }
		if (HX_FIELD_EQ(inName,"align") ) { return align; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"hilite") ) { return hilite_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"builder") ) { return builder; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"setIgnore") ) { return setIgnore_dyn(); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"countActive") ) { return countActive_dyn(); }
		if (HX_FIELD_EQ(inName,"isReordered") ) { return isReordered_dyn(); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"quoteForDiff") ) { return quoteForDiff_dyn(); }
		if (HX_FIELD_EQ(inName,"getSeparator") ) { return getSeparator_dyn(); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"spreadContext") ) { return spreadContext_dyn(); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"setCellBuilder") ) { return setCellBuilder_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic TableDiff_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 5:
		if (HX_FIELD_EQ(inName,"flags") ) { flags=inValue.Cast< ::coopy::CompareFlags >(); return inValue; }
		if (HX_FIELD_EQ(inName,"align") ) { align=inValue.Cast< ::coopy::Alignment >(); return inValue; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"builder") ) { builder=inValue.Cast< ::coopy::CellBuilder >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void TableDiff_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("builder"));
	outFields->push(HX_CSTRING("flags"));
	outFields->push(HX_CSTRING("align"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("hilite"),
	HX_CSTRING("countActive"),
	HX_CSTRING("setIgnore"),
	HX_CSTRING("spreadContext"),
	HX_CSTRING("isReordered"),
	HX_CSTRING("quoteForDiff"),
	HX_CSTRING("getSeparator"),
	HX_CSTRING("setCellBuilder"),
	HX_CSTRING("builder"),
	HX_CSTRING("flags"),
	HX_CSTRING("align"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(TableDiff_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(TableDiff_obj::__mClass,"__mClass");
};

Class TableDiff_obj::__mClass;

void TableDiff_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.TableDiff"), hx::TCanCast< TableDiff_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void TableDiff_obj::__boot()
{
}

} // end namespace coopy

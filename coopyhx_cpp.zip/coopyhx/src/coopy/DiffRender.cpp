#include <hxcpp.h>

#ifndef INCLUDED_StringTools
#include <StringTools.h>
#endif
#ifndef INCLUDED_coopy_CellInfo
#include <coopy/CellInfo.h>
#endif
#ifndef INCLUDED_coopy_DiffRender
#include <coopy/DiffRender.h>
#endif
#ifndef INCLUDED_coopy_Table
#include <coopy/Table.h>
#endif
#ifndef INCLUDED_coopy_View
#include <coopy/View.h>
#endif
namespace coopy{

Void DiffRender_obj::__construct()
{
HX_STACK_PUSH("DiffRender::new","coopy/DiffRender.hx",21);
{
	HX_STACK_LINE(22)
	this->text_to_insert = Array_obj< ::String >::__new();
	HX_STACK_LINE(23)
	this->open = false;
	HX_STACK_LINE(24)
	this->pretty_arrows = true;
}
;
	return null();
}

DiffRender_obj::~DiffRender_obj() { }

Dynamic DiffRender_obj::__CreateEmpty() { return  new DiffRender_obj; }
hx::ObjectPtr< DiffRender_obj > DiffRender_obj::__new()
{  hx::ObjectPtr< DiffRender_obj > result = new DiffRender_obj();
	result->__construct();
	return result;}

Dynamic DiffRender_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< DiffRender_obj > result = new DiffRender_obj();
	result->__construct();
	return result;}

Void DiffRender_obj::completeHtml( ){
{
		HX_STACK_PUSH("DiffRender::completeHtml","coopy/DiffRender.hx",433);
		HX_STACK_THIS(this);
		HX_STACK_LINE(434)
		this->text_to_insert->insert((int)0,HX_CSTRING("<!DOCTYPE html>\n<html>\n<head>\n<meta charset='utf-8'>\n<style TYPE='text/css'>\n"));
		HX_STACK_LINE(440)
		this->text_to_insert->insert((int)1,this->sampleCss());
		HX_STACK_LINE(441)
		this->text_to_insert->insert((int)2,HX_CSTRING("</style>\n</head>\n<body>\n<div class='highlighter'>\n"));
		HX_STACK_LINE(446)
		this->text_to_insert->push(HX_CSTRING("</div>\n</body>\n</html>\n"));
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(DiffRender_obj,completeHtml,(void))

::String DiffRender_obj::sampleCss( ){
	HX_STACK_PUSH("DiffRender::sampleCss","coopy/DiffRender.hx",362);
	HX_STACK_THIS(this);
	HX_STACK_LINE(362)
	return HX_CSTRING(".highlighter .add { \n  background-color: #7fff7f;\n}\n\n.highlighter .remove { \n  background-color: #ff7f7f;\n}\n\n.highlighter td.modify { \n  background-color: #7f7fff;\n}\n\n.highlighter td.conflict { \n  background-color: #f00;\n}\n\n.highlighter .spec { \n  background-color: #aaa;\n}\n\n.highlighter .move { \n  background-color: #ffa;\n}\n\n.highlighter .null { \n  color: #888;\n}\n\n.highlighter table { \n  border-collapse:collapse;\n}\n\n.highlighter td, .highlighter th {\n  border: 1px solid #2D4068;\n  padding: 3px 7px 2px;\n}\n\n.highlighter th, .highlighter .header { \n  background-color: #aaf;\n  font-weight: bold;\n  padding-bottom: 4px;\n  padding-top: 5px;\n  text-align:left;\n}\n\n.highlighter tr.header th {\n  border-bottom: 2px solid black;\n}\n\n.highlighter tr.index td, .highlighter .index, .highlighter tr.header th.index {\n  background-color: white;\n  border: none;\n}\n\n.highlighter .gap {\n  color: #888;\n}\n\n.highlighter td {\n  empty-cells: show;\n}\n");
}


HX_DEFINE_DYNAMIC_FUNC0(DiffRender_obj,sampleCss,return )

::coopy::DiffRender DiffRender_obj::render( ::coopy::Table tab){
	HX_STACK_PUSH("DiffRender::render","coopy/DiffRender.hx",307);
	HX_STACK_THIS(this);
	HX_STACK_ARG(tab,"tab");
	HX_STACK_LINE(308)
	if (((bool((tab->get_width() == (int)0)) || bool((tab->get_height() == (int)0))))){
		HX_STACK_LINE(308)
		return hx::ObjectPtr<OBJ_>(this);
	}
	HX_STACK_LINE(309)
	::coopy::DiffRender render = hx::ObjectPtr<OBJ_>(this);		HX_STACK_VAR(render,"render");
	HX_STACK_LINE(310)
	render->beginTable();
	HX_STACK_LINE(311)
	int change_row = (int)-1;		HX_STACK_VAR(change_row,"change_row");
	HX_STACK_LINE(312)
	::coopy::CellInfo cell = ::coopy::CellInfo_obj::__new();		HX_STACK_VAR(cell,"cell");
	HX_STACK_LINE(313)
	::coopy::View view = tab->getCellView();		HX_STACK_VAR(view,"view");
	HX_STACK_LINE(314)
	::String corner = view->toString(tab->getCell((int)0,(int)0));		HX_STACK_VAR(corner,"corner");
	HX_STACK_LINE(315)
	int off = (  (((corner == HX_CSTRING("@:@")))) ? int((int)1) : int((int)0) );		HX_STACK_VAR(off,"off");
	HX_STACK_LINE(316)
	if (((off > (int)0))){
		HX_STACK_LINE(316)
		if (((bool((tab->get_width() <= (int)1)) || bool((tab->get_height() <= (int)1))))){
			HX_STACK_LINE(317)
			return hx::ObjectPtr<OBJ_>(this);
		}
	}
	HX_STACK_LINE(319)
	{
		HX_STACK_LINE(319)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = tab->get_height();		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(319)
		while(((_g1 < _g))){
			HX_STACK_LINE(319)
			int row = (_g1)++;		HX_STACK_VAR(row,"row");
			HX_STACK_LINE(321)
			bool open = false;		HX_STACK_VAR(open,"open");
			HX_STACK_LINE(323)
			::String txt = view->toString(tab->getCell(off,row));		HX_STACK_VAR(txt,"txt");
			HX_STACK_LINE(324)
			if (((txt == null()))){
				HX_STACK_LINE(324)
				txt = HX_CSTRING("");
			}
			HX_STACK_LINE(325)
			::coopy::DiffRender_obj::examineCell(off,row,view,txt,HX_CSTRING(""),txt,corner,cell,off);
			HX_STACK_LINE(326)
			::String row_mode = cell->category;		HX_STACK_VAR(row_mode,"row_mode");
			HX_STACK_LINE(327)
			if (((row_mode == HX_CSTRING("spec")))){
				HX_STACK_LINE(327)
				change_row = row;
			}
			HX_STACK_LINE(330)
			if (((bool((bool((row_mode == HX_CSTRING("header"))) || bool((row_mode == HX_CSTRING("spec"))))) || bool((row_mode == HX_CSTRING("index")))))){
				HX_STACK_LINE(330)
				this->setSection(HX_CSTRING("head"));
			}
			else{
				HX_STACK_LINE(332)
				this->setSection(HX_CSTRING("body"));
			}
			HX_STACK_LINE(336)
			render->beginRow(row_mode);
			HX_STACK_LINE(338)
			{
				HX_STACK_LINE(338)
				int _g3 = (int)0;		HX_STACK_VAR(_g3,"_g3");
				int _g2 = tab->get_width();		HX_STACK_VAR(_g2,"_g2");
				HX_STACK_LINE(338)
				while(((_g3 < _g2))){
					HX_STACK_LINE(338)
					int c = (_g3)++;		HX_STACK_VAR(c,"c");
					HX_STACK_LINE(339)
					::coopy::DiffRender_obj::examineCell(c,row,view,tab->getCell(c,row),(  (((change_row >= (int)0))) ? ::String(view->toString(tab->getCell(c,change_row))) : ::String(HX_CSTRING("")) ),txt,corner,cell,off);
					HX_STACK_LINE(348)
					render->insertCell((  ((this->pretty_arrows)) ? ::String(cell->pretty_value) : ::String(cell->value) ),cell->category_given_tr);
				}
			}
			HX_STACK_LINE(351)
			render->endRow();
		}
	}
	HX_STACK_LINE(353)
	render->endTable();
	HX_STACK_LINE(354)
	return hx::ObjectPtr<OBJ_>(this);
}


HX_DEFINE_DYNAMIC_FUNC1(DiffRender_obj,render,return )

::String DiffRender_obj::toString( ){
	HX_STACK_PUSH("DiffRender::toString","coopy/DiffRender.hx",112);
	HX_STACK_THIS(this);
	HX_STACK_LINE(112)
	return this->html();
}


HX_DEFINE_DYNAMIC_FUNC0(DiffRender_obj,toString,return )

::String DiffRender_obj::html( ){
	HX_STACK_PUSH("DiffRender::html","coopy/DiffRender.hx",103);
	HX_STACK_THIS(this);
	HX_STACK_LINE(103)
	return this->text_to_insert->join(HX_CSTRING(""));
}


HX_DEFINE_DYNAMIC_FUNC0(DiffRender_obj,html,return )

Void DiffRender_obj::endTable( ){
{
		HX_STACK_PUSH("DiffRender::endTable","coopy/DiffRender.hx",92);
		HX_STACK_THIS(this);
		HX_STACK_LINE(93)
		this->setSection(null());
		HX_STACK_LINE(94)
		this->insert(HX_CSTRING("</table>\n"));
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(DiffRender_obj,endTable,(void))

Void DiffRender_obj::endRow( ){
{
		HX_STACK_PUSH("DiffRender::endRow","coopy/DiffRender.hx",87);
		HX_STACK_THIS(this);
		HX_STACK_LINE(87)
		this->insert(HX_CSTRING("</tr>\n"));
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(DiffRender_obj,endRow,(void))

Void DiffRender_obj::insertCell( ::String txt,::String mode){
{
		HX_STACK_PUSH("DiffRender::insertCell","coopy/DiffRender.hx",77);
		HX_STACK_THIS(this);
		HX_STACK_ARG(txt,"txt");
		HX_STACK_ARG(mode,"mode");
		HX_STACK_LINE(78)
		::String cell_decorate = HX_CSTRING("");		HX_STACK_VAR(cell_decorate,"cell_decorate");
		HX_STACK_LINE(79)
		if (((mode != HX_CSTRING("")))){
			HX_STACK_LINE(79)
			cell_decorate = ((HX_CSTRING(" class=\"") + mode) + HX_CSTRING("\""));
		}
		HX_STACK_LINE(82)
		this->insert(((this->td_open + cell_decorate) + HX_CSTRING(">")));
		HX_STACK_LINE(83)
		this->insert(txt);
		HX_STACK_LINE(84)
		this->insert(this->td_close);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC2(DiffRender_obj,insertCell,(void))

Void DiffRender_obj::beginRow( ::String mode){
{
		HX_STACK_PUSH("DiffRender::beginRow","coopy/DiffRender.hx",61);
		HX_STACK_THIS(this);
		HX_STACK_ARG(mode,"mode");
		HX_STACK_LINE(62)
		this->td_open = HX_CSTRING("<td");
		HX_STACK_LINE(63)
		this->td_close = HX_CSTRING("</td>");
		HX_STACK_LINE(64)
		::String row_class = HX_CSTRING("");		HX_STACK_VAR(row_class,"row_class");
		HX_STACK_LINE(65)
		if (((mode == HX_CSTRING("header")))){
			HX_STACK_LINE(66)
			this->td_open = HX_CSTRING("<th");
			HX_STACK_LINE(67)
			this->td_close = HX_CSTRING("</th>");
		}
		HX_STACK_LINE(69)
		row_class = mode;
		HX_STACK_LINE(70)
		::String tr = HX_CSTRING("<tr>");		HX_STACK_VAR(tr,"tr");
		HX_STACK_LINE(71)
		if (((row_class != HX_CSTRING("")))){
			HX_STACK_LINE(71)
			tr = ((HX_CSTRING("<tr class=\"") + row_class) + HX_CSTRING("\">"));
		}
		HX_STACK_LINE(74)
		this->insert(tr);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(DiffRender_obj,beginRow,(void))

Void DiffRender_obj::setSection( ::String str){
{
		HX_STACK_PUSH("DiffRender::setSection","coopy/DiffRender.hx",46);
		HX_STACK_THIS(this);
		HX_STACK_ARG(str,"str");
		HX_STACK_LINE(47)
		if (((str == this->section))){
			HX_STACK_LINE(47)
			return null();
		}
		HX_STACK_LINE(48)
		if (((this->section != null()))){
			HX_STACK_LINE(49)
			this->insert(HX_CSTRING("</t"));
			HX_STACK_LINE(50)
			this->insert(this->section);
			HX_STACK_LINE(51)
			this->insert(HX_CSTRING(">\n"));
		}
		HX_STACK_LINE(53)
		this->section = str;
		HX_STACK_LINE(54)
		if (((this->section != null()))){
			HX_STACK_LINE(55)
			this->insert(HX_CSTRING("<t"));
			HX_STACK_LINE(56)
			this->insert(this->section);
			HX_STACK_LINE(57)
			this->insert(HX_CSTRING(">\n"));
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(DiffRender_obj,setSection,(void))

Void DiffRender_obj::beginTable( ){
{
		HX_STACK_PUSH("DiffRender::beginTable","coopy/DiffRender.hx",41);
		HX_STACK_THIS(this);
		HX_STACK_LINE(42)
		this->insert(HX_CSTRING("<table>\n"));
		HX_STACK_LINE(43)
		this->section = null();
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(DiffRender_obj,beginTable,(void))

Void DiffRender_obj::insert( ::String str){
{
		HX_STACK_PUSH("DiffRender::insert","coopy/DiffRender.hx",37);
		HX_STACK_THIS(this);
		HX_STACK_ARG(str,"str");
		HX_STACK_LINE(37)
		this->text_to_insert->push(str);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(DiffRender_obj,insert,(void))

Void DiffRender_obj::usePrettyArrows( bool flag){
{
		HX_STACK_PUSH("DiffRender::usePrettyArrows","coopy/DiffRender.hx",33);
		HX_STACK_THIS(this);
		HX_STACK_ARG(flag,"flag");
		HX_STACK_LINE(33)
		this->pretty_arrows = flag;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(DiffRender_obj,usePrettyArrows,(void))

Void DiffRender_obj::examineCell( int x,int y,::coopy::View view,Dynamic raw,::String vcol,::String vrow,::String vcorner,::coopy::CellInfo cell,hx::Null< int >  __o_offset){
int offset = __o_offset.Default(0);
	HX_STACK_PUSH("DiffRender::examineCell","coopy/DiffRender.hx",132);
	HX_STACK_ARG(x,"x");
	HX_STACK_ARG(y,"y");
	HX_STACK_ARG(view,"view");
	HX_STACK_ARG(raw,"raw");
	HX_STACK_ARG(vcol,"vcol");
	HX_STACK_ARG(vrow,"vrow");
	HX_STACK_ARG(vcorner,"vcorner");
	HX_STACK_ARG(cell,"cell");
	HX_STACK_ARG(offset,"offset");
{
		HX_STACK_LINE(133)
		bool nested = view->isHash(raw);		HX_STACK_VAR(nested,"nested");
		HX_STACK_LINE(134)
		::String value = null();		HX_STACK_VAR(value,"value");
		HX_STACK_LINE(135)
		if ((!(nested))){
			HX_STACK_LINE(135)
			value = view->toString(raw);
		}
		HX_STACK_LINE(136)
		cell->category = HX_CSTRING("");
		HX_STACK_LINE(137)
		cell->category_given_tr = HX_CSTRING("");
		HX_STACK_LINE(138)
		cell->separator = HX_CSTRING("");
		HX_STACK_LINE(139)
		cell->pretty_separator = HX_CSTRING("");
		HX_STACK_LINE(140)
		cell->conflicted = false;
		HX_STACK_LINE(141)
		cell->updated = false;
		HX_STACK_LINE(142)
		cell->pvalue = cell->lvalue = cell->rvalue = null();
		HX_STACK_LINE(143)
		cell->value = value;
		HX_STACK_LINE(144)
		if (((cell->value == null()))){
			HX_STACK_LINE(144)
			cell->value = HX_CSTRING("");
		}
		HX_STACK_LINE(145)
		cell->pretty_value = cell->value;
		HX_STACK_LINE(146)
		if (((vrow == null()))){
			HX_STACK_LINE(146)
			vrow = HX_CSTRING("");
		}
		HX_STACK_LINE(147)
		if (((vcol == null()))){
			HX_STACK_LINE(147)
			vcol = HX_CSTRING("");
		}
		HX_STACK_LINE(148)
		bool removed_column = false;		HX_STACK_VAR(removed_column,"removed_column");
		HX_STACK_LINE(149)
		if (((vrow == HX_CSTRING(":")))){
			HX_STACK_LINE(149)
			cell->category = HX_CSTRING("move");
		}
		HX_STACK_LINE(152)
		if (((bool((bool((vrow == HX_CSTRING(""))) && bool((offset == (int)1)))) && bool((y == (int)0))))){
			HX_STACK_LINE(152)
			cell->category = HX_CSTRING("index");
		}
		HX_STACK_LINE(155)
		if (((vcol.indexOf(HX_CSTRING("+++"),null()) >= (int)0))){
			HX_STACK_LINE(155)
			cell->category_given_tr = cell->category = HX_CSTRING("add");
		}
		else{
			HX_STACK_LINE(157)
			if (((vcol.indexOf(HX_CSTRING("---"),null()) >= (int)0))){
				HX_STACK_LINE(158)
				cell->category_given_tr = cell->category = HX_CSTRING("remove");
				HX_STACK_LINE(159)
				removed_column = true;
			}
		}
		HX_STACK_LINE(161)
		if (((vrow == HX_CSTRING("!")))){
			HX_STACK_LINE(161)
			cell->category = HX_CSTRING("spec");
		}
		else{
			HX_STACK_LINE(163)
			if (((vrow == HX_CSTRING("@@")))){
				HX_STACK_LINE(163)
				cell->category = HX_CSTRING("header");
			}
			else{
				HX_STACK_LINE(165)
				if (((vrow == HX_CSTRING("...")))){
					HX_STACK_LINE(165)
					cell->category = HX_CSTRING("gap");
				}
				else{
					HX_STACK_LINE(167)
					if (((vrow == HX_CSTRING("+++")))){
						HX_STACK_LINE(167)
						if ((!(removed_column))){
							HX_STACK_LINE(168)
							cell->category = HX_CSTRING("add");
						}
					}
					else{
						HX_STACK_LINE(171)
						if (((vrow == HX_CSTRING("---")))){
							HX_STACK_LINE(171)
							cell->category = HX_CSTRING("remove");
						}
						else{
							HX_STACK_LINE(173)
							if (((vrow.indexOf(HX_CSTRING("->"),null()) >= (int)0))){
								HX_STACK_LINE(173)
								if ((!(removed_column))){
									HX_STACK_LINE(175)
									Array< ::String > tokens = vrow.split(HX_CSTRING("!"));		HX_STACK_VAR(tokens,"tokens");
									HX_STACK_LINE(176)
									::String full = vrow;		HX_STACK_VAR(full,"full");
									HX_STACK_LINE(177)
									::String part = tokens->__get((int)1);		HX_STACK_VAR(part,"part");
									HX_STACK_LINE(178)
									if (((part == null()))){
										HX_STACK_LINE(178)
										part = full;
									}
									HX_STACK_LINE(179)
									if (((bool(nested) || bool((cell->value.indexOf(part,null()) >= (int)0))))){
										HX_STACK_LINE(180)
										::String cat = HX_CSTRING("modify");		HX_STACK_VAR(cat,"cat");
										HX_STACK_LINE(181)
										::String div = part;		HX_STACK_VAR(div,"div");
										HX_STACK_LINE(183)
										if (((part != full))){
											HX_STACK_LINE(184)
											if ((nested)){
												HX_STACK_LINE(184)
												cell->conflicted = view->hashExists(raw,HX_CSTRING("theirs"));
											}
											else{
												HX_STACK_LINE(186)
												cell->conflicted = (cell->value.indexOf(full,null()) >= (int)0);
											}
											HX_STACK_LINE(189)
											if ((cell->conflicted)){
												HX_STACK_LINE(190)
												div = full;
												HX_STACK_LINE(191)
												cat = HX_CSTRING("conflict");
											}
										}
										HX_STACK_LINE(194)
										cell->updated = true;
										HX_STACK_LINE(195)
										cell->separator = div;
										HX_STACK_LINE(196)
										cell->pretty_separator = div;
										HX_STACK_LINE(197)
										if ((nested)){
											HX_STACK_LINE(197)
											if ((cell->conflicted)){
												HX_STACK_LINE(198)
												tokens = Array_obj< ::String >::__new().Add(view->hashGet(raw,HX_CSTRING("before"))).Add(view->hashGet(raw,HX_CSTRING("ours"))).Add(view->hashGet(raw,HX_CSTRING("theirs")));
											}
											else{
												HX_STACK_LINE(202)
												tokens = Array_obj< ::String >::__new().Add(view->hashGet(raw,HX_CSTRING("before"))).Add(view->hashGet(raw,HX_CSTRING("after")));
											}
										}
										else{
											HX_STACK_LINE(206)
											if (((cell->pretty_value == div))){
												HX_STACK_LINE(207)
												tokens = Array_obj< ::String >::__new().Add(HX_CSTRING("")).Add(HX_CSTRING(""));
											}
											else{
												HX_STACK_LINE(209)
												tokens = cell->pretty_value.split(div);
											}
										}
										HX_STACK_LINE(213)
										Array< ::String > pretty_tokens = tokens;		HX_STACK_VAR(pretty_tokens,"pretty_tokens");
										HX_STACK_LINE(214)
										if (((tokens->length >= (int)2))){
											HX_STACK_LINE(215)
											pretty_tokens[(int)0] = ::coopy::DiffRender_obj::markSpaces(tokens->__get((int)0),tokens->__get((int)1));
											HX_STACK_LINE(216)
											pretty_tokens[(int)1] = ::coopy::DiffRender_obj::markSpaces(tokens->__get((int)1),tokens->__get((int)0));
										}
										HX_STACK_LINE(218)
										if (((tokens->length >= (int)3))){
											HX_STACK_LINE(219)
											::String ref = pretty_tokens->__get((int)0);		HX_STACK_VAR(ref,"ref");
											HX_STACK_LINE(220)
											pretty_tokens[(int)0] = ::coopy::DiffRender_obj::markSpaces(ref,tokens->__get((int)2));
											HX_STACK_LINE(221)
											pretty_tokens[(int)2] = ::coopy::DiffRender_obj::markSpaces(tokens->__get((int)2),ref);
										}
										HX_STACK_LINE(223)
										cell->pretty_separator = ::String::fromCharCode((int)8594);
										HX_STACK_LINE(224)
										cell->pretty_value = pretty_tokens->join(cell->pretty_separator);
										HX_STACK_LINE(225)
										cell->category_given_tr = cell->category = cat;
										HX_STACK_LINE(226)
										int offset1 = (  ((cell->conflicted)) ? int((int)1) : int((int)0) );		HX_STACK_VAR(offset1,"offset1");
										HX_STACK_LINE(227)
										cell->lvalue = tokens->__get(offset1);
										HX_STACK_LINE(228)
										cell->rvalue = tokens->__get((offset1 + (int)1));
										HX_STACK_LINE(229)
										if ((cell->conflicted)){
											HX_STACK_LINE(229)
											cell->pvalue = tokens->__get((int)0);
										}
									}
								}
							}
						}
					}
				}
			}
		}
		HX_STACK_LINE(233)
		if (((bool((x == (int)0)) && bool((offset > (int)0))))){
			HX_STACK_LINE(233)
			cell->category_given_tr = cell->category = HX_CSTRING("index");
		}
	}
return null();
}


STATIC_HX_DEFINE_DYNAMIC_FUNC9(DiffRender_obj,examineCell,(void))

::String DiffRender_obj::markSpaces( ::String sl,::String sr){
	HX_STACK_PUSH("DiffRender::markSpaces","coopy/DiffRender.hx",238);
	HX_STACK_ARG(sl,"sl");
	HX_STACK_ARG(sr,"sr");
	HX_STACK_LINE(239)
	if (((sl == sr))){
		HX_STACK_LINE(239)
		return sl;
	}
	HX_STACK_LINE(240)
	if (((bool((sl == null())) || bool((sr == null()))))){
		HX_STACK_LINE(240)
		return sl;
	}
	HX_STACK_LINE(241)
	::String slc = ::StringTools_obj::replace(sl,HX_CSTRING(" "),HX_CSTRING(""));		HX_STACK_VAR(slc,"slc");
	HX_STACK_LINE(242)
	::String src = ::StringTools_obj::replace(sr,HX_CSTRING(" "),HX_CSTRING(""));		HX_STACK_VAR(src,"src");
	HX_STACK_LINE(243)
	if (((slc != src))){
		HX_STACK_LINE(243)
		return sl;
	}
	HX_STACK_LINE(244)
	::String slo = ::String(HX_CSTRING(""));		HX_STACK_VAR(slo,"slo");
	HX_STACK_LINE(245)
	int il = (int)0;		HX_STACK_VAR(il,"il");
	HX_STACK_LINE(246)
	int ir = (int)0;		HX_STACK_VAR(ir,"ir");
	HX_STACK_LINE(247)
	while(((il < sl.length))){
		HX_STACK_LINE(248)
		::String cl = sl.charAt(il);		HX_STACK_VAR(cl,"cl");
		HX_STACK_LINE(249)
		::String cr = HX_CSTRING("");		HX_STACK_VAR(cr,"cr");
		HX_STACK_LINE(250)
		if (((ir < sr.length))){
			HX_STACK_LINE(250)
			cr = sr.charAt(ir);
		}
		HX_STACK_LINE(253)
		if (((cl == cr))){
			HX_STACK_LINE(254)
			hx::AddEq(slo,cl);
			HX_STACK_LINE(255)
			(il)++;
			HX_STACK_LINE(256)
			(ir)++;
		}
		else{
			HX_STACK_LINE(257)
			if (((cr == HX_CSTRING(" ")))){
				HX_STACK_LINE(257)
				(ir)++;
			}
			else{
				HX_STACK_LINE(260)
				hx::AddEq(slo,::String::fromCharCode((int)9251));
				HX_STACK_LINE(261)
				(il)++;
			}
		}
	}
	HX_STACK_LINE(264)
	return slo;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(DiffRender_obj,markSpaces,return )

::coopy::CellInfo DiffRender_obj::renderCell( ::coopy::Table tab,::coopy::View view,int x,int y){
	HX_STACK_PUSH("DiffRender::renderCell","coopy/DiffRender.hx",282);
	HX_STACK_ARG(tab,"tab");
	HX_STACK_ARG(view,"view");
	HX_STACK_ARG(x,"x");
	HX_STACK_ARG(y,"y");
	HX_STACK_LINE(283)
	::coopy::CellInfo cell = ::coopy::CellInfo_obj::__new();		HX_STACK_VAR(cell,"cell");
	HX_STACK_LINE(284)
	::String corner = view->toString(tab->getCell((int)0,(int)0));		HX_STACK_VAR(corner,"corner");
	HX_STACK_LINE(285)
	int off = (  (((corner == HX_CSTRING("@:@")))) ? int((int)1) : int((int)0) );		HX_STACK_VAR(off,"off");
	HX_STACK_LINE(287)
	::coopy::DiffRender_obj::examineCell(x,y,view,tab->getCell(x,y),view->toString(tab->getCell(x,off)),view->toString(tab->getCell(off,y)),corner,cell,off);
	HX_STACK_LINE(296)
	return cell;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC4(DiffRender_obj,renderCell,return )


DiffRender_obj::DiffRender_obj()
{
}

void DiffRender_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(DiffRender);
	HX_MARK_MEMBER_NAME(section,"section");
	HX_MARK_MEMBER_NAME(pretty_arrows,"pretty_arrows");
	HX_MARK_MEMBER_NAME(open,"open");
	HX_MARK_MEMBER_NAME(td_close,"td_close");
	HX_MARK_MEMBER_NAME(td_open,"td_open");
	HX_MARK_MEMBER_NAME(text_to_insert,"text_to_insert");
	HX_MARK_END_CLASS();
}

void DiffRender_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(section,"section");
	HX_VISIT_MEMBER_NAME(pretty_arrows,"pretty_arrows");
	HX_VISIT_MEMBER_NAME(open,"open");
	HX_VISIT_MEMBER_NAME(td_close,"td_close");
	HX_VISIT_MEMBER_NAME(td_open,"td_open");
	HX_VISIT_MEMBER_NAME(text_to_insert,"text_to_insert");
}

Dynamic DiffRender_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"html") ) { return html_dyn(); }
		if (HX_FIELD_EQ(inName,"open") ) { return open; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"render") ) { return render_dyn(); }
		if (HX_FIELD_EQ(inName,"endRow") ) { return endRow_dyn(); }
		if (HX_FIELD_EQ(inName,"insert") ) { return insert_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"section") ) { return section; }
		if (HX_FIELD_EQ(inName,"td_open") ) { return td_open; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"toString") ) { return toString_dyn(); }
		if (HX_FIELD_EQ(inName,"endTable") ) { return endTable_dyn(); }
		if (HX_FIELD_EQ(inName,"beginRow") ) { return beginRow_dyn(); }
		if (HX_FIELD_EQ(inName,"td_close") ) { return td_close; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"sampleCss") ) { return sampleCss_dyn(); }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"markSpaces") ) { return markSpaces_dyn(); }
		if (HX_FIELD_EQ(inName,"renderCell") ) { return renderCell_dyn(); }
		if (HX_FIELD_EQ(inName,"insertCell") ) { return insertCell_dyn(); }
		if (HX_FIELD_EQ(inName,"setSection") ) { return setSection_dyn(); }
		if (HX_FIELD_EQ(inName,"beginTable") ) { return beginTable_dyn(); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"examineCell") ) { return examineCell_dyn(); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"completeHtml") ) { return completeHtml_dyn(); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"pretty_arrows") ) { return pretty_arrows; }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"text_to_insert") ) { return text_to_insert; }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"usePrettyArrows") ) { return usePrettyArrows_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic DiffRender_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"open") ) { open=inValue.Cast< bool >(); return inValue; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"section") ) { section=inValue.Cast< ::String >(); return inValue; }
		if (HX_FIELD_EQ(inName,"td_open") ) { td_open=inValue.Cast< ::String >(); return inValue; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"td_close") ) { td_close=inValue.Cast< ::String >(); return inValue; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"pretty_arrows") ) { pretty_arrows=inValue.Cast< bool >(); return inValue; }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"text_to_insert") ) { text_to_insert=inValue.Cast< Array< ::String > >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void DiffRender_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("section"));
	outFields->push(HX_CSTRING("pretty_arrows"));
	outFields->push(HX_CSTRING("open"));
	outFields->push(HX_CSTRING("td_close"));
	outFields->push(HX_CSTRING("td_open"));
	outFields->push(HX_CSTRING("text_to_insert"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	HX_CSTRING("examineCell"),
	HX_CSTRING("markSpaces"),
	HX_CSTRING("renderCell"),
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("completeHtml"),
	HX_CSTRING("sampleCss"),
	HX_CSTRING("render"),
	HX_CSTRING("toString"),
	HX_CSTRING("html"),
	HX_CSTRING("endTable"),
	HX_CSTRING("endRow"),
	HX_CSTRING("insertCell"),
	HX_CSTRING("beginRow"),
	HX_CSTRING("setSection"),
	HX_CSTRING("beginTable"),
	HX_CSTRING("insert"),
	HX_CSTRING("usePrettyArrows"),
	HX_CSTRING("section"),
	HX_CSTRING("pretty_arrows"),
	HX_CSTRING("open"),
	HX_CSTRING("td_close"),
	HX_CSTRING("td_open"),
	HX_CSTRING("text_to_insert"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(DiffRender_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(DiffRender_obj::__mClass,"__mClass");
};

Class DiffRender_obj::__mClass;

void DiffRender_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.DiffRender"), hx::TCanCast< DiffRender_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void DiffRender_obj::__boot()
{
}

} // end namespace coopy

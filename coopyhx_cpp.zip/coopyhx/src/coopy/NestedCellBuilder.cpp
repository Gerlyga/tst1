#include <hxcpp.h>

#ifndef INCLUDED_coopy_CellBuilder
#include <coopy/CellBuilder.h>
#endif
#ifndef INCLUDED_coopy_NestedCellBuilder
#include <coopy/NestedCellBuilder.h>
#endif
#ifndef INCLUDED_coopy_Unit
#include <coopy/Unit.h>
#endif
#ifndef INCLUDED_coopy_View
#include <coopy/View.h>
#endif
namespace coopy{

Void NestedCellBuilder_obj::__construct()
{
HX_STACK_PUSH("NestedCellBuilder::new","coopy/NestedCellBuilder.hx",11);
{
}
;
	return null();
}

NestedCellBuilder_obj::~NestedCellBuilder_obj() { }

Dynamic NestedCellBuilder_obj::__CreateEmpty() { return  new NestedCellBuilder_obj; }
hx::ObjectPtr< NestedCellBuilder_obj > NestedCellBuilder_obj::__new()
{  hx::ObjectPtr< NestedCellBuilder_obj > result = new NestedCellBuilder_obj();
	result->__construct();
	return result;}

Dynamic NestedCellBuilder_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< NestedCellBuilder_obj > result = new NestedCellBuilder_obj();
	result->__construct();
	return result;}

hx::Object *NestedCellBuilder_obj::__ToInterface(const hx::type_info &inType) {
	if (inType==typeid( ::coopy::CellBuilder_obj)) return operator ::coopy::CellBuilder_obj *();
	return super::__ToInterface(inType);
}

Dynamic NestedCellBuilder_obj::links( ::coopy::Unit unit){
	HX_STACK_PUSH("NestedCellBuilder::links","coopy/NestedCellBuilder.hx",53);
	HX_STACK_THIS(this);
	HX_STACK_ARG(unit,"unit");
	HX_STACK_LINE(54)
	Dynamic h = this->view->makeHash();		HX_STACK_VAR(h,"h");
	HX_STACK_LINE(55)
	if (((unit->p >= (int)-1))){
		HX_STACK_LINE(56)
		this->view->hashSet(h,HX_CSTRING("before"),this->negToNull(unit->p));
		HX_STACK_LINE(57)
		this->view->hashSet(h,HX_CSTRING("ours"),this->negToNull(unit->l));
		HX_STACK_LINE(58)
		this->view->hashSet(h,HX_CSTRING("theirs"),this->negToNull(unit->r));
		HX_STACK_LINE(59)
		return h;
	}
	HX_STACK_LINE(61)
	this->view->hashSet(h,HX_CSTRING("before"),this->negToNull(unit->l));
	HX_STACK_LINE(62)
	this->view->hashSet(h,HX_CSTRING("after"),this->negToNull(unit->r));
	HX_STACK_LINE(63)
	return h;
}


HX_DEFINE_DYNAMIC_FUNC1(NestedCellBuilder_obj,links,return )

Dynamic NestedCellBuilder_obj::negToNull( int x){
	HX_STACK_PUSH("NestedCellBuilder::negToNull","coopy/NestedCellBuilder.hx",48);
	HX_STACK_THIS(this);
	HX_STACK_ARG(x,"x");
	HX_STACK_LINE(49)
	if (((x < (int)0))){
		HX_STACK_LINE(49)
		return null();
	}
	HX_STACK_LINE(50)
	return x;
}


HX_DEFINE_DYNAMIC_FUNC1(NestedCellBuilder_obj,negToNull,return )

Dynamic NestedCellBuilder_obj::marker( ::String label){
	HX_STACK_PUSH("NestedCellBuilder::marker","coopy/NestedCellBuilder.hx",44);
	HX_STACK_THIS(this);
	HX_STACK_ARG(label,"label");
	HX_STACK_LINE(44)
	return this->view->toDatum(label);
}


HX_DEFINE_DYNAMIC_FUNC1(NestedCellBuilder_obj,marker,return )

Dynamic NestedCellBuilder_obj::conflict( Dynamic parent,Dynamic local,Dynamic remote){
	HX_STACK_PUSH("NestedCellBuilder::conflict","coopy/NestedCellBuilder.hx",36);
	HX_STACK_THIS(this);
	HX_STACK_ARG(parent,"parent");
	HX_STACK_ARG(local,"local");
	HX_STACK_ARG(remote,"remote");
	HX_STACK_LINE(37)
	Dynamic h = this->view->makeHash();		HX_STACK_VAR(h,"h");
	HX_STACK_LINE(38)
	this->view->hashSet(h,HX_CSTRING("before"),parent);
	HX_STACK_LINE(39)
	this->view->hashSet(h,HX_CSTRING("ours"),local);
	HX_STACK_LINE(40)
	this->view->hashSet(h,HX_CSTRING("theirs"),remote);
	HX_STACK_LINE(41)
	return h;
}


HX_DEFINE_DYNAMIC_FUNC3(NestedCellBuilder_obj,conflict,return )

Dynamic NestedCellBuilder_obj::update( Dynamic local,Dynamic remote){
	HX_STACK_PUSH("NestedCellBuilder::update","coopy/NestedCellBuilder.hx",28);
	HX_STACK_THIS(this);
	HX_STACK_ARG(local,"local");
	HX_STACK_ARG(remote,"remote");
	HX_STACK_LINE(29)
	Dynamic h = this->view->makeHash();		HX_STACK_VAR(h,"h");
	HX_STACK_LINE(30)
	this->view->hashSet(h,HX_CSTRING("before"),local);
	HX_STACK_LINE(31)
	this->view->hashSet(h,HX_CSTRING("after"),remote);
	HX_STACK_LINE(32)
	return h;
}


HX_DEFINE_DYNAMIC_FUNC2(NestedCellBuilder_obj,update,return )

Void NestedCellBuilder_obj::setView( ::coopy::View view){
{
		HX_STACK_PUSH("NestedCellBuilder::setView","coopy/NestedCellBuilder.hx",24);
		HX_STACK_THIS(this);
		HX_STACK_ARG(view,"view");
		HX_STACK_LINE(24)
		this->view = view;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(NestedCellBuilder_obj,setView,(void))

Void NestedCellBuilder_obj::setConflictSeparator( ::String separator){
{
		HX_STACK_PUSH("NestedCellBuilder::setConflictSeparator","coopy/NestedCellBuilder.hx",21);
		HX_STACK_THIS(this);
		HX_STACK_ARG(separator,"separator");
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(NestedCellBuilder_obj,setConflictSeparator,(void))

Void NestedCellBuilder_obj::setSeparator( ::String separator){
{
		HX_STACK_PUSH("NestedCellBuilder::setSeparator","coopy/NestedCellBuilder.hx",18);
		HX_STACK_THIS(this);
		HX_STACK_ARG(separator,"separator");
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(NestedCellBuilder_obj,setSeparator,(void))

bool NestedCellBuilder_obj::needSeparator( ){
	HX_STACK_PUSH("NestedCellBuilder::needSeparator","coopy/NestedCellBuilder.hx",14);
	HX_STACK_THIS(this);
	HX_STACK_LINE(14)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC0(NestedCellBuilder_obj,needSeparator,return )


NestedCellBuilder_obj::NestedCellBuilder_obj()
{
}

void NestedCellBuilder_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(NestedCellBuilder);
	HX_MARK_MEMBER_NAME(view,"view");
	HX_MARK_END_CLASS();
}

void NestedCellBuilder_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(view,"view");
}

Dynamic NestedCellBuilder_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"view") ) { return view; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"links") ) { return links_dyn(); }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"marker") ) { return marker_dyn(); }
		if (HX_FIELD_EQ(inName,"update") ) { return update_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"setView") ) { return setView_dyn(); }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"conflict") ) { return conflict_dyn(); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"negToNull") ) { return negToNull_dyn(); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"setSeparator") ) { return setSeparator_dyn(); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"needSeparator") ) { return needSeparator_dyn(); }
		break;
	case 20:
		if (HX_FIELD_EQ(inName,"setConflictSeparator") ) { return setConflictSeparator_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic NestedCellBuilder_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"view") ) { view=inValue.Cast< ::coopy::View >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void NestedCellBuilder_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("view"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("links"),
	HX_CSTRING("negToNull"),
	HX_CSTRING("marker"),
	HX_CSTRING("conflict"),
	HX_CSTRING("update"),
	HX_CSTRING("setView"),
	HX_CSTRING("setConflictSeparator"),
	HX_CSTRING("setSeparator"),
	HX_CSTRING("needSeparator"),
	HX_CSTRING("view"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(NestedCellBuilder_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(NestedCellBuilder_obj::__mClass,"__mClass");
};

Class NestedCellBuilder_obj::__mClass;

void NestedCellBuilder_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.NestedCellBuilder"), hx::TCanCast< NestedCellBuilder_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void NestedCellBuilder_obj::__boot()
{
}

} // end namespace coopy

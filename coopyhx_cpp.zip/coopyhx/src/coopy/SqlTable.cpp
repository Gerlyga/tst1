#include <hxcpp.h>

#ifndef INCLUDED_IMap
#include <IMap.h>
#endif
#ifndef INCLUDED_coopy_SimpleView
#include <coopy/SimpleView.h>
#endif
#ifndef INCLUDED_coopy_SqlColumn
#include <coopy/SqlColumn.h>
#endif
#ifndef INCLUDED_coopy_SqlDatabase
#include <coopy/SqlDatabase.h>
#endif
#ifndef INCLUDED_coopy_SqlHelper
#include <coopy/SqlHelper.h>
#endif
#ifndef INCLUDED_coopy_SqlTable
#include <coopy/SqlTable.h>
#endif
#ifndef INCLUDED_coopy_SqlTableName
#include <coopy/SqlTableName.h>
#endif
#ifndef INCLUDED_coopy_Table
#include <coopy/Table.h>
#endif
#ifndef INCLUDED_coopy_View
#include <coopy/View.h>
#endif
#ifndef INCLUDED_haxe_Log
#include <haxe/Log.h>
#endif
#ifndef INCLUDED_haxe_ds_IntMap
#include <haxe/ds/IntMap.h>
#endif
namespace coopy{

Void SqlTable_obj::__construct(::coopy::SqlDatabase db,::coopy::SqlTableName name,::coopy::SqlHelper helper)
{
HX_STACK_PUSH("SqlTable::new","coopy/SqlTable.hx",29);
{
	HX_STACK_LINE(30)
	this->db = db;
	HX_STACK_LINE(31)
	this->name = name;
	HX_STACK_LINE(32)
	this->helper = helper;
	HX_STACK_LINE(33)
	this->cache = ::haxe::ds::IntMap_obj::__new();
	HX_STACK_LINE(34)
	this->h = (int)-1;
	HX_STACK_LINE(35)
	this->id2rid = null();
	HX_STACK_LINE(36)
	this->getColumns();
}
;
	return null();
}

SqlTable_obj::~SqlTable_obj() { }

Dynamic SqlTable_obj::__CreateEmpty() { return  new SqlTable_obj; }
hx::ObjectPtr< SqlTable_obj > SqlTable_obj::__new(::coopy::SqlDatabase db,::coopy::SqlTableName name,::coopy::SqlHelper helper)
{  hx::ObjectPtr< SqlTable_obj > result = new SqlTable_obj();
	result->__construct(db,name,helper);
	return result;}

Dynamic SqlTable_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< SqlTable_obj > result = new SqlTable_obj();
	result->__construct(inArgs[0],inArgs[1],inArgs[2]);
	return result;}

hx::Object *SqlTable_obj::__ToInterface(const hx::type_info &inType) {
	if (inType==typeid( ::coopy::Table_obj)) return operator ::coopy::Table_obj *();
	return super::__ToInterface(inType);
}

::coopy::Table SqlTable_obj::clone( ){
	HX_STACK_PUSH("SqlTable::clone","coopy/SqlTable.hx",162);
	HX_STACK_THIS(this);
	HX_STACK_LINE(162)
	return null();
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,clone,return )

Dynamic SqlTable_obj::getData( ){
	HX_STACK_PUSH("SqlTable::getData","coopy/SqlTable.hx",158);
	HX_STACK_THIS(this);
	HX_STACK_LINE(158)
	return null();
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,getData,return )

int SqlTable_obj::get_height( ){
	HX_STACK_PUSH("SqlTable::get_height","coopy/SqlTable.hx",150);
	HX_STACK_THIS(this);
	HX_STACK_LINE(151)
	if (((this->h >= (int)0))){
		HX_STACK_LINE(151)
		return this->h;
	}
	HX_STACK_LINE(152)
	if (((this->helper == null()))){
		HX_STACK_LINE(152)
		return (int)-1;
	}
	HX_STACK_LINE(153)
	this->id2rid = this->helper->getRowIDs(this->db,this->name);
	HX_STACK_LINE(154)
	this->h = (this->id2rid->length + (int)1);
	HX_STACK_LINE(155)
	return this->h;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,get_height,return )

int SqlTable_obj::get_width( ){
	HX_STACK_PUSH("SqlTable::get_width","coopy/SqlTable.hx",145);
	HX_STACK_THIS(this);
	HX_STACK_LINE(146)
	this->getColumns();
	HX_STACK_LINE(147)
	return this->columns->length;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,get_width,return )

bool SqlTable_obj::trimBlank( ){
	HX_STACK_PUSH("SqlTable::trimBlank","coopy/SqlTable.hx",138);
	HX_STACK_THIS(this);
	HX_STACK_LINE(138)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,trimBlank,return )

bool SqlTable_obj::insertOrDeleteColumns( Array< int > fate,int wfate){
	HX_STACK_PUSH("SqlTable::insertOrDeleteColumns","coopy/SqlTable.hx",134);
	HX_STACK_THIS(this);
	HX_STACK_ARG(fate,"fate");
	HX_STACK_ARG(wfate,"wfate");
	HX_STACK_LINE(134)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC2(SqlTable_obj,insertOrDeleteColumns,return )

bool SqlTable_obj::insertOrDeleteRows( Array< int > fate,int hfate){
	HX_STACK_PUSH("SqlTable::insertOrDeleteRows","coopy/SqlTable.hx",130);
	HX_STACK_THIS(this);
	HX_STACK_ARG(fate,"fate");
	HX_STACK_ARG(hfate,"hfate");
	HX_STACK_LINE(130)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC2(SqlTable_obj,insertOrDeleteRows,return )

Void SqlTable_obj::clear( ){
{
		HX_STACK_PUSH("SqlTable::clear","coopy/SqlTable.hx",127);
		HX_STACK_THIS(this);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,clear,(void))

bool SqlTable_obj::resize( int w,int h){
	HX_STACK_PUSH("SqlTable::resize","coopy/SqlTable.hx",123);
	HX_STACK_THIS(this);
	HX_STACK_ARG(w,"w");
	HX_STACK_ARG(h,"h");
	HX_STACK_LINE(123)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC2(SqlTable_obj,resize,return )

bool SqlTable_obj::isResizable( ){
	HX_STACK_PUSH("SqlTable::isResizable","coopy/SqlTable.hx",119);
	HX_STACK_THIS(this);
	HX_STACK_LINE(119)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,isResizable,return )

::coopy::View SqlTable_obj::getCellView( ){
	HX_STACK_PUSH("SqlTable::getCellView","coopy/SqlTable.hx",115);
	HX_STACK_THIS(this);
	HX_STACK_LINE(115)
	return ::coopy::SimpleView_obj::__new();
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,getCellView,return )

Void SqlTable_obj::setCell( int x,int y,Dynamic c){
{
		HX_STACK_PUSH("SqlTable::setCell","coopy/SqlTable.hx",111);
		HX_STACK_THIS(this);
		HX_STACK_ARG(x,"x");
		HX_STACK_ARG(y,"y");
		HX_STACK_ARG(c,"c");
		HX_STACK_LINE(111)
		::haxe::Log_obj::trace(HX_CSTRING("SqlTable cannot set cells yet"),hx::SourceInfo(HX_CSTRING("SqlTable.hx"),112,HX_CSTRING("coopy.SqlTable"),HX_CSTRING("setCell")));
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(SqlTable_obj,setCell,(void))

Void SqlTable_obj::setCellCache( int x,int y,Dynamic c){
{
		HX_STACK_PUSH("SqlTable::setCellCache","coopy/SqlTable.hx",101);
		HX_STACK_THIS(this);
		HX_STACK_ARG(x,"x");
		HX_STACK_ARG(y,"y");
		HX_STACK_ARG(c,"c");
		HX_STACK_LINE(102)
		::haxe::ds::IntMap row = this->cache->get(y);		HX_STACK_VAR(row,"row");
		HX_STACK_LINE(103)
		if (((row == null()))){
			HX_STACK_LINE(104)
			row = ::haxe::ds::IntMap_obj::__new();
			HX_STACK_LINE(105)
			this->getColumns();
			HX_STACK_LINE(106)
			{
				HX_STACK_LINE(106)
				this->cache->set(y,row);
				HX_STACK_LINE(106)
				row;
			}
		}
		HX_STACK_LINE(108)
		{
			HX_STACK_LINE(108)
			Dynamic v = c;		HX_STACK_VAR(v,"v");
			HX_STACK_LINE(108)
			row->set(x,v);
			HX_STACK_LINE(108)
			v;
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(SqlTable_obj,setCellCache,(void))

Dynamic SqlTable_obj::getCell( int x,int y){
	HX_STACK_PUSH("SqlTable::getCell","coopy/SqlTable.hx",74);
	HX_STACK_THIS(this);
	HX_STACK_ARG(x,"x");
	HX_STACK_ARG(y,"y");
	HX_STACK_LINE(75)
	if (((this->h >= (int)0))){
		HX_STACK_LINE(76)
		y = (y - (int)1);
		HX_STACK_LINE(77)
		if (((y >= (int)0))){
			HX_STACK_LINE(77)
			y = this->id2rid->__get(y);
		}
	}
	HX_STACK_LINE(81)
	if (((y < (int)0))){
		HX_STACK_LINE(82)
		this->getColumns();
		HX_STACK_LINE(83)
		return this->columns->__get(x).StaticCast< ::coopy::SqlColumn >()->name;
	}
	HX_STACK_LINE(85)
	::haxe::ds::IntMap row = this->cache->get(y);		HX_STACK_VAR(row,"row");
	HX_STACK_LINE(86)
	if (((row == null()))){
		HX_STACK_LINE(87)
		row = ::haxe::ds::IntMap_obj::__new();
		HX_STACK_LINE(88)
		this->getColumns();
		HX_STACK_LINE(89)
		this->db->beginRow(this->name,y,this->columnNames);
		HX_STACK_LINE(90)
		while((this->db->read())){
			HX_STACK_LINE(91)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = this->get_width();		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(91)
			while(((_g1 < _g))){
				HX_STACK_LINE(91)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(92)
				{
					HX_STACK_LINE(92)
					Dynamic v = this->db->get(i);		HX_STACK_VAR(v,"v");
					HX_STACK_LINE(92)
					row->set(i,v);
					HX_STACK_LINE(92)
					v;
				}
			}
		}
		HX_STACK_LINE(95)
		this->db->end();
		HX_STACK_LINE(96)
		{
			HX_STACK_LINE(96)
			this->cache->set(y,row);
			HX_STACK_LINE(96)
			row;
		}
	}
	HX_STACK_LINE(98)
	return this->cache->get(y)->__Field(HX_CSTRING("get"),true)(x);
}


HX_DEFINE_DYNAMIC_FUNC2(SqlTable_obj,getCell,return )

::String SqlTable_obj::getQuotedColumnName( ::String name){
	HX_STACK_PUSH("SqlTable::getQuotedColumnName","coopy/SqlTable.hx",70);
	HX_STACK_THIS(this);
	HX_STACK_ARG(name,"name");
	HX_STACK_LINE(70)
	return this->db->getQuotedColumnName(name);
}


HX_DEFINE_DYNAMIC_FUNC1(SqlTable_obj,getQuotedColumnName,return )

::String SqlTable_obj::getQuotedTableName( ){
	HX_STACK_PUSH("SqlTable::getQuotedTableName","coopy/SqlTable.hx",64);
	HX_STACK_THIS(this);
	HX_STACK_LINE(65)
	if (((this->quotedTableName != null()))){
		HX_STACK_LINE(65)
		return this->quotedTableName;
	}
	HX_STACK_LINE(66)
	this->quotedTableName = this->db->getQuotedTableName(this->name);
	HX_STACK_LINE(67)
	return this->quotedTableName;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,getQuotedTableName,return )

Array< ::String > SqlTable_obj::getColumnNames( ){
	HX_STACK_PUSH("SqlTable::getColumnNames","coopy/SqlTable.hx",59);
	HX_STACK_THIS(this);
	HX_STACK_LINE(60)
	this->getColumns();
	HX_STACK_LINE(61)
	return this->columnNames;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,getColumnNames,return )

Array< ::String > SqlTable_obj::getAllButPrimaryKey( ){
	HX_STACK_PUSH("SqlTable::getAllButPrimaryKey","coopy/SqlTable.hx",49);
	HX_STACK_THIS(this);
	HX_STACK_LINE(50)
	this->getColumns();
	HX_STACK_LINE(51)
	Array< ::String > result = Array_obj< ::String >::__new();		HX_STACK_VAR(result,"result");
	HX_STACK_LINE(52)
	{
		HX_STACK_LINE(52)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		Array< ::Dynamic > _g1 = this->columns;		HX_STACK_VAR(_g1,"_g1");
		HX_STACK_LINE(52)
		while(((_g < _g1->length))){
			HX_STACK_LINE(52)
			::coopy::SqlColumn col = _g1->__get(_g).StaticCast< ::coopy::SqlColumn >();		HX_STACK_VAR(col,"col");
			HX_STACK_LINE(52)
			++(_g);
			HX_STACK_LINE(53)
			if ((col->isPrimaryKey())){
				HX_STACK_LINE(53)
				continue;
			}
			HX_STACK_LINE(54)
			result->push(col->getName());
		}
	}
	HX_STACK_LINE(56)
	return result;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,getAllButPrimaryKey,return )

Array< ::String > SqlTable_obj::getPrimaryKey( ){
	HX_STACK_PUSH("SqlTable::getPrimaryKey","coopy/SqlTable.hx",39);
	HX_STACK_THIS(this);
	HX_STACK_LINE(40)
	this->getColumns();
	HX_STACK_LINE(41)
	Array< ::String > result = Array_obj< ::String >::__new();		HX_STACK_VAR(result,"result");
	HX_STACK_LINE(42)
	{
		HX_STACK_LINE(42)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		Array< ::Dynamic > _g1 = this->columns;		HX_STACK_VAR(_g1,"_g1");
		HX_STACK_LINE(42)
		while(((_g < _g1->length))){
			HX_STACK_LINE(42)
			::coopy::SqlColumn col = _g1->__get(_g).StaticCast< ::coopy::SqlColumn >();		HX_STACK_VAR(col,"col");
			HX_STACK_LINE(42)
			++(_g);
			HX_STACK_LINE(43)
			if ((!(col->isPrimaryKey()))){
				HX_STACK_LINE(43)
				continue;
			}
			HX_STACK_LINE(44)
			result->push(col->getName());
		}
	}
	HX_STACK_LINE(46)
	return result;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,getPrimaryKey,return )

Void SqlTable_obj::getColumns( ){
{
		HX_STACK_PUSH("SqlTable::getColumns","coopy/SqlTable.hx",19);
		HX_STACK_THIS(this);
		HX_STACK_LINE(20)
		if (((this->columns != null()))){
			HX_STACK_LINE(20)
			return null();
		}
		HX_STACK_LINE(21)
		if (((this->db == null()))){
			HX_STACK_LINE(21)
			return null();
		}
		HX_STACK_LINE(22)
		this->columns = this->db->getColumns(this->name);
		HX_STACK_LINE(23)
		this->columnNames = Array_obj< ::String >::__new();
		HX_STACK_LINE(24)
		{
			HX_STACK_LINE(24)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			Array< ::Dynamic > _g1 = this->columns;		HX_STACK_VAR(_g1,"_g1");
			HX_STACK_LINE(24)
			while(((_g < _g1->length))){
				HX_STACK_LINE(24)
				::coopy::SqlColumn col = _g1->__get(_g).StaticCast< ::coopy::SqlColumn >();		HX_STACK_VAR(col,"col");
				HX_STACK_LINE(24)
				++(_g);
				HX_STACK_LINE(25)
				this->columnNames->push(col->getName());
			}
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTable_obj,getColumns,(void))


SqlTable_obj::SqlTable_obj()
{
}

void SqlTable_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(SqlTable);
	HX_MARK_MEMBER_NAME(id2rid,"id2rid");
	HX_MARK_MEMBER_NAME(helper,"helper");
	HX_MARK_MEMBER_NAME(h,"h");
	HX_MARK_MEMBER_NAME(columnNames,"columnNames");
	HX_MARK_MEMBER_NAME(cache,"cache");
	HX_MARK_MEMBER_NAME(quotedTableName,"quotedTableName");
	HX_MARK_MEMBER_NAME(name,"name");
	HX_MARK_MEMBER_NAME(columns,"columns");
	HX_MARK_MEMBER_NAME(db,"db");
	HX_MARK_END_CLASS();
}

void SqlTable_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(id2rid,"id2rid");
	HX_VISIT_MEMBER_NAME(helper,"helper");
	HX_VISIT_MEMBER_NAME(h,"h");
	HX_VISIT_MEMBER_NAME(columnNames,"columnNames");
	HX_VISIT_MEMBER_NAME(cache,"cache");
	HX_VISIT_MEMBER_NAME(quotedTableName,"quotedTableName");
	HX_VISIT_MEMBER_NAME(name,"name");
	HX_VISIT_MEMBER_NAME(columns,"columns");
	HX_VISIT_MEMBER_NAME(db,"db");
}

Dynamic SqlTable_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 1:
		if (HX_FIELD_EQ(inName,"h") ) { return h; }
		break;
	case 2:
		if (HX_FIELD_EQ(inName,"db") ) { return db; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { return name; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"clone") ) { return clone_dyn(); }
		if (HX_FIELD_EQ(inName,"width") ) { return get_width(); }
		if (HX_FIELD_EQ(inName,"clear") ) { return clear_dyn(); }
		if (HX_FIELD_EQ(inName,"cache") ) { return cache; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"height") ) { return get_height(); }
		if (HX_FIELD_EQ(inName,"resize") ) { return resize_dyn(); }
		if (HX_FIELD_EQ(inName,"id2rid") ) { return id2rid; }
		if (HX_FIELD_EQ(inName,"helper") ) { return helper; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"getData") ) { return getData_dyn(); }
		if (HX_FIELD_EQ(inName,"setCell") ) { return setCell_dyn(); }
		if (HX_FIELD_EQ(inName,"getCell") ) { return getCell_dyn(); }
		if (HX_FIELD_EQ(inName,"columns") ) { return columns; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"get_width") ) { return get_width_dyn(); }
		if (HX_FIELD_EQ(inName,"trimBlank") ) { return trimBlank_dyn(); }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"get_height") ) { return get_height_dyn(); }
		if (HX_FIELD_EQ(inName,"getColumns") ) { return getColumns_dyn(); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"isResizable") ) { return isResizable_dyn(); }
		if (HX_FIELD_EQ(inName,"getCellView") ) { return getCellView_dyn(); }
		if (HX_FIELD_EQ(inName,"columnNames") ) { return columnNames; }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"setCellCache") ) { return setCellCache_dyn(); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"getPrimaryKey") ) { return getPrimaryKey_dyn(); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"getColumnNames") ) { return getColumnNames_dyn(); }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"quotedTableName") ) { return quotedTableName; }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"insertOrDeleteRows") ) { return insertOrDeleteRows_dyn(); }
		if (HX_FIELD_EQ(inName,"getQuotedTableName") ) { return getQuotedTableName_dyn(); }
		break;
	case 19:
		if (HX_FIELD_EQ(inName,"getQuotedColumnName") ) { return getQuotedColumnName_dyn(); }
		if (HX_FIELD_EQ(inName,"getAllButPrimaryKey") ) { return getAllButPrimaryKey_dyn(); }
		break;
	case 21:
		if (HX_FIELD_EQ(inName,"insertOrDeleteColumns") ) { return insertOrDeleteColumns_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic SqlTable_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 1:
		if (HX_FIELD_EQ(inName,"h") ) { h=inValue.Cast< int >(); return inValue; }
		break;
	case 2:
		if (HX_FIELD_EQ(inName,"db") ) { db=inValue.Cast< ::coopy::SqlDatabase >(); return inValue; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { name=inValue.Cast< ::coopy::SqlTableName >(); return inValue; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"cache") ) { cache=inValue.Cast< ::haxe::ds::IntMap >(); return inValue; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"id2rid") ) { id2rid=inValue.Cast< Array< int > >(); return inValue; }
		if (HX_FIELD_EQ(inName,"helper") ) { helper=inValue.Cast< ::coopy::SqlHelper >(); return inValue; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"columns") ) { columns=inValue.Cast< Array< ::Dynamic > >(); return inValue; }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"columnNames") ) { columnNames=inValue.Cast< Array< ::String > >(); return inValue; }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"quotedTableName") ) { quotedTableName=inValue.Cast< ::String >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void SqlTable_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("width"));
	outFields->push(HX_CSTRING("height"));
	outFields->push(HX_CSTRING("id2rid"));
	outFields->push(HX_CSTRING("helper"));
	outFields->push(HX_CSTRING("h"));
	outFields->push(HX_CSTRING("columnNames"));
	outFields->push(HX_CSTRING("cache"));
	outFields->push(HX_CSTRING("quotedTableName"));
	outFields->push(HX_CSTRING("name"));
	outFields->push(HX_CSTRING("columns"));
	outFields->push(HX_CSTRING("db"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("clone"),
	HX_CSTRING("getData"),
	HX_CSTRING("get_height"),
	HX_CSTRING("get_width"),
	HX_CSTRING("trimBlank"),
	HX_CSTRING("insertOrDeleteColumns"),
	HX_CSTRING("insertOrDeleteRows"),
	HX_CSTRING("clear"),
	HX_CSTRING("resize"),
	HX_CSTRING("isResizable"),
	HX_CSTRING("getCellView"),
	HX_CSTRING("setCell"),
	HX_CSTRING("setCellCache"),
	HX_CSTRING("getCell"),
	HX_CSTRING("getQuotedColumnName"),
	HX_CSTRING("getQuotedTableName"),
	HX_CSTRING("getColumnNames"),
	HX_CSTRING("getAllButPrimaryKey"),
	HX_CSTRING("getPrimaryKey"),
	HX_CSTRING("getColumns"),
	HX_CSTRING("id2rid"),
	HX_CSTRING("helper"),
	HX_CSTRING("h"),
	HX_CSTRING("columnNames"),
	HX_CSTRING("cache"),
	HX_CSTRING("quotedTableName"),
	HX_CSTRING("name"),
	HX_CSTRING("columns"),
	HX_CSTRING("db"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(SqlTable_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(SqlTable_obj::__mClass,"__mClass");
};

Class SqlTable_obj::__mClass;

void SqlTable_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.SqlTable"), hx::TCanCast< SqlTable_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void SqlTable_obj::__boot()
{
}

} // end namespace coopy

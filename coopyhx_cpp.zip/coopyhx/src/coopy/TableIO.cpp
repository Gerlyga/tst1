#include <hxcpp.h>

#ifndef INCLUDED_coopy_SqlDatabase
#include <coopy/SqlDatabase.h>
#endif
#ifndef INCLUDED_coopy_TableIO
#include <coopy/TableIO.h>
#endif
namespace coopy{

Void TableIO_obj::__construct()
{
HX_STACK_PUSH("TableIO::new","coopy/TableIO.hx",14);
{
}
;
	return null();
}

TableIO_obj::~TableIO_obj() { }

Dynamic TableIO_obj::__CreateEmpty() { return  new TableIO_obj; }
hx::ObjectPtr< TableIO_obj > TableIO_obj::__new()
{  hx::ObjectPtr< TableIO_obj > result = new TableIO_obj();
	result->__construct();
	return result;}

Dynamic TableIO_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< TableIO_obj > result = new TableIO_obj();
	result->__construct();
	return result;}

::coopy::SqlDatabase TableIO_obj::openSqliteDatabase( ::String path){
	HX_STACK_PUSH("TableIO::openSqliteDatabase","coopy/TableIO.hx",136);
	HX_STACK_THIS(this);
	HX_STACK_ARG(path,"path");
	HX_STACK_LINE(136)
	return null();
}


HX_DEFINE_DYNAMIC_FUNC1(TableIO_obj,openSqliteDatabase,return )

bool TableIO_obj::exists( ::String path){
	HX_STACK_PUSH("TableIO::exists","coopy/TableIO.hx",121);
	HX_STACK_THIS(this);
	HX_STACK_ARG(path,"path");
	HX_STACK_LINE(121)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC1(TableIO_obj,exists,return )

bool TableIO_obj::async( ){
	HX_STACK_PUSH("TableIO::async","coopy/TableIO.hx",110);
	HX_STACK_THIS(this);
	HX_STACK_LINE(110)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC0(TableIO_obj,async,return )

int TableIO_obj::command( ::String cmd,Array< ::String > args){
	HX_STACK_PUSH("TableIO::command","coopy/TableIO.hx",92);
	HX_STACK_THIS(this);
	HX_STACK_ARG(cmd,"cmd");
	HX_STACK_ARG(args,"args");
	HX_STACK_LINE(92)
	return (int)1;
}


HX_DEFINE_DYNAMIC_FUNC2(TableIO_obj,command,return )

Void TableIO_obj::writeStderr( ::String txt){
{
		HX_STACK_PUSH("TableIO::writeStderr","coopy/TableIO.hx",78);
		HX_STACK_THIS(this);
		HX_STACK_ARG(txt,"txt");
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(TableIO_obj,writeStderr,(void))

Void TableIO_obj::writeStdout( ::String txt){
{
		HX_STACK_PUSH("TableIO::writeStdout","coopy/TableIO.hx",67);
		HX_STACK_THIS(this);
		HX_STACK_ARG(txt,"txt");
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(TableIO_obj,writeStdout,(void))

Array< ::String > TableIO_obj::args( ){
	HX_STACK_PUSH("TableIO::args","coopy/TableIO.hx",54);
	HX_STACK_THIS(this);
	HX_STACK_LINE(54)
	return Array_obj< ::String >::__new();
}


HX_DEFINE_DYNAMIC_FUNC0(TableIO_obj,args,return )

bool TableIO_obj::saveContent( ::String name,::String txt){
	HX_STACK_PUSH("TableIO::saveContent","coopy/TableIO.hx",40);
	HX_STACK_THIS(this);
	HX_STACK_ARG(name,"name");
	HX_STACK_ARG(txt,"txt");
	HX_STACK_LINE(40)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC2(TableIO_obj,saveContent,return )

::String TableIO_obj::getContent( ::String name){
	HX_STACK_PUSH("TableIO::getContent","coopy/TableIO.hx",24);
	HX_STACK_THIS(this);
	HX_STACK_ARG(name,"name");
	HX_STACK_LINE(24)
	return HX_CSTRING("");
}


HX_DEFINE_DYNAMIC_FUNC1(TableIO_obj,getContent,return )


TableIO_obj::TableIO_obj()
{
}

void TableIO_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(TableIO);
	HX_MARK_END_CLASS();
}

void TableIO_obj::__Visit(HX_VISIT_PARAMS)
{
}

Dynamic TableIO_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"args") ) { return args_dyn(); }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"async") ) { return async_dyn(); }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"exists") ) { return exists_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"command") ) { return command_dyn(); }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"getContent") ) { return getContent_dyn(); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"writeStderr") ) { return writeStderr_dyn(); }
		if (HX_FIELD_EQ(inName,"writeStdout") ) { return writeStdout_dyn(); }
		if (HX_FIELD_EQ(inName,"saveContent") ) { return saveContent_dyn(); }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"openSqliteDatabase") ) { return openSqliteDatabase_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic TableIO_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	return super::__SetField(inName,inValue,inCallProp);
}

void TableIO_obj::__GetFields(Array< ::String> &outFields)
{
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("openSqliteDatabase"),
	HX_CSTRING("exists"),
	HX_CSTRING("async"),
	HX_CSTRING("command"),
	HX_CSTRING("writeStderr"),
	HX_CSTRING("writeStdout"),
	HX_CSTRING("args"),
	HX_CSTRING("saveContent"),
	HX_CSTRING("getContent"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(TableIO_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(TableIO_obj::__mClass,"__mClass");
};

Class TableIO_obj::__mClass;

void TableIO_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.TableIO"), hx::TCanCast< TableIO_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void TableIO_obj::__boot()
{
}

} // end namespace coopy

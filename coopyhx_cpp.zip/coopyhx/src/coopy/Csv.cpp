#include <hxcpp.h>

#ifndef INCLUDED_coopy_Csv
#include <coopy/Csv.h>
#endif
#ifndef INCLUDED_coopy_SimpleTable
#include <coopy/SimpleTable.h>
#endif
#ifndef INCLUDED_coopy_Table
#include <coopy/Table.h>
#endif
#ifndef INCLUDED_coopy_View
#include <coopy/View.h>
#endif
namespace coopy{

Void Csv_obj::__construct(::String __o_delim)
{
HX_STACK_PUSH("Csv::new","coopy/Csv.hx",27);
::String delim = __o_delim.Default(HX_CSTRING(","));
{
	HX_STACK_LINE(28)
	this->cursor = (int)0;
	HX_STACK_LINE(29)
	this->row_ended = false;
	HX_STACK_LINE(30)
	this->delim = (  (((delim == null()))) ? ::String(HX_CSTRING(",")) : ::String(delim) );
}
;
	return null();
}

Csv_obj::~Csv_obj() { }

Dynamic Csv_obj::__CreateEmpty() { return  new Csv_obj; }
hx::ObjectPtr< Csv_obj > Csv_obj::__new(::String __o_delim)
{  hx::ObjectPtr< Csv_obj > result = new Csv_obj();
	result->__construct(__o_delim);
	return result;}

Dynamic Csv_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< Csv_obj > result = new Csv_obj();
	result->__construct(inArgs[0]);
	return result;}

::String Csv_obj::parseCell( ::String txt){
	HX_STACK_PUSH("Csv::parseCell","coopy/Csv.hx",237);
	HX_STACK_THIS(this);
	HX_STACK_ARG(txt,"txt");
	HX_STACK_LINE(238)
	this->cursor = (int)0;
	HX_STACK_LINE(239)
	this->row_ended = false;
	HX_STACK_LINE(240)
	this->has_structure = false;
	HX_STACK_LINE(241)
	return this->parseCellPart(txt);
}


HX_DEFINE_DYNAMIC_FUNC1(Csv_obj,parseCell,return )

::String Csv_obj::parseCellPart( ::String txt){
	HX_STACK_PUSH("Csv::parseCellPart","coopy/Csv.hx",160);
	HX_STACK_THIS(this);
	HX_STACK_ARG(txt,"txt");
	HX_STACK_LINE(161)
	if (((txt == null()))){
		HX_STACK_LINE(161)
		return null();
	}
	HX_STACK_LINE(162)
	this->row_ended = false;
	HX_STACK_LINE(163)
	int first_non_underscore = txt.length;		HX_STACK_VAR(first_non_underscore,"first_non_underscore");
	HX_STACK_LINE(164)
	int last_processed = (int)0;		HX_STACK_VAR(last_processed,"last_processed");
	HX_STACK_LINE(165)
	bool quoting = false;		HX_STACK_VAR(quoting,"quoting");
	HX_STACK_LINE(166)
	int quote = (int)0;		HX_STACK_VAR(quote,"quote");
	HX_STACK_LINE(167)
	::String result = HX_CSTRING("");		HX_STACK_VAR(result,"result");
	HX_STACK_LINE(168)
	int start = this->cursor;		HX_STACK_VAR(start,"start");
	HX_STACK_LINE(169)
	{
		HX_STACK_LINE(169)
		int _g1 = this->cursor;		HX_STACK_VAR(_g1,"_g1");
		int _g = txt.length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(169)
		while(((_g1 < _g))){
			HX_STACK_LINE(169)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(170)
			int ch = txt.charCodeAt(i);		HX_STACK_VAR(ch,"ch");
			HX_STACK_LINE(171)
			last_processed = i;
			HX_STACK_LINE(172)
			if (((bool((ch != (int)95)) && bool((i < first_non_underscore))))){
				HX_STACK_LINE(172)
				first_non_underscore = i;
			}
			HX_STACK_LINE(175)
			if ((this->has_structure)){
				HX_STACK_LINE(176)
				if ((!(quoting))){
					HX_STACK_LINE(177)
					if (((ch == this->delim.charCodeAt((int)0)))){
						HX_STACK_LINE(177)
						break;
					}
					HX_STACK_LINE(180)
					if (((bool((ch == (int)13)) || bool((ch == (int)10))))){
						HX_STACK_LINE(181)
						Dynamic ch2 = txt.charCodeAt((i + (int)1));		HX_STACK_VAR(ch2,"ch2");
						HX_STACK_LINE(182)
						if (((ch2 != null()))){
							HX_STACK_LINE(182)
							if (((ch2 != ch))){
								HX_STACK_LINE(183)
								if (((bool((ch2 == (int)13)) || bool((ch2 == (int)10))))){
									HX_STACK_LINE(184)
									(last_processed)++;
								}
							}
						}
						HX_STACK_LINE(189)
						this->row_ended = true;
						HX_STACK_LINE(190)
						break;
					}
					HX_STACK_LINE(192)
					if (((bool((ch == (int)34)) || bool((ch == (int)39))))){
						HX_STACK_LINE(192)
						if (((i == this->cursor))){
							HX_STACK_LINE(194)
							quoting = true;
							HX_STACK_LINE(195)
							quote = ch;
							HX_STACK_LINE(196)
							if (((i != start))){
								HX_STACK_LINE(196)
								hx::AddEq(result,::String::fromCharCode(ch));
							}
							HX_STACK_LINE(199)
							continue;
						}
						else{
							HX_STACK_LINE(200)
							if (((ch == quote))){
								HX_STACK_LINE(200)
								quoting = true;
							}
						}
					}
					HX_STACK_LINE(204)
					hx::AddEq(result,::String::fromCharCode(ch));
					HX_STACK_LINE(205)
					continue;
				}
				HX_STACK_LINE(207)
				if (((ch == quote))){
					HX_STACK_LINE(208)
					quoting = false;
					HX_STACK_LINE(209)
					continue;
				}
			}
			HX_STACK_LINE(212)
			hx::AddEq(result,::String::fromCharCode(ch));
		}
	}
	HX_STACK_LINE(214)
	this->cursor = last_processed;
	HX_STACK_LINE(215)
	if (((quote == (int)0))){
		HX_STACK_LINE(216)
		if (((result == HX_CSTRING("NULL")))){
			HX_STACK_LINE(216)
			return null();
		}
		HX_STACK_LINE(219)
		if (((first_non_underscore > start))){
			HX_STACK_LINE(220)
			int del = (first_non_underscore - start);		HX_STACK_VAR(del,"del");
			HX_STACK_LINE(221)
			if (((result.substr(del,null()) == HX_CSTRING("NULL")))){
				HX_STACK_LINE(221)
				return result.substr((int)1,null());
			}
		}
	}
	HX_STACK_LINE(226)
	return result;
}


HX_DEFINE_DYNAMIC_FUNC1(Csv_obj,parseCellPart,return )

::coopy::Table Csv_obj::makeTable( ::String txt){
	HX_STACK_PUSH("Csv::makeTable","coopy/Csv.hx",153);
	HX_STACK_THIS(this);
	HX_STACK_ARG(txt,"txt");
	HX_STACK_LINE(154)
	::coopy::SimpleTable tab = ::coopy::SimpleTable_obj::__new((int)0,(int)0);		HX_STACK_VAR(tab,"tab");
	HX_STACK_LINE(155)
	this->parseTable(txt,tab);
	HX_STACK_LINE(156)
	return tab;
}


HX_DEFINE_DYNAMIC_FUNC1(Csv_obj,makeTable,return )

bool Csv_obj::parseTable( ::String txt,::coopy::Table tab){
	HX_STACK_PUSH("Csv::parseTable","coopy/Csv.hx",113);
	HX_STACK_THIS(this);
	HX_STACK_ARG(txt,"txt");
	HX_STACK_ARG(tab,"tab");
	HX_STACK_LINE(114)
	if ((!(tab->isResizable()))){
		HX_STACK_LINE(114)
		return false;
	}
	HX_STACK_LINE(115)
	this->cursor = (int)0;
	HX_STACK_LINE(116)
	this->row_ended = false;
	HX_STACK_LINE(117)
	this->has_structure = true;
	HX_STACK_LINE(118)
	tab->resize((int)0,(int)0);
	HX_STACK_LINE(119)
	int w = (int)0;		HX_STACK_VAR(w,"w");
	HX_STACK_LINE(120)
	int h = (int)0;		HX_STACK_VAR(h,"h");
	HX_STACK_LINE(121)
	int at = (int)0;		HX_STACK_VAR(at,"at");
	HX_STACK_LINE(122)
	int yat = (int)0;		HX_STACK_VAR(yat,"yat");
	HX_STACK_LINE(123)
	while(((this->cursor < txt.length))){
		HX_STACK_LINE(124)
		::String cell = this->parseCellPart(txt);		HX_STACK_VAR(cell,"cell");
		HX_STACK_LINE(125)
		if (((yat >= h))){
			HX_STACK_LINE(126)
			h = (yat + (int)1);
			HX_STACK_LINE(127)
			tab->resize(w,h);
		}
		HX_STACK_LINE(129)
		if (((at >= w))){
			HX_STACK_LINE(130)
			w = (at + (int)1);
			HX_STACK_LINE(131)
			tab->resize(w,h);
		}
		HX_STACK_LINE(133)
		tab->setCell(at,(h - (int)1),cell);
		HX_STACK_LINE(134)
		(at)++;
		HX_STACK_LINE(135)
		if ((this->row_ended)){
			HX_STACK_LINE(136)
			at = (int)0;
			HX_STACK_LINE(137)
			(yat)++;
		}
		HX_STACK_LINE(139)
		(this->cursor)++;
	}
	HX_STACK_LINE(141)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC2(Csv_obj,parseTable,return )

::String Csv_obj::renderCell( ::coopy::View v,Dynamic d){
	HX_STACK_PUSH("Csv::renderCell","coopy/Csv.hx",68);
	HX_STACK_THIS(this);
	HX_STACK_ARG(v,"v");
	HX_STACK_ARG(d,"d");
	HX_STACK_LINE(69)
	if (((d == null()))){
		HX_STACK_LINE(69)
		return HX_CSTRING("NULL");
	}
	HX_STACK_LINE(72)
	::String str = v->toString(d);		HX_STACK_VAR(str,"str");
	HX_STACK_LINE(73)
	bool need_quote = false;		HX_STACK_VAR(need_quote,"need_quote");
	HX_STACK_LINE(74)
	{
		HX_STACK_LINE(74)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = str.length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(74)
		while(((_g1 < _g))){
			HX_STACK_LINE(74)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(75)
			::String ch = str.charAt(i);		HX_STACK_VAR(ch,"ch");
			HX_STACK_LINE(76)
			if (((bool((bool((bool((bool((bool((bool((ch == HX_CSTRING("\""))) || bool((ch == HX_CSTRING("'"))))) || bool((ch == this->delim)))) || bool((ch == HX_CSTRING("\r"))))) || bool((ch == HX_CSTRING("\n"))))) || bool((ch == HX_CSTRING("\t"))))) || bool((ch == HX_CSTRING(" ")))))){
				HX_STACK_LINE(77)
				need_quote = true;
				HX_STACK_LINE(78)
				break;
			}
		}
	}
	HX_STACK_LINE(82)
	::String result = HX_CSTRING("");		HX_STACK_VAR(result,"result");
	HX_STACK_LINE(83)
	if ((need_quote)){
		HX_STACK_LINE(83)
		hx::AddEq(result,HX_CSTRING("\""));
	}
	HX_STACK_LINE(84)
	::String line_buf = HX_CSTRING("");		HX_STACK_VAR(line_buf,"line_buf");
	HX_STACK_LINE(85)
	{
		HX_STACK_LINE(85)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = str.length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(85)
		while(((_g1 < _g))){
			HX_STACK_LINE(85)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(86)
			::String ch = str.charAt(i);		HX_STACK_VAR(ch,"ch");
			HX_STACK_LINE(87)
			if (((ch == HX_CSTRING("\"")))){
				HX_STACK_LINE(87)
				hx::AddEq(result,HX_CSTRING("\""));
			}
			HX_STACK_LINE(90)
			if (((bool((ch != HX_CSTRING("\r"))) && bool((ch != HX_CSTRING("\n")))))){
				HX_STACK_LINE(91)
				if (((line_buf.length > (int)0))){
					HX_STACK_LINE(92)
					hx::AddEq(result,line_buf);
					HX_STACK_LINE(93)
					line_buf = HX_CSTRING("");
				}
				HX_STACK_LINE(95)
				hx::AddEq(result,ch);
			}
			else{
				HX_STACK_LINE(96)
				hx::AddEq(line_buf,ch);
			}
		}
	}
	HX_STACK_LINE(100)
	if ((need_quote)){
		HX_STACK_LINE(100)
		hx::AddEq(result,HX_CSTRING("\""));
	}
	HX_STACK_LINE(101)
	return result;
}


HX_DEFINE_DYNAMIC_FUNC2(Csv_obj,renderCell,return )

::String Csv_obj::renderTable( ::coopy::Table t){
	HX_STACK_PUSH("Csv::renderTable","coopy/Csv.hx",41);
	HX_STACK_THIS(this);
	HX_STACK_ARG(t,"t");
	HX_STACK_LINE(42)
	::String result = HX_CSTRING("");		HX_STACK_VAR(result,"result");
	HX_STACK_LINE(43)
	int w = t->get_width();		HX_STACK_VAR(w,"w");
	HX_STACK_LINE(44)
	int h = t->get_height();		HX_STACK_VAR(h,"h");
	HX_STACK_LINE(45)
	::String txt = HX_CSTRING("");		HX_STACK_VAR(txt,"txt");
	HX_STACK_LINE(46)
	::coopy::View v = t->getCellView();		HX_STACK_VAR(v,"v");
	HX_STACK_LINE(47)
	{
		HX_STACK_LINE(47)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(47)
		while(((_g < h))){
			HX_STACK_LINE(47)
			int y = (_g)++;		HX_STACK_VAR(y,"y");
			HX_STACK_LINE(48)
			{
				HX_STACK_LINE(48)
				int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
				HX_STACK_LINE(48)
				while(((_g1 < w))){
					HX_STACK_LINE(48)
					int x = (_g1)++;		HX_STACK_VAR(x,"x");
					HX_STACK_LINE(49)
					if (((x > (int)0))){
						HX_STACK_LINE(49)
						hx::AddEq(txt,this->delim);
					}
					HX_STACK_LINE(52)
					hx::AddEq(txt,this->renderCell(v,t->getCell(x,y)));
				}
			}
			HX_STACK_LINE(54)
			hx::AddEq(txt,HX_CSTRING("\r\n"));
		}
	}
	HX_STACK_LINE(56)
	return txt;
}


HX_DEFINE_DYNAMIC_FUNC1(Csv_obj,renderTable,return )


Csv_obj::Csv_obj()
{
}

void Csv_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(Csv);
	HX_MARK_MEMBER_NAME(delim,"delim");
	HX_MARK_MEMBER_NAME(has_structure,"has_structure");
	HX_MARK_MEMBER_NAME(row_ended,"row_ended");
	HX_MARK_MEMBER_NAME(cursor,"cursor");
	HX_MARK_END_CLASS();
}

void Csv_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(delim,"delim");
	HX_VISIT_MEMBER_NAME(has_structure,"has_structure");
	HX_VISIT_MEMBER_NAME(row_ended,"row_ended");
	HX_VISIT_MEMBER_NAME(cursor,"cursor");
}

Dynamic Csv_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 5:
		if (HX_FIELD_EQ(inName,"delim") ) { return delim; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"cursor") ) { return cursor; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"parseCell") ) { return parseCell_dyn(); }
		if (HX_FIELD_EQ(inName,"makeTable") ) { return makeTable_dyn(); }
		if (HX_FIELD_EQ(inName,"row_ended") ) { return row_ended; }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"parseTable") ) { return parseTable_dyn(); }
		if (HX_FIELD_EQ(inName,"renderCell") ) { return renderCell_dyn(); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"renderTable") ) { return renderTable_dyn(); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"parseCellPart") ) { return parseCellPart_dyn(); }
		if (HX_FIELD_EQ(inName,"has_structure") ) { return has_structure; }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic Csv_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 5:
		if (HX_FIELD_EQ(inName,"delim") ) { delim=inValue.Cast< ::String >(); return inValue; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"cursor") ) { cursor=inValue.Cast< int >(); return inValue; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"row_ended") ) { row_ended=inValue.Cast< bool >(); return inValue; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"has_structure") ) { has_structure=inValue.Cast< bool >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void Csv_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("delim"));
	outFields->push(HX_CSTRING("has_structure"));
	outFields->push(HX_CSTRING("row_ended"));
	outFields->push(HX_CSTRING("cursor"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("parseCell"),
	HX_CSTRING("parseCellPart"),
	HX_CSTRING("makeTable"),
	HX_CSTRING("parseTable"),
	HX_CSTRING("renderCell"),
	HX_CSTRING("renderTable"),
	HX_CSTRING("delim"),
	HX_CSTRING("has_structure"),
	HX_CSTRING("row_ended"),
	HX_CSTRING("cursor"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Csv_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Csv_obj::__mClass,"__mClass");
};

Class Csv_obj::__mClass;

void Csv_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.Csv"), hx::TCanCast< Csv_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void Csv_obj::__boot()
{
}

} // end namespace coopy

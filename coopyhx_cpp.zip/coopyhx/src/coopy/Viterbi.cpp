#include <hxcpp.h>

#ifndef INCLUDED_coopy_SparseSheet
#include <coopy/SparseSheet.h>
#endif
#ifndef INCLUDED_coopy_Viterbi
#include <coopy/Viterbi.h>
#endif
#ifndef INCLUDED_haxe_Log
#include <haxe/Log.h>
#endif
namespace coopy{

Void Viterbi_obj::__construct()
{
HX_STACK_PUSH("Viterbi::new","coopy/Viterbi.hx",26);
{
	HX_STACK_LINE(27)
	this->K = this->T = (int)0;
	HX_STACK_LINE(28)
	this->reset();
	HX_STACK_LINE(29)
	this->cost = ::coopy::SparseSheet_obj::__new();
	HX_STACK_LINE(30)
	this->src = ::coopy::SparseSheet_obj::__new();
	HX_STACK_LINE(31)
	this->path = ::coopy::SparseSheet_obj::__new();
}
;
	return null();
}

Viterbi_obj::~Viterbi_obj() { }

Dynamic Viterbi_obj::__CreateEmpty() { return  new Viterbi_obj; }
hx::ObjectPtr< Viterbi_obj > Viterbi_obj::__new()
{  hx::ObjectPtr< Viterbi_obj > result = new Viterbi_obj();
	result->__construct();
	return result;}

Dynamic Viterbi_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< Viterbi_obj > result = new Viterbi_obj();
	result->__construct();
	return result;}

Float Viterbi_obj::getCost( ){
	HX_STACK_PUSH("Viterbi::getCost","coopy/Viterbi.hx",222);
	HX_STACK_THIS(this);
	HX_STACK_LINE(223)
	this->calculatePath();
	HX_STACK_LINE(224)
	return this->best_cost;
}


HX_DEFINE_DYNAMIC_FUNC0(Viterbi_obj,getCost,return )

int Viterbi_obj::get( int i){
	HX_STACK_PUSH("Viterbi::get","coopy/Viterbi.hx",212);
	HX_STACK_THIS(this);
	HX_STACK_ARG(i,"i");
	HX_STACK_LINE(213)
	this->calculatePath();
	HX_STACK_LINE(214)
	return this->path->get((int)0,i);
}


HX_DEFINE_DYNAMIC_FUNC1(Viterbi_obj,get,return )

int Viterbi_obj::length( ){
	HX_STACK_PUSH("Viterbi::length","coopy/Viterbi.hx",199);
	HX_STACK_THIS(this);
	HX_STACK_LINE(200)
	if (((this->index > (int)0))){
		HX_STACK_LINE(200)
		this->calculatePath();
	}
	HX_STACK_LINE(203)
	return this->index;
}


HX_DEFINE_DYNAMIC_FUNC0(Viterbi_obj,length,return )

::String Viterbi_obj::toString( ){
	HX_STACK_PUSH("Viterbi::toString","coopy/Viterbi.hx",179);
	HX_STACK_THIS(this);
	HX_STACK_LINE(180)
	this->calculatePath();
	HX_STACK_LINE(181)
	::String txt = HX_CSTRING("");		HX_STACK_VAR(txt,"txt");
	HX_STACK_LINE(182)
	{
		HX_STACK_LINE(182)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = this->index;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(182)
		while(((_g1 < _g))){
			HX_STACK_LINE(182)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(183)
			if (((this->path->get((int)0,i) == (int)-1))){
				HX_STACK_LINE(183)
				hx::AddEq(txt,HX_CSTRING("*"));
			}
			else{
				HX_STACK_LINE(185)
				hx::AddEq(txt,this->path->get((int)0,i));
			}
			HX_STACK_LINE(188)
			if (((this->K >= (int)10))){
				HX_STACK_LINE(188)
				hx::AddEq(txt,HX_CSTRING(" "));
			}
		}
	}
	HX_STACK_LINE(190)
	hx::AddEq(txt,(HX_CSTRING(" costs ") + this->getCost()));
	HX_STACK_LINE(191)
	return txt;
}


HX_DEFINE_DYNAMIC_FUNC0(Viterbi_obj,toString,return )

Void Viterbi_obj::calculatePath( ){
{
		HX_STACK_PUSH("Viterbi::calculatePath","coopy/Viterbi.hx",144);
		HX_STACK_THIS(this);
		HX_STACK_LINE(145)
		if ((this->path_valid)){
			HX_STACK_LINE(145)
			return null();
		}
		HX_STACK_LINE(146)
		this->endTransitions();
		HX_STACK_LINE(147)
		Float best = (int)0;		HX_STACK_VAR(best,"best");
		HX_STACK_LINE(148)
		int bestj = (int)-1;		HX_STACK_VAR(bestj,"bestj");
		HX_STACK_LINE(149)
		if (((this->index <= (int)0))){
			HX_STACK_LINE(151)
			this->path_valid = true;
			HX_STACK_LINE(152)
			return null();
		}
		HX_STACK_LINE(154)
		{
			HX_STACK_LINE(154)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = this->K;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(154)
			while(((_g1 < _g))){
				HX_STACK_LINE(154)
				int j = (_g1)++;		HX_STACK_VAR(j,"j");
				HX_STACK_LINE(155)
				if (((bool(((bool((this->cost->get(j,(this->index - (int)1)) < best)) || bool((bestj == (int)-1))))) && bool((this->src->get(j,(this->index - (int)1)) != (int)-1))))){
					HX_STACK_LINE(157)
					best = this->cost->get(j,(this->index - (int)1));
					HX_STACK_LINE(158)
					bestj = j;
				}
			}
		}
		HX_STACK_LINE(161)
		this->best_cost = best;
		HX_STACK_LINE(163)
		{
			HX_STACK_LINE(163)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = this->index;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(163)
			while(((_g1 < _g))){
				HX_STACK_LINE(163)
				int j = (_g1)++;		HX_STACK_VAR(j,"j");
				HX_STACK_LINE(164)
				int i = ((this->index - (int)1) - j);		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(165)
				this->path->set((int)0,i,bestj);
				HX_STACK_LINE(166)
				if ((!(((bool((bestj != (int)-1)) && bool(((bool((bestj >= (int)0)) && bool((bestj < this->K)))))))))){
					HX_STACK_LINE(166)
					::haxe::Log_obj::trace(HX_CSTRING("Problem in Viterbi"),hx::SourceInfo(HX_CSTRING("Viterbi.hx"),167,HX_CSTRING("coopy.Viterbi"),HX_CSTRING("calculatePath")));
				}
				HX_STACK_LINE(169)
				bestj = this->src->get(bestj,i);
			}
		}
		HX_STACK_LINE(171)
		this->path_valid = true;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(Viterbi_obj,calculatePath,(void))

Void Viterbi_obj::beginTransitions( ){
{
		HX_STACK_PUSH("Viterbi::beginTransitions","coopy/Viterbi.hx",134);
		HX_STACK_THIS(this);
		HX_STACK_LINE(135)
		this->path_valid = false;
		HX_STACK_LINE(136)
		this->assertMode((int)1);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(Viterbi_obj,beginTransitions,(void))

Void Viterbi_obj::endTransitions( ){
{
		HX_STACK_PUSH("Viterbi::endTransitions","coopy/Viterbi.hx",120);
		HX_STACK_THIS(this);
		HX_STACK_LINE(121)
		this->path_valid = false;
		HX_STACK_LINE(122)
		this->assertMode((int)0);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(Viterbi_obj,endTransitions,(void))

Void Viterbi_obj::addTransition( int s0,int s1,Float c){
{
		HX_STACK_PUSH("Viterbi::addTransition","coopy/Viterbi.hx",73);
		HX_STACK_THIS(this);
		HX_STACK_ARG(s0,"s0");
		HX_STACK_ARG(s1,"s1");
		HX_STACK_ARG(c,"c");
		HX_STACK_LINE(74)
		bool resize = false;		HX_STACK_VAR(resize,"resize");
		HX_STACK_LINE(75)
		if (((s0 >= this->K))){
			HX_STACK_LINE(76)
			this->K = (s0 + (int)1);
			HX_STACK_LINE(77)
			resize = true;
		}
		HX_STACK_LINE(79)
		if (((s1 >= this->K))){
			HX_STACK_LINE(80)
			this->K = (s1 + (int)1);
			HX_STACK_LINE(81)
			resize = true;
		}
		HX_STACK_LINE(83)
		if ((resize)){
			HX_STACK_LINE(84)
			this->cost->nonDestructiveResize(this->K,this->T,(int)0);
			HX_STACK_LINE(85)
			this->src->nonDestructiveResize(this->K,this->T,(int)-1);
			HX_STACK_LINE(86)
			this->path->nonDestructiveResize((int)1,this->T,(int)-1);
		}
		HX_STACK_LINE(88)
		this->path_valid = false;
		HX_STACK_LINE(89)
		this->assertMode((int)1);
		HX_STACK_LINE(90)
		if (((this->index >= this->T))){
			HX_STACK_LINE(91)
			this->T = (this->index + (int)1);
			HX_STACK_LINE(92)
			this->cost->nonDestructiveResize(this->K,this->T,(int)0);
			HX_STACK_LINE(93)
			this->src->nonDestructiveResize(this->K,this->T,(int)-1);
			HX_STACK_LINE(94)
			this->path->nonDestructiveResize((int)1,this->T,(int)-1);
		}
		HX_STACK_LINE(96)
		bool sourced = false;		HX_STACK_VAR(sourced,"sourced");
		HX_STACK_LINE(97)
		if (((this->index > (int)0))){
			HX_STACK_LINE(98)
			hx::AddEq(c,this->cost->get(s0,(this->index - (int)1)));
			HX_STACK_LINE(99)
			sourced = (this->src->get(s0,(this->index - (int)1)) != (int)-1);
		}
		else{
			HX_STACK_LINE(100)
			sourced = true;
		}
		HX_STACK_LINE(104)
		if ((sourced)){
			HX_STACK_LINE(104)
			if (((bool((c < this->cost->get(s1,this->index))) || bool((this->src->get(s1,this->index) == (int)-1))))){
				HX_STACK_LINE(106)
				this->cost->set(s1,this->index,c);
				HX_STACK_LINE(107)
				this->src->set(s1,this->index,s0);
			}
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(Viterbi_obj,addTransition,(void))

Void Viterbi_obj::assertMode( int next){
{
		HX_STACK_PUSH("Viterbi::assertMode","coopy/Viterbi.hx",62);
		HX_STACK_THIS(this);
		HX_STACK_ARG(next,"next");
		HX_STACK_LINE(63)
		if (((bool((next == (int)0)) && bool((this->mode == (int)1))))){
			HX_STACK_LINE(63)
			(this->index)++;
		}
		HX_STACK_LINE(64)
		this->mode = next;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(Viterbi_obj,assertMode,(void))

Void Viterbi_obj::setSize( int states,int sequence_length){
{
		HX_STACK_PUSH("Viterbi::setSize","coopy/Viterbi.hx",54);
		HX_STACK_THIS(this);
		HX_STACK_ARG(states,"states");
		HX_STACK_ARG(sequence_length,"sequence_length");
		HX_STACK_LINE(55)
		this->K = states;
		HX_STACK_LINE(56)
		this->T = sequence_length;
		HX_STACK_LINE(57)
		this->cost->resize(this->K,this->T,(int)0);
		HX_STACK_LINE(58)
		this->src->resize(this->K,this->T,(int)-1);
		HX_STACK_LINE(59)
		this->path->resize((int)1,this->T,(int)-1);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC2(Viterbi_obj,setSize,(void))

Void Viterbi_obj::reset( ){
{
		HX_STACK_PUSH("Viterbi::reset","coopy/Viterbi.hx",39);
		HX_STACK_THIS(this);
		HX_STACK_LINE(40)
		this->index = (int)0;
		HX_STACK_LINE(41)
		this->mode = (int)0;
		HX_STACK_LINE(42)
		this->path_valid = false;
		HX_STACK_LINE(43)
		this->best_cost = (int)0;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(Viterbi_obj,reset,(void))


Viterbi_obj::Viterbi_obj()
{
}

void Viterbi_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(Viterbi);
	HX_MARK_MEMBER_NAME(path,"path");
	HX_MARK_MEMBER_NAME(src,"src");
	HX_MARK_MEMBER_NAME(cost,"cost");
	HX_MARK_MEMBER_NAME(best_cost,"best_cost");
	HX_MARK_MEMBER_NAME(path_valid,"path_valid");
	HX_MARK_MEMBER_NAME(mode,"mode");
	HX_MARK_MEMBER_NAME(index,"index");
	HX_MARK_MEMBER_NAME(T,"T");
	HX_MARK_MEMBER_NAME(K,"K");
	HX_MARK_END_CLASS();
}

void Viterbi_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(path,"path");
	HX_VISIT_MEMBER_NAME(src,"src");
	HX_VISIT_MEMBER_NAME(cost,"cost");
	HX_VISIT_MEMBER_NAME(best_cost,"best_cost");
	HX_VISIT_MEMBER_NAME(path_valid,"path_valid");
	HX_VISIT_MEMBER_NAME(mode,"mode");
	HX_VISIT_MEMBER_NAME(index,"index");
	HX_VISIT_MEMBER_NAME(T,"T");
	HX_VISIT_MEMBER_NAME(K,"K");
}

Dynamic Viterbi_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 1:
		if (HX_FIELD_EQ(inName,"T") ) { return T; }
		if (HX_FIELD_EQ(inName,"K") ) { return K; }
		break;
	case 3:
		if (HX_FIELD_EQ(inName,"get") ) { return get_dyn(); }
		if (HX_FIELD_EQ(inName,"src") ) { return src; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"path") ) { return path; }
		if (HX_FIELD_EQ(inName,"cost") ) { return cost; }
		if (HX_FIELD_EQ(inName,"mode") ) { return mode; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"reset") ) { return reset_dyn(); }
		if (HX_FIELD_EQ(inName,"index") ) { return index; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"length") ) { return length_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"getCost") ) { return getCost_dyn(); }
		if (HX_FIELD_EQ(inName,"setSize") ) { return setSize_dyn(); }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"toString") ) { return toString_dyn(); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"best_cost") ) { return best_cost; }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"assertMode") ) { return assertMode_dyn(); }
		if (HX_FIELD_EQ(inName,"path_valid") ) { return path_valid; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"calculatePath") ) { return calculatePath_dyn(); }
		if (HX_FIELD_EQ(inName,"addTransition") ) { return addTransition_dyn(); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"endTransitions") ) { return endTransitions_dyn(); }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"beginTransitions") ) { return beginTransitions_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic Viterbi_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 1:
		if (HX_FIELD_EQ(inName,"T") ) { T=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"K") ) { K=inValue.Cast< int >(); return inValue; }
		break;
	case 3:
		if (HX_FIELD_EQ(inName,"src") ) { src=inValue.Cast< ::coopy::SparseSheet >(); return inValue; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"path") ) { path=inValue.Cast< ::coopy::SparseSheet >(); return inValue; }
		if (HX_FIELD_EQ(inName,"cost") ) { cost=inValue.Cast< ::coopy::SparseSheet >(); return inValue; }
		if (HX_FIELD_EQ(inName,"mode") ) { mode=inValue.Cast< int >(); return inValue; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"index") ) { index=inValue.Cast< int >(); return inValue; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"best_cost") ) { best_cost=inValue.Cast< Float >(); return inValue; }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"path_valid") ) { path_valid=inValue.Cast< bool >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void Viterbi_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("path"));
	outFields->push(HX_CSTRING("src"));
	outFields->push(HX_CSTRING("cost"));
	outFields->push(HX_CSTRING("best_cost"));
	outFields->push(HX_CSTRING("path_valid"));
	outFields->push(HX_CSTRING("mode"));
	outFields->push(HX_CSTRING("index"));
	outFields->push(HX_CSTRING("T"));
	outFields->push(HX_CSTRING("K"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("getCost"),
	HX_CSTRING("get"),
	HX_CSTRING("length"),
	HX_CSTRING("toString"),
	HX_CSTRING("calculatePath"),
	HX_CSTRING("beginTransitions"),
	HX_CSTRING("endTransitions"),
	HX_CSTRING("addTransition"),
	HX_CSTRING("assertMode"),
	HX_CSTRING("setSize"),
	HX_CSTRING("reset"),
	HX_CSTRING("path"),
	HX_CSTRING("src"),
	HX_CSTRING("cost"),
	HX_CSTRING("best_cost"),
	HX_CSTRING("path_valid"),
	HX_CSTRING("mode"),
	HX_CSTRING("index"),
	HX_CSTRING("T"),
	HX_CSTRING("K"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Viterbi_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Viterbi_obj::__mClass,"__mClass");
};

Class Viterbi_obj::__mClass;

void Viterbi_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.Viterbi"), hx::TCanCast< Viterbi_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void Viterbi_obj::__boot()
{
}

} // end namespace coopy

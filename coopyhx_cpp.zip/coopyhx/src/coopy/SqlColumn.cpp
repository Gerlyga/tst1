#include <hxcpp.h>

#ifndef INCLUDED_coopy_SqlColumn
#include <coopy/SqlColumn.h>
#endif
namespace coopy{

Void SqlColumn_obj::__construct()
{
HX_STACK_PUSH("SqlColumn::new","coopy/SqlColumn.hx",12);
{
}
;
	return null();
}

SqlColumn_obj::~SqlColumn_obj() { }

Dynamic SqlColumn_obj::__CreateEmpty() { return  new SqlColumn_obj; }
hx::ObjectPtr< SqlColumn_obj > SqlColumn_obj::__new()
{  hx::ObjectPtr< SqlColumn_obj > result = new SqlColumn_obj();
	result->__construct();
	return result;}

Dynamic SqlColumn_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< SqlColumn_obj > result = new SqlColumn_obj();
	result->__construct();
	return result;}

::String SqlColumn_obj::toString( ){
	HX_STACK_PUSH("SqlColumn::toString","coopy/SqlColumn.hx",29);
	HX_STACK_THIS(this);
	HX_STACK_LINE(29)
	return (((  ((this->primary)) ? ::String(HX_CSTRING("*")) : ::String(HX_CSTRING("")) )) + this->name);
}


HX_DEFINE_DYNAMIC_FUNC0(SqlColumn_obj,toString,return )

bool SqlColumn_obj::isPrimaryKey( ){
	HX_STACK_PUSH("SqlColumn::isPrimaryKey","coopy/SqlColumn.hx",25);
	HX_STACK_THIS(this);
	HX_STACK_LINE(25)
	return this->primary;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlColumn_obj,isPrimaryKey,return )

::String SqlColumn_obj::getName( ){
	HX_STACK_PUSH("SqlColumn::getName","coopy/SqlColumn.hx",21);
	HX_STACK_THIS(this);
	HX_STACK_LINE(21)
	return this->name;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlColumn_obj,getName,return )

::coopy::SqlColumn SqlColumn_obj::byNameAndPrimaryKey( ::String name,bool primary){
	HX_STACK_PUSH("SqlColumn::byNameAndPrimaryKey","coopy/SqlColumn.hx",14);
	HX_STACK_ARG(name,"name");
	HX_STACK_ARG(primary,"primary");
	HX_STACK_LINE(15)
	::coopy::SqlColumn result = ::coopy::SqlColumn_obj::__new();		HX_STACK_VAR(result,"result");
	HX_STACK_LINE(16)
	result->name = name;
	HX_STACK_LINE(17)
	result->primary = primary;
	HX_STACK_LINE(18)
	return result;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(SqlColumn_obj,byNameAndPrimaryKey,return )


SqlColumn_obj::SqlColumn_obj()
{
}

void SqlColumn_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(SqlColumn);
	HX_MARK_MEMBER_NAME(primary,"primary");
	HX_MARK_MEMBER_NAME(name,"name");
	HX_MARK_END_CLASS();
}

void SqlColumn_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(primary,"primary");
	HX_VISIT_MEMBER_NAME(name,"name");
}

Dynamic SqlColumn_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { return name; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"getName") ) { return getName_dyn(); }
		if (HX_FIELD_EQ(inName,"primary") ) { return primary; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"toString") ) { return toString_dyn(); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"isPrimaryKey") ) { return isPrimaryKey_dyn(); }
		break;
	case 19:
		if (HX_FIELD_EQ(inName,"byNameAndPrimaryKey") ) { return byNameAndPrimaryKey_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic SqlColumn_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { name=inValue.Cast< ::String >(); return inValue; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"primary") ) { primary=inValue.Cast< bool >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void SqlColumn_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("primary"));
	outFields->push(HX_CSTRING("name"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	HX_CSTRING("byNameAndPrimaryKey"),
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("toString"),
	HX_CSTRING("isPrimaryKey"),
	HX_CSTRING("getName"),
	HX_CSTRING("primary"),
	HX_CSTRING("name"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(SqlColumn_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(SqlColumn_obj::__mClass,"__mClass");
};

Class SqlColumn_obj::__mClass;

void SqlColumn_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.SqlColumn"), hx::TCanCast< SqlColumn_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void SqlColumn_obj::__boot()
{
}

} // end namespace coopy

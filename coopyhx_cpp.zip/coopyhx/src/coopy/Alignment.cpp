#include <hxcpp.h>

#ifndef INCLUDED_IMap
#include <IMap.h>
#endif
#ifndef INCLUDED_coopy_Alignment
#include <coopy/Alignment.h>
#endif
#ifndef INCLUDED_coopy_Ordering
#include <coopy/Ordering.h>
#endif
#ifndef INCLUDED_coopy_Table
#include <coopy/Table.h>
#endif
#ifndef INCLUDED_coopy_Unit
#include <coopy/Unit.h>
#endif
#ifndef INCLUDED_haxe_Log
#include <haxe/Log.h>
#endif
#ifndef INCLUDED_haxe_ds_IntMap
#include <haxe/ds/IntMap.h>
#endif
namespace coopy{

Void Alignment_obj::__construct()
{
HX_STACK_PUSH("Alignment::new","coopy/Alignment.hx",30);
{
	HX_STACK_LINE(31)
	this->map_a2b = ::haxe::ds::IntMap_obj::__new();
	HX_STACK_LINE(32)
	this->map_b2a = ::haxe::ds::IntMap_obj::__new();
	HX_STACK_LINE(33)
	this->ha = this->hb = (int)0;
	HX_STACK_LINE(34)
	this->map_count = (int)0;
	HX_STACK_LINE(35)
	this->reference = null();
	HX_STACK_LINE(36)
	this->meta = null();
	HX_STACK_LINE(37)
	this->order_cache_has_reference = false;
	HX_STACK_LINE(38)
	this->ia = (int)-1;
	HX_STACK_LINE(39)
	this->ib = (int)-1;
}
;
	return null();
}

Alignment_obj::~Alignment_obj() { }

Dynamic Alignment_obj::__CreateEmpty() { return  new Alignment_obj; }
hx::ObjectPtr< Alignment_obj > Alignment_obj::__new()
{  hx::ObjectPtr< Alignment_obj > result = new Alignment_obj();
	result->__construct();
	return result;}

Dynamic Alignment_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< Alignment_obj > result = new Alignment_obj();
	result->__construct();
	return result;}

::coopy::Ordering Alignment_obj::toOrder3( ){
	HX_STACK_PUSH("Alignment::toOrder3","coopy/Alignment.hx",240);
	HX_STACK_THIS(this);
	HX_STACK_LINE(241)
	::coopy::Alignment ref = this->reference;		HX_STACK_VAR(ref,"ref");
	HX_STACK_LINE(242)
	if (((ref == null()))){
		HX_STACK_LINE(243)
		ref = ::coopy::Alignment_obj::__new();
		HX_STACK_LINE(244)
		ref->range(this->ha,this->ha);
		HX_STACK_LINE(245)
		ref->tables(this->ta,this->ta);
		HX_STACK_LINE(246)
		{
			HX_STACK_LINE(246)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = this->ha;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(246)
			while(((_g1 < _g))){
				HX_STACK_LINE(246)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(247)
				ref->link(i,i);
			}
		}
	}
	HX_STACK_LINE(250)
	::coopy::Ordering order = ::coopy::Ordering_obj::__new();		HX_STACK_VAR(order,"order");
	HX_STACK_LINE(251)
	if (((this->reference == null()))){
		HX_STACK_LINE(251)
		order->ignoreParent();
	}
	HX_STACK_LINE(254)
	int xp = (int)0;		HX_STACK_VAR(xp,"xp");
	HX_STACK_LINE(255)
	int xl = (int)0;		HX_STACK_VAR(xl,"xl");
	HX_STACK_LINE(256)
	int xr = (int)0;		HX_STACK_VAR(xr,"xr");
	HX_STACK_LINE(257)
	int hp = this->ha;		HX_STACK_VAR(hp,"hp");
	HX_STACK_LINE(258)
	int hl = ref->hb;		HX_STACK_VAR(hl,"hl");
	HX_STACK_LINE(259)
	int hr = this->hb;		HX_STACK_VAR(hr,"hr");
	HX_STACK_LINE(260)
	::haxe::ds::IntMap vp = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(vp,"vp");
	HX_STACK_LINE(261)
	::haxe::ds::IntMap vl = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(vl,"vl");
	HX_STACK_LINE(262)
	::haxe::ds::IntMap vr = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(vr,"vr");
	HX_STACK_LINE(263)
	{
		HX_STACK_LINE(263)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(263)
		while(((_g < hp))){
			HX_STACK_LINE(263)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(263)
			vp->set(i,i);
		}
	}
	HX_STACK_LINE(264)
	{
		HX_STACK_LINE(264)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(264)
		while(((_g < hl))){
			HX_STACK_LINE(264)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(264)
			vl->set(i,i);
		}
	}
	HX_STACK_LINE(265)
	{
		HX_STACK_LINE(265)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(265)
		while(((_g < hr))){
			HX_STACK_LINE(265)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(265)
			vr->set(i,i);
		}
	}
	HX_STACK_LINE(266)
	int ct_vp = hp;		HX_STACK_VAR(ct_vp,"ct_vp");
	HX_STACK_LINE(267)
	int ct_vl = hl;		HX_STACK_VAR(ct_vl,"ct_vl");
	HX_STACK_LINE(268)
	int ct_vr = hr;		HX_STACK_VAR(ct_vr,"ct_vr");
	HX_STACK_LINE(269)
	int prev = (int)-1;		HX_STACK_VAR(prev,"prev");
	HX_STACK_LINE(270)
	int ct = (int)0;		HX_STACK_VAR(ct,"ct");
	HX_STACK_LINE(271)
	int max_ct = ((((hp + hl) + hr)) * (int)10);		HX_STACK_VAR(max_ct,"max_ct");
	HX_STACK_LINE(272)
	while(((bool((bool((ct_vp > (int)0)) || bool((ct_vl > (int)0)))) || bool((ct_vr > (int)0))))){
		HX_STACK_LINE(275)
		(ct)++;
		HX_STACK_LINE(276)
		if (((ct > max_ct))){
			HX_STACK_LINE(277)
			::haxe::Log_obj::trace(HX_CSTRING("Ordering took too long, something went wrong"),hx::SourceInfo(HX_CSTRING("Alignment.hx"),277,HX_CSTRING("coopy.Alignment"),HX_CSTRING("toOrder3")));
			HX_STACK_LINE(278)
			break;
		}
		HX_STACK_LINE(280)
		if (((xp >= hp))){
			HX_STACK_LINE(280)
			xp = (int)0;
		}
		HX_STACK_LINE(281)
		if (((xl >= hl))){
			HX_STACK_LINE(281)
			xl = (int)0;
		}
		HX_STACK_LINE(282)
		if (((xr >= hr))){
			HX_STACK_LINE(282)
			xr = (int)0;
		}
		HX_STACK_LINE(283)
		if (((bool((xp < hp)) && bool((ct_vp > (int)0))))){
			HX_STACK_LINE(283)
			if (((bool((this->a2b(xp) == null())) && bool((ref->a2b(xp) == null()))))){
				HX_STACK_LINE(286)
				if ((vp->exists(xp))){
					HX_STACK_LINE(287)
					order->add((int)-1,(int)-1,xp);
					HX_STACK_LINE(288)
					prev = xp;
					HX_STACK_LINE(289)
					vp->remove(xp);
					HX_STACK_LINE(290)
					(ct_vp)--;
				}
				HX_STACK_LINE(292)
				(xp)++;
				HX_STACK_LINE(293)
				continue;
			}
		}
		HX_STACK_LINE(296)
		Dynamic zl = null();		HX_STACK_VAR(zl,"zl");
		HX_STACK_LINE(297)
		Dynamic zr = null();		HX_STACK_VAR(zr,"zr");
		HX_STACK_LINE(298)
		if (((bool((xl < hl)) && bool((ct_vl > (int)0))))){
			HX_STACK_LINE(299)
			zl = ref->b2a(xl);
			HX_STACK_LINE(300)
			if (((zl == null()))){
				HX_STACK_LINE(301)
				if ((vl->exists(xl))){
					HX_STACK_LINE(302)
					order->add(xl,(int)-1,(int)-1);
					HX_STACK_LINE(303)
					vl->remove(xl);
					HX_STACK_LINE(304)
					(ct_vl)--;
				}
				HX_STACK_LINE(306)
				(xl)++;
				HX_STACK_LINE(307)
				continue;
			}
		}
		HX_STACK_LINE(310)
		if (((bool((xr < hr)) && bool((ct_vr > (int)0))))){
			HX_STACK_LINE(311)
			zr = this->b2a(xr);
			HX_STACK_LINE(312)
			if (((zr == null()))){
				HX_STACK_LINE(313)
				if ((vr->exists(xr))){
					HX_STACK_LINE(314)
					order->add((int)-1,xr,(int)-1);
					HX_STACK_LINE(315)
					vr->remove(xr);
					HX_STACK_LINE(316)
					(ct_vr)--;
				}
				HX_STACK_LINE(318)
				(xr)++;
				HX_STACK_LINE(319)
				continue;
			}
		}
		HX_STACK_LINE(322)
		if (((zl != null()))){
			HX_STACK_LINE(322)
			if (((this->a2b(zl) == null()))){
				HX_STACK_LINE(325)
				if ((vl->exists(xl))){
					HX_STACK_LINE(326)
					order->add(xl,(int)-1,zl);
					HX_STACK_LINE(327)
					prev = zl;
					HX_STACK_LINE(328)
					vp->remove(zl);
					HX_STACK_LINE(329)
					(ct_vp)--;
					HX_STACK_LINE(330)
					vl->remove(xl);
					HX_STACK_LINE(331)
					(ct_vl)--;
					HX_STACK_LINE(332)
					xp = (zl + (int)1);
				}
				HX_STACK_LINE(334)
				(xl)++;
				HX_STACK_LINE(335)
				continue;
			}
		}
		HX_STACK_LINE(338)
		if (((zr != null()))){
			HX_STACK_LINE(338)
			if (((ref->a2b(zr) == null()))){
				HX_STACK_LINE(341)
				if ((vr->exists(xr))){
					HX_STACK_LINE(342)
					order->add((int)-1,xr,zr);
					HX_STACK_LINE(343)
					prev = zr;
					HX_STACK_LINE(344)
					vp->remove(zr);
					HX_STACK_LINE(345)
					(ct_vp)--;
					HX_STACK_LINE(346)
					vr->remove(xr);
					HX_STACK_LINE(347)
					(ct_vr)--;
					HX_STACK_LINE(348)
					xp = (zr + (int)1);
				}
				HX_STACK_LINE(350)
				(xr)++;
				HX_STACK_LINE(351)
				continue;
			}
		}
		HX_STACK_LINE(354)
		if (((bool((bool((bool((zl != null())) && bool((zr != null())))) && bool((this->a2b(zl) != null())))) && bool((ref->a2b(zr) != null()))))){
			HX_STACK_LINE(355)
			if (((bool((zl == (prev + (int)1))) || bool((zr != (prev + (int)1)))))){
				HX_STACK_LINE(360)
				if ((vr->exists(xr))){
					HX_STACK_LINE(361)
					order->add(ref->a2b(zr),xr,zr);
					HX_STACK_LINE(362)
					prev = zr;
					HX_STACK_LINE(363)
					vp->remove(zr);
					HX_STACK_LINE(364)
					(ct_vp)--;
					HX_STACK_LINE(365)
					vl->remove(ref->a2b(zr));
					HX_STACK_LINE(366)
					(ct_vl)--;
					HX_STACK_LINE(367)
					vr->remove(xr);
					HX_STACK_LINE(368)
					(ct_vr)--;
					HX_STACK_LINE(369)
					xp = (zr + (int)1);
					HX_STACK_LINE(370)
					xl = (ref->a2b(zr) + (int)1);
				}
				HX_STACK_LINE(372)
				(xr)++;
				HX_STACK_LINE(373)
				continue;
			}
			else{
				HX_STACK_LINE(375)
				if ((vl->exists(xl))){
					HX_STACK_LINE(376)
					order->add(xl,this->a2b(zl),zl);
					HX_STACK_LINE(377)
					prev = zl;
					HX_STACK_LINE(378)
					vp->remove(zl);
					HX_STACK_LINE(379)
					(ct_vp)--;
					HX_STACK_LINE(380)
					vl->remove(xl);
					HX_STACK_LINE(381)
					(ct_vl)--;
					HX_STACK_LINE(382)
					vr->remove(this->a2b(zl));
					HX_STACK_LINE(383)
					(ct_vr)--;
					HX_STACK_LINE(384)
					xp = (zl + (int)1);
					HX_STACK_LINE(385)
					xr = (this->a2b(zl) + (int)1);
				}
				HX_STACK_LINE(387)
				(xl)++;
				HX_STACK_LINE(388)
				continue;
			}
		}
		HX_STACK_LINE(391)
		(xp)++;
		HX_STACK_LINE(392)
		(xl)++;
		HX_STACK_LINE(393)
		(xr)++;
	}
	HX_STACK_LINE(395)
	return order;
}


HX_DEFINE_DYNAMIC_FUNC0(Alignment_obj,toOrder3,return )

int Alignment_obj::getTargetHeader( ){
	HX_STACK_PUSH("Alignment::getTargetHeader","coopy/Alignment.hx",236);
	HX_STACK_THIS(this);
	HX_STACK_LINE(236)
	return this->ib;
}


HX_DEFINE_DYNAMIC_FUNC0(Alignment_obj,getTargetHeader,return )

int Alignment_obj::getSourceHeader( ){
	HX_STACK_PUSH("Alignment::getSourceHeader","coopy/Alignment.hx",225);
	HX_STACK_THIS(this);
	HX_STACK_LINE(225)
	return this->ia;
}


HX_DEFINE_DYNAMIC_FUNC0(Alignment_obj,getSourceHeader,return )

::coopy::Table Alignment_obj::getTarget( ){
	HX_STACK_PUSH("Alignment::getTarget","coopy/Alignment.hx",214);
	HX_STACK_THIS(this);
	HX_STACK_LINE(214)
	return this->tb;
}


HX_DEFINE_DYNAMIC_FUNC0(Alignment_obj,getTarget,return )

::coopy::Table Alignment_obj::getSource( ){
	HX_STACK_PUSH("Alignment::getSource","coopy/Alignment.hx",205);
	HX_STACK_THIS(this);
	HX_STACK_LINE(205)
	return this->ta;
}


HX_DEFINE_DYNAMIC_FUNC0(Alignment_obj,getSource,return )

Void Alignment_obj::addToOrder( int l,int r,Dynamic __o_p){
Dynamic p = __o_p.Default(-2);
	HX_STACK_PUSH("Alignment::addToOrder","coopy/Alignment.hx",194);
	HX_STACK_THIS(this);
	HX_STACK_ARG(l,"l");
	HX_STACK_ARG(r,"r");
	HX_STACK_ARG(p,"p");
{
		HX_STACK_LINE(195)
		if (((this->order_cache == null()))){
			HX_STACK_LINE(195)
			this->order_cache = ::coopy::Ordering_obj::__new();
		}
		HX_STACK_LINE(196)
		this->order_cache->add(l,r,p);
		HX_STACK_LINE(197)
		this->order_cache_has_reference = (p != (int)-2);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(Alignment_obj,addToOrder,(void))

::coopy::Ordering Alignment_obj::toOrder( ){
	HX_STACK_PUSH("Alignment::toOrder","coopy/Alignment.hx",173);
	HX_STACK_THIS(this);
	HX_STACK_LINE(174)
	if (((this->order_cache != null()))){
		HX_STACK_LINE(174)
		if (((this->reference != null()))){
			HX_STACK_LINE(175)
			if ((!(this->order_cache_has_reference))){
				HX_STACK_LINE(176)
				this->order_cache = null();
			}
		}
	}
	HX_STACK_LINE(181)
	if (((this->order_cache == null()))){
		HX_STACK_LINE(181)
		this->order_cache = this->toOrder3();
	}
	HX_STACK_LINE(182)
	if (((this->reference != null()))){
		HX_STACK_LINE(182)
		this->order_cache_has_reference = true;
	}
	HX_STACK_LINE(183)
	return this->order_cache;
}


HX_DEFINE_DYNAMIC_FUNC0(Alignment_obj,toOrder,return )

::String Alignment_obj::toString( ){
	HX_STACK_PUSH("Alignment::toString","coopy/Alignment.hx",163);
	HX_STACK_THIS(this);
	HX_STACK_LINE(163)
	return (HX_CSTRING("") + this->map_a2b->toString());
}


HX_DEFINE_DYNAMIC_FUNC0(Alignment_obj,toString,return )

int Alignment_obj::count( ){
	HX_STACK_PUSH("Alignment::count","coopy/Alignment.hx",154);
	HX_STACK_THIS(this);
	HX_STACK_LINE(154)
	return this->map_count;
}


HX_DEFINE_DYNAMIC_FUNC0(Alignment_obj,count,return )

Dynamic Alignment_obj::b2a( int b){
	HX_STACK_PUSH("Alignment::b2a","coopy/Alignment.hx",145);
	HX_STACK_THIS(this);
	HX_STACK_ARG(b,"b");
	HX_STACK_LINE(145)
	return this->map_b2a->get(b);
}


HX_DEFINE_DYNAMIC_FUNC1(Alignment_obj,b2a,return )

Dynamic Alignment_obj::a2b( int a){
	HX_STACK_PUSH("Alignment::a2b","coopy/Alignment.hx",135);
	HX_STACK_THIS(this);
	HX_STACK_ARG(a,"a");
	HX_STACK_LINE(135)
	return this->map_a2b->get(a);
}


HX_DEFINE_DYNAMIC_FUNC1(Alignment_obj,a2b,return )

Array< ::Dynamic > Alignment_obj::getIndexColumns( ){
	HX_STACK_PUSH("Alignment::getIndexColumns","coopy/Alignment.hx",125);
	HX_STACK_THIS(this);
	HX_STACK_LINE(125)
	return this->index_columns;
}


HX_DEFINE_DYNAMIC_FUNC0(Alignment_obj,getIndexColumns,return )

Void Alignment_obj::addIndexColumns( ::coopy::Unit unit){
{
		HX_STACK_PUSH("Alignment::addIndexColumns","coopy/Alignment.hx",113);
		HX_STACK_THIS(this);
		HX_STACK_ARG(unit,"unit");
		HX_STACK_LINE(114)
		if (((this->index_columns == null()))){
			HX_STACK_LINE(114)
			this->index_columns = Array_obj< ::Dynamic >::__new();
		}
		HX_STACK_LINE(117)
		this->index_columns->push(unit);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(Alignment_obj,addIndexColumns,(void))

Void Alignment_obj::link( int a,int b){
{
		HX_STACK_PUSH("Alignment::link","coopy/Alignment.hx",97);
		HX_STACK_THIS(this);
		HX_STACK_ARG(a,"a");
		HX_STACK_ARG(b,"b");
		HX_STACK_LINE(98)
		this->map_a2b->set(a,b);
		HX_STACK_LINE(99)
		this->map_b2a->set(b,a);
		HX_STACK_LINE(100)
		(this->map_count)++;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC2(Alignment_obj,link,(void))

Void Alignment_obj::setRowlike( bool flag){
{
		HX_STACK_PUSH("Alignment::setRowlike","coopy/Alignment.hx",85);
		HX_STACK_THIS(this);
		HX_STACK_ARG(flag,"flag");
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(Alignment_obj,setRowlike,(void))

Void Alignment_obj::headers( int ia,int ib){
{
		HX_STACK_PUSH("Alignment::headers","coopy/Alignment.hx",73);
		HX_STACK_THIS(this);
		HX_STACK_ARG(ia,"ia");
		HX_STACK_ARG(ib,"ib");
		HX_STACK_LINE(74)
		this->ia = ia;
		HX_STACK_LINE(75)
		this->ib = ib;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC2(Alignment_obj,headers,(void))

Void Alignment_obj::tables( ::coopy::Table ta,::coopy::Table tb){
{
		HX_STACK_PUSH("Alignment::tables","coopy/Alignment.hx",59);
		HX_STACK_THIS(this);
		HX_STACK_ARG(ta,"ta");
		HX_STACK_ARG(tb,"tb");
		HX_STACK_LINE(60)
		this->ta = ta;
		HX_STACK_LINE(61)
		this->tb = tb;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC2(Alignment_obj,tables,(void))

Void Alignment_obj::range( int ha,int hb){
{
		HX_STACK_PUSH("Alignment::range","coopy/Alignment.hx",47);
		HX_STACK_THIS(this);
		HX_STACK_ARG(ha,"ha");
		HX_STACK_ARG(hb,"hb");
		HX_STACK_LINE(48)
		this->ha = ha;
		HX_STACK_LINE(49)
		this->hb = hb;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC2(Alignment_obj,range,(void))


Alignment_obj::Alignment_obj()
{
}

void Alignment_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(Alignment);
	HX_MARK_MEMBER_NAME(meta,"meta");
	HX_MARK_MEMBER_NAME(reference,"reference");
	HX_MARK_MEMBER_NAME(index_columns,"index_columns");
	HX_MARK_MEMBER_NAME(order_cache_has_reference,"order_cache_has_reference");
	HX_MARK_MEMBER_NAME(order_cache,"order_cache");
	HX_MARK_MEMBER_NAME(map_count,"map_count");
	HX_MARK_MEMBER_NAME(ib,"ib");
	HX_MARK_MEMBER_NAME(ia,"ia");
	HX_MARK_MEMBER_NAME(tb,"tb");
	HX_MARK_MEMBER_NAME(ta,"ta");
	HX_MARK_MEMBER_NAME(hb,"hb");
	HX_MARK_MEMBER_NAME(ha,"ha");
	HX_MARK_MEMBER_NAME(map_b2a,"map_b2a");
	HX_MARK_MEMBER_NAME(map_a2b,"map_a2b");
	HX_MARK_END_CLASS();
}

void Alignment_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(meta,"meta");
	HX_VISIT_MEMBER_NAME(reference,"reference");
	HX_VISIT_MEMBER_NAME(index_columns,"index_columns");
	HX_VISIT_MEMBER_NAME(order_cache_has_reference,"order_cache_has_reference");
	HX_VISIT_MEMBER_NAME(order_cache,"order_cache");
	HX_VISIT_MEMBER_NAME(map_count,"map_count");
	HX_VISIT_MEMBER_NAME(ib,"ib");
	HX_VISIT_MEMBER_NAME(ia,"ia");
	HX_VISIT_MEMBER_NAME(tb,"tb");
	HX_VISIT_MEMBER_NAME(ta,"ta");
	HX_VISIT_MEMBER_NAME(hb,"hb");
	HX_VISIT_MEMBER_NAME(ha,"ha");
	HX_VISIT_MEMBER_NAME(map_b2a,"map_b2a");
	HX_VISIT_MEMBER_NAME(map_a2b,"map_a2b");
}

Dynamic Alignment_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 2:
		if (HX_FIELD_EQ(inName,"ib") ) { return ib; }
		if (HX_FIELD_EQ(inName,"ia") ) { return ia; }
		if (HX_FIELD_EQ(inName,"tb") ) { return tb; }
		if (HX_FIELD_EQ(inName,"ta") ) { return ta; }
		if (HX_FIELD_EQ(inName,"hb") ) { return hb; }
		if (HX_FIELD_EQ(inName,"ha") ) { return ha; }
		break;
	case 3:
		if (HX_FIELD_EQ(inName,"b2a") ) { return b2a_dyn(); }
		if (HX_FIELD_EQ(inName,"a2b") ) { return a2b_dyn(); }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"link") ) { return link_dyn(); }
		if (HX_FIELD_EQ(inName,"meta") ) { return meta; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"count") ) { return count_dyn(); }
		if (HX_FIELD_EQ(inName,"range") ) { return range_dyn(); }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"tables") ) { return tables_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"toOrder") ) { return toOrder_dyn(); }
		if (HX_FIELD_EQ(inName,"headers") ) { return headers_dyn(); }
		if (HX_FIELD_EQ(inName,"map_b2a") ) { return map_b2a; }
		if (HX_FIELD_EQ(inName,"map_a2b") ) { return map_a2b; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"toOrder3") ) { return toOrder3_dyn(); }
		if (HX_FIELD_EQ(inName,"toString") ) { return toString_dyn(); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"getTarget") ) { return getTarget_dyn(); }
		if (HX_FIELD_EQ(inName,"getSource") ) { return getSource_dyn(); }
		if (HX_FIELD_EQ(inName,"reference") ) { return reference; }
		if (HX_FIELD_EQ(inName,"map_count") ) { return map_count; }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"addToOrder") ) { return addToOrder_dyn(); }
		if (HX_FIELD_EQ(inName,"setRowlike") ) { return setRowlike_dyn(); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"order_cache") ) { return order_cache; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"index_columns") ) { return index_columns; }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"getTargetHeader") ) { return getTargetHeader_dyn(); }
		if (HX_FIELD_EQ(inName,"getSourceHeader") ) { return getSourceHeader_dyn(); }
		if (HX_FIELD_EQ(inName,"getIndexColumns") ) { return getIndexColumns_dyn(); }
		if (HX_FIELD_EQ(inName,"addIndexColumns") ) { return addIndexColumns_dyn(); }
		break;
	case 25:
		if (HX_FIELD_EQ(inName,"order_cache_has_reference") ) { return order_cache_has_reference; }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic Alignment_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 2:
		if (HX_FIELD_EQ(inName,"ib") ) { ib=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"ia") ) { ia=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"tb") ) { tb=inValue.Cast< ::coopy::Table >(); return inValue; }
		if (HX_FIELD_EQ(inName,"ta") ) { ta=inValue.Cast< ::coopy::Table >(); return inValue; }
		if (HX_FIELD_EQ(inName,"hb") ) { hb=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"ha") ) { ha=inValue.Cast< int >(); return inValue; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"meta") ) { meta=inValue.Cast< ::coopy::Alignment >(); return inValue; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"map_b2a") ) { map_b2a=inValue.Cast< ::haxe::ds::IntMap >(); return inValue; }
		if (HX_FIELD_EQ(inName,"map_a2b") ) { map_a2b=inValue.Cast< ::haxe::ds::IntMap >(); return inValue; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"reference") ) { reference=inValue.Cast< ::coopy::Alignment >(); return inValue; }
		if (HX_FIELD_EQ(inName,"map_count") ) { map_count=inValue.Cast< int >(); return inValue; }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"order_cache") ) { order_cache=inValue.Cast< ::coopy::Ordering >(); return inValue; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"index_columns") ) { index_columns=inValue.Cast< Array< ::Dynamic > >(); return inValue; }
		break;
	case 25:
		if (HX_FIELD_EQ(inName,"order_cache_has_reference") ) { order_cache_has_reference=inValue.Cast< bool >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void Alignment_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("meta"));
	outFields->push(HX_CSTRING("reference"));
	outFields->push(HX_CSTRING("index_columns"));
	outFields->push(HX_CSTRING("order_cache_has_reference"));
	outFields->push(HX_CSTRING("order_cache"));
	outFields->push(HX_CSTRING("map_count"));
	outFields->push(HX_CSTRING("ib"));
	outFields->push(HX_CSTRING("ia"));
	outFields->push(HX_CSTRING("tb"));
	outFields->push(HX_CSTRING("ta"));
	outFields->push(HX_CSTRING("hb"));
	outFields->push(HX_CSTRING("ha"));
	outFields->push(HX_CSTRING("map_b2a"));
	outFields->push(HX_CSTRING("map_a2b"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("toOrder3"),
	HX_CSTRING("getTargetHeader"),
	HX_CSTRING("getSourceHeader"),
	HX_CSTRING("getTarget"),
	HX_CSTRING("getSource"),
	HX_CSTRING("addToOrder"),
	HX_CSTRING("toOrder"),
	HX_CSTRING("toString"),
	HX_CSTRING("count"),
	HX_CSTRING("b2a"),
	HX_CSTRING("a2b"),
	HX_CSTRING("getIndexColumns"),
	HX_CSTRING("addIndexColumns"),
	HX_CSTRING("link"),
	HX_CSTRING("setRowlike"),
	HX_CSTRING("headers"),
	HX_CSTRING("tables"),
	HX_CSTRING("range"),
	HX_CSTRING("meta"),
	HX_CSTRING("reference"),
	HX_CSTRING("index_columns"),
	HX_CSTRING("order_cache_has_reference"),
	HX_CSTRING("order_cache"),
	HX_CSTRING("map_count"),
	HX_CSTRING("ib"),
	HX_CSTRING("ia"),
	HX_CSTRING("tb"),
	HX_CSTRING("ta"),
	HX_CSTRING("hb"),
	HX_CSTRING("ha"),
	HX_CSTRING("map_b2a"),
	HX_CSTRING("map_a2b"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Alignment_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Alignment_obj::__mClass,"__mClass");
};

Class Alignment_obj::__mClass;

void Alignment_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.Alignment"), hx::TCanCast< Alignment_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void Alignment_obj::__boot()
{
}

} // end namespace coopy

#include <hxcpp.h>

#ifndef INCLUDED_coopy_Alignment
#include <coopy/Alignment.h>
#endif
#ifndef INCLUDED_coopy_SqlCompare
#include <coopy/SqlCompare.h>
#endif
#ifndef INCLUDED_coopy_SqlDatabase
#include <coopy/SqlDatabase.h>
#endif
#ifndef INCLUDED_coopy_SqlTable
#include <coopy/SqlTable.h>
#endif
#ifndef INCLUDED_coopy_Table
#include <coopy/Table.h>
#endif
namespace coopy{

Void SqlCompare_obj::__construct(::coopy::SqlDatabase db,::coopy::SqlTable local,::coopy::SqlTable remote)
{
HX_STACK_PUSH("SqlCompare::new","coopy/SqlCompare.hx",17);
{
	HX_STACK_LINE(18)
	this->db = db;
	HX_STACK_LINE(19)
	this->local = local;
	HX_STACK_LINE(20)
	this->remote = remote;
}
;
	return null();
}

SqlCompare_obj::~SqlCompare_obj() { }

Dynamic SqlCompare_obj::__CreateEmpty() { return  new SqlCompare_obj; }
hx::ObjectPtr< SqlCompare_obj > SqlCompare_obj::__new(::coopy::SqlDatabase db,::coopy::SqlTable local,::coopy::SqlTable remote)
{  hx::ObjectPtr< SqlCompare_obj > result = new SqlCompare_obj();
	result->__construct(db,local,remote);
	return result;}

Dynamic SqlCompare_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< SqlCompare_obj > result = new SqlCompare_obj();
	result->__construct(inArgs[0],inArgs[1],inArgs[2]);
	return result;}

::coopy::Alignment SqlCompare_obj::apply( ){
	HX_STACK_PUSH("SqlCompare::apply","coopy/SqlCompare.hx",91);
	HX_STACK_THIS(this);
	HX_STACK_LINE(92)
	if (((this->db == null()))){
		HX_STACK_LINE(92)
		return null();
	}
	HX_STACK_LINE(93)
	if ((!(this->validateSchema()))){
		HX_STACK_LINE(93)
		return null();
	}
	HX_STACK_LINE(95)
	::String rowid_name = this->db->rowid();		HX_STACK_VAR(rowid_name,"rowid_name");
	HX_STACK_LINE(97)
	this->align = ::coopy::Alignment_obj::__new();
	HX_STACK_LINE(99)
	Array< ::String > key_cols = this->local->getPrimaryKey();		HX_STACK_VAR(key_cols,"key_cols");
	HX_STACK_LINE(100)
	Array< ::String > data_cols = this->local->getAllButPrimaryKey();		HX_STACK_VAR(data_cols,"data_cols");
	HX_STACK_LINE(101)
	Array< ::String > all_cols = this->local->getColumnNames();		HX_STACK_VAR(all_cols,"all_cols");
	HX_STACK_LINE(104)
	this->align->meta = ::coopy::Alignment_obj::__new();
	HX_STACK_LINE(105)
	{
		HX_STACK_LINE(105)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = all_cols->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(105)
		while(((_g1 < _g))){
			HX_STACK_LINE(105)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(106)
			this->align->meta->link(i,i);
		}
	}
	HX_STACK_LINE(108)
	this->align->meta->range(all_cols->length,all_cols->length);
	HX_STACK_LINE(110)
	this->align->tables(this->local,this->remote);
	HX_STACK_LINE(111)
	this->align->range((int)999,(int)999);
	HX_STACK_LINE(113)
	::String sql_table1 = this->local->getQuotedTableName();		HX_STACK_VAR(sql_table1,"sql_table1");
	HX_STACK_LINE(114)
	::String sql_table2 = this->remote->getQuotedTableName();		HX_STACK_VAR(sql_table2,"sql_table2");
	HX_STACK_LINE(115)
	::String sql_key_cols = HX_CSTRING("");		HX_STACK_VAR(sql_key_cols,"sql_key_cols");
	HX_STACK_LINE(116)
	{
		HX_STACK_LINE(116)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = key_cols->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(116)
		while(((_g1 < _g))){
			HX_STACK_LINE(116)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(117)
			if (((i > (int)0))){
				HX_STACK_LINE(117)
				hx::AddEq(sql_key_cols,HX_CSTRING(","));
			}
			HX_STACK_LINE(118)
			hx::AddEq(sql_key_cols,this->local->getQuotedColumnName(key_cols->__get(i)));
		}
	}
	HX_STACK_LINE(120)
	::String sql_all_cols = HX_CSTRING("");		HX_STACK_VAR(sql_all_cols,"sql_all_cols");
	HX_STACK_LINE(121)
	{
		HX_STACK_LINE(121)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = all_cols->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(121)
		while(((_g1 < _g))){
			HX_STACK_LINE(121)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(122)
			if (((i > (int)0))){
				HX_STACK_LINE(122)
				hx::AddEq(sql_all_cols,HX_CSTRING(","));
			}
			HX_STACK_LINE(123)
			hx::AddEq(sql_all_cols,this->local->getQuotedColumnName(all_cols->__get(i)));
		}
	}
	HX_STACK_LINE(125)
	::String sql_key_match = HX_CSTRING("");		HX_STACK_VAR(sql_key_match,"sql_key_match");
	HX_STACK_LINE(126)
	{
		HX_STACK_LINE(126)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = key_cols->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(126)
		while(((_g1 < _g))){
			HX_STACK_LINE(126)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(127)
			if (((i > (int)0))){
				HX_STACK_LINE(127)
				hx::AddEq(sql_key_match,HX_CSTRING(" AND "));
			}
			HX_STACK_LINE(128)
			::String n = this->local->getQuotedColumnName(key_cols->__get(i));		HX_STACK_VAR(n,"n");
			HX_STACK_LINE(129)
			hx::AddEq(sql_key_match,((((((sql_table1 + HX_CSTRING(".")) + n) + HX_CSTRING(" IS ")) + sql_table2) + HX_CSTRING(".")) + n));
		}
	}
	HX_STACK_LINE(131)
	::String sql_data_mismatch = HX_CSTRING("");		HX_STACK_VAR(sql_data_mismatch,"sql_data_mismatch");
	HX_STACK_LINE(132)
	{
		HX_STACK_LINE(132)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = data_cols->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(132)
		while(((_g1 < _g))){
			HX_STACK_LINE(132)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(133)
			if (((i > (int)0))){
				HX_STACK_LINE(133)
				hx::AddEq(sql_data_mismatch,HX_CSTRING(" OR "));
			}
			HX_STACK_LINE(134)
			::String n = this->local->getQuotedColumnName(data_cols->__get(i));		HX_STACK_VAR(n,"n");
			HX_STACK_LINE(135)
			hx::AddEq(sql_data_mismatch,((((((sql_table1 + HX_CSTRING(".")) + n) + HX_CSTRING(" IS NOT ")) + sql_table2) + HX_CSTRING(".")) + n));
		}
	}
	HX_STACK_LINE(137)
	::String sql_dbl_cols = HX_CSTRING("");		HX_STACK_VAR(sql_dbl_cols,"sql_dbl_cols");
	HX_STACK_LINE(138)
	Array< ::String > dbl_cols = Array_obj< ::String >::__new();		HX_STACK_VAR(dbl_cols,"dbl_cols");
	HX_STACK_LINE(139)
	{
		HX_STACK_LINE(139)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = all_cols->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(139)
		while(((_g1 < _g))){
			HX_STACK_LINE(139)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(140)
			if (((i > (int)0))){
				HX_STACK_LINE(140)
				hx::AddEq(sql_dbl_cols,HX_CSTRING(","));
			}
			HX_STACK_LINE(141)
			::String n = this->local->getQuotedColumnName(all_cols->__get(i));		HX_STACK_VAR(n,"n");
			HX_STACK_LINE(142)
			::String buf = (HX_CSTRING("__coopy_") + i);		HX_STACK_VAR(buf,"buf");
			HX_STACK_LINE(143)
			hx::AddEq(sql_dbl_cols,((((sql_table1 + HX_CSTRING(".")) + n) + HX_CSTRING(" AS ")) + buf));
			HX_STACK_LINE(144)
			dbl_cols->push(buf);
			HX_STACK_LINE(145)
			hx::AddEq(sql_dbl_cols,HX_CSTRING(","));
			HX_STACK_LINE(146)
			hx::AddEq(sql_dbl_cols,(((((sql_table2 + HX_CSTRING(".")) + n) + HX_CSTRING(" AS ")) + buf) + HX_CSTRING("b")));
			HX_STACK_LINE(147)
			dbl_cols->push((buf + HX_CSTRING("b")));
		}
	}
	HX_STACK_LINE(149)
	::String sql_order = HX_CSTRING("");		HX_STACK_VAR(sql_order,"sql_order");
	HX_STACK_LINE(150)
	{
		HX_STACK_LINE(150)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = key_cols->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(150)
		while(((_g1 < _g))){
			HX_STACK_LINE(150)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(151)
			if (((i > (int)0))){
				HX_STACK_LINE(151)
				hx::AddEq(sql_order,HX_CSTRING(","));
			}
			HX_STACK_LINE(152)
			::String n = this->local->getQuotedColumnName(key_cols->__get(i));		HX_STACK_VAR(n,"n");
			HX_STACK_LINE(153)
			hx::AddEq(sql_order,n);
		}
	}
	HX_STACK_LINE(155)
	::String sql_dbl_order = HX_CSTRING("");		HX_STACK_VAR(sql_dbl_order,"sql_dbl_order");
	HX_STACK_LINE(156)
	{
		HX_STACK_LINE(156)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = key_cols->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(156)
		while(((_g1 < _g))){
			HX_STACK_LINE(156)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(157)
			if (((i > (int)0))){
				HX_STACK_LINE(157)
				hx::AddEq(sql_dbl_order,HX_CSTRING(","));
			}
			HX_STACK_LINE(158)
			::String n = this->local->getQuotedColumnName(key_cols->__get(i));		HX_STACK_VAR(n,"n");
			HX_STACK_LINE(159)
			hx::AddEq(sql_dbl_order,((sql_table1 + HX_CSTRING(".")) + n));
		}
	}
	HX_STACK_LINE(162)
	::String rowid = HX_CSTRING("-3");		HX_STACK_VAR(rowid,"rowid");
	HX_STACK_LINE(163)
	::String rowid1 = HX_CSTRING("-3");		HX_STACK_VAR(rowid1,"rowid1");
	HX_STACK_LINE(164)
	::String rowid2 = HX_CSTRING("-3");		HX_STACK_VAR(rowid2,"rowid2");
	HX_STACK_LINE(165)
	if (((rowid_name != null()))){
		HX_STACK_LINE(166)
		rowid = rowid_name;
		HX_STACK_LINE(167)
		rowid1 = ((sql_table1 + HX_CSTRING(".")) + rowid_name);
		HX_STACK_LINE(168)
		rowid2 = ((sql_table2 + HX_CSTRING(".")) + rowid_name);
	}
	HX_STACK_LINE(171)
	::String sql_inserts = ((((((((((HX_CSTRING("SELECT DISTINCT NULL, ") + rowid) + HX_CSTRING(" AS rowid, ")) + sql_all_cols) + HX_CSTRING(" FROM ")) + sql_table2) + HX_CSTRING(" WHERE NOT EXISTS (SELECT 1 FROM ")) + sql_table1) + HX_CSTRING(" WHERE ")) + sql_key_match) + HX_CSTRING(")"));		HX_STACK_VAR(sql_inserts,"sql_inserts");
	HX_STACK_LINE(172)
	Array< ::String > sql_inserts_order = Array_obj< ::String >::__new().Add(HX_CSTRING("NULL")).Add(HX_CSTRING("rowid"))->concat(all_cols);		HX_STACK_VAR(sql_inserts_order,"sql_inserts_order");
	HX_STACK_LINE(173)
	::String sql_updates = (((((((((((((HX_CSTRING("SELECT DISTINCT ") + rowid1) + HX_CSTRING(" AS __coopy_rowid0, ")) + rowid2) + HX_CSTRING(" AS __coopy_rowid1, ")) + sql_dbl_cols) + HX_CSTRING(" FROM ")) + sql_table1) + HX_CSTRING(" INNER JOIN ")) + sql_table2) + HX_CSTRING(" ON ")) + sql_key_match) + HX_CSTRING(" WHERE ")) + sql_data_mismatch);		HX_STACK_VAR(sql_updates,"sql_updates");
	HX_STACK_LINE(175)
	Array< ::String > sql_updates_order = Array_obj< ::String >::__new().Add(HX_CSTRING("__coopy_rowid0")).Add(HX_CSTRING("__coopy_rowid1"))->concat(dbl_cols);		HX_STACK_VAR(sql_updates_order,"sql_updates_order");
	HX_STACK_LINE(176)
	::String sql_deletes = ((((((((((HX_CSTRING("SELECT DISTINCT ") + rowid) + HX_CSTRING(" AS rowid, NULL, ")) + sql_all_cols) + HX_CSTRING(" FROM ")) + sql_table1) + HX_CSTRING(" WHERE NOT EXISTS (SELECT 1 FROM ")) + sql_table2) + HX_CSTRING(" WHERE ")) + sql_key_match) + HX_CSTRING(")"));		HX_STACK_VAR(sql_deletes,"sql_deletes");
	HX_STACK_LINE(177)
	Array< ::String > sql_deletes_order = Array_obj< ::String >::__new().Add(HX_CSTRING("rowid")).Add(HX_CSTRING("NULL"))->concat(all_cols);		HX_STACK_VAR(sql_deletes_order,"sql_deletes_order");
	HX_STACK_LINE(179)
	this->at0 = (int)1;
	HX_STACK_LINE(180)
	this->at1 = (int)1;
	HX_STACK_LINE(181)
	this->linkQuery(sql_inserts,sql_inserts_order);
	HX_STACK_LINE(182)
	this->linkQuery(sql_updates,sql_updates_order);
	HX_STACK_LINE(183)
	this->linkQuery(sql_deletes,sql_deletes_order);
	HX_STACK_LINE(185)
	return this->align;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlCompare_obj,apply,return )

Void SqlCompare_obj::linkQuery( ::String query,Array< ::String > order){
{
		HX_STACK_PUSH("SqlCompare::linkQuery","coopy/SqlCompare.hx",80);
		HX_STACK_THIS(this);
		HX_STACK_ARG(query,"query");
		HX_STACK_ARG(order,"order");
		HX_STACK_LINE(80)
		if ((this->db->begin(query,null(),order))){
			HX_STACK_LINE(82)
			while((this->db->read())){
				HX_STACK_LINE(82)
				this->link();
			}
			HX_STACK_LINE(85)
			this->db->end();
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC2(SqlCompare_obj,linkQuery,(void))

Void SqlCompare_obj::link( ){
{
		HX_STACK_PUSH("SqlCompare::link","coopy/SqlCompare.hx",53);
		HX_STACK_THIS(this);
		HX_STACK_LINE(54)
		int i0 = this->denull(this->db->get((int)0));		HX_STACK_VAR(i0,"i0");
		HX_STACK_LINE(55)
		int i1 = this->denull(this->db->get((int)1));		HX_STACK_VAR(i1,"i1");
		HX_STACK_LINE(56)
		if (((i0 == (int)-3))){
			HX_STACK_LINE(57)
			i0 = this->at0;
			HX_STACK_LINE(58)
			(this->at0)++;
		}
		HX_STACK_LINE(60)
		if (((i1 == (int)-3))){
			HX_STACK_LINE(61)
			i1 = this->at1;
			HX_STACK_LINE(62)
			(this->at1)++;
		}
		HX_STACK_LINE(64)
		int factor = (  (((bool((i0 >= (int)0)) && bool((i1 >= (int)0))))) ? int((int)2) : int((int)1) );		HX_STACK_VAR(factor,"factor");
		HX_STACK_LINE(65)
		int offset = (factor - (int)1);		HX_STACK_VAR(offset,"offset");
		HX_STACK_LINE(66)
		if (((i0 >= (int)0))){
			HX_STACK_LINE(67)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = this->local->get_width();		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(67)
			while(((_g1 < _g))){
				HX_STACK_LINE(67)
				int x = (_g1)++;		HX_STACK_VAR(x,"x");
				HX_STACK_LINE(68)
				this->local->setCellCache(x,i0,this->db->get(((int)2 + (factor * x))));
			}
		}
		HX_STACK_LINE(71)
		if (((i1 >= (int)0))){
			HX_STACK_LINE(72)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = this->remote->get_width();		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(72)
			while(((_g1 < _g))){
				HX_STACK_LINE(72)
				int x = (_g1)++;		HX_STACK_VAR(x,"x");
				HX_STACK_LINE(73)
				this->remote->setCellCache(x,i1,this->db->get((((int)2 + (factor * x)) + offset)));
			}
		}
		HX_STACK_LINE(76)
		this->align->link(i0,i1);
		HX_STACK_LINE(77)
		this->align->addToOrder(i0,i1,null());
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(SqlCompare_obj,link,(void))

int SqlCompare_obj::denull( Dynamic x){
	HX_STACK_PUSH("SqlCompare::denull","coopy/SqlCompare.hx",48);
	HX_STACK_THIS(this);
	HX_STACK_ARG(x,"x");
	HX_STACK_LINE(49)
	if (((x == null()))){
		HX_STACK_LINE(49)
		return (int)-1;
	}
	HX_STACK_LINE(50)
	return x;
}


HX_DEFINE_DYNAMIC_FUNC1(SqlCompare_obj,denull,return )

bool SqlCompare_obj::validateSchema( ){
	HX_STACK_PUSH("SqlCompare::validateSchema","coopy/SqlCompare.hx",31);
	HX_STACK_THIS(this);
	HX_STACK_LINE(32)
	Array< ::String > all_cols1 = this->local->getColumnNames();		HX_STACK_VAR(all_cols1,"all_cols1");
	HX_STACK_LINE(33)
	Array< ::String > all_cols2 = this->remote->getColumnNames();		HX_STACK_VAR(all_cols2,"all_cols2");
	HX_STACK_LINE(34)
	if ((!(this->equalArray(all_cols1,all_cols2)))){
		HX_STACK_LINE(34)
		return false;
	}
	HX_STACK_LINE(37)
	Array< ::String > key_cols1 = this->local->getPrimaryKey();		HX_STACK_VAR(key_cols1,"key_cols1");
	HX_STACK_LINE(38)
	Array< ::String > key_cols2 = this->remote->getPrimaryKey();		HX_STACK_VAR(key_cols2,"key_cols2");
	HX_STACK_LINE(39)
	if ((!(this->equalArray(key_cols1,key_cols2)))){
		HX_STACK_LINE(39)
		return false;
	}
	HX_STACK_LINE(42)
	if (((key_cols1->length == (int)0))){
		HX_STACK_LINE(42)
		return false;
	}
	HX_STACK_LINE(45)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC0(SqlCompare_obj,validateSchema,return )

bool SqlCompare_obj::equalArray( Array< ::String > a1,Array< ::String > a2){
	HX_STACK_PUSH("SqlCompare::equalArray","coopy/SqlCompare.hx",23);
	HX_STACK_THIS(this);
	HX_STACK_ARG(a1,"a1");
	HX_STACK_ARG(a2,"a2");
	HX_STACK_LINE(24)
	if (((a1->length != a2->length))){
		HX_STACK_LINE(24)
		return false;
	}
	HX_STACK_LINE(25)
	{
		HX_STACK_LINE(25)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = a1->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(25)
		while(((_g1 < _g))){
			HX_STACK_LINE(25)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(26)
			if (((a1->__get(i) != a2->__get(i)))){
				HX_STACK_LINE(26)
				return false;
			}
		}
	}
	HX_STACK_LINE(28)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC2(SqlCompare_obj,equalArray,return )


SqlCompare_obj::SqlCompare_obj()
{
}

void SqlCompare_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(SqlCompare);
	HX_MARK_MEMBER_NAME(align,"align");
	HX_MARK_MEMBER_NAME(at1,"at1");
	HX_MARK_MEMBER_NAME(at0,"at0");
	HX_MARK_MEMBER_NAME(remote,"remote");
	HX_MARK_MEMBER_NAME(local,"local");
	HX_MARK_MEMBER_NAME(parent,"parent");
	HX_MARK_MEMBER_NAME(db,"db");
	HX_MARK_END_CLASS();
}

void SqlCompare_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(align,"align");
	HX_VISIT_MEMBER_NAME(at1,"at1");
	HX_VISIT_MEMBER_NAME(at0,"at0");
	HX_VISIT_MEMBER_NAME(remote,"remote");
	HX_VISIT_MEMBER_NAME(local,"local");
	HX_VISIT_MEMBER_NAME(parent,"parent");
	HX_VISIT_MEMBER_NAME(db,"db");
}

Dynamic SqlCompare_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 2:
		if (HX_FIELD_EQ(inName,"db") ) { return db; }
		break;
	case 3:
		if (HX_FIELD_EQ(inName,"at1") ) { return at1; }
		if (HX_FIELD_EQ(inName,"at0") ) { return at0; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"link") ) { return link_dyn(); }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"apply") ) { return apply_dyn(); }
		if (HX_FIELD_EQ(inName,"align") ) { return align; }
		if (HX_FIELD_EQ(inName,"local") ) { return local; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"denull") ) { return denull_dyn(); }
		if (HX_FIELD_EQ(inName,"remote") ) { return remote; }
		if (HX_FIELD_EQ(inName,"parent") ) { return parent; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"linkQuery") ) { return linkQuery_dyn(); }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"equalArray") ) { return equalArray_dyn(); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"validateSchema") ) { return validateSchema_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic SqlCompare_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 2:
		if (HX_FIELD_EQ(inName,"db") ) { db=inValue.Cast< ::coopy::SqlDatabase >(); return inValue; }
		break;
	case 3:
		if (HX_FIELD_EQ(inName,"at1") ) { at1=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"at0") ) { at0=inValue.Cast< int >(); return inValue; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"align") ) { align=inValue.Cast< ::coopy::Alignment >(); return inValue; }
		if (HX_FIELD_EQ(inName,"local") ) { local=inValue.Cast< ::coopy::SqlTable >(); return inValue; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"remote") ) { remote=inValue.Cast< ::coopy::SqlTable >(); return inValue; }
		if (HX_FIELD_EQ(inName,"parent") ) { parent=inValue.Cast< ::coopy::SqlTable >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void SqlCompare_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("align"));
	outFields->push(HX_CSTRING("at1"));
	outFields->push(HX_CSTRING("at0"));
	outFields->push(HX_CSTRING("remote"));
	outFields->push(HX_CSTRING("local"));
	outFields->push(HX_CSTRING("parent"));
	outFields->push(HX_CSTRING("db"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("apply"),
	HX_CSTRING("linkQuery"),
	HX_CSTRING("link"),
	HX_CSTRING("denull"),
	HX_CSTRING("validateSchema"),
	HX_CSTRING("equalArray"),
	HX_CSTRING("align"),
	HX_CSTRING("at1"),
	HX_CSTRING("at0"),
	HX_CSTRING("remote"),
	HX_CSTRING("local"),
	HX_CSTRING("parent"),
	HX_CSTRING("db"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(SqlCompare_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(SqlCompare_obj::__mClass,"__mClass");
};

Class SqlCompare_obj::__mClass;

void SqlCompare_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.SqlCompare"), hx::TCanCast< SqlCompare_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void SqlCompare_obj::__boot()
{
}

} // end namespace coopy

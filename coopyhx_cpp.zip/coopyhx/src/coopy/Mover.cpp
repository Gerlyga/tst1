#include <hxcpp.h>

#ifndef INCLUDED_IMap
#include <IMap.h>
#endif
#ifndef INCLUDED_coopy_Mover
#include <coopy/Mover.h>
#endif
#ifndef INCLUDED_coopy_Unit
#include <coopy/Unit.h>
#endif
#ifndef INCLUDED_haxe_ds_IntMap
#include <haxe/ds/IntMap.h>
#endif
namespace coopy{

Void Mover_obj::__construct()
{
	return null();
}

Mover_obj::~Mover_obj() { }

Dynamic Mover_obj::__CreateEmpty() { return  new Mover_obj; }
hx::ObjectPtr< Mover_obj > Mover_obj::__new()
{  hx::ObjectPtr< Mover_obj > result = new Mover_obj();
	result->__construct();
	return result;}

Dynamic Mover_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< Mover_obj > result = new Mover_obj();
	result->__construct();
	return result;}

Array< int > Mover_obj::moveUnits( Array< ::Dynamic > units){
	HX_STACK_PUSH("Mover::moveUnits","coopy/Mover.hx",25);
	HX_STACK_ARG(units,"units");
	HX_STACK_LINE(26)
	Array< int > isrc = Array_obj< int >::__new();		HX_STACK_VAR(isrc,"isrc");
	HX_STACK_LINE(27)
	Array< int > idest = Array_obj< int >::__new();		HX_STACK_VAR(idest,"idest");
	HX_STACK_LINE(28)
	int len = units->length;		HX_STACK_VAR(len,"len");
	HX_STACK_LINE(29)
	int ltop = (int)-1;		HX_STACK_VAR(ltop,"ltop");
	HX_STACK_LINE(30)
	int rtop = (int)-1;		HX_STACK_VAR(rtop,"rtop");
	HX_STACK_LINE(31)
	::haxe::ds::IntMap in_src = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(in_src,"in_src");
	HX_STACK_LINE(32)
	::haxe::ds::IntMap in_dest = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(in_dest,"in_dest");
	HX_STACK_LINE(33)
	{
		HX_STACK_LINE(33)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(33)
		while(((_g < len))){
			HX_STACK_LINE(33)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(34)
			::coopy::Unit unit = units->__get(i).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(unit,"unit");
			HX_STACK_LINE(35)
			if (((bool((unit->l >= (int)0)) && bool((unit->r >= (int)0))))){
				HX_STACK_LINE(36)
				if (((ltop < unit->l))){
					HX_STACK_LINE(36)
					ltop = unit->l;
				}
				HX_STACK_LINE(37)
				if (((rtop < unit->r))){
					HX_STACK_LINE(37)
					rtop = unit->r;
				}
				HX_STACK_LINE(38)
				{
					HX_STACK_LINE(38)
					in_src->set(unit->l,i);
					HX_STACK_LINE(38)
					i;
				}
				HX_STACK_LINE(39)
				{
					HX_STACK_LINE(39)
					in_dest->set(unit->r,i);
					HX_STACK_LINE(39)
					i;
				}
			}
		}
	}
	HX_STACK_LINE(42)
	Dynamic v;		HX_STACK_VAR(v,"v");
	HX_STACK_LINE(43)
	{
		HX_STACK_LINE(43)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = (ltop + (int)1);		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(43)
		while(((_g1 < _g))){
			HX_STACK_LINE(43)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(44)
			v = in_src->get(i);
			HX_STACK_LINE(45)
			if (((v != null()))){
				HX_STACK_LINE(45)
				isrc->push(v);
			}
		}
	}
	HX_STACK_LINE(47)
	{
		HX_STACK_LINE(47)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = (rtop + (int)1);		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(47)
		while(((_g1 < _g))){
			HX_STACK_LINE(47)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(48)
			v = in_dest->get(i);
			HX_STACK_LINE(49)
			if (((v != null()))){
				HX_STACK_LINE(49)
				idest->push(v);
			}
		}
	}
	HX_STACK_LINE(51)
	return ::coopy::Mover_obj::moveWithoutExtras(isrc,idest);
}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Mover_obj,moveUnits,return )

Array< int > Mover_obj::move( Array< int > isrc,Array< int > idest){
	HX_STACK_PUSH("Mover::move","coopy/Mover.hx",65);
	HX_STACK_ARG(isrc,"isrc");
	HX_STACK_ARG(idest,"idest");
	HX_STACK_LINE(66)
	int len = isrc->length;		HX_STACK_VAR(len,"len");
	HX_STACK_LINE(67)
	int len2 = idest->length;		HX_STACK_VAR(len2,"len2");
	HX_STACK_LINE(68)
	::haxe::ds::IntMap in_src = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(in_src,"in_src");
	HX_STACK_LINE(69)
	::haxe::ds::IntMap in_dest = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(in_dest,"in_dest");
	HX_STACK_LINE(70)
	{
		HX_STACK_LINE(70)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(70)
		while(((_g < len))){
			HX_STACK_LINE(70)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(71)
			{
				HX_STACK_LINE(71)
				in_src->set(isrc->__get(i),i);
				HX_STACK_LINE(71)
				i;
			}
		}
	}
	HX_STACK_LINE(73)
	{
		HX_STACK_LINE(73)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(73)
		while(((_g < len2))){
			HX_STACK_LINE(73)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(74)
			{
				HX_STACK_LINE(74)
				in_dest->set(idest->__get(i),i);
				HX_STACK_LINE(74)
				i;
			}
		}
	}
	HX_STACK_LINE(76)
	Array< int > src = Array_obj< int >::__new();		HX_STACK_VAR(src,"src");
	HX_STACK_LINE(77)
	Array< int > dest = Array_obj< int >::__new();		HX_STACK_VAR(dest,"dest");
	HX_STACK_LINE(78)
	int v;		HX_STACK_VAR(v,"v");
	HX_STACK_LINE(79)
	{
		HX_STACK_LINE(79)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(79)
		while(((_g < len))){
			HX_STACK_LINE(79)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(80)
			v = isrc->__get(i);
			HX_STACK_LINE(81)
			if ((in_dest->exists(v))){
				HX_STACK_LINE(81)
				src->push(v);
			}
		}
	}
	HX_STACK_LINE(83)
	{
		HX_STACK_LINE(83)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(83)
		while(((_g < len2))){
			HX_STACK_LINE(83)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(84)
			v = idest->__get(i);
			HX_STACK_LINE(85)
			if ((in_src->exists(v))){
				HX_STACK_LINE(85)
				dest->push(v);
			}
		}
	}
	HX_STACK_LINE(88)
	return ::coopy::Mover_obj::moveWithoutExtras(src,dest);
}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(Mover_obj,move,return )

Array< int > Mover_obj::moveWithoutExtras( Array< int > src,Array< int > dest){
	HX_STACK_PUSH("Mover::moveWithoutExtras","coopy/Mover.hx",91);
	HX_STACK_ARG(src,"src");
	HX_STACK_ARG(dest,"dest");
	HX_STACK_LINE(92)
	if (((src->length != dest->length))){
		HX_STACK_LINE(92)
		return null();
	}
	HX_STACK_LINE(93)
	if (((src->length <= (int)1))){
		HX_STACK_LINE(93)
		return Array_obj< int >::__new();
	}
	HX_STACK_LINE(95)
	int len = src->length;		HX_STACK_VAR(len,"len");
	HX_STACK_LINE(96)
	::haxe::ds::IntMap in_src = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(in_src,"in_src");
	HX_STACK_LINE(97)
	Array< ::Dynamic > blk_len = Array_obj< ::Dynamic >::__new().Add(::haxe::ds::IntMap_obj::__new());		HX_STACK_VAR(blk_len,"blk_len");
	HX_STACK_LINE(98)
	::haxe::ds::IntMap blk_src_loc = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(blk_src_loc,"blk_src_loc");
	HX_STACK_LINE(99)
	::haxe::ds::IntMap blk_dest_loc = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(blk_dest_loc,"blk_dest_loc");
	HX_STACK_LINE(100)
	{
		HX_STACK_LINE(100)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(100)
		while(((_g < len))){
			HX_STACK_LINE(100)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(101)
			{
				HX_STACK_LINE(101)
				in_src->set(src->__get(i),i);
				HX_STACK_LINE(101)
				i;
			}
		}
	}
	HX_STACK_LINE(103)
	int ct = (int)0;		HX_STACK_VAR(ct,"ct");
	HX_STACK_LINE(104)
	int in_cursor = (int)-2;		HX_STACK_VAR(in_cursor,"in_cursor");
	HX_STACK_LINE(105)
	int out_cursor = (int)0;		HX_STACK_VAR(out_cursor,"out_cursor");
	HX_STACK_LINE(106)
	int next;		HX_STACK_VAR(next,"next");
	HX_STACK_LINE(107)
	int blk = (int)-1;		HX_STACK_VAR(blk,"blk");
	HX_STACK_LINE(108)
	int v;		HX_STACK_VAR(v,"v");
	HX_STACK_LINE(109)
	while(((out_cursor < len))){
		HX_STACK_LINE(110)
		v = dest->__get(out_cursor);
		HX_STACK_LINE(111)
		next = in_src->get(v);
		HX_STACK_LINE(112)
		if (((next != (in_cursor + (int)1)))){
			HX_STACK_LINE(113)
			blk = v;
			HX_STACK_LINE(114)
			ct = (int)1;
			HX_STACK_LINE(115)
			blk_src_loc->set(blk,next);
			HX_STACK_LINE(116)
			blk_dest_loc->set(blk,out_cursor);
		}
		else{
			HX_STACK_LINE(117)
			(ct)++;
		}
		HX_STACK_LINE(120)
		blk_len->__get((int)0).StaticCast< ::haxe::ds::IntMap >()->set(blk,ct);
		HX_STACK_LINE(121)
		in_cursor = next;
		HX_STACK_LINE(122)
		(out_cursor)++;
	}
	HX_STACK_LINE(125)
	Array< int > blks = Array_obj< int >::__new();		HX_STACK_VAR(blks,"blks");
	HX_STACK_LINE(126)
	for(::cpp::FastIterator_obj< int > *__it = ::cpp::CreateFastIterator< int >(blk_len->__get((int)0).StaticCast< ::haxe::ds::IntMap >()->keys());  __it->hasNext(); ){
		int k = __it->next();
		blks->push(k);
	}

	HX_BEGIN_LOCAL_FUNC_S1(hx::LocalFunc,_Function_1_1,Array< ::Dynamic >,blk_len)
	int run(int a,int b){
		HX_STACK_PUSH("*::_Function_1_1","coopy/Mover.hx",127);
		HX_STACK_ARG(a,"a");
		HX_STACK_ARG(b,"b");
		{
			HX_STACK_LINE(127)
			return (blk_len->__get((int)0).StaticCast< ::haxe::ds::IntMap >()->get(b) - blk_len->__get((int)0).StaticCast< ::haxe::ds::IntMap >()->get(a));
		}
		return null();
	}
	HX_END_LOCAL_FUNC2(return)

	HX_STACK_LINE(127)
	blks->sort( Dynamic(new _Function_1_1(blk_len)));
	HX_STACK_LINE(129)
	Array< int > moved = Array_obj< int >::__new();		HX_STACK_VAR(moved,"moved");
	HX_STACK_LINE(131)
	while(((blks->length > (int)0))){
		HX_STACK_LINE(132)
		int blk1 = blks->shift();		HX_STACK_VAR(blk1,"blk1");
		HX_STACK_LINE(133)
		int blen = blks->length;		HX_STACK_VAR(blen,"blen");
		HX_STACK_LINE(134)
		int ref_src_loc = blk_src_loc->get(blk1);		HX_STACK_VAR(ref_src_loc,"ref_src_loc");
		HX_STACK_LINE(135)
		int ref_dest_loc = blk_dest_loc->get(blk1);		HX_STACK_VAR(ref_dest_loc,"ref_dest_loc");
		HX_STACK_LINE(136)
		int i = (blen - (int)1);		HX_STACK_VAR(i,"i");
		HX_STACK_LINE(137)
		while(((i >= (int)0))){
			HX_STACK_LINE(138)
			int blki = blks->__get(i);		HX_STACK_VAR(blki,"blki");
			HX_STACK_LINE(139)
			int blki_src_loc = blk_src_loc->get(blki);		HX_STACK_VAR(blki_src_loc,"blki_src_loc");
			HX_STACK_LINE(140)
			bool to_left_src = (blki_src_loc < ref_src_loc);		HX_STACK_VAR(to_left_src,"to_left_src");
			HX_STACK_LINE(141)
			bool to_left_dest = (blk_dest_loc->get(blki) < ref_dest_loc);		HX_STACK_VAR(to_left_dest,"to_left_dest");
			HX_STACK_LINE(142)
			if (((to_left_src != to_left_dest))){
				HX_STACK_LINE(143)
				int ct1 = blk_len->__get((int)0).StaticCast< ::haxe::ds::IntMap >()->get(blki);		HX_STACK_VAR(ct1,"ct1");
				HX_STACK_LINE(144)
				{
					HX_STACK_LINE(144)
					int _g = (int)0;		HX_STACK_VAR(_g,"_g");
					HX_STACK_LINE(144)
					while(((_g < ct1))){
						HX_STACK_LINE(144)
						int j = (_g)++;		HX_STACK_VAR(j,"j");
						HX_STACK_LINE(145)
						moved->push(src->__get(blki_src_loc));
						HX_STACK_LINE(146)
						(blki_src_loc)++;
					}
				}
				HX_STACK_LINE(148)
				blks->splice(i,(int)1);
			}
			HX_STACK_LINE(150)
			(i)--;
		}
	}
	HX_STACK_LINE(153)
	return moved;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(Mover_obj,moveWithoutExtras,return )


Mover_obj::Mover_obj()
{
}

void Mover_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(Mover);
	HX_MARK_END_CLASS();
}

void Mover_obj::__Visit(HX_VISIT_PARAMS)
{
}

Dynamic Mover_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"move") ) { return move_dyn(); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"moveUnits") ) { return moveUnits_dyn(); }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"moveWithoutExtras") ) { return moveWithoutExtras_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic Mover_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	return super::__SetField(inName,inValue,inCallProp);
}

void Mover_obj::__GetFields(Array< ::String> &outFields)
{
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	HX_CSTRING("moveUnits"),
	HX_CSTRING("move"),
	HX_CSTRING("moveWithoutExtras"),
	String(null()) };

static ::String sMemberFields[] = {
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Mover_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Mover_obj::__mClass,"__mClass");
};

Class Mover_obj::__mClass;

void Mover_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.Mover"), hx::TCanCast< Mover_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void Mover_obj::__boot()
{
}

} // end namespace coopy

#include <hxcpp.h>

#ifndef INCLUDED_IMap
#include <IMap.h>
#endif
#ifndef INCLUDED_coopy_SparseSheet
#include <coopy/SparseSheet.h>
#endif
#ifndef INCLUDED_haxe_ds_IntMap
#include <haxe/ds/IntMap.h>
#endif
namespace coopy{

Void SparseSheet_obj::__construct()
{
HX_STACK_PUSH("SparseSheet::new","coopy/SparseSheet.hx",14);
{
	HX_STACK_LINE(14)
	this->h = this->w = (int)0;
}
;
	return null();
}

SparseSheet_obj::~SparseSheet_obj() { }

Dynamic SparseSheet_obj::__CreateEmpty() { return  new SparseSheet_obj; }
hx::ObjectPtr< SparseSheet_obj > SparseSheet_obj::__new()
{  hx::ObjectPtr< SparseSheet_obj > result = new SparseSheet_obj();
	result->__construct();
	return result;}

Dynamic SparseSheet_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< SparseSheet_obj > result = new SparseSheet_obj();
	result->__construct();
	return result;}

Void SparseSheet_obj::set( int x,int y,Dynamic val){
{
		HX_STACK_PUSH("SparseSheet::set","coopy/SparseSheet.hx",37);
		HX_STACK_THIS(this);
		HX_STACK_ARG(x,"x");
		HX_STACK_ARG(y,"y");
		HX_STACK_ARG(val,"val");
		HX_STACK_LINE(38)
		::haxe::ds::IntMap cursor = this->row->get(y);		HX_STACK_VAR(cursor,"cursor");
		HX_STACK_LINE(39)
		if (((cursor == null()))){
			HX_STACK_LINE(40)
			cursor = ::haxe::ds::IntMap_obj::__new();
			HX_STACK_LINE(41)
			this->row->set(y,cursor);
		}
		HX_STACK_LINE(43)
		cursor->set(x,val);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(SparseSheet_obj,set,(void))

Dynamic SparseSheet_obj::get( int x,int y){
	HX_STACK_PUSH("SparseSheet::get","coopy/SparseSheet.hx",29);
	HX_STACK_THIS(this);
	HX_STACK_ARG(x,"x");
	HX_STACK_ARG(y,"y");
	HX_STACK_LINE(30)
	::haxe::ds::IntMap cursor = this->row->get(y);		HX_STACK_VAR(cursor,"cursor");
	HX_STACK_LINE(31)
	if (((cursor == null()))){
		HX_STACK_LINE(31)
		return this->zero;
	}
	HX_STACK_LINE(32)
	Dynamic val = cursor->get(x);		HX_STACK_VAR(val,"val");
	HX_STACK_LINE(33)
	if (((val == null()))){
		HX_STACK_LINE(33)
		return this->zero;
	}
	HX_STACK_LINE(34)
	return val;
}


HX_DEFINE_DYNAMIC_FUNC2(SparseSheet_obj,get,return )

Void SparseSheet_obj::nonDestructiveResize( int w,int h,Dynamic zero){
{
		HX_STACK_PUSH("SparseSheet::nonDestructiveResize","coopy/SparseSheet.hx",23);
		HX_STACK_THIS(this);
		HX_STACK_ARG(w,"w");
		HX_STACK_ARG(h,"h");
		HX_STACK_ARG(zero,"zero");
		HX_STACK_LINE(24)
		this->w = w;
		HX_STACK_LINE(25)
		this->h = h;
		HX_STACK_LINE(26)
		this->zero = zero;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(SparseSheet_obj,nonDestructiveResize,(void))

Void SparseSheet_obj::resize( int w,int h,Dynamic zero){
{
		HX_STACK_PUSH("SparseSheet::resize","coopy/SparseSheet.hx",18);
		HX_STACK_THIS(this);
		HX_STACK_ARG(w,"w");
		HX_STACK_ARG(h,"h");
		HX_STACK_ARG(zero,"zero");
		HX_STACK_LINE(19)
		this->row = ::haxe::ds::IntMap_obj::__new();
		HX_STACK_LINE(20)
		this->nonDestructiveResize(w,h,zero);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(SparseSheet_obj,resize,(void))


SparseSheet_obj::SparseSheet_obj()
{
}

void SparseSheet_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(SparseSheet);
	HX_MARK_MEMBER_NAME(zero,"zero");
	HX_MARK_MEMBER_NAME(row,"row");
	HX_MARK_MEMBER_NAME(w,"w");
	HX_MARK_MEMBER_NAME(h,"h");
	HX_MARK_END_CLASS();
}

void SparseSheet_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(zero,"zero");
	HX_VISIT_MEMBER_NAME(row,"row");
	HX_VISIT_MEMBER_NAME(w,"w");
	HX_VISIT_MEMBER_NAME(h,"h");
}

Dynamic SparseSheet_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 1:
		if (HX_FIELD_EQ(inName,"w") ) { return w; }
		if (HX_FIELD_EQ(inName,"h") ) { return h; }
		break;
	case 3:
		if (HX_FIELD_EQ(inName,"set") ) { return set_dyn(); }
		if (HX_FIELD_EQ(inName,"get") ) { return get_dyn(); }
		if (HX_FIELD_EQ(inName,"row") ) { return row; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"zero") ) { return zero; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"resize") ) { return resize_dyn(); }
		break;
	case 20:
		if (HX_FIELD_EQ(inName,"nonDestructiveResize") ) { return nonDestructiveResize_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic SparseSheet_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 1:
		if (HX_FIELD_EQ(inName,"w") ) { w=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"h") ) { h=inValue.Cast< int >(); return inValue; }
		break;
	case 3:
		if (HX_FIELD_EQ(inName,"row") ) { row=inValue.Cast< ::haxe::ds::IntMap >(); return inValue; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"zero") ) { zero=inValue.Cast< Dynamic >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void SparseSheet_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("zero"));
	outFields->push(HX_CSTRING("row"));
	outFields->push(HX_CSTRING("w"));
	outFields->push(HX_CSTRING("h"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("set"),
	HX_CSTRING("get"),
	HX_CSTRING("nonDestructiveResize"),
	HX_CSTRING("resize"),
	HX_CSTRING("zero"),
	HX_CSTRING("row"),
	HX_CSTRING("w"),
	HX_CSTRING("h"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(SparseSheet_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(SparseSheet_obj::__mClass,"__mClass");
};

Class SparseSheet_obj::__mClass;

void SparseSheet_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.SparseSheet"), hx::TCanCast< SparseSheet_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void SparseSheet_obj::__boot()
{
}

} // end namespace coopy

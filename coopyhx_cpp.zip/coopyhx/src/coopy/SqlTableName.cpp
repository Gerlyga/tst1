#include <hxcpp.h>

#ifndef INCLUDED_coopy_SqlTableName
#include <coopy/SqlTableName.h>
#endif
namespace coopy{

Void SqlTableName_obj::__construct(::String __o_name,::String __o_prefix)
{
HX_STACK_PUSH("SqlTableName::new","coopy/SqlTableName.hx",12);
::String name = __o_name.Default(HX_CSTRING(""));
::String prefix = __o_prefix.Default(HX_CSTRING(""));
{
	HX_STACK_LINE(13)
	this->name = name;
	HX_STACK_LINE(14)
	this->prefix = prefix;
}
;
	return null();
}

SqlTableName_obj::~SqlTableName_obj() { }

Dynamic SqlTableName_obj::__CreateEmpty() { return  new SqlTableName_obj; }
hx::ObjectPtr< SqlTableName_obj > SqlTableName_obj::__new(::String __o_name,::String __o_prefix)
{  hx::ObjectPtr< SqlTableName_obj > result = new SqlTableName_obj();
	result->__construct(__o_name,__o_prefix);
	return result;}

Dynamic SqlTableName_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< SqlTableName_obj > result = new SqlTableName_obj();
	result->__construct(inArgs[0],inArgs[1]);
	return result;}

::String SqlTableName_obj::toString( ){
	HX_STACK_PUSH("SqlTableName::toString","coopy/SqlTableName.hx",17);
	HX_STACK_THIS(this);
	HX_STACK_LINE(18)
	if (((this->prefix == HX_CSTRING("")))){
		HX_STACK_LINE(18)
		return this->name;
	}
	HX_STACK_LINE(19)
	return ((this->prefix + HX_CSTRING(".")) + this->name);
}


HX_DEFINE_DYNAMIC_FUNC0(SqlTableName_obj,toString,return )


SqlTableName_obj::SqlTableName_obj()
{
}

void SqlTableName_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(SqlTableName);
	HX_MARK_MEMBER_NAME(prefix,"prefix");
	HX_MARK_MEMBER_NAME(name,"name");
	HX_MARK_END_CLASS();
}

void SqlTableName_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(prefix,"prefix");
	HX_VISIT_MEMBER_NAME(name,"name");
}

Dynamic SqlTableName_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { return name; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"prefix") ) { return prefix; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"toString") ) { return toString_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic SqlTableName_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { name=inValue.Cast< ::String >(); return inValue; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"prefix") ) { prefix=inValue.Cast< ::String >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void SqlTableName_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("prefix"));
	outFields->push(HX_CSTRING("name"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("toString"),
	HX_CSTRING("prefix"),
	HX_CSTRING("name"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(SqlTableName_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(SqlTableName_obj::__mClass,"__mClass");
};

Class SqlTableName_obj::__mClass;

void SqlTableName_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.SqlTableName"), hx::TCanCast< SqlTableName_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void SqlTableName_obj::__boot()
{
}

} // end namespace coopy

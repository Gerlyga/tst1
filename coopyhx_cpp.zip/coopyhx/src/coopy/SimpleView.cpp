#include <hxcpp.h>

#ifndef INCLUDED_IMap
#include <IMap.h>
#endif
#ifndef INCLUDED_Std
#include <Std.h>
#endif
#ifndef INCLUDED_coopy_SimpleCell
#include <coopy/SimpleCell.h>
#endif
#ifndef INCLUDED_coopy_SimpleView
#include <coopy/SimpleView.h>
#endif
#ifndef INCLUDED_coopy_View
#include <coopy/View.h>
#endif
#ifndef INCLUDED_haxe_ds_StringMap
#include <haxe/ds/StringMap.h>
#endif
namespace coopy{

Void SimpleView_obj::__construct()
{
HX_STACK_PUSH("SimpleView::new","coopy/SimpleView.hx",16);
{
}
;
	return null();
}

SimpleView_obj::~SimpleView_obj() { }

Dynamic SimpleView_obj::__CreateEmpty() { return  new SimpleView_obj; }
hx::ObjectPtr< SimpleView_obj > SimpleView_obj::__new()
{  hx::ObjectPtr< SimpleView_obj > result = new SimpleView_obj();
	result->__construct();
	return result;}

Dynamic SimpleView_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< SimpleView_obj > result = new SimpleView_obj();
	result->__construct();
	return result;}

hx::Object *SimpleView_obj::__ToInterface(const hx::type_info &inType) {
	if (inType==typeid( ::coopy::View_obj)) return operator ::coopy::View_obj *();
	return super::__ToInterface(inType);
}

bool SimpleView_obj::isHash( Dynamic h){
	HX_STACK_PUSH("SimpleView::isHash","coopy/SimpleView.hx",59);
	HX_STACK_THIS(this);
	HX_STACK_ARG(h,"h");
	HX_STACK_LINE(59)
	return ::Std_obj::is(h,hx::ClassOf< ::haxe::ds::StringMap >());
}


HX_DEFINE_DYNAMIC_FUNC1(SimpleView_obj,isHash,return )

Dynamic SimpleView_obj::hashGet( Dynamic h,::String str){
	HX_STACK_PUSH("SimpleView::hashGet","coopy/SimpleView.hx",54);
	HX_STACK_THIS(this);
	HX_STACK_ARG(h,"h");
	HX_STACK_ARG(str,"str");
	HX_STACK_LINE(55)
	::haxe::ds::StringMap hh = h;		HX_STACK_VAR(hh,"hh");
	HX_STACK_LINE(56)
	return hh->get(str);
}


HX_DEFINE_DYNAMIC_FUNC2(SimpleView_obj,hashGet,return )

bool SimpleView_obj::hashExists( Dynamic h,::String str){
	HX_STACK_PUSH("SimpleView::hashExists","coopy/SimpleView.hx",49);
	HX_STACK_THIS(this);
	HX_STACK_ARG(h,"h");
	HX_STACK_ARG(str,"str");
	HX_STACK_LINE(50)
	::haxe::ds::StringMap hh = h;		HX_STACK_VAR(hh,"hh");
	HX_STACK_LINE(51)
	return hh->exists(str);
}


HX_DEFINE_DYNAMIC_FUNC2(SimpleView_obj,hashExists,return )

Void SimpleView_obj::hashSet( Dynamic h,::String str,Dynamic d){
{
		HX_STACK_PUSH("SimpleView::hashSet","coopy/SimpleView.hx",44);
		HX_STACK_THIS(this);
		HX_STACK_ARG(h,"h");
		HX_STACK_ARG(str,"str");
		HX_STACK_ARG(d,"d");
		HX_STACK_LINE(45)
		::haxe::ds::StringMap hh = h;		HX_STACK_VAR(hh,"hh");
		HX_STACK_LINE(46)
		{
			HX_STACK_LINE(46)
			Dynamic value = d;		HX_STACK_VAR(value,"value");
			HX_STACK_LINE(46)
			hh->set(str,value);
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(SimpleView_obj,hashSet,(void))

Dynamic SimpleView_obj::makeHash( ){
	HX_STACK_PUSH("SimpleView::makeHash","coopy/SimpleView.hx",40);
	HX_STACK_THIS(this);
	HX_STACK_LINE(40)
	return ::haxe::ds::StringMap_obj::__new();
}


HX_DEFINE_DYNAMIC_FUNC0(SimpleView_obj,makeHash,return )

Dynamic SimpleView_obj::toDatum( ::String _tmp_x){
	HX_STACK_PUSH("SimpleView::toDatum","coopy/SimpleView.hx",32);
	HX_STACK_THIS(this);
	HX_STACK_ARG(_tmp_x,"_tmp_x");
	HX_STACK_LINE(32)
	Dynamic x = _tmp_x;		HX_STACK_VAR(x,"x");
	HX_STACK_LINE(32)
	return ::coopy::SimpleCell_obj::__new(x);
}


HX_DEFINE_DYNAMIC_FUNC1(SimpleView_obj,toDatum,return )

bool SimpleView_obj::equals( Dynamic d1,Dynamic d2){
	HX_STACK_PUSH("SimpleView::equals","coopy/SimpleView.hx",24);
	HX_STACK_THIS(this);
	HX_STACK_ARG(d1,"d1");
	HX_STACK_ARG(d2,"d2");
	HX_STACK_LINE(26)
	if (((bool((d1 == null())) && bool((d2 == null()))))){
		HX_STACK_LINE(26)
		return true;
	}
	HX_STACK_LINE(27)
	if (((bool((d1 == null())) && bool(((HX_CSTRING("") + ::Std_obj::string(d2)) == HX_CSTRING("")))))){
		HX_STACK_LINE(27)
		return true;
	}
	HX_STACK_LINE(28)
	if (((bool(((HX_CSTRING("") + ::Std_obj::string(d1)) == HX_CSTRING(""))) && bool((d2 == null()))))){
		HX_STACK_LINE(28)
		return true;
	}
	HX_STACK_LINE(29)
	return ((HX_CSTRING("") + ::Std_obj::string(d1)) == (HX_CSTRING("") + ::Std_obj::string(d2)));
}


HX_DEFINE_DYNAMIC_FUNC2(SimpleView_obj,equals,return )

::String SimpleView_obj::toString( Dynamic d){
	HX_STACK_PUSH("SimpleView::toString","coopy/SimpleView.hx",19);
	HX_STACK_THIS(this);
	HX_STACK_ARG(d,"d");
	HX_STACK_LINE(20)
	if (((d == null()))){
		HX_STACK_LINE(20)
		return null();
	}
	HX_STACK_LINE(21)
	return (HX_CSTRING("") + ::Std_obj::string(d));
}


HX_DEFINE_DYNAMIC_FUNC1(SimpleView_obj,toString,return )


SimpleView_obj::SimpleView_obj()
{
}

void SimpleView_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(SimpleView);
	HX_MARK_END_CLASS();
}

void SimpleView_obj::__Visit(HX_VISIT_PARAMS)
{
}

Dynamic SimpleView_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 6:
		if (HX_FIELD_EQ(inName,"isHash") ) { return isHash_dyn(); }
		if (HX_FIELD_EQ(inName,"equals") ) { return equals_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"hashGet") ) { return hashGet_dyn(); }
		if (HX_FIELD_EQ(inName,"hashSet") ) { return hashSet_dyn(); }
		if (HX_FIELD_EQ(inName,"toDatum") ) { return toDatum_dyn(); }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"makeHash") ) { return makeHash_dyn(); }
		if (HX_FIELD_EQ(inName,"toString") ) { return toString_dyn(); }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"hashExists") ) { return hashExists_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic SimpleView_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	return super::__SetField(inName,inValue,inCallProp);
}

void SimpleView_obj::__GetFields(Array< ::String> &outFields)
{
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("isHash"),
	HX_CSTRING("hashGet"),
	HX_CSTRING("hashExists"),
	HX_CSTRING("hashSet"),
	HX_CSTRING("makeHash"),
	HX_CSTRING("toDatum"),
	HX_CSTRING("equals"),
	HX_CSTRING("toString"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(SimpleView_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(SimpleView_obj::__mClass,"__mClass");
};

Class SimpleView_obj::__mClass;

void SimpleView_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.SimpleView"), hx::TCanCast< SimpleView_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void SimpleView_obj::__boot()
{
}

} // end namespace coopy

#include <hxcpp.h>

#ifndef INCLUDED_IMap
#include <IMap.h>
#endif
#ifndef INCLUDED_Lambda
#include <Lambda.h>
#endif
#ifndef INCLUDED_List
#include <List.h>
#endif
#ifndef INCLUDED_coopy_Alignment
#include <coopy/Alignment.h>
#endif
#ifndef INCLUDED_coopy_CompareFlags
#include <coopy/CompareFlags.h>
#endif
#ifndef INCLUDED_coopy_CompareTable
#include <coopy/CompareTable.h>
#endif
#ifndef INCLUDED_coopy_CrossMatch
#include <coopy/CrossMatch.h>
#endif
#ifndef INCLUDED_coopy_IndexItem
#include <coopy/IndexItem.h>
#endif
#ifndef INCLUDED_coopy_IndexPair
#include <coopy/IndexPair.h>
#endif
#ifndef INCLUDED_coopy_Ordering
#include <coopy/Ordering.h>
#endif
#ifndef INCLUDED_coopy_Table
#include <coopy/Table.h>
#endif
#ifndef INCLUDED_coopy_TableComparisonState
#include <coopy/TableComparisonState.h>
#endif
#ifndef INCLUDED_coopy_Unit
#include <coopy/Unit.h>
#endif
#ifndef INCLUDED_coopy_View
#include <coopy/View.h>
#endif
#ifndef INCLUDED_haxe_ds_IntMap
#include <haxe/ds/IntMap.h>
#endif
#ifndef INCLUDED_haxe_ds_StringMap
#include <haxe/ds/StringMap.h>
#endif
#ifndef INCLUDED_hxMath
#include <hxMath.h>
#endif
namespace coopy{

Void CompareTable_obj::__construct(::coopy::TableComparisonState comp)
{
HX_STACK_PUSH("CompareTable::new","coopy/CompareTable.hx",24);
{
	HX_STACK_LINE(24)
	this->comp = comp;
}
;
	return null();
}

CompareTable_obj::~CompareTable_obj() { }

Dynamic CompareTable_obj::__CreateEmpty() { return  new CompareTable_obj; }
hx::ObjectPtr< CompareTable_obj > CompareTable_obj::__new(::coopy::TableComparisonState comp)
{  hx::ObjectPtr< CompareTable_obj > result = new CompareTable_obj();
	result->__construct(comp);
	return result;}

Dynamic CompareTable_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< CompareTable_obj > result = new CompareTable_obj();
	result->__construct(inArgs[0]);
	return result;}

Array< ::Dynamic > CompareTable_obj::getIndexes( ){
	HX_STACK_PUSH("CompareTable::getIndexes","coopy/CompareTable.hx",506);
	HX_STACK_THIS(this);
	HX_STACK_LINE(506)
	return this->indexes;
}


HX_DEFINE_DYNAMIC_FUNC0(CompareTable_obj,getIndexes,return )

Void CompareTable_obj::storeIndexes( ){
{
		HX_STACK_PUSH("CompareTable::storeIndexes","coopy/CompareTable.hx",491);
		HX_STACK_THIS(this);
		HX_STACK_LINE(491)
		this->indexes = Array_obj< ::Dynamic >::__new();
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(CompareTable_obj,storeIndexes,(void))

bool CompareTable_obj::compareCore( ){
	HX_STACK_PUSH("CompareTable::compareCore","coopy/CompareTable.hx",471);
	HX_STACK_THIS(this);
	HX_STACK_LINE(472)
	if ((this->comp->completed)){
		HX_STACK_LINE(472)
		return false;
	}
	HX_STACK_LINE(473)
	if ((!(this->comp->is_equal_known))){
		HX_STACK_LINE(473)
		return this->testIsEqual();
	}
	HX_STACK_LINE(476)
	if ((!(this->comp->has_same_columns_known))){
		HX_STACK_LINE(476)
		return this->testHasSameColumns();
	}
	HX_STACK_LINE(479)
	this->comp->completed = true;
	HX_STACK_LINE(480)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC0(CompareTable_obj,compareCore,return )

bool CompareTable_obj::isEqual2( ::coopy::Table a,::coopy::Table b){
	HX_STACK_PUSH("CompareTable::isEqual2","coopy/CompareTable.hx",456);
	HX_STACK_THIS(this);
	HX_STACK_ARG(a,"a");
	HX_STACK_ARG(b,"b");
	HX_STACK_LINE(457)
	if (((bool((a->get_width() != b->get_width())) || bool((a->get_height() != b->get_height()))))){
		HX_STACK_LINE(457)
		return false;
	}
	HX_STACK_LINE(460)
	::coopy::View av = a->getCellView();		HX_STACK_VAR(av,"av");
	HX_STACK_LINE(461)
	{
		HX_STACK_LINE(461)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = a->get_height();		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(461)
		while(((_g1 < _g))){
			HX_STACK_LINE(461)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(462)
			{
				HX_STACK_LINE(462)
				int _g3 = (int)0;		HX_STACK_VAR(_g3,"_g3");
				int _g2 = a->get_width();		HX_STACK_VAR(_g2,"_g2");
				HX_STACK_LINE(462)
				while(((_g3 < _g2))){
					HX_STACK_LINE(462)
					int j = (_g3)++;		HX_STACK_VAR(j,"j");
					HX_STACK_LINE(463)
					if ((!(av->equals(a->getCell(j,i),b->getCell(j,i))))){
						HX_STACK_LINE(463)
						return false;
					}
				}
			}
		}
	}
	HX_STACK_LINE(468)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC2(CompareTable_obj,isEqual2,return )

bool CompareTable_obj::testIsEqual( ){
	HX_STACK_PUSH("CompareTable::testIsEqual","coopy/CompareTable.hx",443);
	HX_STACK_THIS(this);
	HX_STACK_LINE(444)
	::coopy::Table p = this->comp->p;		HX_STACK_VAR(p,"p");
	HX_STACK_LINE(445)
	::coopy::Table a = this->comp->a;		HX_STACK_VAR(a,"a");
	HX_STACK_LINE(446)
	::coopy::Table b = this->comp->b;		HX_STACK_VAR(b,"b");
	HX_STACK_LINE(447)
	bool eq = this->isEqual2(a,b);		HX_STACK_VAR(eq,"eq");
	HX_STACK_LINE(448)
	if (((bool(eq) && bool((p != null()))))){
		HX_STACK_LINE(448)
		eq = this->isEqual2(p,a);
	}
	HX_STACK_LINE(451)
	this->comp->is_equal = eq;
	HX_STACK_LINE(452)
	this->comp->is_equal_known = true;
	HX_STACK_LINE(453)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC0(CompareTable_obj,testIsEqual,return )

bool CompareTable_obj::hasSameColumns2( ::coopy::Table a,::coopy::Table b){
	HX_STACK_PUSH("CompareTable::hasSameColumns2","coopy/CompareTable.hx",418);
	HX_STACK_THIS(this);
	HX_STACK_ARG(a,"a");
	HX_STACK_ARG(b,"b");
	HX_STACK_LINE(419)
	if (((a->get_width() != b->get_width()))){
		HX_STACK_LINE(419)
		return false;
	}
	HX_STACK_LINE(422)
	if (((bool((a->get_height() == (int)0)) || bool((b->get_height() == (int)0))))){
		HX_STACK_LINE(422)
		return true;
	}
	HX_STACK_LINE(428)
	::coopy::View av = a->getCellView();		HX_STACK_VAR(av,"av");
	HX_STACK_LINE(429)
	{
		HX_STACK_LINE(429)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = a->get_width();		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(429)
		while(((_g1 < _g))){
			HX_STACK_LINE(429)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(430)
			{
				HX_STACK_LINE(430)
				int _g3 = (i + (int)1);		HX_STACK_VAR(_g3,"_g3");
				int _g2 = a->get_width();		HX_STACK_VAR(_g2,"_g2");
				HX_STACK_LINE(430)
				while(((_g3 < _g2))){
					HX_STACK_LINE(430)
					int j = (_g3)++;		HX_STACK_VAR(j,"j");
					HX_STACK_LINE(431)
					if ((av->equals(a->getCell(i,(int)0),a->getCell(j,(int)0)))){
						HX_STACK_LINE(431)
						return false;
					}
				}
			}
			HX_STACK_LINE(435)
			if ((!(av->equals(a->getCell(i,(int)0),b->getCell(i,(int)0))))){
				HX_STACK_LINE(435)
				return false;
			}
		}
	}
	HX_STACK_LINE(440)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC2(CompareTable_obj,hasSameColumns2,return )

bool CompareTable_obj::testHasSameColumns( ){
	HX_STACK_PUSH("CompareTable::testHasSameColumns","coopy/CompareTable.hx",405);
	HX_STACK_THIS(this);
	HX_STACK_LINE(406)
	::coopy::Table p = this->comp->p;		HX_STACK_VAR(p,"p");
	HX_STACK_LINE(407)
	::coopy::Table a = this->comp->a;		HX_STACK_VAR(a,"a");
	HX_STACK_LINE(408)
	::coopy::Table b = this->comp->b;		HX_STACK_VAR(b,"b");
	HX_STACK_LINE(409)
	bool eq = this->hasSameColumns2(a,b);		HX_STACK_VAR(eq,"eq");
	HX_STACK_LINE(410)
	if (((bool(eq) && bool((p != null()))))){
		HX_STACK_LINE(410)
		eq = this->hasSameColumns2(p,a);
	}
	HX_STACK_LINE(413)
	this->comp->has_same_columns = eq;
	HX_STACK_LINE(414)
	this->comp->has_same_columns_known = true;
	HX_STACK_LINE(415)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC0(CompareTable_obj,testHasSameColumns,return )

Void CompareTable_obj::alignColumns( ::coopy::Alignment align,::coopy::Table a,::coopy::Table b){
{
		HX_STACK_PUSH("CompareTable::alignColumns","coopy/CompareTable.hx",311);
		HX_STACK_THIS(this);
		HX_STACK_ARG(align,"align");
		HX_STACK_ARG(a,"a");
		HX_STACK_ARG(b,"b");
		HX_STACK_LINE(312)
		align->range(a->get_width(),b->get_width());
		HX_STACK_LINE(313)
		align->tables(a,b);
		HX_STACK_LINE(314)
		align->setRowlike(false);
		HX_STACK_LINE(316)
		int slop = (int)5;		HX_STACK_VAR(slop,"slop");
		HX_STACK_LINE(318)
		::coopy::View va = a->getCellView();		HX_STACK_VAR(va,"va");
		HX_STACK_LINE(319)
		::coopy::View vb = b->getCellView();		HX_STACK_VAR(vb,"vb");
		HX_STACK_LINE(320)
		int ra_best = (int)0;		HX_STACK_VAR(ra_best,"ra_best");
		HX_STACK_LINE(321)
		int rb_best = (int)0;		HX_STACK_VAR(rb_best,"rb_best");
		HX_STACK_LINE(322)
		int ct_best = (int)-1;		HX_STACK_VAR(ct_best,"ct_best");
		HX_STACK_LINE(323)
		::haxe::ds::StringMap ma_best = null();		HX_STACK_VAR(ma_best,"ma_best");
		HX_STACK_LINE(324)
		::haxe::ds::StringMap mb_best = null();		HX_STACK_VAR(mb_best,"mb_best");
		HX_STACK_LINE(325)
		int ra_header = (int)0;		HX_STACK_VAR(ra_header,"ra_header");
		HX_STACK_LINE(326)
		int rb_header = (int)0;		HX_STACK_VAR(rb_header,"rb_header");
		HX_STACK_LINE(327)
		int ra_uniques = (int)0;		HX_STACK_VAR(ra_uniques,"ra_uniques");
		HX_STACK_LINE(328)
		int rb_uniques = (int)0;		HX_STACK_VAR(rb_uniques,"rb_uniques");
		HX_STACK_LINE(329)
		{
			HX_STACK_LINE(329)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(329)
			while(((_g < slop))){
				HX_STACK_LINE(329)
				int ra = (_g)++;		HX_STACK_VAR(ra,"ra");
				HX_STACK_LINE(330)
				if (((ra >= a->get_height()))){
					HX_STACK_LINE(330)
					break;
				}
				HX_STACK_LINE(331)
				{
					HX_STACK_LINE(331)
					int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
					HX_STACK_LINE(331)
					while(((_g1 < slop))){
						HX_STACK_LINE(331)
						int rb = (_g1)++;		HX_STACK_VAR(rb,"rb");
						HX_STACK_LINE(332)
						if (((rb >= b->get_height()))){
							HX_STACK_LINE(332)
							break;
						}
						HX_STACK_LINE(333)
						::haxe::ds::StringMap ma = ::haxe::ds::StringMap_obj::__new();		HX_STACK_VAR(ma,"ma");
						HX_STACK_LINE(334)
						::haxe::ds::StringMap mb = ::haxe::ds::StringMap_obj::__new();		HX_STACK_VAR(mb,"mb");
						HX_STACK_LINE(335)
						int ct = (int)0;		HX_STACK_VAR(ct,"ct");
						HX_STACK_LINE(336)
						int uniques = (int)0;		HX_STACK_VAR(uniques,"uniques");
						HX_STACK_LINE(337)
						{
							HX_STACK_LINE(337)
							int _g3 = (int)0;		HX_STACK_VAR(_g3,"_g3");
							int _g2 = a->get_width();		HX_STACK_VAR(_g2,"_g2");
							HX_STACK_LINE(337)
							while(((_g3 < _g2))){
								HX_STACK_LINE(337)
								int ca = (_g3)++;		HX_STACK_VAR(ca,"ca");
								HX_STACK_LINE(338)
								::String key = va->toString(a->getCell(ca,ra));		HX_STACK_VAR(key,"key");
								HX_STACK_LINE(339)
								if ((ma->exists(key))){
									HX_STACK_LINE(340)
									ma->set(key,(int)-1);
									HX_STACK_LINE(341)
									(uniques)--;
								}
								else{
									HX_STACK_LINE(343)
									ma->set(key,ca);
									HX_STACK_LINE(344)
									(uniques)++;
								}
							}
						}
						HX_STACK_LINE(347)
						if (((uniques > ra_uniques))){
							HX_STACK_LINE(348)
							ra_header = ra;
							HX_STACK_LINE(349)
							ra_uniques = uniques;
						}
						HX_STACK_LINE(351)
						uniques = (int)0;
						HX_STACK_LINE(352)
						{
							HX_STACK_LINE(352)
							int _g3 = (int)0;		HX_STACK_VAR(_g3,"_g3");
							int _g2 = b->get_width();		HX_STACK_VAR(_g2,"_g2");
							HX_STACK_LINE(352)
							while(((_g3 < _g2))){
								HX_STACK_LINE(352)
								int cb = (_g3)++;		HX_STACK_VAR(cb,"cb");
								HX_STACK_LINE(353)
								::String key = vb->toString(b->getCell(cb,rb));		HX_STACK_VAR(key,"key");
								HX_STACK_LINE(354)
								if ((mb->exists(key))){
									HX_STACK_LINE(355)
									mb->set(key,(int)-1);
									HX_STACK_LINE(356)
									(uniques)--;
								}
								else{
									HX_STACK_LINE(358)
									mb->set(key,cb);
									HX_STACK_LINE(359)
									(uniques)++;
								}
							}
						}
						HX_STACK_LINE(362)
						if (((uniques > rb_uniques))){
							HX_STACK_LINE(363)
							rb_header = rb;
							HX_STACK_LINE(364)
							rb_uniques = uniques;
						}
						HX_STACK_LINE(367)
						for(::cpp::FastIterator_obj< ::String > *__it = ::cpp::CreateFastIterator< ::String >(ma->keys());  __it->hasNext(); ){
							::String key = __it->next();
							{
								HX_STACK_LINE(368)
								int i0 = ma->get(key);		HX_STACK_VAR(i0,"i0");
								HX_STACK_LINE(369)
								Dynamic i1 = mb->get(key);		HX_STACK_VAR(i1,"i1");
								HX_STACK_LINE(370)
								if (((i1 != null()))){
									HX_STACK_LINE(370)
									if (((bool((i1 >= (int)0)) && bool((i0 >= (int)0))))){
										HX_STACK_LINE(371)
										(ct)++;
									}
								}
							}
;
						}
						HX_STACK_LINE(377)
						if (((ct > ct_best))){
							HX_STACK_LINE(378)
							ct_best = ct;
							HX_STACK_LINE(379)
							ma_best = ma;
							HX_STACK_LINE(380)
							mb_best = mb;
							HX_STACK_LINE(381)
							ra_best = ra;
							HX_STACK_LINE(382)
							rb_best = rb;
						}
					}
				}
			}
		}
		HX_STACK_LINE(387)
		if (((ma_best == null()))){
			HX_STACK_LINE(388)
			if (((bool((a->get_height() > (int)0)) && bool((b->get_height() == (int)0))))){
				HX_STACK_LINE(388)
				align->headers((int)0,(int)-1);
			}
			else{
				HX_STACK_LINE(390)
				if (((bool((a->get_height() == (int)0)) && bool((b->get_height() > (int)0))))){
					HX_STACK_LINE(390)
					align->headers((int)-1,(int)0);
				}
			}
			HX_STACK_LINE(393)
			return null();
		}
		HX_STACK_LINE(395)
		for(::cpp::FastIterator_obj< ::String > *__it = ::cpp::CreateFastIterator< ::String >(ma_best->keys());  __it->hasNext(); ){
			::String key = __it->next();
			{
				HX_STACK_LINE(396)
				Dynamic i0 = ma_best->get(key);		HX_STACK_VAR(i0,"i0");
				HX_STACK_LINE(397)
				Dynamic i1 = mb_best->get(key);		HX_STACK_VAR(i1,"i1");
				HX_STACK_LINE(398)
				if (((bool((i1 != null())) && bool((i0 != null()))))){
					HX_STACK_LINE(398)
					align->link(i0,i1);
				}
			}
;
		}
		HX_STACK_LINE(402)
		align->headers(ra_header,rb_header);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(CompareTable_obj,alignColumns,(void))

Void CompareTable_obj::alignCore2( ::coopy::Alignment align,::coopy::Table a,::coopy::Table b){
{
		HX_STACK_PUSH("CompareTable::alignCore2","coopy/CompareTable.hx",84);
		HX_STACK_THIS(this);
		HX_STACK_ARG(align,"align");
		HX_STACK_ARG(a,"a");
		HX_STACK_ARG(b,"b");
		HX_STACK_LINE(85)
		if (((align->meta == null()))){
			HX_STACK_LINE(85)
			align->meta = ::coopy::Alignment_obj::__new();
		}
		HX_STACK_LINE(88)
		this->alignColumns(align->meta,a,b);
		HX_STACK_LINE(89)
		::coopy::Ordering column_order = align->meta->toOrder();		HX_STACK_VAR(column_order,"column_order");
		HX_STACK_LINE(91)
		align->range(a->get_height(),b->get_height());
		HX_STACK_LINE(92)
		align->tables(a,b);
		HX_STACK_LINE(93)
		align->setRowlike(true);
		HX_STACK_LINE(95)
		int w = a->get_width();		HX_STACK_VAR(w,"w");
		HX_STACK_LINE(96)
		int ha = a->get_height();		HX_STACK_VAR(ha,"ha");
		HX_STACK_LINE(97)
		int hb = b->get_height();		HX_STACK_VAR(hb,"hb");
		HX_STACK_LINE(99)
		::coopy::View av = a->getCellView();		HX_STACK_VAR(av,"av");
		HX_STACK_LINE(101)
		Array< ::String > ids = null();		HX_STACK_VAR(ids,"ids");
		HX_STACK_LINE(102)
		::haxe::ds::StringMap ignore = null();		HX_STACK_VAR(ignore,"ignore");
		HX_STACK_LINE(103)
		if (((this->comp->compare_flags != null()))){
			HX_STACK_LINE(104)
			ids = this->comp->compare_flags->ids;
			HX_STACK_LINE(105)
			ignore = this->comp->compare_flags->getIgnoredColumns();
		}
		HX_STACK_LINE(108)
		Array< ::Dynamic > common_units = Array_obj< ::Dynamic >::__new();		HX_STACK_VAR(common_units,"common_units");
		HX_STACK_LINE(109)
		int ra_header = align->getSourceHeader();		HX_STACK_VAR(ra_header,"ra_header");
		HX_STACK_LINE(110)
		int rb_header = align->getSourceHeader();		HX_STACK_VAR(rb_header,"rb_header");
		HX_STACK_LINE(111)
		{
			HX_STACK_LINE(111)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			Array< ::Dynamic > _g1 = column_order->getList();		HX_STACK_VAR(_g1,"_g1");
			HX_STACK_LINE(111)
			while(((_g < _g1->length))){
				HX_STACK_LINE(111)
				::coopy::Unit unit = _g1->__get(_g).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(unit,"unit");
				HX_STACK_LINE(111)
				++(_g);
				HX_STACK_LINE(112)
				if (((bool((bool((unit->l >= (int)0)) && bool((unit->r >= (int)0)))) && bool((unit->p != (int)-1))))){
					HX_STACK_LINE(113)
					if (((ignore != null()))){
						HX_STACK_LINE(114)
						if (((bool((bool((unit->l >= (int)0)) && bool((ra_header >= (int)0)))) && bool((ra_header < a->get_height()))))){
							HX_STACK_LINE(115)
							::String name = av->toString(a->getCell(unit->l,ra_header));		HX_STACK_VAR(name,"name");
							HX_STACK_LINE(116)
							if ((ignore->exists(name))){
								HX_STACK_LINE(116)
								continue;
							}
						}
						HX_STACK_LINE(118)
						if (((bool((bool((unit->r >= (int)0)) && bool((rb_header >= (int)0)))) && bool((rb_header < b->get_height()))))){
							HX_STACK_LINE(119)
							::String name = av->toString(b->getCell(unit->r,rb_header));		HX_STACK_VAR(name,"name");
							HX_STACK_LINE(120)
							if ((ignore->exists(name))){
								HX_STACK_LINE(120)
								continue;
							}
						}
					}
					HX_STACK_LINE(123)
					common_units->push(unit);
				}
			}
		}
		HX_STACK_LINE(127)
		if (((ids != null()))){
			HX_STACK_LINE(131)
			::coopy::IndexPair index = ::coopy::IndexPair_obj::__new();		HX_STACK_VAR(index,"index");
			HX_STACK_LINE(132)
			::haxe::ds::StringMap ids_as_map = ::haxe::ds::StringMap_obj::__new();		HX_STACK_VAR(ids_as_map,"ids_as_map");
			HX_STACK_LINE(133)
			{
				HX_STACK_LINE(133)
				int _g = (int)0;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(133)
				while(((_g < ids->length))){
					HX_STACK_LINE(133)
					::String id = ids->__get(_g);		HX_STACK_VAR(id,"id");
					HX_STACK_LINE(133)
					++(_g);
					HX_STACK_LINE(134)
					{
						HX_STACK_LINE(134)
						ids_as_map->set(id,true);
						HX_STACK_LINE(134)
						true;
					}
				}
			}
			HX_STACK_LINE(136)
			{
				HX_STACK_LINE(136)
				int _g = (int)0;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(136)
				while(((_g < common_units->length))){
					HX_STACK_LINE(136)
					::coopy::Unit unit = common_units->__get(_g).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(unit,"unit");
					HX_STACK_LINE(136)
					++(_g);
					HX_STACK_LINE(137)
					::String na = av->toString(a->getCell(unit->l,(int)0));		HX_STACK_VAR(na,"na");
					HX_STACK_LINE(138)
					::String nb = av->toString(b->getCell(unit->r,(int)0));		HX_STACK_VAR(nb,"nb");
					HX_STACK_LINE(139)
					if (((bool(ids_as_map->exists(na)) || bool(ids_as_map->exists(nb))))){
						HX_STACK_LINE(140)
						index->addColumns(unit->l,unit->r);
						HX_STACK_LINE(141)
						align->addIndexColumns(unit);
					}
				}
			}
			HX_STACK_LINE(144)
			index->indexTables(a,b,(int)1);
			HX_STACK_LINE(145)
			if (((this->indexes != null()))){
				HX_STACK_LINE(145)
				this->indexes->push(index);
			}
			HX_STACK_LINE(148)
			{
				HX_STACK_LINE(148)
				int _g = (int)0;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(148)
				while(((_g < ha))){
					HX_STACK_LINE(148)
					int j = (_g)++;		HX_STACK_VAR(j,"j");
					HX_STACK_LINE(149)
					::coopy::CrossMatch cross = index->queryLocal(j);		HX_STACK_VAR(cross,"cross");
					HX_STACK_LINE(150)
					int spot_a = cross->spot_a;		HX_STACK_VAR(spot_a,"spot_a");
					HX_STACK_LINE(151)
					int spot_b = cross->spot_b;		HX_STACK_VAR(spot_b,"spot_b");
					HX_STACK_LINE(152)
					if (((bool((spot_a != (int)1)) || bool((spot_b != (int)1))))){
						HX_STACK_LINE(152)
						continue;
					}
					HX_STACK_LINE(153)
					align->link(j,cross->item_b->lst->__get((int)0));
				}
			}
		}
		else{
			HX_STACK_LINE(161)
			int N = (int)5;		HX_STACK_VAR(N,"N");
			HX_STACK_LINE(162)
			Array< int > columns = Array_obj< int >::__new();		HX_STACK_VAR(columns,"columns");
			HX_STACK_LINE(163)
			if (((common_units->length > N))){
				HX_STACK_LINE(164)
				Array< ::Dynamic > columns_eval = Array_obj< ::Dynamic >::__new();		HX_STACK_VAR(columns_eval,"columns_eval");
				HX_STACK_LINE(165)
				{
					HX_STACK_LINE(165)
					int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
					int _g = common_units->length;		HX_STACK_VAR(_g,"_g");
					HX_STACK_LINE(165)
					while(((_g1 < _g))){
						HX_STACK_LINE(165)
						int i = (_g1)++;		HX_STACK_VAR(i,"i");
						HX_STACK_LINE(166)
						int ct = (int)0;		HX_STACK_VAR(ct,"ct");
						HX_STACK_LINE(167)
						::haxe::ds::StringMap mem = ::haxe::ds::StringMap_obj::__new();		HX_STACK_VAR(mem,"mem");
						HX_STACK_LINE(168)
						::haxe::ds::StringMap mem2 = ::haxe::ds::StringMap_obj::__new();		HX_STACK_VAR(mem2,"mem2");
						HX_STACK_LINE(169)
						int ca = common_units->__get(i).StaticCast< ::coopy::Unit >()->l;		HX_STACK_VAR(ca,"ca");
						HX_STACK_LINE(170)
						int cb = common_units->__get(i).StaticCast< ::coopy::Unit >()->r;		HX_STACK_VAR(cb,"cb");
						HX_STACK_LINE(171)
						{
							HX_STACK_LINE(171)
							int _g2 = (int)0;		HX_STACK_VAR(_g2,"_g2");
							HX_STACK_LINE(171)
							while(((_g2 < ha))){
								HX_STACK_LINE(171)
								int j = (_g2)++;		HX_STACK_VAR(j,"j");
								HX_STACK_LINE(172)
								::String key = av->toString(a->getCell(ca,j));		HX_STACK_VAR(key,"key");
								HX_STACK_LINE(173)
								if ((!(mem->exists(key)))){
									HX_STACK_LINE(174)
									mem->set(key,(int)1);
									HX_STACK_LINE(175)
									(ct)++;
								}
							}
						}
						HX_STACK_LINE(178)
						{
							HX_STACK_LINE(178)
							int _g2 = (int)0;		HX_STACK_VAR(_g2,"_g2");
							HX_STACK_LINE(178)
							while(((_g2 < hb))){
								HX_STACK_LINE(178)
								int j = (_g2)++;		HX_STACK_VAR(j,"j");
								HX_STACK_LINE(179)
								::String key = av->toString(b->getCell(cb,j));		HX_STACK_VAR(key,"key");
								HX_STACK_LINE(180)
								if ((!(mem2->exists(key)))){
									HX_STACK_LINE(181)
									mem2->set(key,(int)1);
									HX_STACK_LINE(182)
									(ct)++;
								}
							}
						}
						HX_STACK_LINE(185)
						columns_eval->push(Array_obj< int >::__new().Add(i).Add(ct));
					}
				}

				HX_BEGIN_LOCAL_FUNC_S0(hx::LocalFunc,_Function_3_1)
				int run(Array< int > a1,Array< int > b1){
					HX_STACK_PUSH("*::_Function_3_1","coopy/CompareTable.hx",187);
					HX_STACK_ARG(a1,"a1");
					HX_STACK_ARG(b1,"b1");
					{
						HX_STACK_LINE(188)
						if (((a1->__get((int)1) < b1->__get((int)1)))){
							HX_STACK_LINE(188)
							return (int)1;
						}
						HX_STACK_LINE(189)
						if (((a1->__get((int)1) > b1->__get((int)1)))){
							HX_STACK_LINE(189)
							return (int)-1;
						}
						HX_STACK_LINE(190)
						if (((a1->__get((int)0) > b1->__get((int)0)))){
							HX_STACK_LINE(190)
							return (int)1;
						}
						HX_STACK_LINE(191)
						if (((a1->__get((int)0) < b1->__get((int)0)))){
							HX_STACK_LINE(191)
							return (int)-1;
						}
						HX_STACK_LINE(192)
						return (int)0;
					}
					return null();
				}
				HX_END_LOCAL_FUNC2(return)

				HX_STACK_LINE(187)
				Dynamic sorter =  Dynamic(new _Function_3_1());		HX_STACK_VAR(sorter,"sorter");
				HX_STACK_LINE(194)
				columns_eval->sort(sorter);

				HX_BEGIN_LOCAL_FUNC_S0(hx::LocalFunc,_Function_3_2)
				int run(Array< int > v){
					HX_STACK_PUSH("*::_Function_3_2","coopy/CompareTable.hx",195);
					HX_STACK_ARG(v,"v");
					{
						HX_STACK_LINE(195)
						return v->__get((int)0);
					}
					return null();
				}
				HX_END_LOCAL_FUNC1(return)

				HX_STACK_LINE(195)
				columns = ::Lambda_obj::array(::Lambda_obj::map(columns_eval, Dynamic(new _Function_3_2())));
				HX_STACK_LINE(196)
				columns = columns->slice((int)0,N);
			}
			else{
				HX_STACK_LINE(198)
				int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
				int _g = common_units->length;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(198)
				while(((_g1 < _g))){
					HX_STACK_LINE(198)
					int i = (_g1)++;		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(199)
					columns->push(i);
				}
			}
			HX_STACK_LINE(203)
			int top = ::Math_obj::round(::Math_obj::pow((int)2,columns->length));		HX_STACK_VAR(top,"top");
			HX_STACK_LINE(205)
			::haxe::ds::IntMap pending = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(pending,"pending");
			HX_STACK_LINE(206)
			{
				HX_STACK_LINE(206)
				int _g = (int)0;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(206)
				while(((_g < ha))){
					HX_STACK_LINE(206)
					int j = (_g)++;		HX_STACK_VAR(j,"j");
					HX_STACK_LINE(207)
					pending->set(j,j);
				}
			}
			HX_STACK_LINE(209)
			int pending_ct = ha;		HX_STACK_VAR(pending_ct,"pending_ct");
			HX_STACK_LINE(211)
			::haxe::ds::IntMap added_columns = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(added_columns,"added_columns");
			HX_STACK_LINE(212)
			int index_ct = (int)0;		HX_STACK_VAR(index_ct,"index_ct");
			HX_STACK_LINE(214)
			::coopy::IndexPair index_top = null();		HX_STACK_VAR(index_top,"index_top");
			HX_STACK_LINE(215)
			{
				HX_STACK_LINE(215)
				int _g = (int)0;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(215)
				while(((_g < top))){
					HX_STACK_LINE(215)
					int k = (_g)++;		HX_STACK_VAR(k,"k");
					HX_STACK_LINE(216)
					if (((k == (int)0))){
						HX_STACK_LINE(216)
						continue;
					}
					HX_STACK_LINE(217)
					if (((pending_ct == (int)0))){
						HX_STACK_LINE(217)
						break;
					}
					HX_STACK_LINE(218)
					Array< int > active_columns = Array_obj< int >::__new();		HX_STACK_VAR(active_columns,"active_columns");
					HX_STACK_LINE(219)
					int kk = k;		HX_STACK_VAR(kk,"kk");
					HX_STACK_LINE(220)
					int at = (int)0;		HX_STACK_VAR(at,"at");
					HX_STACK_LINE(221)
					while(((kk > (int)0))){
						HX_STACK_LINE(222)
						if (((hx::Mod(kk,(int)2) == (int)1))){
							HX_STACK_LINE(222)
							active_columns->push(columns->__get(at));
						}
						HX_STACK_LINE(225)
						hx::ShrEq(kk,(int)1);
						HX_STACK_LINE(226)
						(at)++;
					}
					HX_STACK_LINE(229)
					::coopy::IndexPair index = ::coopy::IndexPair_obj::__new();		HX_STACK_VAR(index,"index");
					HX_STACK_LINE(230)
					{
						HX_STACK_LINE(230)
						int _g2 = (int)0;		HX_STACK_VAR(_g2,"_g2");
						int _g1 = active_columns->length;		HX_STACK_VAR(_g1,"_g1");
						HX_STACK_LINE(230)
						while(((_g2 < _g1))){
							HX_STACK_LINE(230)
							int k1 = (_g2)++;		HX_STACK_VAR(k1,"k1");
							HX_STACK_LINE(231)
							int col = active_columns->__get(k1);		HX_STACK_VAR(col,"col");
							HX_STACK_LINE(232)
							::coopy::Unit unit = common_units->__get(col).StaticCast< ::coopy::Unit >();		HX_STACK_VAR(unit,"unit");
							HX_STACK_LINE(233)
							index->addColumns(unit->l,unit->r);
							HX_STACK_LINE(234)
							if ((!(added_columns->exists(col)))){
								HX_STACK_LINE(235)
								align->addIndexColumns(unit);
								HX_STACK_LINE(236)
								added_columns->set(col,true);
							}
						}
					}
					HX_STACK_LINE(239)
					index->indexTables(a,b,(int)1);
					HX_STACK_LINE(240)
					if (((k == (top - (int)1)))){
						HX_STACK_LINE(240)
						index_top = index;
					}
					HX_STACK_LINE(242)
					int h = a->get_height();		HX_STACK_VAR(h,"h");
					HX_STACK_LINE(243)
					if (((b->get_height() > h))){
						HX_STACK_LINE(243)
						h = b->get_height();
					}
					HX_STACK_LINE(244)
					if (((h < (int)1))){
						HX_STACK_LINE(244)
						h = (int)1;
					}
					HX_STACK_LINE(245)
					int wide_top_freq = index->getTopFreq();		HX_STACK_VAR(wide_top_freq,"wide_top_freq");
					HX_STACK_LINE(246)
					Float ratio = wide_top_freq;		HX_STACK_VAR(ratio,"ratio");
					HX_STACK_LINE(247)
					hx::DivEq(ratio,(h + (int)20));
					HX_STACK_LINE(248)
					if (((ratio >= 0.1))){
						HX_STACK_LINE(248)
						if (((bool((index_ct > (int)0)) || bool((k < (top - (int)1)))))){
							HX_STACK_LINE(250)
							continue;
						}
					}
					HX_STACK_LINE(254)
					(index_ct)++;
					HX_STACK_LINE(255)
					if (((this->indexes != null()))){
						HX_STACK_LINE(255)
						this->indexes->push(index);
					}
					HX_STACK_LINE(259)
					Array< int > fixed = Array_obj< int >::__new();		HX_STACK_VAR(fixed,"fixed");
					HX_STACK_LINE(260)
					for(::cpp::FastIterator_obj< int > *__it = ::cpp::CreateFastIterator< int >(pending->keys());  __it->hasNext(); ){
						int j = __it->next();
						{
							HX_STACK_LINE(261)
							::coopy::CrossMatch cross = index->queryLocal(j);		HX_STACK_VAR(cross,"cross");
							HX_STACK_LINE(262)
							int spot_a = cross->spot_a;		HX_STACK_VAR(spot_a,"spot_a");
							HX_STACK_LINE(263)
							int spot_b = cross->spot_b;		HX_STACK_VAR(spot_b,"spot_b");
							HX_STACK_LINE(264)
							if (((bool((spot_a != (int)1)) || bool((spot_b != (int)1))))){
								HX_STACK_LINE(264)
								continue;
							}
							HX_STACK_LINE(265)
							fixed->push(j);
							HX_STACK_LINE(266)
							align->link(j,cross->item_b->lst->__get((int)0));
						}
;
					}
					HX_STACK_LINE(268)
					{
						HX_STACK_LINE(268)
						int _g2 = (int)0;		HX_STACK_VAR(_g2,"_g2");
						int _g1 = fixed->length;		HX_STACK_VAR(_g1,"_g1");
						HX_STACK_LINE(268)
						while(((_g2 < _g1))){
							HX_STACK_LINE(268)
							int j = (_g2)++;		HX_STACK_VAR(j,"j");
							HX_STACK_LINE(269)
							pending->remove(fixed->__get(j));
							HX_STACK_LINE(270)
							(pending_ct)--;
						}
					}
				}
			}
			HX_STACK_LINE(274)
			if (((index_top != null()))){
				HX_STACK_LINE(275)
				int offset = (int)0;		HX_STACK_VAR(offset,"offset");
				HX_STACK_LINE(276)
				int scale = (int)1;		HX_STACK_VAR(scale,"scale");
				HX_STACK_LINE(277)
				{
					HX_STACK_LINE(277)
					int _g = (int)0;		HX_STACK_VAR(_g,"_g");
					HX_STACK_LINE(277)
					while(((_g < (int)2))){
						HX_STACK_LINE(277)
						int sgn = (_g)++;		HX_STACK_VAR(sgn,"sgn");
						HX_STACK_LINE(278)
						if (((pending_ct > (int)0))){
							HX_STACK_LINE(279)
							Dynamic xb = null();		HX_STACK_VAR(xb,"xb");
							HX_STACK_LINE(280)
							if (((bool((scale == (int)-1)) && bool((hb > (int)0))))){
								HX_STACK_LINE(280)
								xb = (hb - (int)1);
							}
							HX_STACK_LINE(281)
							{
								HX_STACK_LINE(281)
								int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
								HX_STACK_LINE(281)
								while(((_g1 < ha))){
									HX_STACK_LINE(281)
									int xa0 = (_g1)++;		HX_STACK_VAR(xa0,"xa0");
									HX_STACK_LINE(282)
									int xa = ((xa0 * scale) + offset);		HX_STACK_VAR(xa,"xa");
									HX_STACK_LINE(283)
									Dynamic xb2 = align->a2b(xa);		HX_STACK_VAR(xb2,"xb2");
									HX_STACK_LINE(284)
									if (((xb2 != null()))){
										HX_STACK_LINE(285)
										xb = (xb2 + scale);
										HX_STACK_LINE(286)
										if (((bool((xb >= hb)) || bool((xb < (int)0))))){
											HX_STACK_LINE(286)
											break;
										}
										HX_STACK_LINE(287)
										continue;
									}
									HX_STACK_LINE(289)
									if (((xb == null()))){
										HX_STACK_LINE(289)
										continue;
									}
									HX_STACK_LINE(290)
									::String ka = index_top->localKey(xa);		HX_STACK_VAR(ka,"ka");
									HX_STACK_LINE(291)
									::String kb = index_top->remoteKey(xb);		HX_STACK_VAR(kb,"kb");
									HX_STACK_LINE(292)
									if (((ka != kb))){
										HX_STACK_LINE(292)
										continue;
									}
									HX_STACK_LINE(293)
									align->link(xa,xb);
									HX_STACK_LINE(294)
									(pending_ct)--;
									HX_STACK_LINE(295)
									hx::AddEq(xb,scale);
									HX_STACK_LINE(296)
									if (((bool((xb >= hb)) || bool((xb < (int)0))))){
										HX_STACK_LINE(296)
										break;
									}
									HX_STACK_LINE(297)
									if (((pending_ct == (int)0))){
										HX_STACK_LINE(297)
										break;
									}
								}
							}
						}
						HX_STACK_LINE(300)
						offset = (ha - (int)1);
						HX_STACK_LINE(301)
						scale = (int)-1;
					}
				}
			}
		}
		HX_STACK_LINE(306)
		if (((bool((ha > (int)0)) && bool((hb > (int)0))))){
			HX_STACK_LINE(306)
			align->link((int)0,(int)0);
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC3(CompareTable_obj,alignCore2,(void))

Void CompareTable_obj::alignCore( ::coopy::Alignment align){
{
		HX_STACK_PUSH("CompareTable::alignCore","coopy/CompareTable.hx",71);
		HX_STACK_THIS(this);
		HX_STACK_ARG(align,"align");
		HX_STACK_LINE(72)
		if (((this->comp->p == null()))){
			HX_STACK_LINE(73)
			this->alignCore2(align,this->comp->a,this->comp->b);
			HX_STACK_LINE(74)
			return null();
		}
		HX_STACK_LINE(76)
		align->reference = ::coopy::Alignment_obj::__new();
		HX_STACK_LINE(77)
		this->alignCore2(align,this->comp->p,this->comp->b);
		HX_STACK_LINE(78)
		this->alignCore2(align->reference,this->comp->p,this->comp->a);
		HX_STACK_LINE(79)
		align->meta->reference = align->reference->meta;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(CompareTable_obj,alignCore,(void))

::coopy::TableComparisonState CompareTable_obj::getComparisonState( ){
	HX_STACK_PUSH("CompareTable::getComparisonState","coopy/CompareTable.hx",67);
	HX_STACK_THIS(this);
	HX_STACK_LINE(67)
	return this->comp;
}


HX_DEFINE_DYNAMIC_FUNC0(CompareTable_obj,getComparisonState,return )

::coopy::Alignment CompareTable_obj::align( ){
	HX_STACK_PUSH("CompareTable::align","coopy/CompareTable.hx",52);
	HX_STACK_THIS(this);
	HX_STACK_LINE(53)
	while((!(this->comp->completed))){
		HX_STACK_LINE(53)
		this->run();
	}
	HX_STACK_LINE(56)
	::coopy::Alignment alignment = ::coopy::Alignment_obj::__new();		HX_STACK_VAR(alignment,"alignment");
	HX_STACK_LINE(57)
	this->alignCore(alignment);
	HX_STACK_LINE(58)
	return alignment;
}


HX_DEFINE_DYNAMIC_FUNC0(CompareTable_obj,align,return )

bool CompareTable_obj::run( ){
	HX_STACK_PUSH("CompareTable::run","coopy/CompareTable.hx",35);
	HX_STACK_THIS(this);
	HX_STACK_LINE(36)
	bool more = this->compareCore();		HX_STACK_VAR(more,"more");
	HX_STACK_LINE(37)
	while(((bool(more) && bool(this->comp->run_to_completion)))){
		HX_STACK_LINE(37)
		more = this->compareCore();
	}
	HX_STACK_LINE(40)
	return !(more);
}


HX_DEFINE_DYNAMIC_FUNC0(CompareTable_obj,run,return )


CompareTable_obj::CompareTable_obj()
{
}

void CompareTable_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(CompareTable);
	HX_MARK_MEMBER_NAME(indexes,"indexes");
	HX_MARK_MEMBER_NAME(comp,"comp");
	HX_MARK_END_CLASS();
}

void CompareTable_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(indexes,"indexes");
	HX_VISIT_MEMBER_NAME(comp,"comp");
}

Dynamic CompareTable_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 3:
		if (HX_FIELD_EQ(inName,"run") ) { return run_dyn(); }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"comp") ) { return comp; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"align") ) { return align_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"indexes") ) { return indexes; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"isEqual2") ) { return isEqual2_dyn(); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"alignCore") ) { return alignCore_dyn(); }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"getIndexes") ) { return getIndexes_dyn(); }
		if (HX_FIELD_EQ(inName,"alignCore2") ) { return alignCore2_dyn(); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"compareCore") ) { return compareCore_dyn(); }
		if (HX_FIELD_EQ(inName,"testIsEqual") ) { return testIsEqual_dyn(); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"storeIndexes") ) { return storeIndexes_dyn(); }
		if (HX_FIELD_EQ(inName,"alignColumns") ) { return alignColumns_dyn(); }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"hasSameColumns2") ) { return hasSameColumns2_dyn(); }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"testHasSameColumns") ) { return testHasSameColumns_dyn(); }
		if (HX_FIELD_EQ(inName,"getComparisonState") ) { return getComparisonState_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic CompareTable_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"comp") ) { comp=inValue.Cast< ::coopy::TableComparisonState >(); return inValue; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"indexes") ) { indexes=inValue.Cast< Array< ::Dynamic > >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void CompareTable_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("indexes"));
	outFields->push(HX_CSTRING("comp"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("getIndexes"),
	HX_CSTRING("storeIndexes"),
	HX_CSTRING("compareCore"),
	HX_CSTRING("isEqual2"),
	HX_CSTRING("testIsEqual"),
	HX_CSTRING("hasSameColumns2"),
	HX_CSTRING("testHasSameColumns"),
	HX_CSTRING("alignColumns"),
	HX_CSTRING("alignCore2"),
	HX_CSTRING("alignCore"),
	HX_CSTRING("getComparisonState"),
	HX_CSTRING("align"),
	HX_CSTRING("run"),
	HX_CSTRING("indexes"),
	HX_CSTRING("comp"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(CompareTable_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(CompareTable_obj::__mClass,"__mClass");
};

Class CompareTable_obj::__mClass;

void CompareTable_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.CompareTable"), hx::TCanCast< CompareTable_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void CompareTable_obj::__boot()
{
}

} // end namespace coopy

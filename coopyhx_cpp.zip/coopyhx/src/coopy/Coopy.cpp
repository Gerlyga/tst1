#include <hxcpp.h>

#ifndef INCLUDED_IMap
#include <IMap.h>
#endif
#ifndef INCLUDED_Std
#include <Std.h>
#endif
#ifndef INCLUDED_coopy_Alignment
#include <coopy/Alignment.h>
#endif
#ifndef INCLUDED_coopy_CompareFlags
#include <coopy/CompareFlags.h>
#endif
#ifndef INCLUDED_coopy_CompareTable
#include <coopy/CompareTable.h>
#endif
#ifndef INCLUDED_coopy_Coopy
#include <coopy/Coopy.h>
#endif
#ifndef INCLUDED_coopy_Csv
#include <coopy/Csv.h>
#endif
#ifndef INCLUDED_coopy_DiffRender
#include <coopy/DiffRender.h>
#endif
#ifndef INCLUDED_coopy_HighlightPatch
#include <coopy/HighlightPatch.h>
#endif
#ifndef INCLUDED_coopy_Index
#include <coopy/Index.h>
#endif
#ifndef INCLUDED_coopy_Mover
#include <coopy/Mover.h>
#endif
#ifndef INCLUDED_coopy_Row
#include <coopy/Row.h>
#endif
#ifndef INCLUDED_coopy_SimpleTable
#include <coopy/SimpleTable.h>
#endif
#ifndef INCLUDED_coopy_SqlCompare
#include <coopy/SqlCompare.h>
#endif
#ifndef INCLUDED_coopy_SqlDatabase
#include <coopy/SqlDatabase.h>
#endif
#ifndef INCLUDED_coopy_SqlTable
#include <coopy/SqlTable.h>
#endif
#ifndef INCLUDED_coopy_Table
#include <coopy/Table.h>
#endif
#ifndef INCLUDED_coopy_TableComparisonState
#include <coopy/TableComparisonState.h>
#endif
#ifndef INCLUDED_coopy_TableDiff
#include <coopy/TableDiff.h>
#endif
#ifndef INCLUDED_coopy_TableIO
#include <coopy/TableIO.h>
#endif
#ifndef INCLUDED_coopy_TableModifier
#include <coopy/TableModifier.h>
#endif
#ifndef INCLUDED_coopy_Viterbi
#include <coopy/Viterbi.h>
#endif
#ifndef INCLUDED_haxe_Log
#include <haxe/Log.h>
#endif
#ifndef INCLUDED_haxe_ds_StringMap
#include <haxe/ds/StringMap.h>
#endif
namespace coopy{

Void Coopy_obj::__construct()
{
HX_STACK_PUSH("Coopy::new","coopy/Coopy.hx",34);
{
	HX_STACK_LINE(35)
	this->extern_preference = false;
	HX_STACK_LINE(36)
	this->format_preference = null();
	HX_STACK_LINE(37)
	this->delim_preference = null();
	HX_STACK_LINE(38)
	this->output_format = HX_CSTRING("copy");
	HX_STACK_LINE(39)
	this->nested_output = false;
	HX_STACK_LINE(40)
	this->order_set = false;
	HX_STACK_LINE(41)
	this->order_preference = false;
}
;
	return null();
}

Coopy_obj::~Coopy_obj() { }

Dynamic Coopy_obj::__CreateEmpty() { return  new Coopy_obj; }
hx::ObjectPtr< Coopy_obj > Coopy_obj::__new()
{  hx::ObjectPtr< Coopy_obj > result = new Coopy_obj();
	result->__construct();
	return result;}

Dynamic Coopy_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< Coopy_obj > result = new Coopy_obj();
	result->__construct();
	return result;}

::String Coopy_obj::VERSION;

::coopy::CompareTable Coopy_obj::compareTables( ::coopy::Table local,::coopy::Table remote,::coopy::CompareFlags flags){
	HX_STACK_PUSH("Coopy::compareTables","coopy/Coopy.hx",54);
	HX_STACK_ARG(local,"local");
	HX_STACK_ARG(remote,"remote");
	HX_STACK_ARG(flags,"flags");
	HX_STACK_LINE(55)
	::coopy::TableComparisonState comp = ::coopy::TableComparisonState_obj::__new();		HX_STACK_VAR(comp,"comp");
	HX_STACK_LINE(56)
	comp->a = local;
	HX_STACK_LINE(57)
	comp->b = remote;
	HX_STACK_LINE(58)
	comp->compare_flags = flags;
	HX_STACK_LINE(59)
	::coopy::CompareTable ct = ::coopy::CompareTable_obj::__new(comp);		HX_STACK_VAR(ct,"ct");
	HX_STACK_LINE(60)
	return ct;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC3(Coopy_obj,compareTables,return )

::coopy::CompareTable Coopy_obj::compareTables3( ::coopy::Table parent,::coopy::Table local,::coopy::Table remote,::coopy::CompareFlags flags){
	HX_STACK_PUSH("Coopy::compareTables3","coopy/Coopy.hx",78);
	HX_STACK_ARG(parent,"parent");
	HX_STACK_ARG(local,"local");
	HX_STACK_ARG(remote,"remote");
	HX_STACK_ARG(flags,"flags");
	HX_STACK_LINE(79)
	::coopy::TableComparisonState comp = ::coopy::TableComparisonState_obj::__new();		HX_STACK_VAR(comp,"comp");
	HX_STACK_LINE(80)
	comp->p = parent;
	HX_STACK_LINE(81)
	comp->a = local;
	HX_STACK_LINE(82)
	comp->b = remote;
	HX_STACK_LINE(83)
	comp->compare_flags = flags;
	HX_STACK_LINE(84)
	::coopy::CompareTable ct = ::coopy::CompareTable_obj::__new(comp);		HX_STACK_VAR(ct,"ct");
	HX_STACK_LINE(85)
	return ct;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC4(Coopy_obj,compareTables3,return )

int Coopy_obj::keepAround( ){
	HX_STACK_PUSH("Coopy::keepAround","coopy/Coopy.hx",88);
	HX_STACK_LINE(89)
	::coopy::SimpleTable st = ::coopy::SimpleTable_obj::__new((int)1,(int)1);		HX_STACK_VAR(st,"st");
	HX_STACK_LINE(90)
	::coopy::Viterbi v = ::coopy::Viterbi_obj::__new();		HX_STACK_VAR(v,"v");
	HX_STACK_LINE(91)
	::coopy::TableDiff td = ::coopy::TableDiff_obj::__new(null(),null());		HX_STACK_VAR(td,"td");
	HX_STACK_LINE(92)
	::coopy::Index idx = ::coopy::Index_obj::__new();		HX_STACK_VAR(idx,"idx");
	HX_STACK_LINE(93)
	::coopy::DiffRender dr = ::coopy::DiffRender_obj::__new();		HX_STACK_VAR(dr,"dr");
	HX_STACK_LINE(94)
	::coopy::CompareFlags cf = ::coopy::CompareFlags_obj::__new();		HX_STACK_VAR(cf,"cf");
	HX_STACK_LINE(95)
	::coopy::HighlightPatch hp = ::coopy::HighlightPatch_obj::__new(null(),null());		HX_STACK_VAR(hp,"hp");
	HX_STACK_LINE(96)
	::coopy::Csv csv = ::coopy::Csv_obj::__new(null());		HX_STACK_VAR(csv,"csv");
	HX_STACK_LINE(97)
	::coopy::TableModifier tm = ::coopy::TableModifier_obj::__new(null());		HX_STACK_VAR(tm,"tm");
	HX_STACK_LINE(98)
	::coopy::SqlCompare sc = ::coopy::SqlCompare_obj::__new(null(),null(),null());		HX_STACK_VAR(sc,"sc");
	HX_STACK_LINE(100)
	return (int)0;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC0(Coopy_obj,keepAround,return )

int Coopy_obj::main( ){
	HX_STACK_PUSH("Coopy::main","coopy/Coopy.hx",772);
	HX_STACK_LINE(772)
	return (int)0;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC0(Coopy_obj,main,return )

Void Coopy_obj::show( ::coopy::Table t){
{
		HX_STACK_PUSH("Coopy::show","coopy/Coopy.hx",783);
		HX_STACK_ARG(t,"t");
		HX_STACK_LINE(784)
		int w = t->get_width();		HX_STACK_VAR(w,"w");
		HX_STACK_LINE(785)
		int h = t->get_height();		HX_STACK_VAR(h,"h");
		HX_STACK_LINE(786)
		::String txt = HX_CSTRING("");		HX_STACK_VAR(txt,"txt");
		HX_STACK_LINE(787)
		{
			HX_STACK_LINE(787)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(787)
			while(((_g < h))){
				HX_STACK_LINE(787)
				int y = (_g)++;		HX_STACK_VAR(y,"y");
				HX_STACK_LINE(788)
				{
					HX_STACK_LINE(788)
					int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
					HX_STACK_LINE(788)
					while(((_g1 < w))){
						HX_STACK_LINE(788)
						int x = (_g1)++;		HX_STACK_VAR(x,"x");
						HX_STACK_LINE(789)
						hx::AddEq(txt,::Std_obj::string(t->getCell(x,y)));
						HX_STACK_LINE(790)
						hx::AddEq(txt,HX_CSTRING(" "));
					}
				}
				HX_STACK_LINE(792)
				hx::AddEq(txt,HX_CSTRING("\n"));
			}
		}
		HX_STACK_LINE(794)
		::haxe::Log_obj::trace(txt,hx::SourceInfo(HX_CSTRING("Coopy.hx"),794,HX_CSTRING("coopy.Coopy"),HX_CSTRING("show")));
	}
return null();
}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Coopy_obj,show,(void))

Dynamic Coopy_obj::jsonify( ::coopy::Table t){
	HX_STACK_PUSH("Coopy::jsonify","coopy/Coopy.hx",798);
	HX_STACK_ARG(t,"t");
	HX_STACK_LINE(799)
	::haxe::ds::StringMap workbook = ::haxe::ds::StringMap_obj::__new();		HX_STACK_VAR(workbook,"workbook");
	HX_STACK_LINE(800)
	Dynamic sheet = Dynamic( Array_obj<Dynamic>::__new() );		HX_STACK_VAR(sheet,"sheet");
	HX_STACK_LINE(801)
	int w = t->get_width();		HX_STACK_VAR(w,"w");
	HX_STACK_LINE(802)
	int h = t->get_height();		HX_STACK_VAR(h,"h");
	HX_STACK_LINE(803)
	::String txt = HX_CSTRING("");		HX_STACK_VAR(txt,"txt");
	HX_STACK_LINE(804)
	{
		HX_STACK_LINE(804)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(804)
		while(((_g < h))){
			HX_STACK_LINE(804)
			int y = (_g)++;		HX_STACK_VAR(y,"y");
			HX_STACK_LINE(805)
			Dynamic row = Dynamic( Array_obj<Dynamic>::__new() );		HX_STACK_VAR(row,"row");
			HX_STACK_LINE(806)
			{
				HX_STACK_LINE(806)
				int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
				HX_STACK_LINE(806)
				while(((_g1 < w))){
					HX_STACK_LINE(806)
					int x = (_g1)++;		HX_STACK_VAR(x,"x");
					HX_STACK_LINE(807)
					Dynamic v = t->getCell(x,y);		HX_STACK_VAR(v,"v");
					HX_STACK_LINE(808)
					row->__Field(HX_CSTRING("push"),true)(v);
				}
			}
			HX_STACK_LINE(810)
			sheet->__Field(HX_CSTRING("push"),true)(row);
		}
	}
	HX_STACK_LINE(812)
	workbook->set(HX_CSTRING("sheet"),sheet);
	HX_STACK_LINE(813)
	return workbook;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Coopy_obj,jsonify,return )


Coopy_obj::Coopy_obj()
{
}

void Coopy_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(Coopy);
	HX_MARK_MEMBER_NAME(mv,"mv");
	HX_MARK_MEMBER_NAME(io,"io");
	HX_MARK_MEMBER_NAME(order_preference,"order_preference");
	HX_MARK_MEMBER_NAME(order_set,"order_set");
	HX_MARK_MEMBER_NAME(nested_output,"nested_output");
	HX_MARK_MEMBER_NAME(output_format,"output_format");
	HX_MARK_MEMBER_NAME(extern_preference,"extern_preference");
	HX_MARK_MEMBER_NAME(delim_preference,"delim_preference");
	HX_MARK_MEMBER_NAME(format_preference,"format_preference");
	HX_MARK_END_CLASS();
}

void Coopy_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(mv,"mv");
	HX_VISIT_MEMBER_NAME(io,"io");
	HX_VISIT_MEMBER_NAME(order_preference,"order_preference");
	HX_VISIT_MEMBER_NAME(order_set,"order_set");
	HX_VISIT_MEMBER_NAME(nested_output,"nested_output");
	HX_VISIT_MEMBER_NAME(output_format,"output_format");
	HX_VISIT_MEMBER_NAME(extern_preference,"extern_preference");
	HX_VISIT_MEMBER_NAME(delim_preference,"delim_preference");
	HX_VISIT_MEMBER_NAME(format_preference,"format_preference");
}

Dynamic Coopy_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 2:
		if (HX_FIELD_EQ(inName,"mv") ) { return mv; }
		if (HX_FIELD_EQ(inName,"io") ) { return io; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"main") ) { return main_dyn(); }
		if (HX_FIELD_EQ(inName,"show") ) { return show_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"VERSION") ) { return VERSION; }
		if (HX_FIELD_EQ(inName,"jsonify") ) { return jsonify_dyn(); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"order_set") ) { return order_set; }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"keepAround") ) { return keepAround_dyn(); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"compareTables") ) { return compareTables_dyn(); }
		if (HX_FIELD_EQ(inName,"nested_output") ) { return nested_output; }
		if (HX_FIELD_EQ(inName,"output_format") ) { return output_format; }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"compareTables3") ) { return compareTables3_dyn(); }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"order_preference") ) { return order_preference; }
		if (HX_FIELD_EQ(inName,"delim_preference") ) { return delim_preference; }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"extern_preference") ) { return extern_preference; }
		if (HX_FIELD_EQ(inName,"format_preference") ) { return format_preference; }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic Coopy_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 2:
		if (HX_FIELD_EQ(inName,"mv") ) { mv=inValue.Cast< ::coopy::Mover >(); return inValue; }
		if (HX_FIELD_EQ(inName,"io") ) { io=inValue.Cast< ::coopy::TableIO >(); return inValue; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"VERSION") ) { VERSION=inValue.Cast< ::String >(); return inValue; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"order_set") ) { order_set=inValue.Cast< bool >(); return inValue; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"nested_output") ) { nested_output=inValue.Cast< bool >(); return inValue; }
		if (HX_FIELD_EQ(inName,"output_format") ) { output_format=inValue.Cast< ::String >(); return inValue; }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"order_preference") ) { order_preference=inValue.Cast< bool >(); return inValue; }
		if (HX_FIELD_EQ(inName,"delim_preference") ) { delim_preference=inValue.Cast< ::String >(); return inValue; }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"extern_preference") ) { extern_preference=inValue.Cast< bool >(); return inValue; }
		if (HX_FIELD_EQ(inName,"format_preference") ) { format_preference=inValue.Cast< ::String >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void Coopy_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("mv"));
	outFields->push(HX_CSTRING("io"));
	outFields->push(HX_CSTRING("order_preference"));
	outFields->push(HX_CSTRING("order_set"));
	outFields->push(HX_CSTRING("nested_output"));
	outFields->push(HX_CSTRING("output_format"));
	outFields->push(HX_CSTRING("extern_preference"));
	outFields->push(HX_CSTRING("delim_preference"));
	outFields->push(HX_CSTRING("format_preference"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	HX_CSTRING("VERSION"),
	HX_CSTRING("compareTables"),
	HX_CSTRING("compareTables3"),
	HX_CSTRING("keepAround"),
	HX_CSTRING("main"),
	HX_CSTRING("show"),
	HX_CSTRING("jsonify"),
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("mv"),
	HX_CSTRING("io"),
	HX_CSTRING("order_preference"),
	HX_CSTRING("order_set"),
	HX_CSTRING("nested_output"),
	HX_CSTRING("output_format"),
	HX_CSTRING("extern_preference"),
	HX_CSTRING("delim_preference"),
	HX_CSTRING("format_preference"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Coopy_obj::__mClass,"__mClass");
	HX_MARK_MEMBER_NAME(Coopy_obj::VERSION,"VERSION");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Coopy_obj::__mClass,"__mClass");
	HX_VISIT_MEMBER_NAME(Coopy_obj::VERSION,"VERSION");
};

Class Coopy_obj::__mClass;

void Coopy_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.Coopy"), hx::TCanCast< Coopy_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void Coopy_obj::__boot()
{
	VERSION= HX_CSTRING("1.2.6");
}

} // end namespace coopy

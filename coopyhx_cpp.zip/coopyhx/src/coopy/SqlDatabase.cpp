#include <hxcpp.h>

#ifndef INCLUDED_coopy_SqlColumn
#include <coopy/SqlColumn.h>
#endif
#ifndef INCLUDED_coopy_SqlDatabase
#include <coopy/SqlDatabase.h>
#endif
#ifndef INCLUDED_coopy_SqlTableName
#include <coopy/SqlTableName.h>
#endif
namespace coopy{

HX_DEFINE_DYNAMIC_FUNC0(SqlDatabase_obj,rowid,return )

HX_DEFINE_DYNAMIC_FUNC0(SqlDatabase_obj,width,return )

HX_DEFINE_DYNAMIC_FUNC0(SqlDatabase_obj,end,return )

HX_DEFINE_DYNAMIC_FUNC1(SqlDatabase_obj,get,return )

HX_DEFINE_DYNAMIC_FUNC0(SqlDatabase_obj,read,return )

HX_DEFINE_DYNAMIC_FUNC3(SqlDatabase_obj,beginRow,return )

HX_DEFINE_DYNAMIC_FUNC3(SqlDatabase_obj,begin,return )

HX_DEFINE_DYNAMIC_FUNC1(SqlDatabase_obj,getQuotedColumnName,return )

HX_DEFINE_DYNAMIC_FUNC1(SqlDatabase_obj,getQuotedTableName,return )

HX_DEFINE_DYNAMIC_FUNC1(SqlDatabase_obj,getColumns,return )


static ::String sMemberFields[] = {
	HX_CSTRING("rowid"),
	HX_CSTRING("width"),
	HX_CSTRING("end"),
	HX_CSTRING("get"),
	HX_CSTRING("read"),
	HX_CSTRING("beginRow"),
	HX_CSTRING("begin"),
	HX_CSTRING("getQuotedColumnName"),
	HX_CSTRING("getQuotedTableName"),
	HX_CSTRING("getColumns"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(SqlDatabase_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(SqlDatabase_obj::__mClass,"__mClass");
};

Class SqlDatabase_obj::__mClass;

void SqlDatabase_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.SqlDatabase"), hx::TCanCast< SqlDatabase_obj> ,0,sMemberFields,
	0, 0,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void SqlDatabase_obj::__boot()
{
}

} // end namespace coopy

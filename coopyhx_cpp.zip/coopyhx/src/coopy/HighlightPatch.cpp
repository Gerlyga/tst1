#include <hxcpp.h>

#ifndef INCLUDED_IMap
#include <IMap.h>
#endif
#ifndef INCLUDED_coopy_Alignment
#include <coopy/Alignment.h>
#endif
#ifndef INCLUDED_coopy_CellInfo
#include <coopy/CellInfo.h>
#endif
#ifndef INCLUDED_coopy_CompareTable
#include <coopy/CompareTable.h>
#endif
#ifndef INCLUDED_coopy_CrossMatch
#include <coopy/CrossMatch.h>
#endif
#ifndef INCLUDED_coopy_Csv
#include <coopy/Csv.h>
#endif
#ifndef INCLUDED_coopy_DiffRender
#include <coopy/DiffRender.h>
#endif
#ifndef INCLUDED_coopy_HighlightPatch
#include <coopy/HighlightPatch.h>
#endif
#ifndef INCLUDED_coopy_HighlightPatchUnit
#include <coopy/HighlightPatchUnit.h>
#endif
#ifndef INCLUDED_coopy_IndexItem
#include <coopy/IndexItem.h>
#endif
#ifndef INCLUDED_coopy_IndexPair
#include <coopy/IndexPair.h>
#endif
#ifndef INCLUDED_coopy_Row
#include <coopy/Row.h>
#endif
#ifndef INCLUDED_coopy_Table
#include <coopy/Table.h>
#endif
#ifndef INCLUDED_coopy_TableComparisonState
#include <coopy/TableComparisonState.h>
#endif
#ifndef INCLUDED_coopy_View
#include <coopy/View.h>
#endif
#ifndef INCLUDED_haxe_ds_IntMap
#include <haxe/ds/IntMap.h>
#endif
#ifndef INCLUDED_haxe_ds_StringMap
#include <haxe/ds/StringMap.h>
#endif
namespace coopy{

Void HighlightPatch_obj::__construct(::coopy::Table source,::coopy::Table patch)
{
HX_STACK_PUSH("HighlightPatch::new","coopy/HighlightPatch.hx",64);
{
	HX_STACK_LINE(65)
	this->source = source;
	HX_STACK_LINE(66)
	this->patch = patch;
	HX_STACK_LINE(67)
	this->view = patch->getCellView();
	HX_STACK_LINE(68)
	this->sourceView = source->getCellView();
}
;
	return null();
}

HighlightPatch_obj::~HighlightPatch_obj() { }

Dynamic HighlightPatch_obj::__CreateEmpty() { return  new HighlightPatch_obj; }
hx::ObjectPtr< HighlightPatch_obj > HighlightPatch_obj::__new(::coopy::Table source,::coopy::Table patch)
{  hx::ObjectPtr< HighlightPatch_obj > result = new HighlightPatch_obj();
	result->__construct(source,patch);
	return result;}

Dynamic HighlightPatch_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< HighlightPatch_obj > result = new HighlightPatch_obj();
	result->__construct(inArgs[0],inArgs[1]);
	return result;}

hx::Object *HighlightPatch_obj::__ToInterface(const hx::type_info &inType) {
	if (inType==typeid( ::coopy::Row_obj)) return operator ::coopy::Row_obj *();
	return super::__ToInterface(inType);
}

Void HighlightPatch_obj::finishColumns( ){
{
		HX_STACK_PUSH("HighlightPatch::finishColumns","coopy/HighlightPatch.hx",535);
		HX_STACK_THIS(this);
		HX_STACK_LINE(538)
		this->needSourceColumns();
		HX_STACK_LINE(539)
		{
			HX_STACK_LINE(539)
			int _g1 = this->payloadCol;		HX_STACK_VAR(_g1,"_g1");
			int _g = this->payloadTop;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(539)
			while(((_g1 < _g))){
				HX_STACK_LINE(539)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(540)
				::String act = this->modifier->get(i);		HX_STACK_VAR(act,"act");
				HX_STACK_LINE(541)
				::String hdr = this->header->get(i);		HX_STACK_VAR(hdr,"hdr");
				HX_STACK_LINE(542)
				if (((act == null()))){
					HX_STACK_LINE(542)
					act = HX_CSTRING("");
				}
				HX_STACK_LINE(543)
				if (((act == HX_CSTRING("---")))){
					HX_STACK_LINE(544)
					int at = this->patchInSourceCol->get(i);		HX_STACK_VAR(at,"at");
					HX_STACK_LINE(545)
					::coopy::HighlightPatchUnit mod = ::coopy::HighlightPatchUnit_obj::__new();		HX_STACK_VAR(mod,"mod");
					HX_STACK_LINE(546)
					mod->code = act;
					HX_STACK_LINE(547)
					mod->rem = true;
					HX_STACK_LINE(548)
					mod->sourceRow = at;
					HX_STACK_LINE(549)
					mod->patchRow = i;
					HX_STACK_LINE(550)
					this->cmods->push(mod);
				}
				else{
					HX_STACK_LINE(551)
					if (((act == HX_CSTRING("+++")))){
						HX_STACK_LINE(552)
						::coopy::HighlightPatchUnit mod = ::coopy::HighlightPatchUnit_obj::__new();		HX_STACK_VAR(mod,"mod");
						HX_STACK_LINE(553)
						mod->code = act;
						HX_STACK_LINE(554)
						mod->add = true;
						HX_STACK_LINE(555)
						int prev = (int)-1;		HX_STACK_VAR(prev,"prev");
						HX_STACK_LINE(556)
						bool cont = false;		HX_STACK_VAR(cont,"cont");
						HX_STACK_LINE(557)
						mod->sourceRow = (int)-1;
						HX_STACK_LINE(558)
						if (((this->cmods->length > (int)0))){
							HX_STACK_LINE(558)
							mod->sourceRow = this->cmods->__get((this->cmods->length - (int)1)).StaticCast< ::coopy::HighlightPatchUnit >()->sourceRow;
						}
						HX_STACK_LINE(561)
						if (((mod->sourceRow != (int)-1))){
							HX_STACK_LINE(561)
							mod->sourceRowOffset = (int)1;
						}
						HX_STACK_LINE(564)
						mod->patchRow = i;
						HX_STACK_LINE(565)
						this->cmods->push(mod);
					}
					else{
						HX_STACK_LINE(566)
						if (((act != HX_CSTRING("...")))){
							HX_STACK_LINE(567)
							::coopy::HighlightPatchUnit mod = ::coopy::HighlightPatchUnit_obj::__new();		HX_STACK_VAR(mod,"mod");
							HX_STACK_LINE(568)
							mod->code = act;
							HX_STACK_LINE(569)
							mod->patchRow = i;
							HX_STACK_LINE(570)
							mod->sourceRow = this->patchInSourceCol->get(i);
							HX_STACK_LINE(571)
							this->cmods->push(mod);
						}
					}
				}
			}
		}
		HX_STACK_LINE(574)
		int at = (int)-1;		HX_STACK_VAR(at,"at");
		HX_STACK_LINE(575)
		int rat = (int)-1;		HX_STACK_VAR(rat,"rat");
		HX_STACK_LINE(576)
		{
			HX_STACK_LINE(576)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = (this->cmods->length - (int)1);		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(576)
			while(((_g1 < _g))){
				HX_STACK_LINE(576)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(577)
				::String icode = this->cmods->__get(i).StaticCast< ::coopy::HighlightPatchUnit >()->code;		HX_STACK_VAR(icode,"icode");
				HX_STACK_LINE(578)
				if (((bool((icode != HX_CSTRING("+++"))) && bool((icode != HX_CSTRING("---")))))){
					HX_STACK_LINE(578)
					at = this->cmods->__get(i).StaticCast< ::coopy::HighlightPatchUnit >()->sourceRow;
				}
				HX_STACK_LINE(581)
				this->cmods->__get((i + (int)1)).StaticCast< ::coopy::HighlightPatchUnit >()->sourcePrevRow = at;
				HX_STACK_LINE(582)
				int j = ((this->cmods->length - (int)1) - i);		HX_STACK_VAR(j,"j");
				HX_STACK_LINE(583)
				::String jcode = this->cmods->__get(j).StaticCast< ::coopy::HighlightPatchUnit >()->code;		HX_STACK_VAR(jcode,"jcode");
				HX_STACK_LINE(584)
				if (((bool((jcode != HX_CSTRING("+++"))) && bool((jcode != HX_CSTRING("---")))))){
					HX_STACK_LINE(584)
					rat = this->cmods->__get(j).StaticCast< ::coopy::HighlightPatchUnit >()->sourceRow;
				}
				HX_STACK_LINE(587)
				this->cmods->__get((j - (int)1)).StaticCast< ::coopy::HighlightPatchUnit >()->sourceNextRow = rat;
			}
		}
		HX_STACK_LINE(589)
		Array< int > fate = Array_obj< int >::__new();		HX_STACK_VAR(fate,"fate");
		HX_STACK_LINE(590)
		this->permuteColumns();
		HX_STACK_LINE(591)
		if (((this->headerMove != null()))){
			HX_STACK_LINE(591)
			if (((this->colPermutation->length > (int)0))){
				HX_STACK_LINE(593)
				{
					HX_STACK_LINE(593)
					int _g = (int)0;		HX_STACK_VAR(_g,"_g");
					Array< ::Dynamic > _g1 = this->cmods;		HX_STACK_VAR(_g1,"_g1");
					HX_STACK_LINE(593)
					while(((_g < _g1->length))){
						HX_STACK_LINE(593)
						::coopy::HighlightPatchUnit mod = _g1->__get(_g).StaticCast< ::coopy::HighlightPatchUnit >();		HX_STACK_VAR(mod,"mod");
						HX_STACK_LINE(593)
						++(_g);
						HX_STACK_LINE(594)
						if (((mod->sourceRow >= (int)0))){
							HX_STACK_LINE(594)
							mod->sourceRow = this->colPermutation->__get(mod->sourceRow);
						}
					}
				}
				HX_STACK_LINE(598)
				this->source->insertOrDeleteColumns(this->colPermutation,this->colPermutation->length);
			}
		}
		HX_STACK_LINE(602)
		int len = this->processMods(this->cmods,fate,this->source->get_width());		HX_STACK_VAR(len,"len");
		HX_STACK_LINE(603)
		this->source->insertOrDeleteColumns(fate,len);
		HX_STACK_LINE(604)
		{
			HX_STACK_LINE(604)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			Array< ::Dynamic > _g1 = this->cmods;		HX_STACK_VAR(_g1,"_g1");
			HX_STACK_LINE(604)
			while(((_g < _g1->length))){
				HX_STACK_LINE(604)
				::coopy::HighlightPatchUnit cmod = _g1->__get(_g).StaticCast< ::coopy::HighlightPatchUnit >();		HX_STACK_VAR(cmod,"cmod");
				HX_STACK_LINE(604)
				++(_g);
				HX_STACK_LINE(605)
				if ((!(cmod->rem))){
					HX_STACK_LINE(605)
					if ((cmod->add)){
						HX_STACK_LINE(611)
						{
							HX_STACK_LINE(611)
							int _g2 = (int)0;		HX_STACK_VAR(_g2,"_g2");
							Array< ::Dynamic > _g3 = this->mods;		HX_STACK_VAR(_g3,"_g3");
							HX_STACK_LINE(611)
							while(((_g2 < _g3->length))){
								HX_STACK_LINE(611)
								::coopy::HighlightPatchUnit mod = _g3->__get(_g2).StaticCast< ::coopy::HighlightPatchUnit >();		HX_STACK_VAR(mod,"mod");
								HX_STACK_LINE(611)
								++(_g2);
								HX_STACK_LINE(612)
								if (((bool((mod->patchRow != (int)-1)) && bool((mod->destRow != (int)-1))))){
									HX_STACK_LINE(613)
									Dynamic d = this->patch->getCell(cmod->patchRow,mod->patchRow);		HX_STACK_VAR(d,"d");
									HX_STACK_LINE(615)
									this->source->setCell(cmod->destRow,mod->destRow,d);
								}
							}
						}
						HX_STACK_LINE(620)
						::String hdr = this->header->get(cmod->patchRow);		HX_STACK_VAR(hdr,"hdr");
						HX_STACK_LINE(621)
						this->source->setCell(cmod->destRow,(int)0,this->view->toDatum(hdr));
					}
				}
			}
		}
		HX_STACK_LINE(627)
		{
			HX_STACK_LINE(627)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = this->source->get_width();		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(627)
			while(((_g1 < _g))){
				HX_STACK_LINE(627)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(628)
				::String name = this->view->toString(this->source->getCell(i,(int)0));		HX_STACK_VAR(name,"name");
				HX_STACK_LINE(629)
				::String next_name = this->headerRename->get(name);		HX_STACK_VAR(next_name,"next_name");
				HX_STACK_LINE(630)
				if (((next_name == null()))){
					HX_STACK_LINE(630)
					continue;
				}
				HX_STACK_LINE(631)
				this->source->setCell(i,(int)0,this->view->toDatum(next_name));
			}
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,finishColumns,(void))

Void HighlightPatch_obj::permuteColumns( ){
{
		HX_STACK_PUSH("HighlightPatch::permuteColumns","coopy/HighlightPatch.hx",527);
		HX_STACK_THIS(this);
		HX_STACK_LINE(528)
		if (((this->headerMove == null()))){
			HX_STACK_LINE(528)
			return null();
		}
		HX_STACK_LINE(529)
		this->colPermutation = Array_obj< int >::__new();
		HX_STACK_LINE(530)
		this->colPermutationRev = Array_obj< int >::__new();
		HX_STACK_LINE(531)
		this->computeOrdering(this->cmods,this->colPermutation,this->colPermutationRev,this->source->get_width());
		HX_STACK_LINE(532)
		if (((this->colPermutation->length == (int)0))){
			HX_STACK_LINE(532)
			return null();
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,permuteColumns,(void))

Void HighlightPatch_obj::finishRows( ){
{
		HX_STACK_PUSH("HighlightPatch::finishRows","coopy/HighlightPatch.hx",476);
		HX_STACK_THIS(this);
		HX_STACK_LINE(477)
		Array< int > fate = Array_obj< int >::__new();		HX_STACK_VAR(fate,"fate");
		HX_STACK_LINE(478)
		this->permuteRows();
		HX_STACK_LINE(479)
		if (((this->rowPermutation->length > (int)0))){
			HX_STACK_LINE(480)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			Array< ::Dynamic > _g1 = this->mods;		HX_STACK_VAR(_g1,"_g1");
			HX_STACK_LINE(480)
			while(((_g < _g1->length))){
				HX_STACK_LINE(480)
				::coopy::HighlightPatchUnit mod = _g1->__get(_g).StaticCast< ::coopy::HighlightPatchUnit >();		HX_STACK_VAR(mod,"mod");
				HX_STACK_LINE(480)
				++(_g);
				HX_STACK_LINE(481)
				if (((mod->sourceRow >= (int)0))){
					HX_STACK_LINE(481)
					mod->sourceRow = this->rowPermutation->__get(mod->sourceRow);
				}
			}
		}
		HX_STACK_LINE(487)
		if (((this->rowPermutation->length > (int)0))){
			HX_STACK_LINE(487)
			this->source->insertOrDeleteRows(this->rowPermutation,this->rowPermutation->length);
		}
		HX_STACK_LINE(491)
		int len = this->processMods(this->mods,fate,this->source->get_height());		HX_STACK_VAR(len,"len");
		HX_STACK_LINE(492)
		this->source->insertOrDeleteRows(fate,len);
		HX_STACK_LINE(494)
		{
			HX_STACK_LINE(494)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			Array< ::Dynamic > _g1 = this->mods;		HX_STACK_VAR(_g1,"_g1");
			HX_STACK_LINE(494)
			while(((_g < _g1->length))){
				HX_STACK_LINE(494)
				::coopy::HighlightPatchUnit mod = _g1->__get(_g).StaticCast< ::coopy::HighlightPatchUnit >();		HX_STACK_VAR(mod,"mod");
				HX_STACK_LINE(494)
				++(_g);
				HX_STACK_LINE(496)
				if ((!(mod->rem))){
					HX_STACK_LINE(496)
					if ((mod->add)){
						struct _Function_5_1{
							inline static Dynamic Block( ::coopy::HighlightPatch_obj *__this){
								HX_STACK_PUSH("*::closure","coopy/HighlightPatch.hx",498);
								{
									HX_STACK_LINE(498)
									Array< ::Dynamic > _e = Array_obj< ::Dynamic >::__new().Add(__this->headerPost);		HX_STACK_VAR(_e,"_e");

									HX_BEGIN_LOCAL_FUNC_S1(hx::LocalFunc,_Function_6_1,Array< ::Dynamic >,_e)
									Dynamic run(){
										HX_STACK_PUSH("*::_Function_6_1","coopy/HighlightPatch.hx",498);
										{
											HX_STACK_LINE(498)
											return _e->__get((int)0).StaticCast< ::haxe::ds::StringMap >()->iterator();
										}
										return null();
									}
									HX_END_LOCAL_FUNC0(return)

									HX_STACK_LINE(498)
									return  Dynamic(new _Function_6_1(_e));
								}
								return null();
							}
						};
						HX_STACK_LINE(497)
						for(::cpp::FastIterator_obj< int > *__it = ::cpp::CreateFastIterator< int >((_Function_5_1::Block(this))());  __it->hasNext(); ){
							int c = __it->next();
							{
								HX_STACK_LINE(499)
								Dynamic offset = this->patchInSourceCol->get(c);		HX_STACK_VAR(offset,"offset");
								HX_STACK_LINE(500)
								if (((bool((offset != null())) && bool((offset >= (int)0))))){
									HX_STACK_LINE(500)
									this->source->setCell(offset,mod->destRow,this->patch->getCell(c,mod->patchRow));
								}
							}
;
						}
					}
					else{
						HX_STACK_LINE(506)
						if ((mod->update)){
							HX_STACK_LINE(508)
							this->currentRow = mod->patchRow;
							HX_STACK_LINE(509)
							this->checkAct();
							HX_STACK_LINE(510)
							if ((!(this->rowInfo->updated))){
								HX_STACK_LINE(510)
								continue;
							}
							struct _Function_6_1{
								inline static Dynamic Block( ::coopy::HighlightPatch_obj *__this){
									HX_STACK_PUSH("*::closure","coopy/HighlightPatch.hx",511);
									{
										HX_STACK_LINE(511)
										Array< ::Dynamic > _e = Array_obj< ::Dynamic >::__new().Add(__this->headerPre);		HX_STACK_VAR(_e,"_e");

										HX_BEGIN_LOCAL_FUNC_S1(hx::LocalFunc,_Function_7_1,Array< ::Dynamic >,_e)
										Dynamic run(){
											HX_STACK_PUSH("*::_Function_7_1","coopy/HighlightPatch.hx",511);
											{
												HX_STACK_LINE(511)
												return _e->__get((int)0).StaticCast< ::haxe::ds::StringMap >()->iterator();
											}
											return null();
										}
										HX_END_LOCAL_FUNC0(return)

										HX_STACK_LINE(511)
										return  Dynamic(new _Function_7_1(_e));
									}
									return null();
								}
							};
							HX_STACK_LINE(511)
							for(::cpp::FastIterator_obj< int > *__it = ::cpp::CreateFastIterator< int >((_Function_6_1::Block(this))());  __it->hasNext(); ){
								int c = __it->next();
								{
									HX_STACK_LINE(513)
									::String txt = this->view->toString(this->patch->getCell(c,mod->patchRow));		HX_STACK_VAR(txt,"txt");
									HX_STACK_LINE(514)
									::coopy::DiffRender_obj::examineCell((int)0,(int)0,this->view,txt,HX_CSTRING(""),this->rowInfo->value,HX_CSTRING(""),this->cellInfo,null());
									HX_STACK_LINE(515)
									if ((!(this->cellInfo->updated))){
										HX_STACK_LINE(515)
										continue;
									}
									HX_STACK_LINE(516)
									if ((this->cellInfo->conflicted)){
										HX_STACK_LINE(516)
										continue;
									}
									HX_STACK_LINE(517)
									Dynamic d = this->view->toDatum(this->csv->parseCell(this->cellInfo->rvalue));		HX_STACK_VAR(d,"d");
									HX_STACK_LINE(518)
									this->source->setCell(this->patchInSourceCol->get(c),mod->destRow,d);
								}
;
							}
						}
					}
				}
			}
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,finishRows,(void))

Void HighlightPatch_obj::permuteRows( ){
{
		HX_STACK_PUSH("HighlightPatch::permuteRows","coopy/HighlightPatch.hx",470);
		HX_STACK_THIS(this);
		HX_STACK_LINE(471)
		this->rowPermutation = Array_obj< int >::__new();
		HX_STACK_LINE(472)
		this->rowPermutationRev = Array_obj< int >::__new();
		HX_STACK_LINE(473)
		this->computeOrdering(this->mods,this->rowPermutation,this->rowPermutationRev,this->source->get_height());
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,permuteRows,(void))

Void HighlightPatch_obj::computeOrdering( Array< ::Dynamic > mods,Array< int > permutation,Array< int > permutationRev,int dim){
{
		HX_STACK_PUSH("HighlightPatch::computeOrdering","coopy/HighlightPatch.hx",388);
		HX_STACK_THIS(this);
		HX_STACK_ARG(mods,"mods");
		HX_STACK_ARG(permutation,"permutation");
		HX_STACK_ARG(permutationRev,"permutationRev");
		HX_STACK_ARG(dim,"dim");
		HX_STACK_LINE(392)
		::haxe::ds::IntMap to_unit = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(to_unit,"to_unit");
		HX_STACK_LINE(393)
		::haxe::ds::IntMap from_unit = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(from_unit,"from_unit");
		HX_STACK_LINE(394)
		::haxe::ds::IntMap meta_from_unit = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(meta_from_unit,"meta_from_unit");
		HX_STACK_LINE(395)
		int ct = (int)0;		HX_STACK_VAR(ct,"ct");
		HX_STACK_LINE(396)
		{
			HX_STACK_LINE(396)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(396)
			while(((_g < mods->length))){
				HX_STACK_LINE(396)
				::coopy::HighlightPatchUnit mod = mods->__get(_g).StaticCast< ::coopy::HighlightPatchUnit >();		HX_STACK_VAR(mod,"mod");
				HX_STACK_LINE(396)
				++(_g);
				HX_STACK_LINE(397)
				if (((bool(mod->add) || bool(mod->rem)))){
					HX_STACK_LINE(397)
					continue;
				}
				HX_STACK_LINE(398)
				if (((mod->sourceRow < (int)0))){
					HX_STACK_LINE(398)
					continue;
				}
				HX_STACK_LINE(399)
				if (((mod->sourcePrevRow >= (int)0))){
					HX_STACK_LINE(400)
					{
						HX_STACK_LINE(400)
						int v = mod->sourceRow;		HX_STACK_VAR(v,"v");
						HX_STACK_LINE(400)
						to_unit->set(mod->sourcePrevRow,v);
						HX_STACK_LINE(400)
						v;
					}
					HX_STACK_LINE(401)
					{
						HX_STACK_LINE(401)
						int v = mod->sourcePrevRow;		HX_STACK_VAR(v,"v");
						HX_STACK_LINE(401)
						from_unit->set(mod->sourceRow,v);
						HX_STACK_LINE(401)
						v;
					}
					HX_STACK_LINE(402)
					if ((((mod->sourcePrevRow + (int)1) != mod->sourceRow))){
						HX_STACK_LINE(402)
						(ct)++;
					}
				}
				HX_STACK_LINE(406)
				if (((mod->sourceNextRow >= (int)0))){
					HX_STACK_LINE(408)
					{
						HX_STACK_LINE(408)
						int v = mod->sourceNextRow;		HX_STACK_VAR(v,"v");
						HX_STACK_LINE(408)
						to_unit->set(mod->sourceRow,v);
						HX_STACK_LINE(408)
						v;
					}
					HX_STACK_LINE(409)
					{
						HX_STACK_LINE(409)
						int v = mod->sourceRow;		HX_STACK_VAR(v,"v");
						HX_STACK_LINE(409)
						from_unit->set(mod->sourceNextRow,v);
						HX_STACK_LINE(409)
						v;
					}
					HX_STACK_LINE(410)
					if ((((mod->sourceRow + (int)1) != mod->sourceNextRow))){
						HX_STACK_LINE(410)
						(ct)++;
					}
				}
			}
		}
		HX_STACK_LINE(426)
		if (((ct > (int)0))){
			HX_STACK_LINE(427)
			Dynamic cursor = null();		HX_STACK_VAR(cursor,"cursor");
			HX_STACK_LINE(428)
			Dynamic logical = null();		HX_STACK_VAR(logical,"logical");
			HX_STACK_LINE(429)
			Array< int > starts = Array_obj< int >::__new();		HX_STACK_VAR(starts,"starts");
			HX_STACK_LINE(430)
			{
				HX_STACK_LINE(430)
				int _g = (int)0;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(430)
				while(((_g < dim))){
					HX_STACK_LINE(430)
					int i = (_g)++;		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(431)
					Dynamic u = from_unit->get(i);		HX_STACK_VAR(u,"u");
					HX_STACK_LINE(432)
					if (((u != null()))){
						HX_STACK_LINE(433)
						meta_from_unit->set(u,i);
						HX_STACK_LINE(433)
						i;
					}
					else{
						HX_STACK_LINE(434)
						starts->push(i);
					}
				}
			}
			HX_STACK_LINE(438)
			::haxe::ds::IntMap used = ::haxe::ds::IntMap_obj::__new();		HX_STACK_VAR(used,"used");
			HX_STACK_LINE(439)
			int len = (int)0;		HX_STACK_VAR(len,"len");
			HX_STACK_LINE(440)
			{
				HX_STACK_LINE(440)
				int _g = (int)0;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(440)
				while(((_g < dim))){
					HX_STACK_LINE(440)
					int i = (_g)++;		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(441)
					if ((meta_from_unit->exists(logical))){
						HX_STACK_LINE(441)
						cursor = meta_from_unit->get(logical);
					}
					else{
						HX_STACK_LINE(443)
						cursor = null();
					}
					HX_STACK_LINE(446)
					if (((cursor == null()))){
						HX_STACK_LINE(447)
						int v = starts->shift();		HX_STACK_VAR(v,"v");
						HX_STACK_LINE(448)
						cursor = v;
						HX_STACK_LINE(449)
						logical = v;
					}
					HX_STACK_LINE(451)
					if (((cursor == null()))){
						HX_STACK_LINE(451)
						cursor = (int)0;
					}
					HX_STACK_LINE(454)
					while((used->exists(cursor))){
						HX_STACK_LINE(454)
						cursor = hx::Mod(((cursor + (int)1)),dim);
					}
					HX_STACK_LINE(457)
					logical = cursor;
					HX_STACK_LINE(458)
					permutationRev->push(cursor);
					HX_STACK_LINE(459)
					{
						HX_STACK_LINE(459)
						used->set(cursor,(int)1);
						HX_STACK_LINE(459)
						(int)1;
					}
				}
			}
			HX_STACK_LINE(461)
			{
				HX_STACK_LINE(461)
				int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
				int _g = permutationRev->length;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(461)
				while(((_g1 < _g))){
					HX_STACK_LINE(461)
					int i = (_g1)++;		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(462)
					permutation[i] = (int)-1;
				}
			}
			HX_STACK_LINE(464)
			{
				HX_STACK_LINE(464)
				int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
				int _g = permutation->length;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(464)
				while(((_g1 < _g))){
					HX_STACK_LINE(464)
					int i = (_g1)++;		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(465)
					permutation[permutationRev->__get(i)] = i;
				}
			}
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC4(HighlightPatch_obj,computeOrdering,(void))

int HighlightPatch_obj::processMods( Array< ::Dynamic > rmods,Array< int > fate,int len){
	HX_STACK_PUSH("HighlightPatch::processMods","coopy/HighlightPatch.hx",340);
	HX_STACK_THIS(this);
	HX_STACK_ARG(rmods,"rmods");
	HX_STACK_ARG(fate,"fate");
	HX_STACK_ARG(len,"len");
	HX_STACK_LINE(341)
	rmods->sort(this->sortMods_dyn());
	HX_STACK_LINE(342)
	int offset = (int)0;		HX_STACK_VAR(offset,"offset");
	HX_STACK_LINE(343)
	int last = (int)-1;		HX_STACK_VAR(last,"last");
	HX_STACK_LINE(344)
	int target = (int)0;		HX_STACK_VAR(target,"target");
	HX_STACK_LINE(345)
	if (((rmods->length > (int)0))){
		HX_STACK_LINE(345)
		if (((rmods->__get((int)0).StaticCast< ::coopy::HighlightPatchUnit >()->sourcePrevRow == (int)-1))){
			HX_STACK_LINE(346)
			last = (int)0;
		}
	}
	HX_STACK_LINE(350)
	{
		HX_STACK_LINE(350)
		int _g = (int)0;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(350)
		while(((_g < rmods->length))){
			HX_STACK_LINE(350)
			::coopy::HighlightPatchUnit mod = rmods->__get(_g).StaticCast< ::coopy::HighlightPatchUnit >();		HX_STACK_VAR(mod,"mod");
			HX_STACK_LINE(350)
			++(_g);
			HX_STACK_LINE(351)
			if (((last != (int)-1))){
				HX_STACK_LINE(352)
				int _g2 = last;		HX_STACK_VAR(_g2,"_g2");
				int _g1 = (mod->sourceRow + mod->sourceRowOffset);		HX_STACK_VAR(_g1,"_g1");
				HX_STACK_LINE(352)
				while(((_g2 < _g1))){
					HX_STACK_LINE(352)
					int i = (_g2)++;		HX_STACK_VAR(i,"i");
					HX_STACK_LINE(353)
					fate->push((i + offset));
					HX_STACK_LINE(354)
					(target)++;
					HX_STACK_LINE(355)
					(last)++;
				}
			}
			HX_STACK_LINE(358)
			if ((mod->rem)){
				HX_STACK_LINE(359)
				fate->push((int)-1);
				HX_STACK_LINE(360)
				(offset)--;
			}
			else{
				HX_STACK_LINE(361)
				if ((mod->add)){
					HX_STACK_LINE(362)
					mod->destRow = target;
					HX_STACK_LINE(363)
					(target)++;
					HX_STACK_LINE(364)
					(offset)++;
				}
				else{
					HX_STACK_LINE(365)
					mod->destRow = target;
				}
			}
			HX_STACK_LINE(368)
			if (((mod->sourceRow >= (int)0))){
				HX_STACK_LINE(369)
				last = (mod->sourceRow + mod->sourceRowOffset);
				HX_STACK_LINE(370)
				if ((mod->rem)){
					HX_STACK_LINE(370)
					(last)++;
				}
			}
			else{
				HX_STACK_LINE(371)
				last = (int)-1;
			}
		}
	}
	HX_STACK_LINE(375)
	if (((last != (int)-1))){
		HX_STACK_LINE(376)
		int _g = last;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(376)
		while(((_g < len))){
			HX_STACK_LINE(376)
			int i = (_g)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(377)
			fate->push((i + offset));
			HX_STACK_LINE(378)
			(target)++;
			HX_STACK_LINE(379)
			(last)++;
		}
	}
	HX_STACK_LINE(382)
	return (len + offset);
}


HX_DEFINE_DYNAMIC_FUNC3(HighlightPatch_obj,processMods,return )

int HighlightPatch_obj::sortMods( ::coopy::HighlightPatchUnit a,::coopy::HighlightPatchUnit b){
	HX_STACK_PUSH("HighlightPatch::sortMods","coopy/HighlightPatch.hx",324);
	HX_STACK_THIS(this);
	HX_STACK_ARG(a,"a");
	HX_STACK_ARG(b,"b");
	HX_STACK_LINE(327)
	if (((bool((b->code == HX_CSTRING("@@"))) && bool((a->code != HX_CSTRING("@@")))))){
		HX_STACK_LINE(327)
		return (int)1;
	}
	HX_STACK_LINE(328)
	if (((bool((a->code == HX_CSTRING("@@"))) && bool((b->code != HX_CSTRING("@@")))))){
		HX_STACK_LINE(328)
		return (int)-1;
	}
	HX_STACK_LINE(329)
	if (((bool((bool((a->sourceRow == (int)-1)) && bool(!(a->add)))) && bool((b->sourceRow != (int)-1))))){
		HX_STACK_LINE(329)
		return (int)1;
	}
	HX_STACK_LINE(330)
	if (((bool((bool((a->sourceRow != (int)-1)) && bool(!(b->add)))) && bool((b->sourceRow == (int)-1))))){
		HX_STACK_LINE(330)
		return (int)-1;
	}
	HX_STACK_LINE(331)
	if ((((a->sourceRow + a->sourceRowOffset) > (b->sourceRow + b->sourceRowOffset)))){
		HX_STACK_LINE(331)
		return (int)1;
	}
	HX_STACK_LINE(332)
	if ((((a->sourceRow + a->sourceRowOffset) < (b->sourceRow + b->sourceRowOffset)))){
		HX_STACK_LINE(332)
		return (int)-1;
	}
	HX_STACK_LINE(333)
	if (((a->patchRow > b->patchRow))){
		HX_STACK_LINE(333)
		return (int)1;
	}
	HX_STACK_LINE(334)
	if (((a->patchRow < b->patchRow))){
		HX_STACK_LINE(334)
		return (int)-1;
	}
	HX_STACK_LINE(334)
	return (int)0;
}


HX_DEFINE_DYNAMIC_FUNC2(HighlightPatch_obj,sortMods,return )

bool HighlightPatch_obj::isPreamble( ){
	HX_STACK_PUSH("HighlightPatch::isPreamble","coopy/HighlightPatch.hx",320);
	HX_STACK_THIS(this);
	HX_STACK_LINE(320)
	return (this->currentRow <= this->headerRow);
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,isPreamble,return )

::String HighlightPatch_obj::getRowString( int c){
	HX_STACK_PUSH("HighlightPatch::getRowString","coopy/HighlightPatch.hx",314);
	HX_STACK_THIS(this);
	HX_STACK_ARG(c,"c");
	HX_STACK_LINE(315)
	Dynamic at = this->sourceInPatchCol->get(c);		HX_STACK_VAR(at,"at");
	HX_STACK_LINE(316)
	if (((at == null()))){
		HX_STACK_LINE(316)
		return HX_CSTRING("NOT_FOUND");
	}
	HX_STACK_LINE(317)
	return this->getPreString(this->getString(at));
}


HX_DEFINE_DYNAMIC_FUNC1(HighlightPatch_obj,getRowString,return )

::String HighlightPatch_obj::getPreString( ::String txt){
	HX_STACK_PUSH("HighlightPatch::getPreString","coopy/HighlightPatch.hx",296);
	HX_STACK_THIS(this);
	HX_STACK_ARG(txt,"txt");
	HX_STACK_LINE(297)
	this->checkAct();
	HX_STACK_LINE(299)
	if ((!(this->rowInfo->updated))){
		HX_STACK_LINE(299)
		return txt;
	}
	HX_STACK_LINE(300)
	::coopy::DiffRender_obj::examineCell((int)0,(int)0,this->view,txt,HX_CSTRING(""),this->rowInfo->value,HX_CSTRING(""),this->cellInfo,null());
	HX_STACK_LINE(301)
	if ((!(this->cellInfo->updated))){
		HX_STACK_LINE(301)
		return txt;
	}
	HX_STACK_LINE(302)
	return this->cellInfo->lvalue;
}


HX_DEFINE_DYNAMIC_FUNC1(HighlightPatch_obj,getPreString,return )

Void HighlightPatch_obj::checkAct( ){
{
		HX_STACK_PUSH("HighlightPatch::checkAct","coopy/HighlightPatch.hx",288);
		HX_STACK_THIS(this);
		HX_STACK_LINE(289)
		::String act = this->getString(this->rcOffset);		HX_STACK_VAR(act,"act");
		HX_STACK_LINE(291)
		if (((this->rowInfo->value != act))){
			HX_STACK_LINE(291)
			::coopy::DiffRender_obj::examineCell((int)0,(int)0,this->view,act,HX_CSTRING(""),act,HX_CSTRING(""),this->rowInfo,null());
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,checkAct,(void))

Void HighlightPatch_obj::applyAction( ::String code){
{
		HX_STACK_PUSH("HighlightPatch::applyAction","coopy/HighlightPatch.hx",254);
		HX_STACK_THIS(this);
		HX_STACK_ARG(code,"code");
		HX_STACK_LINE(255)
		::coopy::HighlightPatchUnit mod = ::coopy::HighlightPatchUnit_obj::__new();		HX_STACK_VAR(mod,"mod");
		HX_STACK_LINE(256)
		mod->code = code;
		HX_STACK_LINE(257)
		mod->add = (code == HX_CSTRING("+++"));
		HX_STACK_LINE(258)
		mod->rem = (code == HX_CSTRING("---"));
		HX_STACK_LINE(259)
		mod->update = (code == HX_CSTRING("->"));
		HX_STACK_LINE(260)
		this->needSourceIndex();
		HX_STACK_LINE(261)
		if (((this->lastSourceRow == (int)-1))){
			HX_STACK_LINE(261)
			this->lastSourceRow = this->lookUp((int)-1);
		}
		HX_STACK_LINE(264)
		mod->sourcePrevRow = this->lastSourceRow;
		HX_STACK_LINE(265)
		::String nextAct = this->actions->__get((this->currentRow + (int)1));		HX_STACK_VAR(nextAct,"nextAct");
		HX_STACK_LINE(266)
		if (((bool((nextAct != HX_CSTRING("+++"))) && bool((nextAct != HX_CSTRING("...")))))){
			HX_STACK_LINE(266)
			mod->sourceNextRow = this->lookUp((int)1);
		}
		HX_STACK_LINE(269)
		if ((mod->add)){
			HX_STACK_LINE(270)
			if (((this->actions->__get((this->currentRow - (int)1)) != HX_CSTRING("+++")))){
				HX_STACK_LINE(270)
				mod->sourcePrevRow = this->lookUp((int)-1);
			}
			HX_STACK_LINE(273)
			mod->sourceRow = mod->sourcePrevRow;
			HX_STACK_LINE(274)
			if (((mod->sourceRow != (int)-1))){
				HX_STACK_LINE(274)
				mod->sourceRowOffset = (int)1;
			}
		}
		else{
			HX_STACK_LINE(275)
			mod->sourceRow = this->lastSourceRow = this->lookUp(null());
		}
		HX_STACK_LINE(278)
		if (((this->actions->__get((this->currentRow + (int)1)) == HX_CSTRING("")))){
			HX_STACK_LINE(278)
			this->lastSourceRow = mod->sourceNextRow;
		}
		HX_STACK_LINE(281)
		mod->patchRow = this->currentRow;
		HX_STACK_LINE(282)
		if (((code == HX_CSTRING("@@")))){
			HX_STACK_LINE(282)
			mod->sourceRow = (int)0;
		}
		HX_STACK_LINE(285)
		this->mods->push(mod);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(HighlightPatch_obj,applyAction,(void))

int HighlightPatch_obj::lookUp( hx::Null< int >  __o_del){
int del = __o_del.Default(0);
	HX_STACK_PUSH("HighlightPatch::lookUp","coopy/HighlightPatch.hx",236);
	HX_STACK_THIS(this);
	HX_STACK_ARG(del,"del");
{
		HX_STACK_LINE(237)
		Dynamic at = this->patchInSourceRow->get((this->currentRow + del));		HX_STACK_VAR(at,"at");
		HX_STACK_LINE(238)
		if (((at != null()))){
			HX_STACK_LINE(238)
			return at;
		}
		HX_STACK_LINE(239)
		int result = (int)-1;		HX_STACK_VAR(result,"result");
		HX_STACK_LINE(240)
		hx::AddEq(this->currentRow,del);
		HX_STACK_LINE(241)
		if (((bool((this->currentRow >= (int)0)) && bool((this->currentRow < this->patch->get_height()))))){
			HX_STACK_LINE(242)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			Array< ::Dynamic > _g1 = this->indexes;		HX_STACK_VAR(_g1,"_g1");
			HX_STACK_LINE(242)
			while(((_g < _g1->length))){
				HX_STACK_LINE(242)
				::coopy::IndexPair idx = _g1->__get(_g).StaticCast< ::coopy::IndexPair >();		HX_STACK_VAR(idx,"idx");
				HX_STACK_LINE(242)
				++(_g);
				HX_STACK_LINE(243)
				::coopy::CrossMatch match = idx->queryByContent(hx::ObjectPtr<OBJ_>(this));		HX_STACK_VAR(match,"match");
				HX_STACK_LINE(244)
				if (((match->spot_a != (int)1))){
					HX_STACK_LINE(244)
					continue;
				}
				HX_STACK_LINE(245)
				result = match->item_a->lst->__get((int)0);
				HX_STACK_LINE(246)
				break;
			}
		}
		HX_STACK_LINE(249)
		{
			HX_STACK_LINE(249)
			this->patchInSourceRow->set(this->currentRow,result);
			HX_STACK_LINE(249)
			result;
		}
		HX_STACK_LINE(250)
		hx::SubEq(this->currentRow,del);
		HX_STACK_LINE(251)
		return result;
	}
}


HX_DEFINE_DYNAMIC_FUNC1(HighlightPatch_obj,lookUp,return )

Void HighlightPatch_obj::applyHeader( ){
{
		HX_STACK_PUSH("HighlightPatch::applyHeader","coopy/HighlightPatch.hx",198);
		HX_STACK_THIS(this);
		HX_STACK_LINE(199)
		{
			HX_STACK_LINE(199)
			int _g1 = this->payloadCol;		HX_STACK_VAR(_g1,"_g1");
			int _g = this->payloadTop;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(199)
			while(((_g1 < _g))){
				HX_STACK_LINE(199)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(200)
				::String name = this->getString(i);		HX_STACK_VAR(name,"name");
				HX_STACK_LINE(201)
				if (((name == HX_CSTRING("...")))){
					HX_STACK_LINE(202)
					this->modifier->set(i,HX_CSTRING("..."));
					HX_STACK_LINE(203)
					this->haveDroppedColumns = true;
					HX_STACK_LINE(204)
					continue;
				}
				HX_STACK_LINE(206)
				::String mod = this->modifier->get(i);		HX_STACK_VAR(mod,"mod");
				HX_STACK_LINE(207)
				bool move = false;		HX_STACK_VAR(move,"move");
				HX_STACK_LINE(208)
				if (((mod != null()))){
					HX_STACK_LINE(208)
					if (((mod.charCodeAt((int)0) == (int)58))){
						HX_STACK_LINE(210)
						move = true;
						HX_STACK_LINE(211)
						mod = mod.substr((int)1,mod.length);
					}
				}
				HX_STACK_LINE(214)
				this->header->set(i,name);
				HX_STACK_LINE(215)
				if (((mod != null()))){
					HX_STACK_LINE(215)
					if (((mod.charCodeAt((int)0) == (int)40))){
						HX_STACK_LINE(217)
						::String prev_name = mod.substr((int)1,(mod.length - (int)2));		HX_STACK_VAR(prev_name,"prev_name");
						HX_STACK_LINE(218)
						this->headerPre->set(prev_name,i);
						HX_STACK_LINE(219)
						this->headerPost->set(name,i);
						HX_STACK_LINE(220)
						this->headerRename->set(prev_name,name);
						HX_STACK_LINE(221)
						continue;
					}
				}
				HX_STACK_LINE(224)
				if (((mod != HX_CSTRING("+++")))){
					HX_STACK_LINE(224)
					this->headerPre->set(name,i);
				}
				HX_STACK_LINE(225)
				if (((mod != HX_CSTRING("---")))){
					HX_STACK_LINE(225)
					this->headerPost->set(name,i);
				}
				HX_STACK_LINE(226)
				if ((move)){
					HX_STACK_LINE(227)
					if (((this->headerMove == null()))){
						HX_STACK_LINE(227)
						this->headerMove = ::haxe::ds::StringMap_obj::__new();
					}
					HX_STACK_LINE(228)
					this->headerMove->set(name,(int)1);
				}
			}
		}
		HX_STACK_LINE(231)
		if (((this->source->get_height() == (int)0))){
			HX_STACK_LINE(231)
			this->applyAction(HX_CSTRING("+++"));
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,applyHeader,(void))

Void HighlightPatch_obj::applyMeta( ){
{
		HX_STACK_PUSH("HighlightPatch::applyMeta","coopy/HighlightPatch.hx",190);
		HX_STACK_THIS(this);
		HX_STACK_LINE(191)
		int _g1 = this->payloadCol;		HX_STACK_VAR(_g1,"_g1");
		int _g = this->payloadTop;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(191)
		while(((_g1 < _g))){
			HX_STACK_LINE(191)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(192)
			::String name = this->getString(i);		HX_STACK_VAR(name,"name");
			HX_STACK_LINE(193)
			if (((name == HX_CSTRING("")))){
				HX_STACK_LINE(193)
				continue;
			}
			HX_STACK_LINE(194)
			this->modifier->set(i,name);
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,applyMeta,(void))

::String HighlightPatch_obj::getString( int c){
	HX_STACK_PUSH("HighlightPatch::getString","coopy/HighlightPatch.hx",185);
	HX_STACK_THIS(this);
	HX_STACK_ARG(c,"c");
	HX_STACK_LINE(185)
	return this->view->toString(this->getDatum(c));
}


HX_DEFINE_DYNAMIC_FUNC1(HighlightPatch_obj,getString,return )

Dynamic HighlightPatch_obj::getDatum( int c){
	HX_STACK_PUSH("HighlightPatch::getDatum","coopy/HighlightPatch.hx",181);
	HX_STACK_THIS(this);
	HX_STACK_ARG(c,"c");
	HX_STACK_LINE(181)
	return this->patch->getCell(c,this->currentRow);
}


HX_DEFINE_DYNAMIC_FUNC1(HighlightPatch_obj,getDatum,return )

Void HighlightPatch_obj::applyRow( int r){
{
		HX_STACK_PUSH("HighlightPatch::applyRow","coopy/HighlightPatch.hx",156);
		HX_STACK_THIS(this);
		HX_STACK_ARG(r,"r");
		HX_STACK_LINE(157)
		this->currentRow = r;
		HX_STACK_LINE(158)
		::String code = this->actions->__get(r);		HX_STACK_VAR(code,"code");
		HX_STACK_LINE(159)
		if (((bool((r == (int)0)) && bool((this->rcOffset > (int)0))))){
		}
		else{
			HX_STACK_LINE(161)
			if (((code == HX_CSTRING("@@")))){
				HX_STACK_LINE(162)
				this->headerRow = r;
				HX_STACK_LINE(163)
				this->applyHeader();
				HX_STACK_LINE(164)
				this->applyAction(HX_CSTRING("@@"));
			}
			else{
				HX_STACK_LINE(165)
				if (((code == HX_CSTRING("!")))){
					HX_STACK_LINE(166)
					this->headerRow = r;
					HX_STACK_LINE(167)
					this->applyMeta();
				}
				else{
					HX_STACK_LINE(168)
					if (((code == HX_CSTRING("+++")))){
						HX_STACK_LINE(168)
						this->applyAction(code);
					}
					else{
						HX_STACK_LINE(170)
						if (((code == HX_CSTRING("---")))){
							HX_STACK_LINE(170)
							this->applyAction(code);
						}
						else{
							HX_STACK_LINE(172)
							if (((bool((code == HX_CSTRING("+"))) || bool((code == HX_CSTRING(":")))))){
								HX_STACK_LINE(172)
								this->applyAction(code);
							}
							else{
								HX_STACK_LINE(174)
								if (((code.indexOf(HX_CSTRING("->"),null()) >= (int)0))){
									HX_STACK_LINE(174)
									this->applyAction(HX_CSTRING("->"));
								}
								else{
									HX_STACK_LINE(176)
									this->lastSourceRow = (int)-1;
								}
							}
						}
					}
				}
			}
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(HighlightPatch_obj,applyRow,(void))

Void HighlightPatch_obj::needSourceIndex( ){
{
		HX_STACK_PUSH("HighlightPatch::needSourceIndex","coopy/HighlightPatch.hx",143);
		HX_STACK_THIS(this);
		HX_STACK_LINE(144)
		if (((this->indexes != null()))){
			HX_STACK_LINE(144)
			return null();
		}
		HX_STACK_LINE(145)
		::coopy::TableComparisonState state = ::coopy::TableComparisonState_obj::__new();		HX_STACK_VAR(state,"state");
		HX_STACK_LINE(146)
		state->a = this->source;
		HX_STACK_LINE(147)
		state->b = this->source;
		HX_STACK_LINE(148)
		::coopy::CompareTable comp = ::coopy::CompareTable_obj::__new(state);		HX_STACK_VAR(comp,"comp");
		HX_STACK_LINE(149)
		comp->storeIndexes();
		HX_STACK_LINE(150)
		comp->run();
		HX_STACK_LINE(151)
		comp->align();
		HX_STACK_LINE(152)
		this->indexes = comp->getIndexes();
		HX_STACK_LINE(153)
		this->needSourceColumns();
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,needSourceIndex,(void))

Void HighlightPatch_obj::needSourceColumns( ){
{
		HX_STACK_PUSH("HighlightPatch::needSourceColumns","coopy/HighlightPatch.hx",127);
		HX_STACK_THIS(this);
		HX_STACK_LINE(128)
		if (((this->sourceInPatchCol != null()))){
			HX_STACK_LINE(128)
			return null();
		}
		HX_STACK_LINE(129)
		this->sourceInPatchCol = ::haxe::ds::IntMap_obj::__new();
		HX_STACK_LINE(130)
		this->patchInSourceCol = ::haxe::ds::IntMap_obj::__new();
		HX_STACK_LINE(133)
		::coopy::View av = this->source->getCellView();		HX_STACK_VAR(av,"av");
		HX_STACK_LINE(134)
		{
			HX_STACK_LINE(134)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			int _g = this->source->get_width();		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(134)
			while(((_g1 < _g))){
				HX_STACK_LINE(134)
				int i = (_g1)++;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(135)
				::String name = av->toString(this->source->getCell(i,(int)0));		HX_STACK_VAR(name,"name");
				HX_STACK_LINE(136)
				Dynamic at = this->headerPre->get(name);		HX_STACK_VAR(at,"at");
				HX_STACK_LINE(137)
				if (((at == null()))){
					HX_STACK_LINE(137)
					continue;
				}
				HX_STACK_LINE(138)
				this->sourceInPatchCol->set(i,at);
				HX_STACK_LINE(139)
				this->patchInSourceCol->set(at,i);
			}
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,needSourceColumns,(void))

bool HighlightPatch_obj::apply( ){
	HX_STACK_PUSH("HighlightPatch::apply","coopy/HighlightPatch.hx",106);
	HX_STACK_THIS(this);
	HX_STACK_LINE(107)
	this->reset();
	HX_STACK_LINE(108)
	if (((this->patch->get_width() < (int)2))){
		HX_STACK_LINE(108)
		return true;
	}
	HX_STACK_LINE(109)
	if (((this->patch->get_height() < (int)1))){
		HX_STACK_LINE(109)
		return true;
	}
	HX_STACK_LINE(110)
	this->payloadCol = ((int)1 + this->rcOffset);
	HX_STACK_LINE(111)
	this->payloadTop = this->patch->get_width();
	HX_STACK_LINE(112)
	::String corner = this->patch->getCellView()->toString(this->patch->getCell((int)0,(int)0));		HX_STACK_VAR(corner,"corner");
	HX_STACK_LINE(113)
	this->rcOffset = (  (((corner == HX_CSTRING("@:@")))) ? int((int)1) : int((int)0) );
	HX_STACK_LINE(114)
	{
		HX_STACK_LINE(114)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = this->patch->get_height();		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(114)
		while(((_g1 < _g))){
			HX_STACK_LINE(114)
			int r = (_g1)++;		HX_STACK_VAR(r,"r");
			HX_STACK_LINE(115)
			::String str = this->view->toString(this->patch->getCell(this->rcOffset,r));		HX_STACK_VAR(str,"str");
			HX_STACK_LINE(116)
			this->actions->push((  (((str != null()))) ? ::String(str) : ::String(HX_CSTRING("")) ));
		}
	}
	HX_STACK_LINE(118)
	this->headerRow = this->rcOffset;
	HX_STACK_LINE(119)
	{
		HX_STACK_LINE(119)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = this->patch->get_height();		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(119)
		while(((_g1 < _g))){
			HX_STACK_LINE(119)
			int r = (_g1)++;		HX_STACK_VAR(r,"r");
			HX_STACK_LINE(120)
			this->applyRow(r);
		}
	}
	HX_STACK_LINE(122)
	this->finishRows();
	HX_STACK_LINE(123)
	this->finishColumns();
	HX_STACK_LINE(124)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,apply,return )

Void HighlightPatch_obj::reset( ){
{
		HX_STACK_PUSH("HighlightPatch::reset","coopy/HighlightPatch.hx",71);
		HX_STACK_THIS(this);
		HX_STACK_LINE(72)
		this->header = ::haxe::ds::IntMap_obj::__new();
		HX_STACK_LINE(73)
		this->headerPre = ::haxe::ds::StringMap_obj::__new();
		HX_STACK_LINE(74)
		this->headerPost = ::haxe::ds::StringMap_obj::__new();
		HX_STACK_LINE(75)
		this->headerRename = ::haxe::ds::StringMap_obj::__new();
		HX_STACK_LINE(76)
		this->headerMove = null();
		HX_STACK_LINE(77)
		this->modifier = ::haxe::ds::IntMap_obj::__new();
		HX_STACK_LINE(78)
		this->mods = Array_obj< ::Dynamic >::__new();
		HX_STACK_LINE(79)
		this->cmods = Array_obj< ::Dynamic >::__new();
		HX_STACK_LINE(80)
		this->csv = ::coopy::Csv_obj::__new(null());
		HX_STACK_LINE(81)
		this->rcOffset = (int)0;
		HX_STACK_LINE(82)
		this->currentRow = (int)-1;
		HX_STACK_LINE(83)
		this->rowInfo = ::coopy::CellInfo_obj::__new();
		HX_STACK_LINE(84)
		this->cellInfo = ::coopy::CellInfo_obj::__new();
		HX_STACK_LINE(86)
		this->sourceInPatchCol = this->patchInSourceCol = null();
		HX_STACK_LINE(87)
		this->patchInSourceRow = ::haxe::ds::IntMap_obj::__new();
		HX_STACK_LINE(88)
		this->indexes = null();
		HX_STACK_LINE(89)
		this->lastSourceRow = (int)-1;
		HX_STACK_LINE(90)
		this->actions = Array_obj< ::String >::__new();
		HX_STACK_LINE(91)
		this->rowPermutation = null();
		HX_STACK_LINE(92)
		this->rowPermutationRev = null();
		HX_STACK_LINE(93)
		this->colPermutation = null();
		HX_STACK_LINE(94)
		this->colPermutationRev = null();
		HX_STACK_LINE(95)
		this->haveDroppedColumns = false;
		HX_STACK_LINE(96)
		this->headerRow = (int)0;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(HighlightPatch_obj,reset,(void))


HighlightPatch_obj::HighlightPatch_obj()
{
}

void HighlightPatch_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(HighlightPatch);
	HX_MARK_MEMBER_NAME(headerRow,"headerRow");
	HX_MARK_MEMBER_NAME(haveDroppedColumns,"haveDroppedColumns");
	HX_MARK_MEMBER_NAME(colPermutationRev,"colPermutationRev");
	HX_MARK_MEMBER_NAME(colPermutation,"colPermutation");
	HX_MARK_MEMBER_NAME(rowPermutationRev,"rowPermutationRev");
	HX_MARK_MEMBER_NAME(rowPermutation,"rowPermutation");
	HX_MARK_MEMBER_NAME(actions,"actions");
	HX_MARK_MEMBER_NAME(lastSourceRow,"lastSourceRow");
	HX_MARK_MEMBER_NAME(patchInSourceRow,"patchInSourceRow");
	HX_MARK_MEMBER_NAME(patchInSourceCol,"patchInSourceCol");
	HX_MARK_MEMBER_NAME(sourceInPatchCol,"sourceInPatchCol");
	HX_MARK_MEMBER_NAME(indexes,"indexes");
	HX_MARK_MEMBER_NAME(rcOffset,"rcOffset");
	HX_MARK_MEMBER_NAME(cellInfo,"cellInfo");
	HX_MARK_MEMBER_NAME(rowInfo,"rowInfo");
	HX_MARK_MEMBER_NAME(cmods,"cmods");
	HX_MARK_MEMBER_NAME(mods,"mods");
	HX_MARK_MEMBER_NAME(payloadTop,"payloadTop");
	HX_MARK_MEMBER_NAME(payloadCol,"payloadCol");
	HX_MARK_MEMBER_NAME(currentRow,"currentRow");
	HX_MARK_MEMBER_NAME(modifier,"modifier");
	HX_MARK_MEMBER_NAME(headerMove,"headerMove");
	HX_MARK_MEMBER_NAME(headerRename,"headerRename");
	HX_MARK_MEMBER_NAME(headerPost,"headerPost");
	HX_MARK_MEMBER_NAME(headerPre,"headerPre");
	HX_MARK_MEMBER_NAME(header,"header");
	HX_MARK_MEMBER_NAME(csv,"csv");
	HX_MARK_MEMBER_NAME(sourceView,"sourceView");
	HX_MARK_MEMBER_NAME(view,"view");
	HX_MARK_MEMBER_NAME(patch,"patch");
	HX_MARK_MEMBER_NAME(source,"source");
	HX_MARK_END_CLASS();
}

void HighlightPatch_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(headerRow,"headerRow");
	HX_VISIT_MEMBER_NAME(haveDroppedColumns,"haveDroppedColumns");
	HX_VISIT_MEMBER_NAME(colPermutationRev,"colPermutationRev");
	HX_VISIT_MEMBER_NAME(colPermutation,"colPermutation");
	HX_VISIT_MEMBER_NAME(rowPermutationRev,"rowPermutationRev");
	HX_VISIT_MEMBER_NAME(rowPermutation,"rowPermutation");
	HX_VISIT_MEMBER_NAME(actions,"actions");
	HX_VISIT_MEMBER_NAME(lastSourceRow,"lastSourceRow");
	HX_VISIT_MEMBER_NAME(patchInSourceRow,"patchInSourceRow");
	HX_VISIT_MEMBER_NAME(patchInSourceCol,"patchInSourceCol");
	HX_VISIT_MEMBER_NAME(sourceInPatchCol,"sourceInPatchCol");
	HX_VISIT_MEMBER_NAME(indexes,"indexes");
	HX_VISIT_MEMBER_NAME(rcOffset,"rcOffset");
	HX_VISIT_MEMBER_NAME(cellInfo,"cellInfo");
	HX_VISIT_MEMBER_NAME(rowInfo,"rowInfo");
	HX_VISIT_MEMBER_NAME(cmods,"cmods");
	HX_VISIT_MEMBER_NAME(mods,"mods");
	HX_VISIT_MEMBER_NAME(payloadTop,"payloadTop");
	HX_VISIT_MEMBER_NAME(payloadCol,"payloadCol");
	HX_VISIT_MEMBER_NAME(currentRow,"currentRow");
	HX_VISIT_MEMBER_NAME(modifier,"modifier");
	HX_VISIT_MEMBER_NAME(headerMove,"headerMove");
	HX_VISIT_MEMBER_NAME(headerRename,"headerRename");
	HX_VISIT_MEMBER_NAME(headerPost,"headerPost");
	HX_VISIT_MEMBER_NAME(headerPre,"headerPre");
	HX_VISIT_MEMBER_NAME(header,"header");
	HX_VISIT_MEMBER_NAME(csv,"csv");
	HX_VISIT_MEMBER_NAME(sourceView,"sourceView");
	HX_VISIT_MEMBER_NAME(view,"view");
	HX_VISIT_MEMBER_NAME(patch,"patch");
	HX_VISIT_MEMBER_NAME(source,"source");
}

Dynamic HighlightPatch_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 3:
		if (HX_FIELD_EQ(inName,"csv") ) { return csv; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"mods") ) { return mods; }
		if (HX_FIELD_EQ(inName,"view") ) { return view; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"apply") ) { return apply_dyn(); }
		if (HX_FIELD_EQ(inName,"reset") ) { return reset_dyn(); }
		if (HX_FIELD_EQ(inName,"cmods") ) { return cmods; }
		if (HX_FIELD_EQ(inName,"patch") ) { return patch; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"lookUp") ) { return lookUp_dyn(); }
		if (HX_FIELD_EQ(inName,"header") ) { return header; }
		if (HX_FIELD_EQ(inName,"source") ) { return source; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"actions") ) { return actions; }
		if (HX_FIELD_EQ(inName,"indexes") ) { return indexes; }
		if (HX_FIELD_EQ(inName,"rowInfo") ) { return rowInfo; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"sortMods") ) { return sortMods_dyn(); }
		if (HX_FIELD_EQ(inName,"checkAct") ) { return checkAct_dyn(); }
		if (HX_FIELD_EQ(inName,"getDatum") ) { return getDatum_dyn(); }
		if (HX_FIELD_EQ(inName,"applyRow") ) { return applyRow_dyn(); }
		if (HX_FIELD_EQ(inName,"rcOffset") ) { return rcOffset; }
		if (HX_FIELD_EQ(inName,"cellInfo") ) { return cellInfo; }
		if (HX_FIELD_EQ(inName,"modifier") ) { return modifier; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"applyMeta") ) { return applyMeta_dyn(); }
		if (HX_FIELD_EQ(inName,"getString") ) { return getString_dyn(); }
		if (HX_FIELD_EQ(inName,"headerRow") ) { return headerRow; }
		if (HX_FIELD_EQ(inName,"headerPre") ) { return headerPre; }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"finishRows") ) { return finishRows_dyn(); }
		if (HX_FIELD_EQ(inName,"isPreamble") ) { return isPreamble_dyn(); }
		if (HX_FIELD_EQ(inName,"payloadTop") ) { return payloadTop; }
		if (HX_FIELD_EQ(inName,"payloadCol") ) { return payloadCol; }
		if (HX_FIELD_EQ(inName,"currentRow") ) { return currentRow; }
		if (HX_FIELD_EQ(inName,"headerMove") ) { return headerMove; }
		if (HX_FIELD_EQ(inName,"headerPost") ) { return headerPost; }
		if (HX_FIELD_EQ(inName,"sourceView") ) { return sourceView; }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"permuteRows") ) { return permuteRows_dyn(); }
		if (HX_FIELD_EQ(inName,"processMods") ) { return processMods_dyn(); }
		if (HX_FIELD_EQ(inName,"applyAction") ) { return applyAction_dyn(); }
		if (HX_FIELD_EQ(inName,"applyHeader") ) { return applyHeader_dyn(); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"getRowString") ) { return getRowString_dyn(); }
		if (HX_FIELD_EQ(inName,"getPreString") ) { return getPreString_dyn(); }
		if (HX_FIELD_EQ(inName,"headerRename") ) { return headerRename; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"finishColumns") ) { return finishColumns_dyn(); }
		if (HX_FIELD_EQ(inName,"lastSourceRow") ) { return lastSourceRow; }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"permuteColumns") ) { return permuteColumns_dyn(); }
		if (HX_FIELD_EQ(inName,"colPermutation") ) { return colPermutation; }
		if (HX_FIELD_EQ(inName,"rowPermutation") ) { return rowPermutation; }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"computeOrdering") ) { return computeOrdering_dyn(); }
		if (HX_FIELD_EQ(inName,"needSourceIndex") ) { return needSourceIndex_dyn(); }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"patchInSourceRow") ) { return patchInSourceRow; }
		if (HX_FIELD_EQ(inName,"patchInSourceCol") ) { return patchInSourceCol; }
		if (HX_FIELD_EQ(inName,"sourceInPatchCol") ) { return sourceInPatchCol; }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"needSourceColumns") ) { return needSourceColumns_dyn(); }
		if (HX_FIELD_EQ(inName,"colPermutationRev") ) { return colPermutationRev; }
		if (HX_FIELD_EQ(inName,"rowPermutationRev") ) { return rowPermutationRev; }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"haveDroppedColumns") ) { return haveDroppedColumns; }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic HighlightPatch_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 3:
		if (HX_FIELD_EQ(inName,"csv") ) { csv=inValue.Cast< ::coopy::Csv >(); return inValue; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"mods") ) { mods=inValue.Cast< Array< ::Dynamic > >(); return inValue; }
		if (HX_FIELD_EQ(inName,"view") ) { view=inValue.Cast< ::coopy::View >(); return inValue; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"cmods") ) { cmods=inValue.Cast< Array< ::Dynamic > >(); return inValue; }
		if (HX_FIELD_EQ(inName,"patch") ) { patch=inValue.Cast< ::coopy::Table >(); return inValue; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"header") ) { header=inValue.Cast< ::haxe::ds::IntMap >(); return inValue; }
		if (HX_FIELD_EQ(inName,"source") ) { source=inValue.Cast< ::coopy::Table >(); return inValue; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"actions") ) { actions=inValue.Cast< Array< ::String > >(); return inValue; }
		if (HX_FIELD_EQ(inName,"indexes") ) { indexes=inValue.Cast< Array< ::Dynamic > >(); return inValue; }
		if (HX_FIELD_EQ(inName,"rowInfo") ) { rowInfo=inValue.Cast< ::coopy::CellInfo >(); return inValue; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"rcOffset") ) { rcOffset=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"cellInfo") ) { cellInfo=inValue.Cast< ::coopy::CellInfo >(); return inValue; }
		if (HX_FIELD_EQ(inName,"modifier") ) { modifier=inValue.Cast< ::haxe::ds::IntMap >(); return inValue; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"headerRow") ) { headerRow=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"headerPre") ) { headerPre=inValue.Cast< ::haxe::ds::StringMap >(); return inValue; }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"payloadTop") ) { payloadTop=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"payloadCol") ) { payloadCol=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"currentRow") ) { currentRow=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"headerMove") ) { headerMove=inValue.Cast< ::haxe::ds::StringMap >(); return inValue; }
		if (HX_FIELD_EQ(inName,"headerPost") ) { headerPost=inValue.Cast< ::haxe::ds::StringMap >(); return inValue; }
		if (HX_FIELD_EQ(inName,"sourceView") ) { sourceView=inValue.Cast< ::coopy::View >(); return inValue; }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"headerRename") ) { headerRename=inValue.Cast< ::haxe::ds::StringMap >(); return inValue; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"lastSourceRow") ) { lastSourceRow=inValue.Cast< int >(); return inValue; }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"colPermutation") ) { colPermutation=inValue.Cast< Array< int > >(); return inValue; }
		if (HX_FIELD_EQ(inName,"rowPermutation") ) { rowPermutation=inValue.Cast< Array< int > >(); return inValue; }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"patchInSourceRow") ) { patchInSourceRow=inValue.Cast< ::haxe::ds::IntMap >(); return inValue; }
		if (HX_FIELD_EQ(inName,"patchInSourceCol") ) { patchInSourceCol=inValue.Cast< ::haxe::ds::IntMap >(); return inValue; }
		if (HX_FIELD_EQ(inName,"sourceInPatchCol") ) { sourceInPatchCol=inValue.Cast< ::haxe::ds::IntMap >(); return inValue; }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"colPermutationRev") ) { colPermutationRev=inValue.Cast< Array< int > >(); return inValue; }
		if (HX_FIELD_EQ(inName,"rowPermutationRev") ) { rowPermutationRev=inValue.Cast< Array< int > >(); return inValue; }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"haveDroppedColumns") ) { haveDroppedColumns=inValue.Cast< bool >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void HighlightPatch_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("headerRow"));
	outFields->push(HX_CSTRING("haveDroppedColumns"));
	outFields->push(HX_CSTRING("colPermutationRev"));
	outFields->push(HX_CSTRING("colPermutation"));
	outFields->push(HX_CSTRING("rowPermutationRev"));
	outFields->push(HX_CSTRING("rowPermutation"));
	outFields->push(HX_CSTRING("actions"));
	outFields->push(HX_CSTRING("lastSourceRow"));
	outFields->push(HX_CSTRING("patchInSourceRow"));
	outFields->push(HX_CSTRING("patchInSourceCol"));
	outFields->push(HX_CSTRING("sourceInPatchCol"));
	outFields->push(HX_CSTRING("indexes"));
	outFields->push(HX_CSTRING("rcOffset"));
	outFields->push(HX_CSTRING("cellInfo"));
	outFields->push(HX_CSTRING("rowInfo"));
	outFields->push(HX_CSTRING("cmods"));
	outFields->push(HX_CSTRING("mods"));
	outFields->push(HX_CSTRING("payloadTop"));
	outFields->push(HX_CSTRING("payloadCol"));
	outFields->push(HX_CSTRING("currentRow"));
	outFields->push(HX_CSTRING("modifier"));
	outFields->push(HX_CSTRING("headerMove"));
	outFields->push(HX_CSTRING("headerRename"));
	outFields->push(HX_CSTRING("headerPost"));
	outFields->push(HX_CSTRING("headerPre"));
	outFields->push(HX_CSTRING("header"));
	outFields->push(HX_CSTRING("csv"));
	outFields->push(HX_CSTRING("sourceView"));
	outFields->push(HX_CSTRING("view"));
	outFields->push(HX_CSTRING("patch"));
	outFields->push(HX_CSTRING("source"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("finishColumns"),
	HX_CSTRING("permuteColumns"),
	HX_CSTRING("finishRows"),
	HX_CSTRING("permuteRows"),
	HX_CSTRING("computeOrdering"),
	HX_CSTRING("processMods"),
	HX_CSTRING("sortMods"),
	HX_CSTRING("isPreamble"),
	HX_CSTRING("getRowString"),
	HX_CSTRING("getPreString"),
	HX_CSTRING("checkAct"),
	HX_CSTRING("applyAction"),
	HX_CSTRING("lookUp"),
	HX_CSTRING("applyHeader"),
	HX_CSTRING("applyMeta"),
	HX_CSTRING("getString"),
	HX_CSTRING("getDatum"),
	HX_CSTRING("applyRow"),
	HX_CSTRING("needSourceIndex"),
	HX_CSTRING("needSourceColumns"),
	HX_CSTRING("apply"),
	HX_CSTRING("reset"),
	HX_CSTRING("headerRow"),
	HX_CSTRING("haveDroppedColumns"),
	HX_CSTRING("colPermutationRev"),
	HX_CSTRING("colPermutation"),
	HX_CSTRING("rowPermutationRev"),
	HX_CSTRING("rowPermutation"),
	HX_CSTRING("actions"),
	HX_CSTRING("lastSourceRow"),
	HX_CSTRING("patchInSourceRow"),
	HX_CSTRING("patchInSourceCol"),
	HX_CSTRING("sourceInPatchCol"),
	HX_CSTRING("indexes"),
	HX_CSTRING("rcOffset"),
	HX_CSTRING("cellInfo"),
	HX_CSTRING("rowInfo"),
	HX_CSTRING("cmods"),
	HX_CSTRING("mods"),
	HX_CSTRING("payloadTop"),
	HX_CSTRING("payloadCol"),
	HX_CSTRING("currentRow"),
	HX_CSTRING("modifier"),
	HX_CSTRING("headerMove"),
	HX_CSTRING("headerRename"),
	HX_CSTRING("headerPost"),
	HX_CSTRING("headerPre"),
	HX_CSTRING("header"),
	HX_CSTRING("csv"),
	HX_CSTRING("sourceView"),
	HX_CSTRING("view"),
	HX_CSTRING("patch"),
	HX_CSTRING("source"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(HighlightPatch_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(HighlightPatch_obj::__mClass,"__mClass");
};

Class HighlightPatch_obj::__mClass;

void HighlightPatch_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.HighlightPatch"), hx::TCanCast< HighlightPatch_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void HighlightPatch_obj::__boot()
{
}

} // end namespace coopy

#include <hxcpp.h>

#ifndef INCLUDED_IMap
#include <IMap.h>
#endif
#ifndef INCLUDED_coopy_CompareFlags
#include <coopy/CompareFlags.h>
#endif
#ifndef INCLUDED_haxe_ds_StringMap
#include <haxe/ds/StringMap.h>
#endif
namespace coopy{

Void CompareFlags_obj::__construct()
{
HX_STACK_PUSH("CompareFlags::new","coopy/CompareFlags.hx",126);
{
	HX_STACK_LINE(127)
	this->ordered = true;
	HX_STACK_LINE(128)
	this->show_unchanged = false;
	HX_STACK_LINE(129)
	this->unchanged_context = (int)1;
	HX_STACK_LINE(130)
	this->always_show_order = false;
	HX_STACK_LINE(131)
	this->never_show_order = true;
	HX_STACK_LINE(132)
	this->show_unchanged_columns = false;
	HX_STACK_LINE(133)
	this->unchanged_column_context = (int)1;
	HX_STACK_LINE(134)
	this->always_show_header = true;
	HX_STACK_LINE(135)
	this->acts = null();
	HX_STACK_LINE(136)
	this->ids = null();
	HX_STACK_LINE(137)
	this->columns_to_ignore = null();
	HX_STACK_LINE(138)
	this->allow_nested_cells = false;
}
;
	return null();
}

CompareFlags_obj::~CompareFlags_obj() { }

Dynamic CompareFlags_obj::__CreateEmpty() { return  new CompareFlags_obj; }
hx::ObjectPtr< CompareFlags_obj > CompareFlags_obj::__new()
{  hx::ObjectPtr< CompareFlags_obj > result = new CompareFlags_obj();
	result->__construct();
	return result;}

Dynamic CompareFlags_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< CompareFlags_obj > result = new CompareFlags_obj();
	result->__construct();
	return result;}

Void CompareFlags_obj::ignoreColumn( ::String column){
{
		HX_STACK_PUSH("CompareFlags::ignoreColumn","coopy/CompareFlags.hx",228);
		HX_STACK_THIS(this);
		HX_STACK_ARG(column,"column");
		HX_STACK_LINE(229)
		if (((this->columns_to_ignore == null()))){
			HX_STACK_LINE(229)
			this->columns_to_ignore = Array_obj< ::String >::__new();
		}
		HX_STACK_LINE(230)
		this->columns_to_ignore->push(column);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(CompareFlags_obj,ignoreColumn,(void))

Void CompareFlags_obj::addPrimaryKey( ::String column){
{
		HX_STACK_PUSH("CompareFlags::addPrimaryKey","coopy/CompareFlags.hx",215);
		HX_STACK_THIS(this);
		HX_STACK_ARG(column,"column");
		HX_STACK_LINE(216)
		if (((this->ids == null()))){
			HX_STACK_LINE(216)
			this->ids = Array_obj< ::String >::__new();
		}
		HX_STACK_LINE(217)
		this->ids->push(column);
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(CompareFlags_obj,addPrimaryKey,(void))

::haxe::ds::StringMap CompareFlags_obj::getIgnoredColumns( ){
	HX_STACK_PUSH("CompareFlags::getIgnoredColumns","coopy/CompareFlags.hx",197);
	HX_STACK_THIS(this);
	HX_STACK_LINE(198)
	if (((this->columns_to_ignore == null()))){
		HX_STACK_LINE(198)
		return null();
	}
	HX_STACK_LINE(199)
	::haxe::ds::StringMap ignore = ::haxe::ds::StringMap_obj::__new();		HX_STACK_VAR(ignore,"ignore");
	HX_STACK_LINE(200)
	{
		HX_STACK_LINE(200)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		int _g = this->columns_to_ignore->length;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(200)
		while(((_g1 < _g))){
			HX_STACK_LINE(200)
			int i = (_g1)++;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(201)
			ignore->set(this->columns_to_ignore->__get(i),true);
		}
	}
	HX_STACK_LINE(203)
	return ignore;
}


HX_DEFINE_DYNAMIC_FUNC0(CompareFlags_obj,getIgnoredColumns,return )

bool CompareFlags_obj::allowDelete( ){
	HX_STACK_PUSH("CompareFlags::allowDelete","coopy/CompareFlags.hx",187);
	HX_STACK_THIS(this);
	HX_STACK_LINE(188)
	if (((this->acts == null()))){
		HX_STACK_LINE(188)
		return true;
	}
	HX_STACK_LINE(189)
	return this->acts->exists(HX_CSTRING("delete"));
}


HX_DEFINE_DYNAMIC_FUNC0(CompareFlags_obj,allowDelete,return )

bool CompareFlags_obj::allowInsert( ){
	HX_STACK_PUSH("CompareFlags::allowInsert","coopy/CompareFlags.hx",177);
	HX_STACK_THIS(this);
	HX_STACK_LINE(178)
	if (((this->acts == null()))){
		HX_STACK_LINE(178)
		return true;
	}
	HX_STACK_LINE(179)
	return this->acts->exists(HX_CSTRING("insert"));
}


HX_DEFINE_DYNAMIC_FUNC0(CompareFlags_obj,allowInsert,return )

bool CompareFlags_obj::allowUpdate( ){
	HX_STACK_PUSH("CompareFlags::allowUpdate","coopy/CompareFlags.hx",167);
	HX_STACK_THIS(this);
	HX_STACK_LINE(168)
	if (((this->acts == null()))){
		HX_STACK_LINE(168)
		return true;
	}
	HX_STACK_LINE(169)
	return this->acts->exists(HX_CSTRING("update"));
}


HX_DEFINE_DYNAMIC_FUNC0(CompareFlags_obj,allowUpdate,return )

bool CompareFlags_obj::filter( ::String act,bool allow){
	HX_STACK_PUSH("CompareFlags::filter","coopy/CompareFlags.hx",150);
	HX_STACK_THIS(this);
	HX_STACK_ARG(act,"act");
	HX_STACK_ARG(allow,"allow");
	HX_STACK_LINE(151)
	if (((this->acts == null()))){
		HX_STACK_LINE(152)
		this->acts = ::haxe::ds::StringMap_obj::__new();
		HX_STACK_LINE(153)
		this->acts->set(HX_CSTRING("update"),!(allow));
		HX_STACK_LINE(154)
		this->acts->set(HX_CSTRING("insert"),!(allow));
		HX_STACK_LINE(155)
		this->acts->set(HX_CSTRING("delete"),!(allow));
	}
	HX_STACK_LINE(157)
	if ((!(this->acts->exists(act)))){
		HX_STACK_LINE(157)
		return false;
	}
	HX_STACK_LINE(158)
	this->acts->set(act,allow);
	HX_STACK_LINE(159)
	return true;
}


HX_DEFINE_DYNAMIC_FUNC2(CompareFlags_obj,filter,return )


CompareFlags_obj::CompareFlags_obj()
{
}

void CompareFlags_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(CompareFlags);
	HX_MARK_MEMBER_NAME(allow_nested_cells,"allow_nested_cells");
	HX_MARK_MEMBER_NAME(columns_to_ignore,"columns_to_ignore");
	HX_MARK_MEMBER_NAME(ids,"ids");
	HX_MARK_MEMBER_NAME(acts,"acts");
	HX_MARK_MEMBER_NAME(always_show_header,"always_show_header");
	HX_MARK_MEMBER_NAME(unchanged_column_context,"unchanged_column_context");
	HX_MARK_MEMBER_NAME(show_unchanged_columns,"show_unchanged_columns");
	HX_MARK_MEMBER_NAME(never_show_order,"never_show_order");
	HX_MARK_MEMBER_NAME(always_show_order,"always_show_order");
	HX_MARK_MEMBER_NAME(unchanged_context,"unchanged_context");
	HX_MARK_MEMBER_NAME(show_unchanged,"show_unchanged");
	HX_MARK_MEMBER_NAME(ordered,"ordered");
	HX_MARK_END_CLASS();
}

void CompareFlags_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(allow_nested_cells,"allow_nested_cells");
	HX_VISIT_MEMBER_NAME(columns_to_ignore,"columns_to_ignore");
	HX_VISIT_MEMBER_NAME(ids,"ids");
	HX_VISIT_MEMBER_NAME(acts,"acts");
	HX_VISIT_MEMBER_NAME(always_show_header,"always_show_header");
	HX_VISIT_MEMBER_NAME(unchanged_column_context,"unchanged_column_context");
	HX_VISIT_MEMBER_NAME(show_unchanged_columns,"show_unchanged_columns");
	HX_VISIT_MEMBER_NAME(never_show_order,"never_show_order");
	HX_VISIT_MEMBER_NAME(always_show_order,"always_show_order");
	HX_VISIT_MEMBER_NAME(unchanged_context,"unchanged_context");
	HX_VISIT_MEMBER_NAME(show_unchanged,"show_unchanged");
	HX_VISIT_MEMBER_NAME(ordered,"ordered");
}

Dynamic CompareFlags_obj::__Field(const ::String &inName,bool inCallProp)
{
	switch(inName.length) {
	case 3:
		if (HX_FIELD_EQ(inName,"ids") ) { return ids; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"acts") ) { return acts; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"filter") ) { return filter_dyn(); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"ordered") ) { return ordered; }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"allowDelete") ) { return allowDelete_dyn(); }
		if (HX_FIELD_EQ(inName,"allowInsert") ) { return allowInsert_dyn(); }
		if (HX_FIELD_EQ(inName,"allowUpdate") ) { return allowUpdate_dyn(); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"ignoreColumn") ) { return ignoreColumn_dyn(); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"addPrimaryKey") ) { return addPrimaryKey_dyn(); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"show_unchanged") ) { return show_unchanged; }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"never_show_order") ) { return never_show_order; }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"getIgnoredColumns") ) { return getIgnoredColumns_dyn(); }
		if (HX_FIELD_EQ(inName,"columns_to_ignore") ) { return columns_to_ignore; }
		if (HX_FIELD_EQ(inName,"always_show_order") ) { return always_show_order; }
		if (HX_FIELD_EQ(inName,"unchanged_context") ) { return unchanged_context; }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"allow_nested_cells") ) { return allow_nested_cells; }
		if (HX_FIELD_EQ(inName,"always_show_header") ) { return always_show_header; }
		break;
	case 22:
		if (HX_FIELD_EQ(inName,"show_unchanged_columns") ) { return show_unchanged_columns; }
		break;
	case 24:
		if (HX_FIELD_EQ(inName,"unchanged_column_context") ) { return unchanged_column_context; }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic CompareFlags_obj::__SetField(const ::String &inName,const Dynamic &inValue,bool inCallProp)
{
	switch(inName.length) {
	case 3:
		if (HX_FIELD_EQ(inName,"ids") ) { ids=inValue.Cast< Array< ::String > >(); return inValue; }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"acts") ) { acts=inValue.Cast< ::haxe::ds::StringMap >(); return inValue; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"ordered") ) { ordered=inValue.Cast< bool >(); return inValue; }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"show_unchanged") ) { show_unchanged=inValue.Cast< bool >(); return inValue; }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"never_show_order") ) { never_show_order=inValue.Cast< bool >(); return inValue; }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"columns_to_ignore") ) { columns_to_ignore=inValue.Cast< Array< ::String > >(); return inValue; }
		if (HX_FIELD_EQ(inName,"always_show_order") ) { always_show_order=inValue.Cast< bool >(); return inValue; }
		if (HX_FIELD_EQ(inName,"unchanged_context") ) { unchanged_context=inValue.Cast< int >(); return inValue; }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"allow_nested_cells") ) { allow_nested_cells=inValue.Cast< bool >(); return inValue; }
		if (HX_FIELD_EQ(inName,"always_show_header") ) { always_show_header=inValue.Cast< bool >(); return inValue; }
		break;
	case 22:
		if (HX_FIELD_EQ(inName,"show_unchanged_columns") ) { show_unchanged_columns=inValue.Cast< bool >(); return inValue; }
		break;
	case 24:
		if (HX_FIELD_EQ(inName,"unchanged_column_context") ) { unchanged_column_context=inValue.Cast< int >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void CompareFlags_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_CSTRING("allow_nested_cells"));
	outFields->push(HX_CSTRING("columns_to_ignore"));
	outFields->push(HX_CSTRING("ids"));
	outFields->push(HX_CSTRING("acts"));
	outFields->push(HX_CSTRING("always_show_header"));
	outFields->push(HX_CSTRING("unchanged_column_context"));
	outFields->push(HX_CSTRING("show_unchanged_columns"));
	outFields->push(HX_CSTRING("never_show_order"));
	outFields->push(HX_CSTRING("always_show_order"));
	outFields->push(HX_CSTRING("unchanged_context"));
	outFields->push(HX_CSTRING("show_unchanged"));
	outFields->push(HX_CSTRING("ordered"));
	super::__GetFields(outFields);
};

static ::String sStaticFields[] = {
	String(null()) };

static ::String sMemberFields[] = {
	HX_CSTRING("ignoreColumn"),
	HX_CSTRING("addPrimaryKey"),
	HX_CSTRING("getIgnoredColumns"),
	HX_CSTRING("allowDelete"),
	HX_CSTRING("allowInsert"),
	HX_CSTRING("allowUpdate"),
	HX_CSTRING("filter"),
	HX_CSTRING("allow_nested_cells"),
	HX_CSTRING("columns_to_ignore"),
	HX_CSTRING("ids"),
	HX_CSTRING("acts"),
	HX_CSTRING("always_show_header"),
	HX_CSTRING("unchanged_column_context"),
	HX_CSTRING("show_unchanged_columns"),
	HX_CSTRING("never_show_order"),
	HX_CSTRING("always_show_order"),
	HX_CSTRING("unchanged_context"),
	HX_CSTRING("show_unchanged"),
	HX_CSTRING("ordered"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(CompareFlags_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(CompareFlags_obj::__mClass,"__mClass");
};

Class CompareFlags_obj::__mClass;

void CompareFlags_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.CompareFlags"), hx::TCanCast< CompareFlags_obj> ,sStaticFields,sMemberFields,
	&__CreateEmpty, &__Create,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void CompareFlags_obj::__boot()
{
}

} // end namespace coopy

#include <hxcpp.h>

#ifndef INCLUDED_coopy_CellBuilder
#include <coopy/CellBuilder.h>
#endif
#ifndef INCLUDED_coopy_Unit
#include <coopy/Unit.h>
#endif
#ifndef INCLUDED_coopy_View
#include <coopy/View.h>
#endif
namespace coopy{

HX_DEFINE_DYNAMIC_FUNC1(CellBuilder_obj,links,return )

HX_DEFINE_DYNAMIC_FUNC1(CellBuilder_obj,marker,return )

HX_DEFINE_DYNAMIC_FUNC3(CellBuilder_obj,conflict,return )

HX_DEFINE_DYNAMIC_FUNC2(CellBuilder_obj,update,return )

HX_DEFINE_DYNAMIC_FUNC1(CellBuilder_obj,setView,)

HX_DEFINE_DYNAMIC_FUNC1(CellBuilder_obj,setConflictSeparator,)

HX_DEFINE_DYNAMIC_FUNC1(CellBuilder_obj,setSeparator,)

HX_DEFINE_DYNAMIC_FUNC0(CellBuilder_obj,needSeparator,return )


static ::String sMemberFields[] = {
	HX_CSTRING("links"),
	HX_CSTRING("marker"),
	HX_CSTRING("conflict"),
	HX_CSTRING("update"),
	HX_CSTRING("setView"),
	HX_CSTRING("setConflictSeparator"),
	HX_CSTRING("setSeparator"),
	HX_CSTRING("needSeparator"),
	String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(CellBuilder_obj::__mClass,"__mClass");
};

static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(CellBuilder_obj::__mClass,"__mClass");
};

Class CellBuilder_obj::__mClass;

void CellBuilder_obj::__register()
{
	hx::Static(__mClass) = hx::RegisterClass(HX_CSTRING("coopy.CellBuilder"), hx::TCanCast< CellBuilder_obj> ,0,sMemberFields,
	0, 0,
	&super::__SGetClass(), 0, sMarkStatics, sVisitStatics);
}

void CellBuilder_obj::__boot()
{
}

} // end namespace coopy

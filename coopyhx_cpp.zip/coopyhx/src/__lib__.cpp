#include <hxcpp.h>

#include <stdio.h>

#ifndef INCLUDED_coopy_Coopy
#include <coopy/Coopy.h>
#endif


HX_BEGIN_LIB_MAIN

::coopy::Coopy_obj::main();
HX_END_LIB_MAIN


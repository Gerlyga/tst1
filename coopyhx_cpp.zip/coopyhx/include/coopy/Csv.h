#ifndef INCLUDED_coopy_Csv
#define INCLUDED_coopy_Csv

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(coopy,Csv)
HX_DECLARE_CLASS1(coopy,Table)
HX_DECLARE_CLASS1(coopy,View)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  Csv_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef Csv_obj OBJ_;
		Csv_obj();
		Void __construct(::String __o_delim);

	public:
		static hx::ObjectPtr< Csv_obj > __new(::String __o_delim);
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		~Csv_obj();

		HX_DO_RTTI;
		static void __boot();
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		::String __ToString() const { return HX_CSTRING("Csv"); }

		virtual ::String parseCell( ::String txt);
		Dynamic parseCell_dyn();

		virtual ::String parseCellPart( ::String txt);
		Dynamic parseCellPart_dyn();

		virtual ::coopy::Table makeTable( ::String txt);
		Dynamic makeTable_dyn();

		virtual bool parseTable( ::String txt,::coopy::Table tab);
		Dynamic parseTable_dyn();

		virtual ::String renderCell( ::coopy::View v,Dynamic d);
		Dynamic renderCell_dyn();

		virtual ::String renderTable( ::coopy::Table t);
		Dynamic renderTable_dyn();

		::String delim;
		bool has_structure;
		bool row_ended;
		int cursor;
};

} // end namespace coopy

#endif /* INCLUDED_coopy_Csv */ 

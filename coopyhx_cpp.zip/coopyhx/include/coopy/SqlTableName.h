#ifndef INCLUDED_coopy_SqlTableName
#define INCLUDED_coopy_SqlTableName

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(coopy,SqlTableName)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  SqlTableName_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef SqlTableName_obj OBJ_;
		SqlTableName_obj();
		Void __construct(::String __o_name,::String __o_prefix);

	public:
		static hx::ObjectPtr< SqlTableName_obj > __new(::String __o_name,::String __o_prefix);
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		~SqlTableName_obj();

		HX_DO_RTTI;
		static void __boot();
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		::String __ToString() const { return HX_CSTRING("SqlTableName"); }

		virtual ::String toString( );
		Dynamic toString_dyn();

		::String prefix;
		::String name;
};

} // end namespace coopy

#endif /* INCLUDED_coopy_SqlTableName */ 

#ifndef INCLUDED_coopy_CellBuilder
#define INCLUDED_coopy_CellBuilder

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(coopy,CellBuilder)
HX_DECLARE_CLASS1(coopy,Unit)
HX_DECLARE_CLASS1(coopy,View)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  CellBuilder_obj : public hx::Interface{
	public:
		typedef hx::Interface super;
		typedef CellBuilder_obj OBJ_;
		HX_DO_INTERFACE_RTTI;
		static void __boot();
virtual Dynamic links( ::coopy::Unit unit)=0;
		Dynamic links_dyn();
virtual Dynamic marker( ::String label)=0;
		Dynamic marker_dyn();
virtual Dynamic conflict( Dynamic parent,Dynamic local,Dynamic remote)=0;
		Dynamic conflict_dyn();
virtual Dynamic update( Dynamic local,Dynamic remote)=0;
		Dynamic update_dyn();
virtual Void setView( ::coopy::View view)=0;
		Dynamic setView_dyn();
virtual Void setConflictSeparator( ::String separator)=0;
		Dynamic setConflictSeparator_dyn();
virtual Void setSeparator( ::String separator)=0;
		Dynamic setSeparator_dyn();
virtual bool needSeparator( )=0;
		Dynamic needSeparator_dyn();
};

#define DELEGATE_coopy_CellBuilder \
virtual Dynamic links( ::coopy::Unit unit) { return mDelegate->links(unit);}  \
virtual Dynamic links_dyn() { return mDelegate->links_dyn();}  \
virtual Dynamic marker( ::String label) { return mDelegate->marker(label);}  \
virtual Dynamic marker_dyn() { return mDelegate->marker_dyn();}  \
virtual Dynamic conflict( Dynamic parent,Dynamic local,Dynamic remote) { return mDelegate->conflict(parent,local,remote);}  \
virtual Dynamic conflict_dyn() { return mDelegate->conflict_dyn();}  \
virtual Dynamic update( Dynamic local,Dynamic remote) { return mDelegate->update(local,remote);}  \
virtual Dynamic update_dyn() { return mDelegate->update_dyn();}  \
virtual Void setView( ::coopy::View view) { return mDelegate->setView(view);}  \
virtual Dynamic setView_dyn() { return mDelegate->setView_dyn();}  \
virtual Void setConflictSeparator( ::String separator) { return mDelegate->setConflictSeparator(separator);}  \
virtual Dynamic setConflictSeparator_dyn() { return mDelegate->setConflictSeparator_dyn();}  \
virtual Void setSeparator( ::String separator) { return mDelegate->setSeparator(separator);}  \
virtual Dynamic setSeparator_dyn() { return mDelegate->setSeparator_dyn();}  \
virtual bool needSeparator( ) { return mDelegate->needSeparator();}  \
virtual Dynamic needSeparator_dyn() { return mDelegate->needSeparator_dyn();}  \


template<typename IMPL>
class CellBuilder_delegate_ : public CellBuilder_obj
{
	protected:
		IMPL *mDelegate;
	public:
		CellBuilder_delegate_(IMPL *inDelegate) : mDelegate(inDelegate) {}
		hx::Object *__GetRealObject() { return mDelegate; }
		void __Visit(HX_VISIT_PARAMS) { HX_VISIT_OBJECT(mDelegate); }
		DELEGATE_coopy_CellBuilder
};

} // end namespace coopy

#endif /* INCLUDED_coopy_CellBuilder */ 

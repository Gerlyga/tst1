#ifndef INCLUDED_coopy_DiffRender
#define INCLUDED_coopy_DiffRender

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(coopy,CellInfo)
HX_DECLARE_CLASS1(coopy,DiffRender)
HX_DECLARE_CLASS1(coopy,Table)
HX_DECLARE_CLASS1(coopy,View)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  DiffRender_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef DiffRender_obj OBJ_;
		DiffRender_obj();
		Void __construct();

	public:
		static hx::ObjectPtr< DiffRender_obj > __new();
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		~DiffRender_obj();

		HX_DO_RTTI;
		static void __boot();
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		::String __ToString() const { return HX_CSTRING("DiffRender"); }

		virtual Void completeHtml( );
		Dynamic completeHtml_dyn();

		virtual ::String sampleCss( );
		Dynamic sampleCss_dyn();

		virtual ::coopy::DiffRender render( ::coopy::Table tab);
		Dynamic render_dyn();

		virtual ::String toString( );
		Dynamic toString_dyn();

		virtual ::String html( );
		Dynamic html_dyn();

		virtual Void endTable( );
		Dynamic endTable_dyn();

		virtual Void endRow( );
		Dynamic endRow_dyn();

		virtual Void insertCell( ::String txt,::String mode);
		Dynamic insertCell_dyn();

		virtual Void beginRow( ::String mode);
		Dynamic beginRow_dyn();

		virtual Void setSection( ::String str);
		Dynamic setSection_dyn();

		virtual Void beginTable( );
		Dynamic beginTable_dyn();

		virtual Void insert( ::String str);
		Dynamic insert_dyn();

		virtual Void usePrettyArrows( bool flag);
		Dynamic usePrettyArrows_dyn();

		::String section;
		bool pretty_arrows;
		bool open;
		::String td_close;
		::String td_open;
		Array< ::String > text_to_insert;
		static Void examineCell( int x,int y,::coopy::View view,Dynamic raw,::String vcol,::String vrow,::String vcorner,::coopy::CellInfo cell,hx::Null< int >  offset);
		static Dynamic examineCell_dyn();

		static ::String markSpaces( ::String sl,::String sr);
		static Dynamic markSpaces_dyn();

		static ::coopy::CellInfo renderCell( ::coopy::Table tab,::coopy::View view,int x,int y);
		static Dynamic renderCell_dyn();

};

} // end namespace coopy

#endif /* INCLUDED_coopy_DiffRender */ 

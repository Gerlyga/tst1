#ifndef INCLUDED_coopy_NestedCellBuilder
#define INCLUDED_coopy_NestedCellBuilder

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

#include <coopy/CellBuilder.h>
HX_DECLARE_CLASS1(coopy,CellBuilder)
HX_DECLARE_CLASS1(coopy,NestedCellBuilder)
HX_DECLARE_CLASS1(coopy,Unit)
HX_DECLARE_CLASS1(coopy,View)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  NestedCellBuilder_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef NestedCellBuilder_obj OBJ_;
		NestedCellBuilder_obj();
		Void __construct();

	public:
		static hx::ObjectPtr< NestedCellBuilder_obj > __new();
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		~NestedCellBuilder_obj();

		HX_DO_RTTI;
		static void __boot();
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		inline operator ::coopy::CellBuilder_obj *()
			{ return new ::coopy::CellBuilder_delegate_< NestedCellBuilder_obj >(this); }
		hx::Object *__ToInterface(const hx::type_info &inType);
		::String __ToString() const { return HX_CSTRING("NestedCellBuilder"); }

		virtual Dynamic links( ::coopy::Unit unit);
		Dynamic links_dyn();

		virtual Dynamic negToNull( int x);
		Dynamic negToNull_dyn();

		virtual Dynamic marker( ::String label);
		Dynamic marker_dyn();

		virtual Dynamic conflict( Dynamic parent,Dynamic local,Dynamic remote);
		Dynamic conflict_dyn();

		virtual Dynamic update( Dynamic local,Dynamic remote);
		Dynamic update_dyn();

		virtual Void setView( ::coopy::View view);
		Dynamic setView_dyn();

		virtual Void setConflictSeparator( ::String separator);
		Dynamic setConflictSeparator_dyn();

		virtual Void setSeparator( ::String separator);
		Dynamic setSeparator_dyn();

		virtual bool needSeparator( );
		Dynamic needSeparator_dyn();

		::coopy::View view;
};

} // end namespace coopy

#endif /* INCLUDED_coopy_NestedCellBuilder */ 

#ifndef INCLUDED_coopy_View
#define INCLUDED_coopy_View

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(coopy,View)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  View_obj : public hx::Interface{
	public:
		typedef hx::Interface super;
		typedef View_obj OBJ_;
		HX_DO_INTERFACE_RTTI;
		static void __boot();
virtual Dynamic hashGet( Dynamic h,::String str)=0;
		Dynamic hashGet_dyn();
virtual bool hashExists( Dynamic h,::String str)=0;
		Dynamic hashExists_dyn();
virtual bool isHash( Dynamic h)=0;
		Dynamic isHash_dyn();
virtual Void hashSet( Dynamic h,::String str,Dynamic d)=0;
		Dynamic hashSet_dyn();
virtual Dynamic makeHash( )=0;
		Dynamic makeHash_dyn();
virtual Dynamic toDatum( ::String str)=0;
		Dynamic toDatum_dyn();
virtual bool equals( Dynamic d1,Dynamic d2)=0;
		Dynamic equals_dyn();
virtual ::String toString( Dynamic d)=0;
		Dynamic toString_dyn();
};

#define DELEGATE_coopy_View \
virtual Dynamic hashGet( Dynamic h,::String str) { return mDelegate->hashGet(h,str);}  \
virtual Dynamic hashGet_dyn() { return mDelegate->hashGet_dyn();}  \
virtual bool hashExists( Dynamic h,::String str) { return mDelegate->hashExists(h,str);}  \
virtual Dynamic hashExists_dyn() { return mDelegate->hashExists_dyn();}  \
virtual bool isHash( Dynamic h) { return mDelegate->isHash(h);}  \
virtual Dynamic isHash_dyn() { return mDelegate->isHash_dyn();}  \
virtual Void hashSet( Dynamic h,::String str,Dynamic d) { return mDelegate->hashSet(h,str,d);}  \
virtual Dynamic hashSet_dyn() { return mDelegate->hashSet_dyn();}  \
virtual Dynamic makeHash( ) { return mDelegate->makeHash();}  \
virtual Dynamic makeHash_dyn() { return mDelegate->makeHash_dyn();}  \
virtual Dynamic toDatum( ::String str) { return mDelegate->toDatum(str);}  \
virtual Dynamic toDatum_dyn() { return mDelegate->toDatum_dyn();}  \
virtual bool equals( Dynamic d1,Dynamic d2) { return mDelegate->equals(d1,d2);}  \
virtual Dynamic equals_dyn() { return mDelegate->equals_dyn();}  \
virtual ::String toString( Dynamic d) { return mDelegate->toString(d);}  \
virtual Dynamic toString_dyn() { return mDelegate->toString_dyn();}  \


template<typename IMPL>
class View_delegate_ : public View_obj
{
	protected:
		IMPL *mDelegate;
	public:
		View_delegate_(IMPL *inDelegate) : mDelegate(inDelegate) {}
		hx::Object *__GetRealObject() { return mDelegate; }
		void __Visit(HX_VISIT_PARAMS) { HX_VISIT_OBJECT(mDelegate); }
		DELEGATE_coopy_View
};

} // end namespace coopy

#endif /* INCLUDED_coopy_View */ 

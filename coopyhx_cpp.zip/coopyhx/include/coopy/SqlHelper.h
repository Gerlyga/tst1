#ifndef INCLUDED_coopy_SqlHelper
#define INCLUDED_coopy_SqlHelper

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(coopy,SqlDatabase)
HX_DECLARE_CLASS1(coopy,SqlHelper)
HX_DECLARE_CLASS1(coopy,SqlTableName)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  SqlHelper_obj : public hx::Interface{
	public:
		typedef hx::Interface super;
		typedef SqlHelper_obj OBJ_;
		HX_DO_INTERFACE_RTTI;
		static void __boot();
virtual Array< int > getRowIDs( ::coopy::SqlDatabase db,::coopy::SqlTableName name)=0;
		Dynamic getRowIDs_dyn();
virtual int countRows( ::coopy::SqlDatabase db,::coopy::SqlTableName name)=0;
		Dynamic countRows_dyn();
virtual Array< ::String > getTableNames( ::coopy::SqlDatabase db)=0;
		Dynamic getTableNames_dyn();
};

#define DELEGATE_coopy_SqlHelper \
virtual Array< int > getRowIDs( ::coopy::SqlDatabase db,::coopy::SqlTableName name) { return mDelegate->getRowIDs(db,name);}  \
virtual Dynamic getRowIDs_dyn() { return mDelegate->getRowIDs_dyn();}  \
virtual int countRows( ::coopy::SqlDatabase db,::coopy::SqlTableName name) { return mDelegate->countRows(db,name);}  \
virtual Dynamic countRows_dyn() { return mDelegate->countRows_dyn();}  \
virtual Array< ::String > getTableNames( ::coopy::SqlDatabase db) { return mDelegate->getTableNames(db);}  \
virtual Dynamic getTableNames_dyn() { return mDelegate->getTableNames_dyn();}  \


template<typename IMPL>
class SqlHelper_delegate_ : public SqlHelper_obj
{
	protected:
		IMPL *mDelegate;
	public:
		SqlHelper_delegate_(IMPL *inDelegate) : mDelegate(inDelegate) {}
		hx::Object *__GetRealObject() { return mDelegate; }
		void __Visit(HX_VISIT_PARAMS) { HX_VISIT_OBJECT(mDelegate); }
		DELEGATE_coopy_SqlHelper
};

} // end namespace coopy

#endif /* INCLUDED_coopy_SqlHelper */ 

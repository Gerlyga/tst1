#ifndef INCLUDED_coopy_SqlTable
#define INCLUDED_coopy_SqlTable

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

#include <coopy/Table.h>
HX_DECLARE_CLASS0(IMap)
HX_DECLARE_CLASS1(coopy,SqlColumn)
HX_DECLARE_CLASS1(coopy,SqlDatabase)
HX_DECLARE_CLASS1(coopy,SqlHelper)
HX_DECLARE_CLASS1(coopy,SqlTable)
HX_DECLARE_CLASS1(coopy,SqlTableName)
HX_DECLARE_CLASS1(coopy,Table)
HX_DECLARE_CLASS1(coopy,View)
HX_DECLARE_CLASS2(haxe,ds,IntMap)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  SqlTable_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef SqlTable_obj OBJ_;
		SqlTable_obj();
		Void __construct(::coopy::SqlDatabase db,::coopy::SqlTableName name,::coopy::SqlHelper helper);

	public:
		static hx::ObjectPtr< SqlTable_obj > __new(::coopy::SqlDatabase db,::coopy::SqlTableName name,::coopy::SqlHelper helper);
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		~SqlTable_obj();

		HX_DO_RTTI;
		static void __boot();
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		inline operator ::coopy::Table_obj *()
			{ return new ::coopy::Table_delegate_< SqlTable_obj >(this); }
		hx::Object *__ToInterface(const hx::type_info &inType);
		::String __ToString() const { return HX_CSTRING("SqlTable"); }

		virtual ::coopy::Table clone( );
		Dynamic clone_dyn();

		virtual Dynamic getData( );
		Dynamic getData_dyn();

		virtual int get_height( );
		Dynamic get_height_dyn();

		virtual int get_width( );
		Dynamic get_width_dyn();

		virtual bool trimBlank( );
		Dynamic trimBlank_dyn();

		virtual bool insertOrDeleteColumns( Array< int > fate,int wfate);
		Dynamic insertOrDeleteColumns_dyn();

		virtual bool insertOrDeleteRows( Array< int > fate,int hfate);
		Dynamic insertOrDeleteRows_dyn();

		virtual Void clear( );
		Dynamic clear_dyn();

		virtual bool resize( int w,int h);
		Dynamic resize_dyn();

		virtual bool isResizable( );
		Dynamic isResizable_dyn();

		virtual ::coopy::View getCellView( );
		Dynamic getCellView_dyn();

		virtual Void setCell( int x,int y,Dynamic c);
		Dynamic setCell_dyn();

		virtual Void setCellCache( int x,int y,Dynamic c);
		Dynamic setCellCache_dyn();

		virtual Dynamic getCell( int x,int y);
		Dynamic getCell_dyn();

		virtual ::String getQuotedColumnName( ::String name);
		Dynamic getQuotedColumnName_dyn();

		virtual ::String getQuotedTableName( );
		Dynamic getQuotedTableName_dyn();

		virtual Array< ::String > getColumnNames( );
		Dynamic getColumnNames_dyn();

		virtual Array< ::String > getAllButPrimaryKey( );
		Dynamic getAllButPrimaryKey_dyn();

		virtual Array< ::String > getPrimaryKey( );
		Dynamic getPrimaryKey_dyn();

		virtual Void getColumns( );
		Dynamic getColumns_dyn();

		Array< int > id2rid;
		::coopy::SqlHelper helper;
		int h;
		Array< ::String > columnNames;
		::haxe::ds::IntMap cache;
		::String quotedTableName;
		::coopy::SqlTableName name;
		Array< ::Dynamic > columns;
		::coopy::SqlDatabase db;
};

} // end namespace coopy

#endif /* INCLUDED_coopy_SqlTable */ 

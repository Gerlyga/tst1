#ifndef INCLUDED_coopy_SqlCompare
#define INCLUDED_coopy_SqlCompare

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(coopy,Alignment)
HX_DECLARE_CLASS1(coopy,SqlCompare)
HX_DECLARE_CLASS1(coopy,SqlDatabase)
HX_DECLARE_CLASS1(coopy,SqlTable)
HX_DECLARE_CLASS1(coopy,Table)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  SqlCompare_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef SqlCompare_obj OBJ_;
		SqlCompare_obj();
		Void __construct(::coopy::SqlDatabase db,::coopy::SqlTable local,::coopy::SqlTable remote);

	public:
		static hx::ObjectPtr< SqlCompare_obj > __new(::coopy::SqlDatabase db,::coopy::SqlTable local,::coopy::SqlTable remote);
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		~SqlCompare_obj();

		HX_DO_RTTI;
		static void __boot();
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		::String __ToString() const { return HX_CSTRING("SqlCompare"); }

		virtual ::coopy::Alignment apply( );
		Dynamic apply_dyn();

		virtual Void linkQuery( ::String query,Array< ::String > order);
		Dynamic linkQuery_dyn();

		virtual Void link( );
		Dynamic link_dyn();

		virtual int denull( Dynamic x);
		Dynamic denull_dyn();

		virtual bool validateSchema( );
		Dynamic validateSchema_dyn();

		virtual bool equalArray( Array< ::String > a1,Array< ::String > a2);
		Dynamic equalArray_dyn();

		::coopy::Alignment align;
		int at1;
		int at0;
		::coopy::SqlTable remote;
		::coopy::SqlTable local;
		::coopy::SqlTable parent;
		::coopy::SqlDatabase db;
};

} // end namespace coopy

#endif /* INCLUDED_coopy_SqlCompare */ 

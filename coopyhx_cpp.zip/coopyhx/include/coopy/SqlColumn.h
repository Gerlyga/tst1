#ifndef INCLUDED_coopy_SqlColumn
#define INCLUDED_coopy_SqlColumn

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(coopy,SqlColumn)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  SqlColumn_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef SqlColumn_obj OBJ_;
		SqlColumn_obj();
		Void __construct();

	public:
		static hx::ObjectPtr< SqlColumn_obj > __new();
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		~SqlColumn_obj();

		HX_DO_RTTI;
		static void __boot();
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		::String __ToString() const { return HX_CSTRING("SqlColumn"); }

		virtual ::String toString( );
		Dynamic toString_dyn();

		virtual bool isPrimaryKey( );
		Dynamic isPrimaryKey_dyn();

		virtual ::String getName( );
		Dynamic getName_dyn();

		bool primary;
		::String name;
		static ::coopy::SqlColumn byNameAndPrimaryKey( ::String name,bool primary);
		static Dynamic byNameAndPrimaryKey_dyn();

};

} // end namespace coopy

#endif /* INCLUDED_coopy_SqlColumn */ 

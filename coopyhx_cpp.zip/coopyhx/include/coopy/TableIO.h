#ifndef INCLUDED_coopy_TableIO
#define INCLUDED_coopy_TableIO

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(coopy,SqlDatabase)
HX_DECLARE_CLASS1(coopy,TableIO)
namespace coopy{


class HXCPP_CLASS_ATTRIBUTES  TableIO_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef TableIO_obj OBJ_;
		TableIO_obj();
		Void __construct();

	public:
		static hx::ObjectPtr< TableIO_obj > __new();
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		~TableIO_obj();

		HX_DO_RTTI;
		static void __boot();
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		::String __ToString() const { return HX_CSTRING("TableIO"); }

		virtual ::coopy::SqlDatabase openSqliteDatabase( ::String path);
		Dynamic openSqliteDatabase_dyn();

		virtual bool exists( ::String path);
		Dynamic exists_dyn();

		virtual bool async( );
		Dynamic async_dyn();

		virtual int command( ::String cmd,Array< ::String > args);
		Dynamic command_dyn();

		virtual Void writeStderr( ::String txt);
		Dynamic writeStderr_dyn();

		virtual Void writeStdout( ::String txt);
		Dynamic writeStdout_dyn();

		virtual Array< ::String > args( );
		Dynamic args_dyn();

		virtual bool saveContent( ::String name,::String txt);
		Dynamic saveContent_dyn();

		virtual ::String getContent( ::String name);
		Dynamic getContent_dyn();

};

} // end namespace coopy

#endif /* INCLUDED_coopy_TableIO */ 

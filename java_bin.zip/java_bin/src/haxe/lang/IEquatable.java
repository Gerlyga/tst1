package haxe.lang;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  interface IEquatable extends haxe.lang.IHxObject
{
	   boolean equals(java.lang.Object to);
	
}



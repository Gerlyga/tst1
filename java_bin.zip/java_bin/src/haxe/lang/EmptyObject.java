package haxe.lang;
public enum EmptyObject
{
	EMPTY
}



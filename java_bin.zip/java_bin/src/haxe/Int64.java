package haxe;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Int64
{
	public    Int64()
	{
		{
		}
		
	}
	
	
}



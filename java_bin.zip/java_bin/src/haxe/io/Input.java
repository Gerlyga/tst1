package haxe.io;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Input extends haxe.lang.HxObject
{
	public    Input(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Input()
	{
		haxe.io.Input.__hx_ctor_haxe_io_Input(this);
	}
	
	
	public static   void __hx_ctor_haxe_io_Input(haxe.io.Input __temp_me59)
	{
		{
		}
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new haxe.io.Input(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new haxe.io.Input();
	}
	
	
	public   int readByte()
	{
		throw haxe.lang.HaxeException.wrap("Not implemented");
	}
	
	
	public   int readBytes(haxe.io.Bytes s, int pos, int len)
	{
		int k = len;
		byte[] b = s.b;
		if (( ( ( pos < 0 ) || ( len < 0 ) ) || ( ( pos + len ) > s.length ) )) 
		{
			throw haxe.lang.HaxeException.wrap(haxe.io.Error.OutsideBounds);
		}
		
		while (( k > 0 ))
		{
			b[pos] = ((byte) (this.readByte()) );
			pos++;
			k--;
		}
		
		return len;
	}
	
	
	public   haxe.io.Bytes readAll(java.lang.Object bufsize)
	{
		if (( bufsize == null )) 
		{
			bufsize = 16384;
		}
		
		haxe.io.Bytes buf = haxe.io.Bytes.alloc(((int) (haxe.lang.Runtime.toInt(bufsize)) ));
		haxe.io.BytesBuffer total = new haxe.io.BytesBuffer();
		try 
		{
			while (true)
			{
				int len = this.readBytes(buf, 0, ((int) (haxe.lang.Runtime.toInt(bufsize)) ));
				if (( len == 0 )) 
				{
					throw haxe.lang.HaxeException.wrap(haxe.io.Error.Blocked);
				}
				
				{
					if (( ( len < 0 ) || ( len > buf.length ) )) 
					{
						throw haxe.lang.HaxeException.wrap(haxe.io.Error.OutsideBounds);
					}
					
					total.b.write(((byte[]) (buf.b) ), ((int) (0) ), ((int) (len) ));
				}
				
			}
			
		}
		catch (java.lang.Throwable __temp_catchallException364)
		{
			java.lang.Object __temp_catchall365 = __temp_catchallException364;
			if (( __temp_catchall365 instanceof haxe.lang.HaxeException )) 
			{
				__temp_catchall365 = ((haxe.lang.HaxeException) (__temp_catchallException364) ).obj;
			}
			
			if (( __temp_catchall365 instanceof haxe.io.Eof )) 
			{
				haxe.io.Eof e = ((haxe.io.Eof) (__temp_catchall365) );
				{
					{
					}
					
				}
				
			}
			 else 
			{
				throw haxe.lang.HaxeException.wrap(__temp_catchallException364);
			}
			
		}
		
		
		return total.getBytes();
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef366 = true;
			switch (field.hashCode())
			{
				case 1080375339:
				{
					if (field.equals("readAll")) 
					{
						__temp_executeDef366 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("readAll"))) );
					}
					
					break;
				}
				
				
				case -868060226:
				{
					if (field.equals("readByte")) 
					{
						__temp_executeDef366 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("readByte"))) );
					}
					
					break;
				}
				
				
				case -1140063115:
				{
					if (field.equals("readBytes")) 
					{
						__temp_executeDef366 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("readBytes"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef366) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef367 = true;
			switch (field.hashCode())
			{
				case 1080375339:
				{
					if (field.equals("readAll")) 
					{
						__temp_executeDef367 = false;
						return this.readAll(dynargs.__get(0));
					}
					
					break;
				}
				
				
				case -868060226:
				{
					if (field.equals("readByte")) 
					{
						__temp_executeDef367 = false;
						return this.readByte();
					}
					
					break;
				}
				
				
				case -1140063115:
				{
					if (field.equals("readBytes")) 
					{
						__temp_executeDef367 = false;
						return this.readBytes(((haxe.io.Bytes) (dynargs.__get(0)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(2))) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef367) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
}



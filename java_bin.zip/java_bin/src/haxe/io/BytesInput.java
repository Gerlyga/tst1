package haxe.io;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class BytesInput extends haxe.io.Input
{
	public    BytesInput(haxe.lang.EmptyObject empty)
	{
		super(haxe.lang.EmptyObject.EMPTY);
	}
	
	
	public    BytesInput(haxe.io.Bytes b, java.lang.Object pos, java.lang.Object len)
	{
		haxe.io.BytesInput.__hx_ctor_haxe_io_BytesInput(this, b, pos, len);
	}
	
	
	public static   void __hx_ctor_haxe_io_BytesInput(haxe.io.BytesInput __temp_me60, haxe.io.Bytes b, java.lang.Object pos, java.lang.Object len)
	{
		if (( pos == null )) 
		{
			pos = 0;
		}
		
		if (( len == null )) 
		{
			len = ( ((int) (b.length) ) - ((int) (haxe.lang.Runtime.toInt(pos)) ) );
		}
		
		if (( ( ( haxe.lang.Runtime.compare(pos, 0) < 0 ) || ( haxe.lang.Runtime.compare(len, 0) < 0 ) ) || ( ( ((int) (haxe.lang.Runtime.toInt(pos)) ) + ((int) (haxe.lang.Runtime.toInt(len)) ) ) > b.length ) )) 
		{
			throw haxe.lang.HaxeException.wrap(haxe.io.Error.OutsideBounds);
		}
		
		__temp_me60.b = b.b;
		__temp_me60.pos = ((int) (haxe.lang.Runtime.toInt(pos)) );
		__temp_me60.len = ((int) (haxe.lang.Runtime.toInt(len)) );
		__temp_me60.totlen = ((int) (haxe.lang.Runtime.toInt(len)) );
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new haxe.io.BytesInput(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new haxe.io.BytesInput(((haxe.io.Bytes) (arr.__get(0)) ), ((java.lang.Object) (arr.__get(1)) ), ((java.lang.Object) (arr.__get(2)) ));
	}
	
	
	public  byte[] b;
	
	public  int pos;
	
	public  int len;
	
	public  int totlen;
	
	@Override public   int readByte()
	{
		if (( this.len == 0 )) 
		{
			throw haxe.lang.HaxeException.wrap(new haxe.io.Eof());
		}
		
		this.len--;
		return ( this.b[this.pos++] & 255 );
	}
	
	
	@Override public   int readBytes(haxe.io.Bytes buf, int pos, int len)
	{
		if (( ( ( pos < 0 ) || ( len < 0 ) ) || ( ( pos + len ) > buf.length ) )) 
		{
			throw haxe.lang.HaxeException.wrap(haxe.io.Error.OutsideBounds);
		}
		
		int avail = this.len;
		if (( len > avail )) 
		{
			len = avail;
		}
		
		if (( len == 0 )) 
		{
			throw haxe.lang.HaxeException.wrap(new haxe.io.Eof());
		}
		
		java.lang.System.arraycopy(((java.lang.Object) (this.b) ), ((int) (this.pos) ), ((java.lang.Object) (buf.b) ), ((int) (pos) ), ((int) (len) ));
		this.pos += len;
		this.len -= len;
		return len;
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef368 = true;
			switch (field.hashCode())
			{
				case -867912164:
				{
					if (field.equals("totlen")) 
					{
						__temp_executeDef368 = false;
						this.totlen = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 111188:
				{
					if (field.equals("pos")) 
					{
						__temp_executeDef368 = false;
						this.pos = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 107029:
				{
					if (field.equals("len")) 
					{
						__temp_executeDef368 = false;
						this.len = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef368) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef369 = true;
			switch (field.hashCode())
			{
				case -867912164:
				{
					if (field.equals("totlen")) 
					{
						__temp_executeDef369 = false;
						this.totlen = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 98:
				{
					if (field.equals("b")) 
					{
						__temp_executeDef369 = false;
						this.b = ((byte[]) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 107029:
				{
					if (field.equals("len")) 
					{
						__temp_executeDef369 = false;
						this.len = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 111188:
				{
					if (field.equals("pos")) 
					{
						__temp_executeDef369 = false;
						this.pos = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef369) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef370 = true;
			switch (field.hashCode())
			{
				case -1140063115:
				{
					if (field.equals("readBytes")) 
					{
						__temp_executeDef370 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("readBytes"))) );
					}
					
					break;
				}
				
				
				case 98:
				{
					if (field.equals("b")) 
					{
						__temp_executeDef370 = false;
						return this.b;
					}
					
					break;
				}
				
				
				case -868060226:
				{
					if (field.equals("readByte")) 
					{
						__temp_executeDef370 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("readByte"))) );
					}
					
					break;
				}
				
				
				case 111188:
				{
					if (field.equals("pos")) 
					{
						__temp_executeDef370 = false;
						return this.pos;
					}
					
					break;
				}
				
				
				case -867912164:
				{
					if (field.equals("totlen")) 
					{
						__temp_executeDef370 = false;
						return this.totlen;
					}
					
					break;
				}
				
				
				case 107029:
				{
					if (field.equals("len")) 
					{
						__temp_executeDef370 = false;
						return this.len;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef370) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef371 = true;
			switch (field.hashCode())
			{
				case -867912164:
				{
					if (field.equals("totlen")) 
					{
						__temp_executeDef371 = false;
						return ((double) (this.totlen) );
					}
					
					break;
				}
				
				
				case 111188:
				{
					if (field.equals("pos")) 
					{
						__temp_executeDef371 = false;
						return ((double) (this.pos) );
					}
					
					break;
				}
				
				
				case 107029:
				{
					if (field.equals("len")) 
					{
						__temp_executeDef371 = false;
						return ((double) (this.len) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef371) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("totlen");
		baseArr.push("len");
		baseArr.push("pos");
		baseArr.push("b");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



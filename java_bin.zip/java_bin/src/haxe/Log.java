package haxe;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Log extends haxe.lang.HxObject
{
	static 
	{
		haxe.Log.trace = ( (( haxe.Log_new_45__Fun.__hx_current != null )) ? (haxe.Log_new_45__Fun.__hx_current) : (haxe.Log_new_45__Fun.__hx_current = ((haxe.Log_new_45__Fun) (new haxe.Log_new_45__Fun()) )) );
	}
	public    Log(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Log()
	{
		haxe.Log.__hx_ctor_haxe_Log(this);
	}
	
	
	public static   void __hx_ctor_haxe_Log(haxe.Log __temp_me52)
	{
		{
		}
		
	}
	
	
	public static  haxe.lang.Function trace;
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new haxe.Log(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new haxe.Log();
	}
	
	
}



package haxe.root;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  interface IMap<K, V> extends haxe.lang.IHxObject
{
	   V get(K k);
	
}



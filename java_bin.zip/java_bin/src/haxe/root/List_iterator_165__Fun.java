package haxe.root;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class List_iterator_165__Fun extends haxe.lang.Function
{
	public    List_iterator_165__Fun(haxe.root.Array<haxe.root.Array> h)
	{
		super(0, 0);
		this.h = h;
	}
	
	
	@Override public   java.lang.Object __hx_invoke0_o()
	{
		return ( this.h.__get(0) != null );
	}
	
	
	public  haxe.root.Array<haxe.root.Array> h;
	
}



package sys.io;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class File extends haxe.lang.HxObject
{
	public    File(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    File()
	{
		sys.io.File.__hx_ctor_sys_io_File(this);
	}
	
	
	public static   void __hx_ctor_sys_io_File(sys.io.File __temp_me76)
	{
		{
		}
		
	}
	
	
	public static   java.lang.String getContent(java.lang.String path)
	{
		sys.io.FileInput f = sys.io.File.read(path, false);
		java.lang.String ret = f.readAll(null).toString();
		f.close();
		return ret;
	}
	
	
	public static   void saveContent(java.lang.String path, java.lang.String content)
	{
		sys.io.FileOutput f = sys.io.File.write(path, false);
		f.writeString(content);
		f.close();
	}
	
	
	public static   sys.io.FileInput read(java.lang.String path, java.lang.Object binary)
	{
		boolean __temp_binary74 = ( (( binary == null )) ? (haxe.lang.Runtime.toBool(true)) : (haxe.lang.Runtime.toBool(binary)) );
		try 
		{
			return new sys.io.FileInput(((java.io.RandomAccessFile) (new java.io.RandomAccessFile(((java.io.File) (new java.io.File(haxe.lang.Runtime.toString(path))) ), haxe.lang.Runtime.toString("r"))) ));
		}
		catch (java.lang.Throwable __temp_catchallException393)
		{
			java.lang.Object __temp_catchall394 = __temp_catchallException393;
			if (( __temp_catchall394 instanceof haxe.lang.HaxeException )) 
			{
				__temp_catchall394 = ((haxe.lang.HaxeException) (__temp_catchallException393) ).obj;
			}
			
			{
				java.lang.Object e = __temp_catchall394;
				throw haxe.lang.HaxeException.wrap(e);
			}
			
		}
		
		
	}
	
	
	public static   sys.io.FileOutput write(java.lang.String path, java.lang.Object binary)
	{
		boolean __temp_binary75 = ( (( binary == null )) ? (haxe.lang.Runtime.toBool(true)) : (haxe.lang.Runtime.toBool(binary)) );
		java.io.File f = new java.io.File(haxe.lang.Runtime.toString(path));
		if (f.exists()) 
		{
			f.delete();
		}
		
		try 
		{
			return new sys.io.FileOutput(((java.io.RandomAccessFile) (new java.io.RandomAccessFile(((java.io.File) (f) ), haxe.lang.Runtime.toString("rw"))) ));
		}
		catch (java.lang.Throwable __temp_catchallException395)
		{
			java.lang.Object __temp_catchall396 = __temp_catchallException395;
			if (( __temp_catchall396 instanceof haxe.lang.HaxeException )) 
			{
				__temp_catchall396 = ((haxe.lang.HaxeException) (__temp_catchallException395) ).obj;
			}
			
			{
				java.lang.Object e = __temp_catchall396;
				throw haxe.lang.HaxeException.wrap(e);
			}
			
		}
		
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new sys.io.File(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new sys.io.File();
	}
	
	
}



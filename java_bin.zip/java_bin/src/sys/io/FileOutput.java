package sys.io;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class FileOutput extends haxe.io.Output
{
	public    FileOutput(haxe.lang.EmptyObject empty)
	{
		super(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public    FileOutput(java.io.RandomAccessFile f)
	{
		sys.io.FileOutput.__hx_ctor_sys_io_FileOutput(this, f);
	}
	
	
	public static   void __hx_ctor_sys_io_FileOutput(sys.io.FileOutput __temp_me78, java.io.RandomAccessFile f)
	{
		__temp_me78.f = f;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new sys.io.FileOutput(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new sys.io.FileOutput(((java.io.RandomAccessFile) (arr.__get(0)) ));
	}
	
	
	public  java.io.RandomAccessFile f;
	
	public   void close()
	{
		try 
		{
			this.f.close();
		}
		catch (java.lang.Throwable __temp_catchallException403)
		{
			java.lang.Object __temp_catchall404 = __temp_catchallException403;
			if (( __temp_catchall404 instanceof haxe.lang.HaxeException )) 
			{
				__temp_catchall404 = ((haxe.lang.HaxeException) (__temp_catchallException403) ).obj;
			}
			
			{
				java.lang.Object e = __temp_catchall404;
				throw haxe.lang.HaxeException.wrap(e);
			}
			
		}
		
		
	}
	
	
	@Override public   void writeByte(int c)
	{
		try 
		{
			this.f.write(((int) (c) ));
		}
		catch (java.io.IOException e)
		{
			throw haxe.lang.HaxeException.wrap(haxe.io.Error.Custom(e));
		}
		
		
	}
	
	
	@Override public   int writeBytes(haxe.io.Bytes s, int pos, int len)
	{
		try 
		{
			this.f.write(((byte[]) (s.b) ), ((int) (pos) ), ((int) (len) ));
			return len;
		}
		catch (java.io.IOException e)
		{
			throw haxe.lang.HaxeException.wrap(haxe.io.Error.Custom(e));
		}
		
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef405 = true;
			switch (field.hashCode())
			{
				case 102:
				{
					if (field.equals("f")) 
					{
						__temp_executeDef405 = false;
						this.f = ((java.io.RandomAccessFile) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef405) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef406 = true;
			switch (field.hashCode())
			{
				case -662729780:
				{
					if (field.equals("writeBytes")) 
					{
						__temp_executeDef406 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("writeBytes"))) );
					}
					
					break;
				}
				
				
				case 102:
				{
					if (field.equals("f")) 
					{
						__temp_executeDef406 = false;
						return this.f;
					}
					
					break;
				}
				
				
				case -1406851705:
				{
					if (field.equals("writeByte")) 
					{
						__temp_executeDef406 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("writeByte"))) );
					}
					
					break;
				}
				
				
				case 94756344:
				{
					if (field.equals("close")) 
					{
						__temp_executeDef406 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("close"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef406) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			int __temp_hash408 = field.hashCode();
			boolean __temp_executeDef407 = true;
			switch (__temp_hash408)
			{
				case -662729780:case -1406851705:
				{
					if (( (( ( __temp_hash408 == -662729780 ) && field.equals("writeBytes") )) || field.equals("writeByte") )) 
					{
						__temp_executeDef407 = false;
						return haxe.lang.Runtime.slowCallField(this, field, dynargs);
					}
					
					break;
				}
				
				
				case 94756344:
				{
					if (field.equals("close")) 
					{
						__temp_executeDef407 = false;
						this.close();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef407) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("f");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



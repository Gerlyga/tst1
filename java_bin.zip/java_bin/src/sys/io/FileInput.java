package sys.io;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class FileInput extends haxe.io.Input
{
	public    FileInput(haxe.lang.EmptyObject empty)
	{
		super(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public    FileInput(java.io.RandomAccessFile f)
	{
		sys.io.FileInput.__hx_ctor_sys_io_FileInput(this, f);
	}
	
	
	public static   void __hx_ctor_sys_io_FileInput(sys.io.FileInput __temp_me77, java.io.RandomAccessFile f)
	{
		__temp_me77.f = f;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new sys.io.FileInput(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new sys.io.FileInput(((java.io.RandomAccessFile) (arr.__get(0)) ));
	}
	
	
	public  java.io.RandomAccessFile f;
	
	public   void close()
	{
		try 
		{
			this.f.close();
		}
		catch (java.lang.Throwable __temp_catchallException397)
		{
			java.lang.Object __temp_catchall398 = __temp_catchallException397;
			if (( __temp_catchall398 instanceof haxe.lang.HaxeException )) 
			{
				__temp_catchall398 = ((haxe.lang.HaxeException) (__temp_catchallException397) ).obj;
			}
			
			{
				java.lang.Object e = __temp_catchall398;
				throw haxe.lang.HaxeException.wrap(e);
			}
			
		}
		
		
	}
	
	
	@Override public   int readByte()
	{
		try 
		{
			return this.f.readUnsignedByte();
		}
		catch (java.io.EOFException e)
		{
			throw haxe.lang.HaxeException.wrap(new haxe.io.Eof());
		}
		
		catch (java.io.IOException e1)
		{
			throw haxe.lang.HaxeException.wrap(haxe.io.Error.Custom(e1));
		}
		
		
	}
	
	
	@Override public   int readBytes(haxe.io.Bytes s, int pos, int len)
	{
		int ret = 0;
		try 
		{
			ret = this.f.read(((byte[]) (s.b) ), ((int) (pos) ), ((int) (len) ));
		}
		catch (java.io.EOFException e)
		{
			throw haxe.lang.HaxeException.wrap(new haxe.io.Eof());
		}
		
		catch (java.io.IOException e1)
		{
			throw haxe.lang.HaxeException.wrap(haxe.io.Error.Custom(e1));
		}
		
		
		if (( ret == -1 )) 
		{
			throw haxe.lang.HaxeException.wrap(new haxe.io.Eof());
		}
		
		return ret;
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef399 = true;
			switch (field.hashCode())
			{
				case 102:
				{
					if (field.equals("f")) 
					{
						__temp_executeDef399 = false;
						this.f = ((java.io.RandomAccessFile) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef399) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef400 = true;
			switch (field.hashCode())
			{
				case -1140063115:
				{
					if (field.equals("readBytes")) 
					{
						__temp_executeDef400 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("readBytes"))) );
					}
					
					break;
				}
				
				
				case 102:
				{
					if (field.equals("f")) 
					{
						__temp_executeDef400 = false;
						return this.f;
					}
					
					break;
				}
				
				
				case -868060226:
				{
					if (field.equals("readByte")) 
					{
						__temp_executeDef400 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("readByte"))) );
					}
					
					break;
				}
				
				
				case 94756344:
				{
					if (field.equals("close")) 
					{
						__temp_executeDef400 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("close"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef400) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			int __temp_hash402 = field.hashCode();
			boolean __temp_executeDef401 = true;
			switch (__temp_hash402)
			{
				case -1140063115:case -868060226:
				{
					if (( (( ( __temp_hash402 == -1140063115 ) && field.equals("readBytes") )) || field.equals("readByte") )) 
					{
						__temp_executeDef401 = false;
						return haxe.lang.Runtime.slowCallField(this, field, dynargs);
					}
					
					break;
				}
				
				
				case 94756344:
				{
					if (field.equals("close")) 
					{
						__temp_executeDef401 = false;
						this.close();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef401) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("f");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



package sys;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class FileSystem extends haxe.lang.HxObject
{
	public    FileSystem(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    FileSystem()
	{
		sys.FileSystem.__hx_ctor_sys_FileSystem(this);
	}
	
	
	public static   void __hx_ctor_sys_FileSystem(sys.FileSystem __temp_me73)
	{
		{
		}
		
	}
	
	
	public static   boolean exists(java.lang.String path)
	{
		return new java.io.File(haxe.lang.Runtime.toString(path)).exists();
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new sys.FileSystem(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new sys.FileSystem();
	}
	
	
}



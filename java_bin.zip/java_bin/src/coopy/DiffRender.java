package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class DiffRender extends haxe.lang.HxObject
{
	public    DiffRender(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    DiffRender()
	{
		coopy.DiffRender.__hx_ctor_coopy_DiffRender(this);
	}
	
	
	public static   void __hx_ctor_coopy_DiffRender(coopy.DiffRender __temp_me20)
	{
		__temp_me20.text_to_insert = new haxe.root.Array<java.lang.String>();
		__temp_me20.open = false;
		__temp_me20.pretty_arrows = true;
	}
	
	
	public static   void examineCell(int x, int y, coopy.View view, java.lang.Object raw, java.lang.String vcol, java.lang.String vrow, java.lang.String vcorner, coopy.CellInfo cell, java.lang.Object offset)
	{
		int __temp_offset19 = ( (( offset == null )) ? (((int) (0) )) : (((int) (haxe.lang.Runtime.toInt(offset)) )) );
		boolean nested = view.isHash(raw);
		java.lang.String value = null;
		if ( ! (nested) ) 
		{
			value = view.toString(raw);
		}
		
		cell.category = "";
		cell.category_given_tr = "";
		cell.separator = "";
		cell.pretty_separator = "";
		cell.conflicted = false;
		cell.updated = false;
		cell.pvalue = cell.lvalue = cell.rvalue = null;
		cell.value = value;
		if (( cell.value == null )) 
		{
			cell.value = "";
		}
		
		cell.pretty_value = cell.value;
		if (( vrow == null )) 
		{
			vrow = "";
		}
		
		if (( vcol == null )) 
		{
			vcol = "";
		}
		
		boolean removed_column = false;
		if (haxe.lang.Runtime.valEq(vrow, ":")) 
		{
			cell.category = "move";
		}
		
		if (( ( haxe.lang.Runtime.valEq(vrow, "") && ( __temp_offset19 == 1 ) ) && ( y == 0 ) )) 
		{
			cell.category = "index";
		}
		
		if (( haxe.lang.StringExt.indexOf(vcol, "+++", null) >= 0 )) 
		{
			cell.category_given_tr = cell.category = "add";
		}
		 else 
		{
			if (( haxe.lang.StringExt.indexOf(vcol, "---", null) >= 0 )) 
			{
				cell.category_given_tr = cell.category = "remove";
				removed_column = true;
			}
			
		}
		
		if (haxe.lang.Runtime.valEq(vrow, "!")) 
		{
			cell.category = "spec";
		}
		 else 
		{
			if (haxe.lang.Runtime.valEq(vrow, "@@")) 
			{
				cell.category = "header";
			}
			 else 
			{
				if (haxe.lang.Runtime.valEq(vrow, "...")) 
				{
					cell.category = "gap";
				}
				 else 
				{
					if (haxe.lang.Runtime.valEq(vrow, "+++")) 
					{
						if ( ! (removed_column) ) 
						{
							cell.category = "add";
						}
						
					}
					 else 
					{
						if (haxe.lang.Runtime.valEq(vrow, "---")) 
						{
							cell.category = "remove";
						}
						 else 
						{
							if (( haxe.lang.StringExt.indexOf(vrow, "->", null) >= 0 )) 
							{
								if ( ! (removed_column) ) 
								{
									haxe.root.Array<java.lang.String> tokens = haxe.lang.StringExt.split(vrow, "!");
									java.lang.String full = vrow;
									java.lang.String part = tokens.__get(1);
									if (( part == null )) 
									{
										part = full;
									}
									
									if (( nested || ( haxe.lang.StringExt.indexOf(cell.value, part, null) >= 0 ) )) 
									{
										java.lang.String cat = "modify";
										java.lang.String div = part;
										if ( ! (haxe.lang.Runtime.valEq(part, full)) ) 
										{
											if (nested) 
											{
												cell.conflicted = view.hashExists(raw, "theirs");
											}
											 else 
											{
												cell.conflicted = ( haxe.lang.StringExt.indexOf(cell.value, full, null) >= 0 );
											}
											
											if (cell.conflicted) 
											{
												div = full;
												cat = "conflict";
											}
											
										}
										
										cell.updated = true;
										cell.separator = div;
										cell.pretty_separator = div;
										if (nested) 
										{
											if (cell.conflicted) 
											{
												tokens = new haxe.root.Array<java.lang.String>(new java.lang.String[]{haxe.lang.Runtime.toString(view.hashGet(raw, "before")), haxe.lang.Runtime.toString(view.hashGet(raw, "ours")), haxe.lang.Runtime.toString(view.hashGet(raw, "theirs"))});
											}
											 else 
											{
												tokens = new haxe.root.Array<java.lang.String>(new java.lang.String[]{haxe.lang.Runtime.toString(view.hashGet(raw, "before")), haxe.lang.Runtime.toString(view.hashGet(raw, "after"))});
											}
											
										}
										 else 
										{
											if (haxe.lang.Runtime.valEq(cell.pretty_value, div)) 
											{
												tokens = new haxe.root.Array<java.lang.String>(new java.lang.String[]{"", ""});
											}
											 else 
											{
												tokens = haxe.lang.StringExt.split(cell.pretty_value, div);
											}
											
										}
										
										haxe.root.Array<java.lang.String> pretty_tokens = tokens;
										if (( tokens.length >= 2 )) 
										{
											pretty_tokens.__set(0, coopy.DiffRender.markSpaces(tokens.__get(0), tokens.__get(1)));
											pretty_tokens.__set(1, coopy.DiffRender.markSpaces(tokens.__get(1), tokens.__get(0)));
										}
										
										if (( tokens.length >= 3 )) 
										{
											java.lang.String ref = pretty_tokens.__get(0);
											pretty_tokens.__set(0, coopy.DiffRender.markSpaces(ref, tokens.__get(2)));
											pretty_tokens.__set(2, coopy.DiffRender.markSpaces(tokens.__get(2), ref));
										}
										
										cell.pretty_separator = Character.toString((char) 8594);
										cell.pretty_value = pretty_tokens.join(cell.pretty_separator);
										cell.category_given_tr = cell.category = cat;
										int offset1 = 0;
										if (cell.conflicted) 
										{
											offset1 = 1;
										}
										 else 
										{
											offset1 = 0;
										}
										
										cell.lvalue = tokens.__get(offset1);
										cell.rvalue = tokens.__get(( offset1 + 1 ));
										if (cell.conflicted) 
										{
											cell.pvalue = tokens.__get(0);
										}
										
									}
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		if (( ( x == 0 ) && ( __temp_offset19 > 0 ) )) 
		{
			cell.category_given_tr = cell.category = "index";
		}
		
	}
	
	
	public static   java.lang.String markSpaces(java.lang.String sl, java.lang.String sr)
	{
		if (haxe.lang.Runtime.valEq(sl, sr)) 
		{
			return sl;
		}
		
		if (( ( sl == null ) || ( sr == null ) )) 
		{
			return sl;
		}
		
		java.lang.String slc = haxe.root.StringTools.replace(sl, " ", "");
		java.lang.String src = haxe.root.StringTools.replace(sr, " ", "");
		if ( ! (haxe.lang.Runtime.valEq(slc, src)) ) 
		{
			return sl;
		}
		
		java.lang.String slo = new java.lang.String(haxe.lang.Runtime.toString(""));
		int il = 0;
		int ir = 0;
		while (( il < sl.length() ))
		{
			java.lang.String cl = haxe.lang.StringExt.charAt(sl, il);
			java.lang.String cr = "";
			if (( ir < sr.length() )) 
			{
				cr = haxe.lang.StringExt.charAt(sr, ir);
			}
			
			if (haxe.lang.Runtime.valEq(cl, cr)) 
			{
				slo += cl;
				il++;
				ir++;
			}
			 else 
			{
				if (haxe.lang.Runtime.valEq(cr, " ")) 
				{
					ir++;
				}
				 else 
				{
					slo += Character.toString((char) 9251);
					il++;
				}
				
			}
			
		}
		
		return slo;
	}
	
	
	public static   coopy.CellInfo renderCell(coopy.Table tab, coopy.View view, int x, int y)
	{
		coopy.CellInfo cell = new coopy.CellInfo();
		java.lang.String corner = view.toString(tab.getCell(0, 0));
		int off = 0;
		if (haxe.lang.Runtime.valEq(corner, "@:@")) 
		{
			off = 1;
		}
		 else 
		{
			off = 0;
		}
		
		coopy.DiffRender.examineCell(x, y, view, tab.getCell(x, y), view.toString(tab.getCell(x, off)), view.toString(tab.getCell(off, y)), corner, cell, off);
		return cell;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.DiffRender(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.DiffRender();
	}
	
	
	public  haxe.root.Array<java.lang.String> text_to_insert;
	
	public  java.lang.String td_open;
	
	public  java.lang.String td_close;
	
	public  boolean open;
	
	public  boolean pretty_arrows;
	
	public  java.lang.String section;
	
	public   void usePrettyArrows(boolean flag)
	{
		this.pretty_arrows = flag;
	}
	
	
	public   void insert(java.lang.String str)
	{
		this.text_to_insert.push(str);
	}
	
	
	public   void beginTable()
	{
		this.insert("<table>\n");
		this.section = null;
	}
	
	
	public   void setSection(java.lang.String str)
	{
		if (haxe.lang.Runtime.valEq(str, this.section)) 
		{
			return ;
		}
		
		if (( this.section != null )) 
		{
			this.insert("</t");
			this.insert(this.section);
			this.insert(">\n");
		}
		
		this.section = str;
		if (( this.section != null )) 
		{
			this.insert("<t");
			this.insert(this.section);
			this.insert(">\n");
		}
		
	}
	
	
	public   void beginRow(java.lang.String mode)
	{
		this.td_open = "<td";
		this.td_close = "</td>";
		java.lang.String row_class = "";
		if (haxe.lang.Runtime.valEq(mode, "header")) 
		{
			this.td_open = "<th";
			this.td_close = "</th>";
		}
		
		row_class = mode;
		java.lang.String tr = "<tr>";
		if ( ! (haxe.lang.Runtime.valEq(row_class, "")) ) 
		{
			tr = ( ( "<tr class=\"" + row_class ) + "\">" );
		}
		
		this.insert(tr);
	}
	
	
	public   void insertCell(java.lang.String txt, java.lang.String mode)
	{
		java.lang.String cell_decorate = "";
		if ( ! (haxe.lang.Runtime.valEq(mode, "")) ) 
		{
			cell_decorate = ( ( " class=\"" + mode ) + "\"" );
		}
		
		this.insert(( ( this.td_open + cell_decorate ) + ">" ));
		this.insert(txt);
		this.insert(this.td_close);
	}
	
	
	public   void endRow()
	{
		this.insert("</tr>\n");
	}
	
	
	public   void endTable()
	{
		this.setSection(null);
		this.insert("</table>\n");
	}
	
	
	public   java.lang.String html()
	{
		return this.text_to_insert.join("");
	}
	
	
	@Override public   java.lang.String toString()
	{
		return this.html();
	}
	
	
	public   coopy.DiffRender render(coopy.Table tab)
	{
		if (( ( tab.get_width() == 0 ) || ( tab.get_height() == 0 ) )) 
		{
			return this;
		}
		
		coopy.DiffRender render = this;
		render.beginTable();
		int change_row = -1;
		coopy.CellInfo cell = new coopy.CellInfo();
		coopy.View view = tab.getCellView();
		java.lang.String corner = view.toString(tab.getCell(0, 0));
		int off = 0;
		if (haxe.lang.Runtime.valEq(corner, "@:@")) 
		{
			off = 1;
		}
		 else 
		{
			off = 0;
		}
		
		if (( off > 0 )) 
		{
			if (( ( tab.get_width() <= 1 ) || ( tab.get_height() <= 1 ) )) 
			{
				return this;
			}
			
		}
		
		{
			int _g1 = 0;
			int _g = tab.get_height();
			while (( _g1 < _g ))
			{
				int row = _g1++;
				boolean open = false;
				java.lang.String txt = view.toString(tab.getCell(off, row));
				if (( txt == null )) 
				{
					txt = "";
				}
				
				coopy.DiffRender.examineCell(off, row, view, txt, "", txt, corner, cell, off);
				java.lang.String row_mode = cell.category;
				if (haxe.lang.Runtime.valEq(row_mode, "spec")) 
				{
					change_row = row;
				}
				
				if (( ( haxe.lang.Runtime.valEq(row_mode, "header") || haxe.lang.Runtime.valEq(row_mode, "spec") ) || haxe.lang.Runtime.valEq(row_mode, "index") )) 
				{
					this.setSection("head");
				}
				 else 
				{
					this.setSection("body");
				}
				
				render.beginRow(row_mode);
				{
					int _g3 = 0;
					int _g2 = tab.get_width();
					while (( _g3 < _g2 ))
					{
						int c = _g3++;
						coopy.DiffRender.examineCell(c, row, view, tab.getCell(c, row), ( (( change_row >= 0 )) ? (view.toString(tab.getCell(c, change_row))) : ("") ), txt, corner, cell, off);
						render.insertCell(( (this.pretty_arrows) ? (cell.pretty_value) : (cell.value) ), cell.category_given_tr);
					}
					
				}
				
				render.endRow();
			}
			
		}
		
		render.endTable();
		return this;
	}
	
	
	public   java.lang.String sampleCss()
	{
		return ".highlighter .add { \n  background-color: #7fff7f;\n}\n\n.highlighter .remove { \n  background-color: #ff7f7f;\n}\n\n.highlighter td.modify { \n  background-color: #7f7fff;\n}\n\n.highlighter td.conflict { \n  background-color: #f00;\n}\n\n.highlighter .spec { \n  background-color: #aaa;\n}\n\n.highlighter .move { \n  background-color: #ffa;\n}\n\n.highlighter .null { \n  color: #888;\n}\n\n.highlighter table { \n  border-collapse:collapse;\n}\n\n.highlighter td, .highlighter th {\n  border: 1px solid #2D4068;\n  padding: 3px 7px 2px;\n}\n\n.highlighter th, .highlighter .header { \n  background-color: #aaf;\n  font-weight: bold;\n  padding-bottom: 4px;\n  padding-top: 5px;\n  text-align:left;\n}\n\n.highlighter tr.header th {\n  border-bottom: 2px solid black;\n}\n\n.highlighter tr.index td, .highlighter .index, .highlighter tr.header th.index {\n  background-color: white;\n  border: none;\n}\n\n.highlighter .gap {\n  color: #888;\n}\n\n.highlighter td {\n  empty-cells: show;\n}\n";
	}
	
	
	public   void completeHtml()
	{
		this.text_to_insert.insert(0, "<!DOCTYPE html>\n<html>\n<head>\n<meta charset=\'utf-8\'>\n<style TYPE=\'text/css\'>\n");
		this.text_to_insert.insert(1, this.sampleCss());
		this.text_to_insert.insert(2, "</style>\n</head>\n<body>\n<div class=\'highlighter\'>\n");
		this.text_to_insert.push("</div>\n</body>\n</html>\n");
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef164 = true;
			switch (field.hashCode())
			{
				case 1970241253:
				{
					if (field.equals("section")) 
					{
						__temp_executeDef164 = false;
						this.section = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case -1059197845:
				{
					if (field.equals("text_to_insert")) 
					{
						__temp_executeDef164 = false;
						this.text_to_insert = ((haxe.root.Array<java.lang.String>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -875376269:
				{
					if (field.equals("pretty_arrows")) 
					{
						__temp_executeDef164 = false;
						this.pretty_arrows = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case -1469688135:
				{
					if (field.equals("td_open")) 
					{
						__temp_executeDef164 = false;
						this.td_open = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 3417674:
				{
					if (field.equals("open")) 
					{
						__temp_executeDef164 = false;
						this.open = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 1673116521:
				{
					if (field.equals("td_close")) 
					{
						__temp_executeDef164 = false;
						this.td_close = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef164) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef165 = true;
			switch (field.hashCode())
			{
				case -410359676:
				{
					if (field.equals("completeHtml")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("completeHtml"))) );
					}
					
					break;
				}
				
				
				case -1059197845:
				{
					if (field.equals("text_to_insert")) 
					{
						__temp_executeDef165 = false;
						return this.text_to_insert;
					}
					
					break;
				}
				
				
				case 1112980473:
				{
					if (field.equals("sampleCss")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("sampleCss"))) );
					}
					
					break;
				}
				
				
				case -1469688135:
				{
					if (field.equals("td_open")) 
					{
						__temp_executeDef165 = false;
						return this.td_open;
					}
					
					break;
				}
				
				
				case -934592106:
				{
					if (field.equals("render")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("render"))) );
					}
					
					break;
				}
				
				
				case 1673116521:
				{
					if (field.equals("td_close")) 
					{
						__temp_executeDef165 = false;
						return this.td_close;
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 3417674:
				{
					if (field.equals("open")) 
					{
						__temp_executeDef165 = false;
						return this.open;
					}
					
					break;
				}
				
				
				case 3213227:
				{
					if (field.equals("html")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("html"))) );
					}
					
					break;
				}
				
				
				case -875376269:
				{
					if (field.equals("pretty_arrows")) 
					{
						__temp_executeDef165 = false;
						return this.pretty_arrows;
					}
					
					break;
				}
				
				
				case 1714820019:
				{
					if (field.equals("endTable")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("endTable"))) );
					}
					
					break;
				}
				
				
				case 1970241253:
				{
					if (field.equals("section")) 
					{
						__temp_executeDef165 = false;
						return this.section;
					}
					
					break;
				}
				
				
				case -1298774273:
				{
					if (field.equals("endRow")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("endRow"))) );
					}
					
					break;
				}
				
				
				case 1865627847:
				{
					if (field.equals("usePrettyArrows")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("usePrettyArrows"))) );
					}
					
					break;
				}
				
				
				case 965655483:
				{
					if (field.equals("insertCell")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("insertCell"))) );
					}
					
					break;
				}
				
				
				case -1183792455:
				{
					if (field.equals("insert")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("insert"))) );
					}
					
					break;
				}
				
				
				case 1489411185:
				{
					if (field.equals("beginRow")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("beginRow"))) );
					}
					
					break;
				}
				
				
				case 1101452453:
				{
					if (field.equals("beginTable")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("beginTable"))) );
					}
					
					break;
				}
				
				
				case 648939555:
				{
					if (field.equals("setSection")) 
					{
						__temp_executeDef165 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setSection"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef165) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef166 = true;
			switch (field.hashCode())
			{
				case -410359676:
				{
					if (field.equals("completeHtml")) 
					{
						__temp_executeDef166 = false;
						this.completeHtml();
					}
					
					break;
				}
				
				
				case 1865627847:
				{
					if (field.equals("usePrettyArrows")) 
					{
						__temp_executeDef166 = false;
						this.usePrettyArrows(haxe.lang.Runtime.toBool(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 1112980473:
				{
					if (field.equals("sampleCss")) 
					{
						__temp_executeDef166 = false;
						return this.sampleCss();
					}
					
					break;
				}
				
				
				case -1183792455:
				{
					if (field.equals("insert")) 
					{
						__temp_executeDef166 = false;
						this.insert(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -934592106:
				{
					if (field.equals("render")) 
					{
						__temp_executeDef166 = false;
						return this.render(((coopy.Table) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case 1101452453:
				{
					if (field.equals("beginTable")) 
					{
						__temp_executeDef166 = false;
						this.beginTable();
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef166 = false;
						return this.toString();
					}
					
					break;
				}
				
				
				case 648939555:
				{
					if (field.equals("setSection")) 
					{
						__temp_executeDef166 = false;
						this.setSection(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 3213227:
				{
					if (field.equals("html")) 
					{
						__temp_executeDef166 = false;
						return this.html();
					}
					
					break;
				}
				
				
				case 1489411185:
				{
					if (field.equals("beginRow")) 
					{
						__temp_executeDef166 = false;
						this.beginRow(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 1714820019:
				{
					if (field.equals("endTable")) 
					{
						__temp_executeDef166 = false;
						this.endTable();
					}
					
					break;
				}
				
				
				case 965655483:
				{
					if (field.equals("insertCell")) 
					{
						__temp_executeDef166 = false;
						this.insertCell(haxe.lang.Runtime.toString(dynargs.__get(0)), haxe.lang.Runtime.toString(dynargs.__get(1)));
					}
					
					break;
				}
				
				
				case -1298774273:
				{
					if (field.equals("endRow")) 
					{
						__temp_executeDef166 = false;
						this.endRow();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef166) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("section");
		baseArr.push("pretty_arrows");
		baseArr.push("open");
		baseArr.push("td_close");
		baseArr.push("td_open");
		baseArr.push("text_to_insert");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



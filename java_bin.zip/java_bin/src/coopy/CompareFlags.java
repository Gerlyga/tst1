package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class CompareFlags extends haxe.lang.HxObject
{
	public    CompareFlags(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    CompareFlags()
	{
		coopy.CompareFlags.__hx_ctor_coopy_CompareFlags(this);
	}
	
	
	public static   void __hx_ctor_coopy_CompareFlags(coopy.CompareFlags __temp_me14)
	{
		__temp_me14.ordered = true;
		__temp_me14.show_unchanged = false;
		__temp_me14.unchanged_context = 1;
		__temp_me14.always_show_order = false;
		__temp_me14.never_show_order = true;
		__temp_me14.show_unchanged_columns = false;
		__temp_me14.unchanged_column_context = 1;
		__temp_me14.always_show_header = true;
		__temp_me14.acts = null;
		__temp_me14.ids = null;
		__temp_me14.columns_to_ignore = null;
		__temp_me14.allow_nested_cells = false;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.CompareFlags(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.CompareFlags();
	}
	
	
	public  boolean ordered;
	
	public  boolean show_unchanged;
	
	public  int unchanged_context;
	
	public  boolean always_show_order;
	
	public  boolean never_show_order;
	
	public  boolean show_unchanged_columns;
	
	public  int unchanged_column_context;
	
	public  boolean always_show_header;
	
	public  haxe.ds.StringMap<java.lang.Object> acts;
	
	public  haxe.root.Array<java.lang.String> ids;
	
	public  haxe.root.Array<java.lang.String> columns_to_ignore;
	
	public  boolean allow_nested_cells;
	
	public   boolean filter(java.lang.String act, boolean allow)
	{
		if (( this.acts == null )) 
		{
			this.acts = new haxe.ds.StringMap<java.lang.Object>();
			this.acts.set("update",  ! (allow) );
			this.acts.set("insert",  ! (allow) );
			this.acts.set("delete",  ! (allow) );
		}
		
		if ( ! (this.acts.exists(act)) ) 
		{
			return false;
		}
		
		this.acts.set(act, allow);
		return true;
	}
	
	
	public   boolean allowUpdate()
	{
		if (( this.acts == null )) 
		{
			return true;
		}
		
		return this.acts.exists("update");
	}
	
	
	public   boolean allowInsert()
	{
		if (( this.acts == null )) 
		{
			return true;
		}
		
		return this.acts.exists("insert");
	}
	
	
	public   boolean allowDelete()
	{
		if (( this.acts == null )) 
		{
			return true;
		}
		
		return this.acts.exists("delete");
	}
	
	
	public   haxe.ds.StringMap<java.lang.Object> getIgnoredColumns()
	{
		if (( this.columns_to_ignore == null )) 
		{
			return null;
		}
		
		haxe.ds.StringMap<java.lang.Object> ignore = new haxe.ds.StringMap<java.lang.Object>();
		{
			int _g1 = 0;
			int _g = this.columns_to_ignore.length;
			while (( _g1 < _g ))
			{
				int i = _g1++;
				ignore.set(this.columns_to_ignore.__get(i), true);
			}
			
		}
		
		return ignore;
	}
	
	
	public   void addPrimaryKey(java.lang.String column)
	{
		if (( this.ids == null )) 
		{
			this.ids = new haxe.root.Array<java.lang.String>();
		}
		
		this.ids.push(column);
	}
	
	
	public   void ignoreColumn(java.lang.String column)
	{
		if (( this.columns_to_ignore == null )) 
		{
			this.columns_to_ignore = new haxe.root.Array<java.lang.String>();
		}
		
		this.columns_to_ignore.push(column);
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef138 = true;
			switch (field.hashCode())
			{
				case 1099361418:
				{
					if (field.equals("unchanged_column_context")) 
					{
						__temp_executeDef138 = false;
						this.unchanged_column_context = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -214034581:
				{
					if (field.equals("unchanged_context")) 
					{
						__temp_executeDef138 = false;
						this.unchanged_context = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef138) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef139 = true;
			switch (field.hashCode())
			{
				case 1768535871:
				{
					if (field.equals("allow_nested_cells")) 
					{
						__temp_executeDef139 = false;
						this.allow_nested_cells = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case -1207109523:
				{
					if (field.equals("ordered")) 
					{
						__temp_executeDef139 = false;
						this.ordered = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 488300084:
				{
					if (field.equals("columns_to_ignore")) 
					{
						__temp_executeDef139 = false;
						this.columns_to_ignore = ((haxe.root.Array<java.lang.String>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 562455353:
				{
					if (field.equals("show_unchanged")) 
					{
						__temp_executeDef139 = false;
						this.show_unchanged = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 104120:
				{
					if (field.equals("ids")) 
					{
						__temp_executeDef139 = false;
						this.ids = ((haxe.root.Array<java.lang.String>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -214034581:
				{
					if (field.equals("unchanged_context")) 
					{
						__temp_executeDef139 = false;
						this.unchanged_context = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 2988577:
				{
					if (field.equals("acts")) 
					{
						__temp_executeDef139 = false;
						this.acts = ((haxe.ds.StringMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -932640836:
				{
					if (field.equals("always_show_order")) 
					{
						__temp_executeDef139 = false;
						this.always_show_order = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 940404703:
				{
					if (field.equals("always_show_header")) 
					{
						__temp_executeDef139 = false;
						this.always_show_header = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case -2029678817:
				{
					if (field.equals("never_show_order")) 
					{
						__temp_executeDef139 = false;
						this.never_show_order = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 1099361418:
				{
					if (field.equals("unchanged_column_context")) 
					{
						__temp_executeDef139 = false;
						this.unchanged_column_context = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 2061195479:
				{
					if (field.equals("show_unchanged_columns")) 
					{
						__temp_executeDef139 = false;
						this.show_unchanged_columns = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef139) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef140 = true;
			switch (field.hashCode())
			{
				case -354773048:
				{
					if (field.equals("ignoreColumn")) 
					{
						__temp_executeDef140 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("ignoreColumn"))) );
					}
					
					break;
				}
				
				
				case -1207109523:
				{
					if (field.equals("ordered")) 
					{
						__temp_executeDef140 = false;
						return this.ordered;
					}
					
					break;
				}
				
				
				case -1254883202:
				{
					if (field.equals("addPrimaryKey")) 
					{
						__temp_executeDef140 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("addPrimaryKey"))) );
					}
					
					break;
				}
				
				
				case 562455353:
				{
					if (field.equals("show_unchanged")) 
					{
						__temp_executeDef140 = false;
						return this.show_unchanged;
					}
					
					break;
				}
				
				
				case -565997663:
				{
					if (field.equals("getIgnoredColumns")) 
					{
						__temp_executeDef140 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getIgnoredColumns"))) );
					}
					
					break;
				}
				
				
				case -214034581:
				{
					if (field.equals("unchanged_context")) 
					{
						__temp_executeDef140 = false;
						return this.unchanged_context;
					}
					
					break;
				}
				
				
				case 569752148:
				{
					if (field.equals("allowDelete")) 
					{
						__temp_executeDef140 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("allowDelete"))) );
					}
					
					break;
				}
				
				
				case -932640836:
				{
					if (field.equals("always_show_order")) 
					{
						__temp_executeDef140 = false;
						return this.always_show_order;
					}
					
					break;
				}
				
				
				case 721418082:
				{
					if (field.equals("allowInsert")) 
					{
						__temp_executeDef140 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("allowInsert"))) );
					}
					
					break;
				}
				
				
				case -2029678817:
				{
					if (field.equals("never_show_order")) 
					{
						__temp_executeDef140 = false;
						return this.never_show_order;
					}
					
					break;
				}
				
				
				case 1066364274:
				{
					if (field.equals("allowUpdate")) 
					{
						__temp_executeDef140 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("allowUpdate"))) );
					}
					
					break;
				}
				
				
				case 2061195479:
				{
					if (field.equals("show_unchanged_columns")) 
					{
						__temp_executeDef140 = false;
						return this.show_unchanged_columns;
					}
					
					break;
				}
				
				
				case -1274492040:
				{
					if (field.equals("filter")) 
					{
						__temp_executeDef140 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("filter"))) );
					}
					
					break;
				}
				
				
				case 1099361418:
				{
					if (field.equals("unchanged_column_context")) 
					{
						__temp_executeDef140 = false;
						return this.unchanged_column_context;
					}
					
					break;
				}
				
				
				case 1768535871:
				{
					if (field.equals("allow_nested_cells")) 
					{
						__temp_executeDef140 = false;
						return this.allow_nested_cells;
					}
					
					break;
				}
				
				
				case 940404703:
				{
					if (field.equals("always_show_header")) 
					{
						__temp_executeDef140 = false;
						return this.always_show_header;
					}
					
					break;
				}
				
				
				case 488300084:
				{
					if (field.equals("columns_to_ignore")) 
					{
						__temp_executeDef140 = false;
						return this.columns_to_ignore;
					}
					
					break;
				}
				
				
				case 2988577:
				{
					if (field.equals("acts")) 
					{
						__temp_executeDef140 = false;
						return this.acts;
					}
					
					break;
				}
				
				
				case 104120:
				{
					if (field.equals("ids")) 
					{
						__temp_executeDef140 = false;
						return this.ids;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef140) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef141 = true;
			switch (field.hashCode())
			{
				case 1099361418:
				{
					if (field.equals("unchanged_column_context")) 
					{
						__temp_executeDef141 = false;
						return ((double) (this.unchanged_column_context) );
					}
					
					break;
				}
				
				
				case -214034581:
				{
					if (field.equals("unchanged_context")) 
					{
						__temp_executeDef141 = false;
						return ((double) (this.unchanged_context) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef141) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef142 = true;
			switch (field.hashCode())
			{
				case -354773048:
				{
					if (field.equals("ignoreColumn")) 
					{
						__temp_executeDef142 = false;
						this.ignoreColumn(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -1274492040:
				{
					if (field.equals("filter")) 
					{
						__temp_executeDef142 = false;
						return this.filter(haxe.lang.Runtime.toString(dynargs.__get(0)), haxe.lang.Runtime.toBool(dynargs.__get(1)));
					}
					
					break;
				}
				
				
				case -1254883202:
				{
					if (field.equals("addPrimaryKey")) 
					{
						__temp_executeDef142 = false;
						this.addPrimaryKey(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 1066364274:
				{
					if (field.equals("allowUpdate")) 
					{
						__temp_executeDef142 = false;
						return this.allowUpdate();
					}
					
					break;
				}
				
				
				case -565997663:
				{
					if (field.equals("getIgnoredColumns")) 
					{
						__temp_executeDef142 = false;
						return this.getIgnoredColumns();
					}
					
					break;
				}
				
				
				case 721418082:
				{
					if (field.equals("allowInsert")) 
					{
						__temp_executeDef142 = false;
						return this.allowInsert();
					}
					
					break;
				}
				
				
				case 569752148:
				{
					if (field.equals("allowDelete")) 
					{
						__temp_executeDef142 = false;
						return this.allowDelete();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef142) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("allow_nested_cells");
		baseArr.push("columns_to_ignore");
		baseArr.push("ids");
		baseArr.push("acts");
		baseArr.push("always_show_header");
		baseArr.push("unchanged_column_context");
		baseArr.push("show_unchanged_columns");
		baseArr.push("never_show_order");
		baseArr.push("always_show_order");
		baseArr.push("unchanged_context");
		baseArr.push("show_unchanged");
		baseArr.push("ordered");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class SqlColumn extends haxe.lang.HxObject
{
	public    SqlColumn(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    SqlColumn()
	{
		coopy.SqlColumn.__hx_ctor_coopy_SqlColumn(this);
	}
	
	
	public static   void __hx_ctor_coopy_SqlColumn(coopy.SqlColumn __temp_me37)
	{
		{
		}
		
	}
	
	
	public static   coopy.SqlColumn byNameAndPrimaryKey(java.lang.String name, boolean primary)
	{
		coopy.SqlColumn result = new coopy.SqlColumn();
		result.name = name;
		result.primary = primary;
		return result;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.SqlColumn(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.SqlColumn();
	}
	
	
	public  java.lang.String name;
	
	public  boolean primary;
	
	public   java.lang.String getName()
	{
		return this.name;
	}
	
	
	public   boolean isPrimaryKey()
	{
		return this.primary;
	}
	
	
	@Override public   java.lang.String toString()
	{
		return ( (( (this.primary) ? ("*") : ("") )) + this.name );
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef236 = true;
			switch (field.hashCode())
			{
				case -314765822:
				{
					if (field.equals("primary")) 
					{
						__temp_executeDef236 = false;
						this.primary = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 3373707:
				{
					if (field.equals("name")) 
					{
						__temp_executeDef236 = false;
						this.name = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef236) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef237 = true;
			switch (field.hashCode())
			{
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef237 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 3373707:
				{
					if (field.equals("name")) 
					{
						__temp_executeDef237 = false;
						return this.name;
					}
					
					break;
				}
				
				
				case 896351687:
				{
					if (field.equals("isPrimaryKey")) 
					{
						__temp_executeDef237 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("isPrimaryKey"))) );
					}
					
					break;
				}
				
				
				case -314765822:
				{
					if (field.equals("primary")) 
					{
						__temp_executeDef237 = false;
						return this.primary;
					}
					
					break;
				}
				
				
				case -75308287:
				{
					if (field.equals("getName")) 
					{
						__temp_executeDef237 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getName"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef237) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef238 = true;
			switch (field.hashCode())
			{
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef238 = false;
						return this.toString();
					}
					
					break;
				}
				
				
				case -75308287:
				{
					if (field.equals("getName")) 
					{
						__temp_executeDef238 = false;
						return this.getName();
					}
					
					break;
				}
				
				
				case 896351687:
				{
					if (field.equals("isPrimaryKey")) 
					{
						__temp_executeDef238 = false;
						return this.isPrimaryKey();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef238) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("primary");
		baseArr.push("name");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class SparseSheet<T> extends haxe.lang.HxObject
{
	public    SparseSheet(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    SparseSheet()
	{
		coopy.SparseSheet.__hx_ctor_coopy_SparseSheet(this);
	}
	
	
	public static  <T_c> void __hx_ctor_coopy_SparseSheet(coopy.SparseSheet<T_c> __temp_me36)
	{
		__temp_me36.h = __temp_me36.w = 0;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.SparseSheet<java.lang.Object>(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.SparseSheet<java.lang.Object>();
	}
	
	
	public  int h;
	
	public  int w;
	
	public  haxe.ds.IntMap<haxe.ds.IntMap> row;
	
	public  T zero;
	
	public   void resize(int w, int h, T zero)
	{
		this.row = new haxe.ds.IntMap<haxe.ds.IntMap>();
		this.nonDestructiveResize(w, h, zero);
	}
	
	
	public   void nonDestructiveResize(int w, int h, T zero)
	{
		this.w = w;
		this.h = h;
		this.zero = zero;
	}
	
	
	public   T get(int x, int y)
	{
		haxe.ds.IntMap<T> cursor = ((haxe.ds.IntMap<T>) (((haxe.ds.IntMap) (this.row.get(((int) (y) ))) )) );
		if (( cursor == null )) 
		{
			return this.zero;
		}
		
		T val = cursor.get(((int) (x) ));
		if (( val == null )) 
		{
			return this.zero;
		}
		
		return val;
	}
	
	
	public   void set(int x, int y, T val)
	{
		haxe.ds.IntMap<T> cursor = ((haxe.ds.IntMap<T>) (((haxe.ds.IntMap) (this.row.get(((int) (y) ))) )) );
		if (( cursor == null )) 
		{
			cursor = new haxe.ds.IntMap<T>();
			this.row.set(y, ((haxe.ds.IntMap) (cursor) ));
		}
		
		cursor.set(x, val);
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef231 = true;
			switch (field.hashCode())
			{
				case 3735208:
				{
					if (field.equals("zero")) 
					{
						__temp_executeDef231 = false;
						this.zero = ((T) (((java.lang.Object) (value) )) );
						return ((double) (haxe.lang.Runtime.toDouble(((java.lang.Object) (value) ))) );
					}
					
					break;
				}
				
				
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef231 = false;
						this.h = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 119:
				{
					if (field.equals("w")) 
					{
						__temp_executeDef231 = false;
						this.w = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef231) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef232 = true;
			switch (field.hashCode())
			{
				case 3735208:
				{
					if (field.equals("zero")) 
					{
						__temp_executeDef232 = false;
						this.zero = ((T) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef232 = false;
						this.h = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 113114:
				{
					if (field.equals("row")) 
					{
						__temp_executeDef232 = false;
						this.row = ((haxe.ds.IntMap<haxe.ds.IntMap>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 119:
				{
					if (field.equals("w")) 
					{
						__temp_executeDef232 = false;
						this.w = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef232) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef233 = true;
			switch (field.hashCode())
			{
				case 113762:
				{
					if (field.equals("set")) 
					{
						__temp_executeDef233 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("set"))) );
					}
					
					break;
				}
				
				
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef233 = false;
						return this.h;
					}
					
					break;
				}
				
				
				case 102230:
				{
					if (field.equals("get")) 
					{
						__temp_executeDef233 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("get"))) );
					}
					
					break;
				}
				
				
				case 119:
				{
					if (field.equals("w")) 
					{
						__temp_executeDef233 = false;
						return this.w;
					}
					
					break;
				}
				
				
				case 1870347657:
				{
					if (field.equals("nonDestructiveResize")) 
					{
						__temp_executeDef233 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("nonDestructiveResize"))) );
					}
					
					break;
				}
				
				
				case 113114:
				{
					if (field.equals("row")) 
					{
						__temp_executeDef233 = false;
						return this.row;
					}
					
					break;
				}
				
				
				case -934437708:
				{
					if (field.equals("resize")) 
					{
						__temp_executeDef233 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("resize"))) );
					}
					
					break;
				}
				
				
				case 3735208:
				{
					if (field.equals("zero")) 
					{
						__temp_executeDef233 = false;
						return this.zero;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef233) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef234 = true;
			switch (field.hashCode())
			{
				case 3735208:
				{
					if (field.equals("zero")) 
					{
						__temp_executeDef234 = false;
						return ((double) (haxe.lang.Runtime.toDouble(((java.lang.Object) (this.zero) ))) );
					}
					
					break;
				}
				
				
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef234 = false;
						return ((double) (this.h) );
					}
					
					break;
				}
				
				
				case 119:
				{
					if (field.equals("w")) 
					{
						__temp_executeDef234 = false;
						return ((double) (this.w) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef234) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef235 = true;
			switch (field.hashCode())
			{
				case 113762:
				{
					if (field.equals("set")) 
					{
						__temp_executeDef235 = false;
						this.set(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), ((T) (dynargs.__get(2)) ));
					}
					
					break;
				}
				
				
				case -934437708:
				{
					if (field.equals("resize")) 
					{
						__temp_executeDef235 = false;
						this.resize(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), ((T) (dynargs.__get(2)) ));
					}
					
					break;
				}
				
				
				case 102230:
				{
					if (field.equals("get")) 
					{
						__temp_executeDef235 = false;
						return this.get(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case 1870347657:
				{
					if (field.equals("nonDestructiveResize")) 
					{
						__temp_executeDef235 = false;
						this.nonDestructiveResize(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), ((T) (dynargs.__get(2)) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef235) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("zero");
		baseArr.push("row");
		baseArr.push("w");
		baseArr.push("h");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class IndexItem extends haxe.lang.HxObject
{
	public    IndexItem(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    IndexItem()
	{
		coopy.IndexItem.__hx_ctor_coopy_IndexItem(this);
	}
	
	
	public static   void __hx_ctor_coopy_IndexItem(coopy.IndexItem __temp_me26)
	{
		{
		}
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.IndexItem(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.IndexItem();
	}
	
	
	public  haxe.root.Array<java.lang.Object> lst;
	
	public final   int add(int i)
	{
		if (( this.lst == null )) 
		{
			this.lst = new haxe.root.Array<java.lang.Object>();
		}
		
		this.lst.push(i);
		return this.lst.length;
	}
	
	
	public final   int length()
	{
		return this.lst.length;
	}
	
	
	public final   int value()
	{
		return ((int) (haxe.lang.Runtime.toInt(this.lst.__get(0))) );
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef192 = true;
			switch (field.hashCode())
			{
				case 107469:
				{
					if (field.equals("lst")) 
					{
						__temp_executeDef192 = false;
						this.lst = ((haxe.root.Array<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef192) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef193 = true;
			switch (field.hashCode())
			{
				case 111972721:
				{
					if (field.equals("value")) 
					{
						__temp_executeDef193 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("value"))) );
					}
					
					break;
				}
				
				
				case 107469:
				{
					if (field.equals("lst")) 
					{
						__temp_executeDef193 = false;
						return this.lst;
					}
					
					break;
				}
				
				
				case -1106363674:
				{
					if (field.equals("length")) 
					{
						__temp_executeDef193 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("length"))) );
					}
					
					break;
				}
				
				
				case 96417:
				{
					if (field.equals("add")) 
					{
						__temp_executeDef193 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("add"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef193) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef194 = true;
			switch (field.hashCode())
			{
				case 111972721:
				{
					if (field.equals("value")) 
					{
						__temp_executeDef194 = false;
						return this.value();
					}
					
					break;
				}
				
				
				case 96417:
				{
					if (field.equals("add")) 
					{
						__temp_executeDef194 = false;
						return this.add(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case -1106363674:
				{
					if (field.equals("length")) 
					{
						__temp_executeDef194 = false;
						return this.length();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef194) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("lst");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



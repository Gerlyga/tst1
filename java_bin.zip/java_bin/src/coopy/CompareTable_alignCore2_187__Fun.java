package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class CompareTable_alignCore2_187__Fun extends haxe.lang.Function
{
	public    CompareTable_alignCore2_187__Fun()
	{
		super(2, 1);
	}
	
	
	public static  coopy.CompareTable_alignCore2_187__Fun __hx_current;
	
	@Override public   double __hx_invoke2_f(double __fn_float1, java.lang.Object __fn_dyn1, double __fn_float2, java.lang.Object __fn_dyn2)
	{
		haxe.root.Array<java.lang.Object> b1 = ( (( __fn_dyn2 == haxe.lang.Runtime.undefined )) ? (((haxe.root.Array<java.lang.Object>) (((java.lang.Object) (__fn_float2) )) )) : (((haxe.root.Array<java.lang.Object>) (__fn_dyn2) )) );
		haxe.root.Array<java.lang.Object> a1 = ( (( __fn_dyn1 == haxe.lang.Runtime.undefined )) ? (((haxe.root.Array<java.lang.Object>) (((java.lang.Object) (__fn_float1) )) )) : (((haxe.root.Array<java.lang.Object>) (__fn_dyn1) )) );
		if (( ((int) (haxe.lang.Runtime.toInt(a1.__get(1))) ) < ((int) (haxe.lang.Runtime.toInt(b1.__get(1))) ) )) 
		{
			return ((double) (1) );
		}
		
		if (( ((int) (haxe.lang.Runtime.toInt(a1.__get(1))) ) > ((int) (haxe.lang.Runtime.toInt(b1.__get(1))) ) )) 
		{
			return ((double) (-1) );
		}
		
		if (( ((int) (haxe.lang.Runtime.toInt(a1.__get(0))) ) > ((int) (haxe.lang.Runtime.toInt(b1.__get(0))) ) )) 
		{
			return ((double) (1) );
		}
		
		if (( ((int) (haxe.lang.Runtime.toInt(a1.__get(0))) ) < ((int) (haxe.lang.Runtime.toInt(b1.__get(0))) ) )) 
		{
			return ((double) (-1) );
		}
		
		return ((double) (0) );
	}
	
	
}



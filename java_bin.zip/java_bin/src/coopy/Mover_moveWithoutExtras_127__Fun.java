package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Mover_moveWithoutExtras_127__Fun extends haxe.lang.Function
{
	public    Mover_moveWithoutExtras_127__Fun(haxe.root.Array<haxe.ds.IntMap> blk_len)
	{
		super(2, 1);
		this.blk_len = blk_len;
	}
	
	
	@Override public   double __hx_invoke2_f(double __fn_float1, java.lang.Object __fn_dyn1, double __fn_float2, java.lang.Object __fn_dyn2)
	{
		int b = ( (( __fn_dyn2 == haxe.lang.Runtime.undefined )) ? (((int) (__fn_float2) )) : (((int) (haxe.lang.Runtime.toInt(__fn_dyn2)) )) );
		int a = ( (( __fn_dyn1 == haxe.lang.Runtime.undefined )) ? (((int) (__fn_float1) )) : (((int) (haxe.lang.Runtime.toInt(__fn_dyn1)) )) );
		return ((double) (( ((int) (haxe.lang.Runtime.toInt(((haxe.ds.IntMap<java.lang.Object>) (((haxe.ds.IntMap) (this.blk_len.__get(0)) )) ).get(((int) (b) )))) ) - ((int) (haxe.lang.Runtime.toInt(((haxe.ds.IntMap<java.lang.Object>) (((haxe.ds.IntMap) (this.blk_len.__get(0)) )) ).get(((int) (a) )))) ) )) );
	}
	
	
	public  haxe.root.Array<haxe.ds.IntMap> blk_len;
	
}



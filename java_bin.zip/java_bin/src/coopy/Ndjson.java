package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Ndjson extends haxe.lang.HxObject
{
	public    Ndjson(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Ndjson(coopy.Table tab)
	{
		coopy.Ndjson.__hx_ctor_coopy_Ndjson(this, tab);
	}
	
	
	public static   void __hx_ctor_coopy_Ndjson(coopy.Ndjson __temp_me30, coopy.Table tab)
	{
		__temp_me30.tab = tab;
		__temp_me30.view = tab.getCellView();
		__temp_me30.header_row = 0;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.Ndjson(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.Ndjson(((coopy.Table) (arr.__get(0)) ));
	}
	
	
	public  coopy.Table tab;
	
	public  coopy.View view;
	
	public  haxe.ds.StringMap<java.lang.Object> columns;
	
	public  int header_row;
	
	public   java.lang.String renderRow(int r)
	{
		haxe.ds.StringMap row = new haxe.ds.StringMap();
		{
			int _g1 = 0;
			int _g = this.tab.get_width();
			while (( _g1 < _g ))
			{
				int c = _g1++;
				java.lang.String key = this.view.toString(this.tab.getCell(c, this.header_row));
				if (( ( c == 0 ) && ( this.header_row == 1 ) )) 
				{
					key = "@:@";
				}
				
				{
					java.lang.Object value = this.tab.getCell(c, r);
					row.set(key, value);
				}
				
			}
			
		}
		
		return haxe.format.JsonPrinter.print(row, null, null);
	}
	
	
	public   java.lang.String render()
	{
		java.lang.String txt = "";
		int offset = 0;
		if (( this.tab.get_height() == 0 )) 
		{
			return txt;
		}
		
		if (( this.tab.get_width() == 0 )) 
		{
			return txt;
		}
		
		if (haxe.lang.Runtime.eq(this.tab.getCell(0, 0), "@:@")) 
		{
			offset = 1;
		}
		
		this.header_row = offset;
		{
			int _g1 = ( this.header_row + 1 );
			int _g = this.tab.get_height();
			while (( _g1 < _g ))
			{
				int r = _g1++;
				txt += this.renderRow(r);
				txt += "\n";
			}
			
		}
		
		return txt;
	}
	
	
	public   void addRow(int r, java.lang.String txt)
	{
		java.lang.Object json = new haxe.format.JsonParser(haxe.lang.Runtime.toString(txt)).parseRec();
		if (( this.columns == null )) 
		{
			this.columns = new haxe.ds.StringMap<java.lang.Object>();
		}
		
		int w = this.tab.get_width();
		int h = this.tab.get_height();
		boolean resize = false;
		{
			int _g = 0;
			haxe.root.Array<java.lang.String> _g1 = haxe.root.Reflect.fields(json);
			while (( _g < _g1.length ))
			{
				java.lang.String name = _g1.__get(_g);
				 ++ _g;
				if ( ! (this.columns.exists(name)) ) 
				{
					this.columns.set(name, w);
					w++;
					resize = true;
				}
				
			}
			
		}
		
		if (( r >= h )) 
		{
			h = ( r + 1 );
			resize = true;
		}
		
		if (resize) 
		{
			this.tab.resize(w, h);
		}
		
		{
			int _g2 = 0;
			haxe.root.Array<java.lang.String> _g11 = haxe.root.Reflect.fields(json);
			while (( _g2 < _g11.length ))
			{
				java.lang.String name1 = _g11.__get(_g2);
				 ++ _g2;
				java.lang.Object v = haxe.root.Reflect.field(json, name1);
				java.lang.Object c = this.columns.get(name1);
				this.tab.setCell(((int) (haxe.lang.Runtime.toInt(c)) ), r, v);
			}
			
		}
		
	}
	
	
	public   void addHeaderRow(int r)
	{
		java.lang.Object names = this.columns.keys();
		{
			java.lang.Object __temp_iterator93 = names;
			while (haxe.lang.Runtime.toBool(haxe.lang.Runtime.callField(__temp_iterator93, "hasNext", null)))
			{
				java.lang.String n = haxe.lang.Runtime.toString(haxe.lang.Runtime.callField(__temp_iterator93, "next", null));
				this.tab.setCell(((int) (haxe.lang.Runtime.toInt(this.columns.get(n))) ), r, this.view.toDatum(n));
			}
			
		}
		
	}
	
	
	public   void parse(java.lang.String txt)
	{
		this.columns = null;
		haxe.root.Array<java.lang.String> rows = haxe.lang.StringExt.split(txt, "\n");
		int h = rows.length;
		if (( h == 0 )) 
		{
			this.tab.clear();
			return ;
		}
		
		if (haxe.lang.Runtime.valEq(rows.__get(( h - 1 )), "")) 
		{
			h--;
		}
		
		{
			int _g = 0;
			while (( _g < ((int) (h) ) ))
			{
				int i = _g++;
				int at = ( ( h - i ) - 1 );
				this.addRow(( at + 1 ), rows.__get(at));
			}
			
		}
		
		this.addHeaderRow(0);
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef213 = true;
			switch (field.hashCode())
			{
				case 1977859368:
				{
					if (field.equals("header_row")) 
					{
						__temp_executeDef213 = false;
						this.header_row = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef213) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef214 = true;
			switch (field.hashCode())
			{
				case 1977859368:
				{
					if (field.equals("header_row")) 
					{
						__temp_executeDef214 = false;
						this.header_row = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 114581:
				{
					if (field.equals("tab")) 
					{
						__temp_executeDef214 = false;
						this.tab = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 949721053:
				{
					if (field.equals("columns")) 
					{
						__temp_executeDef214 = false;
						this.columns = ((haxe.ds.StringMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3619493:
				{
					if (field.equals("view")) 
					{
						__temp_executeDef214 = false;
						this.view = ((coopy.View) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef214) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef215 = true;
			switch (field.hashCode())
			{
				case 106437299:
				{
					if (field.equals("parse")) 
					{
						__temp_executeDef215 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("parse"))) );
					}
					
					break;
				}
				
				
				case 114581:
				{
					if (field.equals("tab")) 
					{
						__temp_executeDef215 = false;
						return this.tab;
					}
					
					break;
				}
				
				
				case -351206292:
				{
					if (field.equals("addHeaderRow")) 
					{
						__temp_executeDef215 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("addHeaderRow"))) );
					}
					
					break;
				}
				
				
				case 3619493:
				{
					if (field.equals("view")) 
					{
						__temp_executeDef215 = false;
						return this.view;
					}
					
					break;
				}
				
				
				case -1422526087:
				{
					if (field.equals("addRow")) 
					{
						__temp_executeDef215 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("addRow"))) );
					}
					
					break;
				}
				
				
				case 949721053:
				{
					if (field.equals("columns")) 
					{
						__temp_executeDef215 = false;
						return this.columns;
					}
					
					break;
				}
				
				
				case -934592106:
				{
					if (field.equals("render")) 
					{
						__temp_executeDef215 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("render"))) );
					}
					
					break;
				}
				
				
				case 1977859368:
				{
					if (field.equals("header_row")) 
					{
						__temp_executeDef215 = false;
						return this.header_row;
					}
					
					break;
				}
				
				
				case 1839632484:
				{
					if (field.equals("renderRow")) 
					{
						__temp_executeDef215 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("renderRow"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef215) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef216 = true;
			switch (field.hashCode())
			{
				case 1977859368:
				{
					if (field.equals("header_row")) 
					{
						__temp_executeDef216 = false;
						return ((double) (this.header_row) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef216) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef217 = true;
			switch (field.hashCode())
			{
				case 106437299:
				{
					if (field.equals("parse")) 
					{
						__temp_executeDef217 = false;
						this.parse(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 1839632484:
				{
					if (field.equals("renderRow")) 
					{
						__temp_executeDef217 = false;
						return this.renderRow(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case -351206292:
				{
					if (field.equals("addHeaderRow")) 
					{
						__temp_executeDef217 = false;
						this.addHeaderRow(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case -934592106:
				{
					if (field.equals("render")) 
					{
						__temp_executeDef217 = false;
						return this.render();
					}
					
					break;
				}
				
				
				case -1422526087:
				{
					if (field.equals("addRow")) 
					{
						__temp_executeDef217 = false;
						this.addRow(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), haxe.lang.Runtime.toString(dynargs.__get(1)));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef217) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("header_row");
		baseArr.push("columns");
		baseArr.push("view");
		baseArr.push("tab");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



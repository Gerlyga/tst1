package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  interface SqlHelper extends haxe.lang.IHxObject
{
	   haxe.root.Array<java.lang.String> getTableNames(coopy.SqlDatabase db);
	
	   int countRows(coopy.SqlDatabase db, coopy.SqlTableName name);
	
	   haxe.root.Array<java.lang.Object> getRowIDs(coopy.SqlDatabase db, coopy.SqlTableName name);
	
}



package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class HighlightPatchUnit extends haxe.lang.HxObject
{
	public    HighlightPatchUnit(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    HighlightPatchUnit()
	{
		coopy.HighlightPatchUnit.__hx_ctor_coopy_HighlightPatchUnit(this);
	}
	
	
	public static   void __hx_ctor_coopy_HighlightPatchUnit(coopy.HighlightPatchUnit __temp_me24)
	{
		__temp_me24.add = false;
		__temp_me24.rem = false;
		__temp_me24.update = false;
		__temp_me24.sourceRow = -1;
		__temp_me24.sourceRowOffset = 0;
		__temp_me24.sourcePrevRow = -1;
		__temp_me24.sourceNextRow = -1;
		__temp_me24.destRow = -1;
		__temp_me24.patchRow = -1;
		__temp_me24.code = "";
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.HighlightPatchUnit(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.HighlightPatchUnit();
	}
	
	
	public  boolean add;
	
	public  boolean rem;
	
	public  boolean update;
	
	public  java.lang.String code;
	
	public  int sourceRow;
	
	public  int sourceRowOffset;
	
	public  int sourcePrevRow;
	
	public  int sourceNextRow;
	
	public  int destRow;
	
	public  int patchRow;
	
	@Override public   java.lang.String toString()
	{
		return ( ( ( ( ( ( ( ( ( ( this.code + " patchRow " ) + this.patchRow ) + " sourceRows " ) + this.sourcePrevRow ) + "," ) + this.sourceRow ) + "," ) + this.sourceNextRow ) + " destRow " ) + this.destRow );
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef182 = true;
			switch (field.hashCode())
			{
				case 1230363762:
				{
					if (field.equals("patchRow")) 
					{
						__temp_executeDef182 = false;
						this.patchRow = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1698422849:
				{
					if (field.equals("sourceRow")) 
					{
						__temp_executeDef182 = false;
						this.sourceRow = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1557342168:
				{
					if (field.equals("destRow")) 
					{
						__temp_executeDef182 = false;
						this.destRow = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1565746482:
				{
					if (field.equals("sourceRowOffset")) 
					{
						__temp_executeDef182 = false;
						this.sourceRowOffset = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1941625164:
				{
					if (field.equals("sourceNextRow")) 
					{
						__temp_executeDef182 = false;
						this.sourceNextRow = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -223643124:
				{
					if (field.equals("sourcePrevRow")) 
					{
						__temp_executeDef182 = false;
						this.sourcePrevRow = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef182) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef183 = true;
			switch (field.hashCode())
			{
				case 1230363762:
				{
					if (field.equals("patchRow")) 
					{
						__temp_executeDef183 = false;
						this.patchRow = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 96417:
				{
					if (field.equals("add")) 
					{
						__temp_executeDef183 = false;
						this.add = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 1557342168:
				{
					if (field.equals("destRow")) 
					{
						__temp_executeDef183 = false;
						this.destRow = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 112794:
				{
					if (field.equals("rem")) 
					{
						__temp_executeDef183 = false;
						this.rem = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 1941625164:
				{
					if (field.equals("sourceNextRow")) 
					{
						__temp_executeDef183 = false;
						this.sourceNextRow = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case -838846263:
				{
					if (field.equals("update")) 
					{
						__temp_executeDef183 = false;
						this.update = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case -223643124:
				{
					if (field.equals("sourcePrevRow")) 
					{
						__temp_executeDef183 = false;
						this.sourcePrevRow = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 3059181:
				{
					if (field.equals("code")) 
					{
						__temp_executeDef183 = false;
						this.code = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 1565746482:
				{
					if (field.equals("sourceRowOffset")) 
					{
						__temp_executeDef183 = false;
						this.sourceRowOffset = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case -1698422849:
				{
					if (field.equals("sourceRow")) 
					{
						__temp_executeDef183 = false;
						this.sourceRow = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef183) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef184 = true;
			switch (field.hashCode())
			{
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef184 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 96417:
				{
					if (field.equals("add")) 
					{
						__temp_executeDef184 = false;
						return this.add;
					}
					
					break;
				}
				
				
				case 1230363762:
				{
					if (field.equals("patchRow")) 
					{
						__temp_executeDef184 = false;
						return this.patchRow;
					}
					
					break;
				}
				
				
				case 112794:
				{
					if (field.equals("rem")) 
					{
						__temp_executeDef184 = false;
						return this.rem;
					}
					
					break;
				}
				
				
				case 1557342168:
				{
					if (field.equals("destRow")) 
					{
						__temp_executeDef184 = false;
						return this.destRow;
					}
					
					break;
				}
				
				
				case -838846263:
				{
					if (field.equals("update")) 
					{
						__temp_executeDef184 = false;
						return this.update;
					}
					
					break;
				}
				
				
				case 1941625164:
				{
					if (field.equals("sourceNextRow")) 
					{
						__temp_executeDef184 = false;
						return this.sourceNextRow;
					}
					
					break;
				}
				
				
				case 3059181:
				{
					if (field.equals("code")) 
					{
						__temp_executeDef184 = false;
						return this.code;
					}
					
					break;
				}
				
				
				case -223643124:
				{
					if (field.equals("sourcePrevRow")) 
					{
						__temp_executeDef184 = false;
						return this.sourcePrevRow;
					}
					
					break;
				}
				
				
				case -1698422849:
				{
					if (field.equals("sourceRow")) 
					{
						__temp_executeDef184 = false;
						return this.sourceRow;
					}
					
					break;
				}
				
				
				case 1565746482:
				{
					if (field.equals("sourceRowOffset")) 
					{
						__temp_executeDef184 = false;
						return this.sourceRowOffset;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef184) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef185 = true;
			switch (field.hashCode())
			{
				case 1230363762:
				{
					if (field.equals("patchRow")) 
					{
						__temp_executeDef185 = false;
						return ((double) (this.patchRow) );
					}
					
					break;
				}
				
				
				case -1698422849:
				{
					if (field.equals("sourceRow")) 
					{
						__temp_executeDef185 = false;
						return ((double) (this.sourceRow) );
					}
					
					break;
				}
				
				
				case 1557342168:
				{
					if (field.equals("destRow")) 
					{
						__temp_executeDef185 = false;
						return ((double) (this.destRow) );
					}
					
					break;
				}
				
				
				case 1565746482:
				{
					if (field.equals("sourceRowOffset")) 
					{
						__temp_executeDef185 = false;
						return ((double) (this.sourceRowOffset) );
					}
					
					break;
				}
				
				
				case 1941625164:
				{
					if (field.equals("sourceNextRow")) 
					{
						__temp_executeDef185 = false;
						return ((double) (this.sourceNextRow) );
					}
					
					break;
				}
				
				
				case -223643124:
				{
					if (field.equals("sourcePrevRow")) 
					{
						__temp_executeDef185 = false;
						return ((double) (this.sourcePrevRow) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef185) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef186 = true;
			switch (field.hashCode())
			{
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef186 = false;
						return this.toString();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef186) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("patchRow");
		baseArr.push("destRow");
		baseArr.push("sourceNextRow");
		baseArr.push("sourcePrevRow");
		baseArr.push("sourceRowOffset");
		baseArr.push("sourceRow");
		baseArr.push("code");
		baseArr.push("update");
		baseArr.push("rem");
		baseArr.push("add");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



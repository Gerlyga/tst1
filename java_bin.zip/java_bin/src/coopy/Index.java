package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Index extends haxe.lang.HxObject
{
	public    Index(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Index()
	{
		coopy.Index.__hx_ctor_coopy_Index(this);
	}
	
	
	public static   void __hx_ctor_coopy_Index(coopy.Index __temp_me25)
	{
		__temp_me25.items = new haxe.ds.StringMap<coopy.IndexItem>();
		__temp_me25.cols = new haxe.root.Array<java.lang.Object>();
		__temp_me25.keys = new haxe.root.Array<java.lang.String>();
		__temp_me25.top_freq = 0;
		__temp_me25.height = 0;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.Index(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.Index();
	}
	
	
	public  haxe.ds.StringMap<coopy.IndexItem> items;
	
	public  haxe.root.Array<java.lang.String> keys;
	
	public  int top_freq;
	
	public  int height;
	
	public  haxe.root.Array<java.lang.Object> cols;
	
	public  coopy.View v;
	
	public  coopy.Table indexed_table;
	
	public   void addColumn(int i)
	{
		this.cols.push(i);
	}
	
	
	public   void indexTable(coopy.Table t)
	{
		this.indexed_table = t;
		if (( ( this.keys.length != t.get_height() ) && ( t.get_height() > 0 ) )) 
		{
			this.keys.__set(( t.get_height() - 1 ), null);
		}
		
		{
			int _g1 = 0;
			int _g = t.get_height();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				java.lang.String key = this.keys.__get(i);
				if (( key == null )) 
				{
					key = this.toKey(t, i);
					this.keys.__set(i, key);
				}
				
				coopy.IndexItem item = this.items.get(key);
				if (( item == null )) 
				{
					item = new coopy.IndexItem();
					this.items.set(key, item);
				}
				
				int ct = 0;
				{
					if (( item.lst == null )) 
					{
						item.lst = new haxe.root.Array<java.lang.Object>();
					}
					
					item.lst.push(i);
					ct = item.lst.length;
				}
				
				if (( ct > this.top_freq )) 
				{
					this.top_freq = ct;
				}
				
			}
			
		}
		
		this.height = t.get_height();
	}
	
	
	public   java.lang.String toKey(coopy.Table t, int i)
	{
		java.lang.String wide = "";
		if (( this.v == null )) 
		{
			this.v = t.getCellView();
		}
		
		{
			int _g1 = 0;
			int _g = this.cols.length;
			while (( _g1 < _g ))
			{
				int k = _g1++;
				java.lang.Object d = t.getCell(((int) (haxe.lang.Runtime.toInt(this.cols.__get(k))) ), i);
				java.lang.String txt = this.v.toString(d);
				if (( ( ( ( txt == null ) || haxe.lang.Runtime.valEq(txt, "") ) || haxe.lang.Runtime.valEq(txt, "null") ) || haxe.lang.Runtime.valEq(txt, "undefined") )) 
				{
					continue;
				}
				
				if (( k > 0 )) 
				{
					wide += " // ";
				}
				
				wide += txt;
			}
			
		}
		
		return wide;
	}
	
	
	public   java.lang.String toKeyByContent(coopy.Row row)
	{
		java.lang.String wide = "";
		{
			int _g1 = 0;
			int _g = this.cols.length;
			while (( _g1 < _g ))
			{
				int k = _g1++;
				java.lang.String txt = row.getRowString(((int) (haxe.lang.Runtime.toInt(this.cols.__get(k))) ));
				if (( ( ( ( txt == null ) || haxe.lang.Runtime.valEq(txt, "") ) || haxe.lang.Runtime.valEq(txt, "null") ) || haxe.lang.Runtime.valEq(txt, "undefined") )) 
				{
					continue;
				}
				
				if (( k > 0 )) 
				{
					wide += " // ";
				}
				
				wide += txt;
			}
			
		}
		
		return wide;
	}
	
	
	public   coopy.Table getTable()
	{
		return this.indexed_table;
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef187 = true;
			switch (field.hashCode())
			{
				case -1221029593:
				{
					if (field.equals("height")) 
					{
						__temp_executeDef187 = false;
						this.height = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -966419678:
				{
					if (field.equals("top_freq")) 
					{
						__temp_executeDef187 = false;
						this.top_freq = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef187) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef188 = true;
			switch (field.hashCode())
			{
				case 2062069504:
				{
					if (field.equals("indexed_table")) 
					{
						__temp_executeDef188 = false;
						this.indexed_table = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 100526016:
				{
					if (field.equals("items")) 
					{
						__temp_executeDef188 = false;
						this.items = ((haxe.ds.StringMap<coopy.IndexItem>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 118:
				{
					if (field.equals("v")) 
					{
						__temp_executeDef188 = false;
						this.v = ((coopy.View) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3288564:
				{
					if (field.equals("keys")) 
					{
						__temp_executeDef188 = false;
						this.keys = ((haxe.root.Array<java.lang.String>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3059443:
				{
					if (field.equals("cols")) 
					{
						__temp_executeDef188 = false;
						this.cols = ((haxe.root.Array<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -966419678:
				{
					if (field.equals("top_freq")) 
					{
						__temp_executeDef188 = false;
						this.top_freq = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case -1221029593:
				{
					if (field.equals("height")) 
					{
						__temp_executeDef188 = false;
						this.height = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef188) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef189 = true;
			switch (field.hashCode())
			{
				case 1965941272:
				{
					if (field.equals("getTable")) 
					{
						__temp_executeDef189 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getTable"))) );
					}
					
					break;
				}
				
				
				case 100526016:
				{
					if (field.equals("items")) 
					{
						__temp_executeDef189 = false;
						return this.items;
					}
					
					break;
				}
				
				
				case 676216478:
				{
					if (field.equals("toKeyByContent")) 
					{
						__temp_executeDef189 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toKeyByContent"))) );
					}
					
					break;
				}
				
				
				case 3288564:
				{
					if (field.equals("keys")) 
					{
						__temp_executeDef189 = false;
						return this.keys;
					}
					
					break;
				}
				
				
				case 110510564:
				{
					if (field.equals("toKey")) 
					{
						__temp_executeDef189 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toKey"))) );
					}
					
					break;
				}
				
				
				case -966419678:
				{
					if (field.equals("top_freq")) 
					{
						__temp_executeDef189 = false;
						return this.top_freq;
					}
					
					break;
				}
				
				
				case 736417308:
				{
					if (field.equals("indexTable")) 
					{
						__temp_executeDef189 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("indexTable"))) );
					}
					
					break;
				}
				
				
				case -1221029593:
				{
					if (field.equals("height")) 
					{
						__temp_executeDef189 = false;
						return this.height;
					}
					
					break;
				}
				
				
				case -461997225:
				{
					if (field.equals("addColumn")) 
					{
						__temp_executeDef189 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("addColumn"))) );
					}
					
					break;
				}
				
				
				case 3059443:
				{
					if (field.equals("cols")) 
					{
						__temp_executeDef189 = false;
						return this.cols;
					}
					
					break;
				}
				
				
				case 2062069504:
				{
					if (field.equals("indexed_table")) 
					{
						__temp_executeDef189 = false;
						return this.indexed_table;
					}
					
					break;
				}
				
				
				case 118:
				{
					if (field.equals("v")) 
					{
						__temp_executeDef189 = false;
						return this.v;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef189) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef190 = true;
			switch (field.hashCode())
			{
				case -1221029593:
				{
					if (field.equals("height")) 
					{
						__temp_executeDef190 = false;
						return ((double) (this.height) );
					}
					
					break;
				}
				
				
				case -966419678:
				{
					if (field.equals("top_freq")) 
					{
						__temp_executeDef190 = false;
						return ((double) (this.top_freq) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef190) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef191 = true;
			switch (field.hashCode())
			{
				case 1965941272:
				{
					if (field.equals("getTable")) 
					{
						__temp_executeDef191 = false;
						return this.getTable();
					}
					
					break;
				}
				
				
				case -461997225:
				{
					if (field.equals("addColumn")) 
					{
						__temp_executeDef191 = false;
						this.addColumn(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case 676216478:
				{
					if (field.equals("toKeyByContent")) 
					{
						__temp_executeDef191 = false;
						return this.toKeyByContent(((coopy.Row) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case 736417308:
				{
					if (field.equals("indexTable")) 
					{
						__temp_executeDef191 = false;
						this.indexTable(((coopy.Table) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case 110510564:
				{
					if (field.equals("toKey")) 
					{
						__temp_executeDef191 = false;
						return this.toKey(((coopy.Table) (dynargs.__get(0)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef191) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("indexed_table");
		baseArr.push("v");
		baseArr.push("cols");
		baseArr.push("height");
		baseArr.push("top_freq");
		baseArr.push("keys");
		baseArr.push("items");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



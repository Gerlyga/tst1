package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Viterbi extends haxe.lang.HxObject
{
	public    Viterbi(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Viterbi()
	{
		coopy.Viterbi.__hx_ctor_coopy_Viterbi(this);
	}
	
	
	public static   void __hx_ctor_coopy_Viterbi(coopy.Viterbi __temp_me51)
	{
		__temp_me51.K = __temp_me51.T = 0;
		__temp_me51.reset();
		__temp_me51.cost = new coopy.SparseSheet<java.lang.Object>();
		__temp_me51.src = new coopy.SparseSheet<java.lang.Object>();
		__temp_me51.path = new coopy.SparseSheet<java.lang.Object>();
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.Viterbi(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.Viterbi();
	}
	
	
	public  int K;
	
	public  int T;
	
	public  int index;
	
	public  int mode;
	
	public  boolean path_valid;
	
	public  double best_cost;
	
	public  coopy.SparseSheet<java.lang.Object> cost;
	
	public  coopy.SparseSheet<java.lang.Object> src;
	
	public  coopy.SparseSheet<java.lang.Object> path;
	
	public   void reset()
	{
		this.index = 0;
		this.mode = 0;
		this.path_valid = false;
		this.best_cost = ((double) (0) );
	}
	
	
	public   void setSize(int states, int sequence_length)
	{
		this.K = states;
		this.T = sequence_length;
		this.cost.resize(this.K, this.T, 0);
		this.src.resize(this.K, this.T, -1);
		this.path.resize(1, this.T, -1);
	}
	
	
	public   void assertMode(int next)
	{
		if (( ( next == 0 ) && ( this.mode == 1 ) )) 
		{
			this.index++;
		}
		
		this.mode = next;
	}
	
	
	public   void addTransition(int s0, int s1, double c)
	{
		boolean resize = false;
		if (( s0 >= this.K )) 
		{
			this.K = ( s0 + 1 );
			resize = true;
		}
		
		if (( s1 >= this.K )) 
		{
			this.K = ( s1 + 1 );
			resize = true;
		}
		
		if (resize) 
		{
			this.cost.nonDestructiveResize(this.K, this.T, 0);
			this.src.nonDestructiveResize(this.K, this.T, -1);
			this.path.nonDestructiveResize(1, this.T, -1);
		}
		
		this.path_valid = false;
		this.assertMode(1);
		if (( this.index >= this.T )) 
		{
			this.T = ( this.index + 1 );
			this.cost.nonDestructiveResize(this.K, this.T, 0);
			this.src.nonDestructiveResize(this.K, this.T, -1);
			this.path.nonDestructiveResize(1, this.T, -1);
		}
		
		boolean sourced = false;
		if (( this.index > 0 )) 
		{
			c += ((double) (haxe.lang.Runtime.toDouble(this.cost.get(s0, ( this.index - 1 )))) );
			sourced = ( ((int) (haxe.lang.Runtime.toInt(this.src.get(s0, ( this.index - 1 )))) ) != -1 );
		}
		 else 
		{
			sourced = true;
		}
		
		if (sourced) 
		{
			if (( ( c < ((double) (haxe.lang.Runtime.toDouble(this.cost.get(s1, this.index))) ) ) || ( ((int) (haxe.lang.Runtime.toInt(this.src.get(s1, this.index))) ) == -1 ) )) 
			{
				this.cost.set(s1, this.index, c);
				this.src.set(s1, this.index, s0);
			}
			
		}
		
	}
	
	
	public   void endTransitions()
	{
		this.path_valid = false;
		this.assertMode(0);
	}
	
	
	public   void beginTransitions()
	{
		this.path_valid = false;
		this.assertMode(1);
	}
	
	
	public   void calculatePath()
	{
		if (this.path_valid) 
		{
			return ;
		}
		
		this.endTransitions();
		double best = ((double) (0) );
		int bestj = -1;
		if (( this.index <= 0 )) 
		{
			this.path_valid = true;
			return ;
		}
		
		{
			int _g1 = 0;
			int _g = this.K;
			while (( _g1 < _g ))
			{
				int j = _g1++;
				if (( (( ( ((double) (haxe.lang.Runtime.toDouble(this.cost.get(j, ( this.index - 1 )))) ) < best ) || ( bestj == -1 ) )) && ( ((int) (haxe.lang.Runtime.toInt(this.src.get(j, ( this.index - 1 )))) ) != -1 ) )) 
				{
					best = ((double) (haxe.lang.Runtime.toDouble(this.cost.get(j, ( this.index - 1 )))) );
					bestj = j;
				}
				
			}
			
		}
		
		this.best_cost = best;
		{
			int _g11 = 0;
			int _g2 = this.index;
			while (( _g11 < _g2 ))
			{
				int j1 = _g11++;
				int i = ( ( this.index - 1 ) - j1 );
				this.path.set(0, i, bestj);
				if ( ! ((( ( bestj != -1 ) && (( ( bestj >= 0 ) && ( bestj < this.K ) )) ))) ) 
				{
					haxe.Log.trace.__hx_invoke2_o(0.0, "Problem in Viterbi", 0.0, new haxe.lang.DynamicObject(new haxe.root.Array<java.lang.String>(new java.lang.String[]{"className", "fileName", "methodName"}), new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{"coopy.Viterbi", "Viterbi.hx", "calculatePath"}), new haxe.root.Array<java.lang.String>(new java.lang.String[]{"lineNumber"}), new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{((java.lang.Object) (((double) (167) )) )})));
				}
				
				bestj = ((int) (haxe.lang.Runtime.toInt(this.src.get(bestj, i))) );
			}
			
		}
		
		this.path_valid = true;
	}
	
	
	@Override public   java.lang.String toString()
	{
		this.calculatePath();
		java.lang.String txt = "";
		{
			int _g1 = 0;
			int _g = this.index;
			while (( _g1 < _g ))
			{
				int i = _g1++;
				if (( ((int) (haxe.lang.Runtime.toInt(this.path.get(0, i))) ) == -1 )) 
				{
					txt += "*";
				}
				 else 
				{
					txt += haxe.lang.Runtime.toString(((int) (haxe.lang.Runtime.toInt(this.path.get(0, i))) ));
				}
				
				if (( this.K >= 10 )) 
				{
					txt += " ";
				}
				
			}
			
		}
		
		txt += ( " costs " + haxe.lang.Runtime.toString(this.getCost()) );
		return txt;
	}
	
	
	public   int length()
	{
		if (( this.index > 0 )) 
		{
			this.calculatePath();
		}
		
		return this.index;
	}
	
	
	public   int get(int i)
	{
		this.calculatePath();
		return ((int) (haxe.lang.Runtime.toInt(this.path.get(0, i))) );
	}
	
	
	public   double getCost()
	{
		this.calculatePath();
		return this.best_cost;
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef281 = true;
			switch (field.hashCode())
			{
				case 1288790344:
				{
					if (field.equals("best_cost")) 
					{
						__temp_executeDef281 = false;
						this.best_cost = ((double) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 75:
				{
					if (field.equals("K")) 
					{
						__temp_executeDef281 = false;
						this.K = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3357091:
				{
					if (field.equals("mode")) 
					{
						__temp_executeDef281 = false;
						this.mode = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 84:
				{
					if (field.equals("T")) 
					{
						__temp_executeDef281 = false;
						this.T = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 100346066:
				{
					if (field.equals("index")) 
					{
						__temp_executeDef281 = false;
						this.index = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef281) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef282 = true;
			switch (field.hashCode())
			{
				case 3433509:
				{
					if (field.equals("path")) 
					{
						__temp_executeDef282 = false;
						this.path = ((coopy.SparseSheet<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 75:
				{
					if (field.equals("K")) 
					{
						__temp_executeDef282 = false;
						this.K = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 114148:
				{
					if (field.equals("src")) 
					{
						__temp_executeDef282 = false;
						this.src = ((coopy.SparseSheet<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 84:
				{
					if (field.equals("T")) 
					{
						__temp_executeDef282 = false;
						this.T = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 3059661:
				{
					if (field.equals("cost")) 
					{
						__temp_executeDef282 = false;
						this.cost = ((coopy.SparseSheet<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 100346066:
				{
					if (field.equals("index")) 
					{
						__temp_executeDef282 = false;
						this.index = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 1288790344:
				{
					if (field.equals("best_cost")) 
					{
						__temp_executeDef282 = false;
						this.best_cost = ((double) (haxe.lang.Runtime.toDouble(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 3357091:
				{
					if (field.equals("mode")) 
					{
						__temp_executeDef282 = false;
						this.mode = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 1181280098:
				{
					if (field.equals("path_valid")) 
					{
						__temp_executeDef282 = false;
						this.path_valid = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef282) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef283 = true;
			switch (field.hashCode())
			{
				case -75622333:
				{
					if (field.equals("getCost")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getCost"))) );
					}
					
					break;
				}
				
				
				case 75:
				{
					if (field.equals("K")) 
					{
						__temp_executeDef283 = false;
						return this.K;
					}
					
					break;
				}
				
				
				case 102230:
				{
					if (field.equals("get")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("get"))) );
					}
					
					break;
				}
				
				
				case 84:
				{
					if (field.equals("T")) 
					{
						__temp_executeDef283 = false;
						return this.T;
					}
					
					break;
				}
				
				
				case -1106363674:
				{
					if (field.equals("length")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("length"))) );
					}
					
					break;
				}
				
				
				case 100346066:
				{
					if (field.equals("index")) 
					{
						__temp_executeDef283 = false;
						return this.index;
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 3357091:
				{
					if (field.equals("mode")) 
					{
						__temp_executeDef283 = false;
						return this.mode;
					}
					
					break;
				}
				
				
				case -586762069:
				{
					if (field.equals("calculatePath")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("calculatePath"))) );
					}
					
					break;
				}
				
				
				case 1181280098:
				{
					if (field.equals("path_valid")) 
					{
						__temp_executeDef283 = false;
						return this.path_valid;
					}
					
					break;
				}
				
				
				case -1051551403:
				{
					if (field.equals("beginTransitions")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("beginTransitions"))) );
					}
					
					break;
				}
				
				
				case 1288790344:
				{
					if (field.equals("best_cost")) 
					{
						__temp_executeDef283 = false;
						return this.best_cost;
					}
					
					break;
				}
				
				
				case -1949444637:
				{
					if (field.equals("endTransitions")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("endTransitions"))) );
					}
					
					break;
				}
				
				
				case 3059661:
				{
					if (field.equals("cost")) 
					{
						__temp_executeDef283 = false;
						return this.cost;
					}
					
					break;
				}
				
				
				case -1704121130:
				{
					if (field.equals("addTransition")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("addTransition"))) );
					}
					
					break;
				}
				
				
				case 114148:
				{
					if (field.equals("src")) 
					{
						__temp_executeDef283 = false;
						return this.src;
					}
					
					break;
				}
				
				
				case 2090733065:
				{
					if (field.equals("assertMode")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("assertMode"))) );
					}
					
					break;
				}
				
				
				case 3433509:
				{
					if (field.equals("path")) 
					{
						__temp_executeDef283 = false;
						return this.path;
					}
					
					break;
				}
				
				
				case 1984958339:
				{
					if (field.equals("setSize")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setSize"))) );
					}
					
					break;
				}
				
				
				case 108404047:
				{
					if (field.equals("reset")) 
					{
						__temp_executeDef283 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("reset"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef283) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef284 = true;
			switch (field.hashCode())
			{
				case 1288790344:
				{
					if (field.equals("best_cost")) 
					{
						__temp_executeDef284 = false;
						return this.best_cost;
					}
					
					break;
				}
				
				
				case 75:
				{
					if (field.equals("K")) 
					{
						__temp_executeDef284 = false;
						return ((double) (this.K) );
					}
					
					break;
				}
				
				
				case 3357091:
				{
					if (field.equals("mode")) 
					{
						__temp_executeDef284 = false;
						return ((double) (this.mode) );
					}
					
					break;
				}
				
				
				case 84:
				{
					if (field.equals("T")) 
					{
						__temp_executeDef284 = false;
						return ((double) (this.T) );
					}
					
					break;
				}
				
				
				case 100346066:
				{
					if (field.equals("index")) 
					{
						__temp_executeDef284 = false;
						return ((double) (this.index) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef284) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef285 = true;
			switch (field.hashCode())
			{
				case -75622333:
				{
					if (field.equals("getCost")) 
					{
						__temp_executeDef285 = false;
						return this.getCost();
					}
					
					break;
				}
				
				
				case 108404047:
				{
					if (field.equals("reset")) 
					{
						__temp_executeDef285 = false;
						this.reset();
					}
					
					break;
				}
				
				
				case 102230:
				{
					if (field.equals("get")) 
					{
						__temp_executeDef285 = false;
						return this.get(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case 1984958339:
				{
					if (field.equals("setSize")) 
					{
						__temp_executeDef285 = false;
						this.setSize(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case -1106363674:
				{
					if (field.equals("length")) 
					{
						__temp_executeDef285 = false;
						return this.length();
					}
					
					break;
				}
				
				
				case 2090733065:
				{
					if (field.equals("assertMode")) 
					{
						__temp_executeDef285 = false;
						this.assertMode(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef285 = false;
						return this.toString();
					}
					
					break;
				}
				
				
				case -1704121130:
				{
					if (field.equals("addTransition")) 
					{
						__temp_executeDef285 = false;
						this.addTransition(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), ((double) (haxe.lang.Runtime.toDouble(dynargs.__get(2))) ));
					}
					
					break;
				}
				
				
				case -586762069:
				{
					if (field.equals("calculatePath")) 
					{
						__temp_executeDef285 = false;
						this.calculatePath();
					}
					
					break;
				}
				
				
				case -1949444637:
				{
					if (field.equals("endTransitions")) 
					{
						__temp_executeDef285 = false;
						this.endTransitions();
					}
					
					break;
				}
				
				
				case -1051551403:
				{
					if (field.equals("beginTransitions")) 
					{
						__temp_executeDef285 = false;
						this.beginTransitions();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef285) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("path");
		baseArr.push("src");
		baseArr.push("cost");
		baseArr.push("best_cost");
		baseArr.push("path_valid");
		baseArr.push("mode");
		baseArr.push("index");
		baseArr.push("T");
		baseArr.push("K");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



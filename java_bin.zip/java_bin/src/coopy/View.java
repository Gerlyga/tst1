package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  interface View extends haxe.lang.IHxObject
{
	   java.lang.String toString(java.lang.Object d);
	
	   boolean equals(java.lang.Object d1, java.lang.Object d2);
	
	   java.lang.Object toDatum(java.lang.String str);
	
	   java.lang.Object makeHash();
	
	   void hashSet(java.lang.Object h, java.lang.String str, java.lang.Object d);
	
	   boolean isHash(java.lang.Object h);
	
	   boolean hashExists(java.lang.Object h, java.lang.String str);
	
	   java.lang.Object hashGet(java.lang.Object h, java.lang.String str);
	
}



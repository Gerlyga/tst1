package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class SqlTableName extends haxe.lang.HxObject
{
	public    SqlTableName(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    SqlTableName(java.lang.String name, java.lang.String prefix)
	{
		coopy.SqlTableName.__hx_ctor_coopy_SqlTableName(this, name, prefix);
	}
	
	
	public static   void __hx_ctor_coopy_SqlTableName(coopy.SqlTableName __temp_me40, java.lang.String name, java.lang.String prefix)
	{
		if (( prefix == null )) 
		{
			prefix = "";
		}
		
		if (( name == null )) 
		{
			name = "";
		}
		
		__temp_me40.name = name;
		__temp_me40.prefix = prefix;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.SqlTableName(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.SqlTableName(haxe.lang.Runtime.toString(arr.__get(0)), haxe.lang.Runtime.toString(arr.__get(1)));
	}
	
	
	public  java.lang.String name;
	
	public  java.lang.String prefix;
	
	@Override public   java.lang.String toString()
	{
		if (haxe.lang.Runtime.valEq(this.prefix, "")) 
		{
			return this.name;
		}
		
		return ( ( this.prefix + "." ) + this.name );
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef253 = true;
			switch (field.hashCode())
			{
				case -980110702:
				{
					if (field.equals("prefix")) 
					{
						__temp_executeDef253 = false;
						this.prefix = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 3373707:
				{
					if (field.equals("name")) 
					{
						__temp_executeDef253 = false;
						this.name = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef253) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef254 = true;
			switch (field.hashCode())
			{
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef254 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 3373707:
				{
					if (field.equals("name")) 
					{
						__temp_executeDef254 = false;
						return this.name;
					}
					
					break;
				}
				
				
				case -980110702:
				{
					if (field.equals("prefix")) 
					{
						__temp_executeDef254 = false;
						return this.prefix;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef254) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef255 = true;
			switch (field.hashCode())
			{
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef255 = false;
						return this.toString();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef255) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("prefix");
		baseArr.push("name");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



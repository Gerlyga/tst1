package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Csv extends haxe.lang.HxObject
{
	public    Csv(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Csv(java.lang.String delim)
	{
		coopy.Csv.__hx_ctor_coopy_Csv(this, delim);
	}
	
	
	public static   void __hx_ctor_coopy_Csv(coopy.Csv __temp_me18, java.lang.String delim)
	{
		if (( delim == null )) 
		{
			delim = ",";
		}
		
		__temp_me18.cursor = 0;
		__temp_me18.row_ended = false;
		if (( delim == null )) 
		{
			__temp_me18.delim = ",";
		}
		 else 
		{
			__temp_me18.delim = delim;
		}
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.Csv(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.Csv(haxe.lang.Runtime.toString(arr.__get(0)));
	}
	
	
	public  int cursor;
	
	public  boolean row_ended;
	
	public  boolean has_structure;
	
	public  java.lang.String delim;
	
	public   java.lang.String renderTable(coopy.Table t)
	{
		java.lang.String result = "";
		int w = t.get_width();
		int h = t.get_height();
		java.lang.String txt = "";
		coopy.View v = t.getCellView();
		{
			int _g = 0;
			while (( _g < h ))
			{
				int y = _g++;
				{
					int _g1 = 0;
					while (( _g1 < w ))
					{
						int x = _g1++;
						if (( x > 0 )) 
						{
							txt += this.delim;
						}
						
						txt += this.renderCell(v, t.getCell(x, y));
					}
					
				}
				
				txt += "\r\n";
			}
			
		}
		
		return txt;
	}
	
	
	public   java.lang.String renderCell(coopy.View v, java.lang.Object d)
	{
		if (( d == null )) 
		{
			return "NULL";
		}
		
		java.lang.String str = v.toString(d);
		boolean need_quote = false;
		{
			int _g1 = 0;
			int _g = str.length();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				java.lang.String ch = haxe.lang.StringExt.charAt(str, i);
				if (( ( ( ( ( ( haxe.lang.Runtime.valEq(ch, "\"") || haxe.lang.Runtime.valEq(ch, "\'") ) || haxe.lang.Runtime.valEq(ch, this.delim) ) || haxe.lang.Runtime.valEq(ch, "\r") ) || haxe.lang.Runtime.valEq(ch, "\n") ) || haxe.lang.Runtime.valEq(ch, "\t") ) || haxe.lang.Runtime.valEq(ch, " ") )) 
				{
					need_quote = true;
					break;
				}
				
			}
			
		}
		
		java.lang.String result = "";
		if (need_quote) 
		{
			result += "\"";
		}
		
		java.lang.String line_buf = "";
		{
			int _g11 = 0;
			int _g2 = str.length();
			while (( _g11 < _g2 ))
			{
				int i1 = _g11++;
				java.lang.String ch1 = haxe.lang.StringExt.charAt(str, i1);
				if (haxe.lang.Runtime.valEq(ch1, "\"")) 
				{
					result += "\"";
				}
				
				if ((  ! (haxe.lang.Runtime.valEq(ch1, "\r"))  &&  ! (haxe.lang.Runtime.valEq(ch1, "\n"))  )) 
				{
					if (( line_buf.length() > 0 )) 
					{
						result += line_buf;
						line_buf = "";
					}
					
					result += ch1;
				}
				 else 
				{
					line_buf += ch1;
				}
				
			}
			
		}
		
		if (need_quote) 
		{
			result += "\"";
		}
		
		return result;
	}
	
	
	public   boolean parseTable(java.lang.String txt, coopy.Table tab)
	{
		if ( ! (tab.isResizable()) ) 
		{
			return false;
		}
		
		this.cursor = 0;
		this.row_ended = false;
		this.has_structure = true;
		tab.resize(0, 0);
		int w = 0;
		int h = 0;
		int at = 0;
		int yat = 0;
		while (( this.cursor < txt.length() ))
		{
			java.lang.String cell = this.parseCellPart(txt);
			if (( yat >= h )) 
			{
				h = ( yat + 1 );
				tab.resize(w, h);
			}
			
			if (( at >= w )) 
			{
				w = ( at + 1 );
				tab.resize(w, h);
			}
			
			tab.setCell(at, ( h - 1 ), cell);
			at++;
			if (this.row_ended) 
			{
				at = 0;
				yat++;
			}
			
			this.cursor++;
		}
		
		return true;
	}
	
	
	public   coopy.Table makeTable(java.lang.String txt)
	{
		coopy.SimpleTable tab = new coopy.SimpleTable(((int) (0) ), ((int) (0) ));
		this.parseTable(txt, tab);
		return tab;
	}
	
	
	public   java.lang.String parseCellPart(java.lang.String txt)
	{
		if (( txt == null )) 
		{
			return null;
		}
		
		this.row_ended = false;
		int first_non_underscore = txt.length();
		int last_processed = 0;
		boolean quoting = false;
		int quote = 0;
		java.lang.String result = "";
		int start = this.cursor;
		{
			int _g1 = this.cursor;
			int _g = txt.length();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				int ch = ((int) (haxe.lang.Runtime.toInt(haxe.lang.StringExt.charCodeAt(txt, i))) );
				last_processed = i;
				if (( ( ch != 95 ) && ( i < first_non_underscore ) )) 
				{
					first_non_underscore = i;
				}
				
				if (this.has_structure) 
				{
					if ( ! (quoting) ) 
					{
						if (haxe.lang.Runtime.eq(ch, haxe.lang.StringExt.charCodeAt(this.delim, 0))) 
						{
							break;
						}
						
						if (( ( ch == 13 ) || ( ch == 10 ) )) 
						{
							java.lang.Object ch2 = haxe.lang.StringExt.charCodeAt(txt, ( i + 1 ));
							if (( ! (( ch2 == null )) )) 
							{
								if (( ! (haxe.lang.Runtime.eq(ch2, ch)) )) 
								{
									if (( haxe.lang.Runtime.eq(ch2, 13) || haxe.lang.Runtime.eq(ch2, 10) )) 
									{
										last_processed++;
									}
									
								}
								
							}
							
							this.row_ended = true;
							break;
						}
						
						if (( ( ch == 34 ) || ( ch == 39 ) )) 
						{
							if (( i == this.cursor )) 
							{
								quoting = true;
								quote = ch;
								if (( i != start )) 
								{
									result += Character.toString((char) ch);
								}
								
								continue;
							}
							 else 
							{
								if (( ch == quote )) 
								{
									quoting = true;
								}
								
							}
							
						}
						
						result += Character.toString((char) ch);
						continue;
					}
					
					if (( ch == quote )) 
					{
						quoting = false;
						continue;
					}
					
				}
				
				result += Character.toString((char) ch);
			}
			
		}
		
		this.cursor = last_processed;
		if (( quote == 0 )) 
		{
			if (haxe.lang.Runtime.valEq(result, "NULL")) 
			{
				return null;
			}
			
			if (( first_non_underscore > start )) 
			{
				int del = ( first_non_underscore - start );
				if (haxe.lang.Runtime.valEq(haxe.lang.StringExt.substr(result, del, null), "NULL")) 
				{
					return haxe.lang.StringExt.substr(result, 1, null);
				}
				
			}
			
		}
		
		return result;
	}
	
	
	public   java.lang.String parseCell(java.lang.String txt)
	{
		this.cursor = 0;
		this.row_ended = false;
		this.has_structure = false;
		return this.parseCellPart(txt);
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef159 = true;
			switch (field.hashCode())
			{
				case -1349119146:
				{
					if (field.equals("cursor")) 
					{
						__temp_executeDef159 = false;
						this.cursor = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef159) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef160 = true;
			switch (field.hashCode())
			{
				case 95468143:
				{
					if (field.equals("delim")) 
					{
						__temp_executeDef160 = false;
						this.delim = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case -1349119146:
				{
					if (field.equals("cursor")) 
					{
						__temp_executeDef160 = false;
						this.cursor = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 1646576142:
				{
					if (field.equals("has_structure")) 
					{
						__temp_executeDef160 = false;
						this.has_structure = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 1342217237:
				{
					if (field.equals("row_ended")) 
					{
						__temp_executeDef160 = false;
						this.row_ended = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef160) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef161 = true;
			switch (field.hashCode())
			{
				case -1833597259:
				{
					if (field.equals("parseCell")) 
					{
						__temp_executeDef161 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("parseCell"))) );
					}
					
					break;
				}
				
				
				case -1349119146:
				{
					if (field.equals("cursor")) 
					{
						__temp_executeDef161 = false;
						return this.cursor;
					}
					
					break;
				}
				
				
				case -1700856760:
				{
					if (field.equals("parseCellPart")) 
					{
						__temp_executeDef161 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("parseCellPart"))) );
					}
					
					break;
				}
				
				
				case 1342217237:
				{
					if (field.equals("row_ended")) 
					{
						__temp_executeDef161 = false;
						return this.row_ended;
					}
					
					break;
				}
				
				
				case 1255590528:
				{
					if (field.equals("makeTable")) 
					{
						__temp_executeDef161 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("makeTable"))) );
					}
					
					break;
				}
				
				
				case 1646576142:
				{
					if (field.equals("has_structure")) 
					{
						__temp_executeDef161 = false;
						return this.has_structure;
					}
					
					break;
				}
				
				
				case -991368997:
				{
					if (field.equals("parseTable")) 
					{
						__temp_executeDef161 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("parseTable"))) );
					}
					
					break;
				}
				
				
				case 95468143:
				{
					if (field.equals("delim")) 
					{
						__temp_executeDef161 = false;
						return this.delim;
					}
					
					break;
				}
				
				
				case 1193575448:
				{
					if (field.equals("renderCell")) 
					{
						__temp_executeDef161 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("renderCell"))) );
					}
					
					break;
				}
				
				
				case -1638295592:
				{
					if (field.equals("renderTable")) 
					{
						__temp_executeDef161 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("renderTable"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef161) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef162 = true;
			switch (field.hashCode())
			{
				case -1349119146:
				{
					if (field.equals("cursor")) 
					{
						__temp_executeDef162 = false;
						return ((double) (this.cursor) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef162) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef163 = true;
			switch (field.hashCode())
			{
				case -1833597259:
				{
					if (field.equals("parseCell")) 
					{
						__temp_executeDef163 = false;
						return this.parseCell(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -1638295592:
				{
					if (field.equals("renderTable")) 
					{
						__temp_executeDef163 = false;
						return this.renderTable(((coopy.Table) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case -1700856760:
				{
					if (field.equals("parseCellPart")) 
					{
						__temp_executeDef163 = false;
						return this.parseCellPart(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 1193575448:
				{
					if (field.equals("renderCell")) 
					{
						__temp_executeDef163 = false;
						return this.renderCell(((coopy.View) (dynargs.__get(0)) ), dynargs.__get(1));
					}
					
					break;
				}
				
				
				case 1255590528:
				{
					if (field.equals("makeTable")) 
					{
						__temp_executeDef163 = false;
						return this.makeTable(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -991368997:
				{
					if (field.equals("parseTable")) 
					{
						__temp_executeDef163 = false;
						return this.parseTable(haxe.lang.Runtime.toString(dynargs.__get(0)), ((coopy.Table) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef163) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("delim");
		baseArr.push("has_structure");
		baseArr.push("row_ended");
		baseArr.push("cursor");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



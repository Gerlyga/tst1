package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Mover extends haxe.lang.HxObject
{
	public    Mover(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Mover()
	{
		coopy.Mover.__hx_ctor_coopy_Mover(this);
	}
	
	
	public static   void __hx_ctor_coopy_Mover(coopy.Mover __temp_me29)
	{
		{
		}
		
	}
	
	
	public static   haxe.root.Array<java.lang.Object> moveUnits(haxe.root.Array<coopy.Unit> units)
	{
		haxe.root.Array<java.lang.Object> isrc = new haxe.root.Array<java.lang.Object>();
		haxe.root.Array<java.lang.Object> idest = new haxe.root.Array<java.lang.Object>();
		int len = units.length;
		int ltop = -1;
		int rtop = -1;
		haxe.ds.IntMap<java.lang.Object> in_src = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> in_dest = new haxe.ds.IntMap<java.lang.Object>();
		{
			int _g = 0;
			while (( _g < len ))
			{
				int i = _g++;
				coopy.Unit unit = units.__get(i);
				if (( ( unit.l >= 0 ) && ( unit.r >= 0 ) )) 
				{
					if (( ltop < unit.l )) 
					{
						ltop = unit.l;
					}
					
					if (( rtop < unit.r )) 
					{
						rtop = unit.r;
					}
					
					{
						in_src.set(unit.l, i);
						int __temp_expr208 = i;
					}
					
					{
						in_dest.set(unit.r, i);
						int __temp_expr209 = i;
					}
					
				}
				
			}
			
		}
		
		java.lang.Object v = null;
		{
			int _g1 = 0;
			int _g2 = ( ltop + 1 );
			while (( _g1 < _g2 ))
			{
				int i1 = _g1++;
				v = in_src.get(((int) (i1) ));
				if (( ! (( v == null )) )) 
				{
					isrc.push(v);
				}
				
			}
			
		}
		
		{
			int _g11 = 0;
			int _g3 = ( rtop + 1 );
			while (( _g11 < _g3 ))
			{
				int i2 = _g11++;
				v = in_dest.get(((int) (i2) ));
				if (( ! (( v == null )) )) 
				{
					idest.push(v);
				}
				
			}
			
		}
		
		return coopy.Mover.moveWithoutExtras(isrc, idest);
	}
	
	
	public static   haxe.root.Array<java.lang.Object> move(haxe.root.Array<java.lang.Object> isrc, haxe.root.Array<java.lang.Object> idest)
	{
		int len = isrc.length;
		int len2 = idest.length;
		haxe.ds.IntMap<java.lang.Object> in_src = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> in_dest = new haxe.ds.IntMap<java.lang.Object>();
		{
			int _g = 0;
			while (( _g < len ))
			{
				int i = _g++;
				{
					in_src.set(((int) (haxe.lang.Runtime.toInt(isrc.__get(i))) ), i);
					int __temp_expr210 = i;
				}
				
			}
			
		}
		
		{
			int _g1 = 0;
			while (( _g1 < len2 ))
			{
				int i1 = _g1++;
				{
					in_dest.set(((int) (haxe.lang.Runtime.toInt(idest.__get(i1))) ), i1);
					int __temp_expr211 = i1;
				}
				
			}
			
		}
		
		haxe.root.Array<java.lang.Object> src = new haxe.root.Array<java.lang.Object>();
		haxe.root.Array<java.lang.Object> dest = new haxe.root.Array<java.lang.Object>();
		int v = 0;
		{
			int _g2 = 0;
			while (( _g2 < len ))
			{
				int i2 = _g2++;
				v = ((int) (haxe.lang.Runtime.toInt(isrc.__get(i2))) );
				if (in_dest.exists(v)) 
				{
					src.push(v);
				}
				
			}
			
		}
		
		{
			int _g3 = 0;
			while (( _g3 < len2 ))
			{
				int i3 = _g3++;
				v = ((int) (haxe.lang.Runtime.toInt(idest.__get(i3))) );
				if (in_src.exists(v)) 
				{
					dest.push(v);
				}
				
			}
			
		}
		
		return coopy.Mover.moveWithoutExtras(src, dest);
	}
	
	
	public static   haxe.root.Array<java.lang.Object> moveWithoutExtras(haxe.root.Array<java.lang.Object> src, haxe.root.Array<java.lang.Object> dest)
	{
		if (( src.length != dest.length )) 
		{
			return null;
		}
		
		if (( src.length <= 1 )) 
		{
			return new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{});
		}
		
		int len = src.length;
		haxe.ds.IntMap<java.lang.Object> in_src = new haxe.ds.IntMap<java.lang.Object>();
		haxe.root.Array<haxe.ds.IntMap> blk_len = new haxe.root.Array<haxe.ds.IntMap>(new haxe.ds.IntMap[]{((haxe.ds.IntMap) (new haxe.ds.IntMap<java.lang.Object>()) )});
		haxe.ds.IntMap<java.lang.Object> blk_src_loc = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> blk_dest_loc = new haxe.ds.IntMap<java.lang.Object>();
		{
			int _g = 0;
			while (( _g < len ))
			{
				int i = _g++;
				{
					in_src.set(((int) (haxe.lang.Runtime.toInt(src.__get(i))) ), i);
					int __temp_expr212 = i;
				}
				
			}
			
		}
		
		int ct = 0;
		int in_cursor = -2;
		int out_cursor = 0;
		int next = 0;
		int blk = -1;
		int v = 0;
		while (( out_cursor < len ))
		{
			v = ((int) (haxe.lang.Runtime.toInt(dest.__get(out_cursor))) );
			next = ((int) (haxe.lang.Runtime.toInt(in_src.get(((int) (v) )))) );
			if (( next != ( in_cursor + 1 ) )) 
			{
				blk = v;
				ct = 1;
				blk_src_loc.set(blk, next);
				blk_dest_loc.set(blk, out_cursor);
			}
			 else 
			{
				ct++;
			}
			
			((haxe.ds.IntMap<java.lang.Object>) (((haxe.ds.IntMap) (blk_len.__get(0)) )) ).set(blk, ct);
			in_cursor = next;
			out_cursor++;
		}
		
		haxe.root.Array<java.lang.Object> blks = new haxe.root.Array<java.lang.Object>();
		{
			java.lang.Object __temp_iterator92 = ((haxe.ds.IntMap<java.lang.Object>) (((haxe.ds.IntMap) (blk_len.__get(0)) )) ).keys();
			while (haxe.lang.Runtime.toBool(haxe.lang.Runtime.callField(__temp_iterator92, "hasNext", null)))
			{
				int k = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.callField(__temp_iterator92, "next", null))) );
				blks.push(k);
			}
			
		}
		
		blks.sort(new coopy.Mover_moveWithoutExtras_127__Fun(((haxe.root.Array<haxe.ds.IntMap>) (blk_len) )));
		haxe.root.Array<java.lang.Object> moved = new haxe.root.Array<java.lang.Object>();
		while (( blks.length > 0 ))
		{
			int blk1 = ((int) (haxe.lang.Runtime.toInt(blks.shift())) );
			int blen = blks.length;
			int ref_src_loc = ((int) (haxe.lang.Runtime.toInt(blk_src_loc.get(((int) (blk1) )))) );
			int ref_dest_loc = ((int) (haxe.lang.Runtime.toInt(blk_dest_loc.get(((int) (blk1) )))) );
			int i1 = ( blen - 1 );
			while (( i1 >= 0 ))
			{
				int blki = ((int) (haxe.lang.Runtime.toInt(blks.__get(i1))) );
				int blki_src_loc = ((int) (haxe.lang.Runtime.toInt(blk_src_loc.get(((int) (blki) )))) );
				boolean to_left_src = ( blki_src_loc < ref_src_loc );
				boolean to_left_dest = ( haxe.lang.Runtime.compare(blk_dest_loc.get(((int) (blki) )), ref_dest_loc) < 0 );
				if (( to_left_src != to_left_dest )) 
				{
					int ct1 = ((int) (haxe.lang.Runtime.toInt(((haxe.ds.IntMap<java.lang.Object>) (((haxe.ds.IntMap) (blk_len.__get(0)) )) ).get(((int) (blki) )))) );
					{
						int _g1 = 0;
						while (( _g1 < ct1 ))
						{
							int j = _g1++;
							moved.push(((int) (haxe.lang.Runtime.toInt(src.__get(blki_src_loc))) ));
							blki_src_loc++;
						}
						
					}
					
					blks.splice(i1, 1);
				}
				
				i1--;
			}
			
		}
		
		return moved;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.Mover(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.Mover();
	}
	
	
}



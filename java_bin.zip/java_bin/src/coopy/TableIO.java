package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class TableIO extends haxe.lang.HxObject
{
	public    TableIO(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    TableIO()
	{
		coopy.TableIO.__hx_ctor_coopy_TableIO(this);
	}
	
	
	public static   void __hx_ctor_coopy_TableIO(coopy.TableIO __temp_me44)
	{
		{
		}
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.TableIO(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.TableIO();
	}
	
	
	public   java.lang.String getContent(java.lang.String name)
	{
		return sys.io.File.getContent(name);
	}
	
	
	public   boolean saveContent(java.lang.String name, java.lang.String txt)
	{
		sys.io.File.saveContent(name, txt);
		return true;
	}
	
	
	public   haxe.root.Array<java.lang.String> args()
	{
		return haxe.root.Sys.args();
	}
	
	
	public   void writeStdout(java.lang.String txt)
	{
		haxe.root.Sys.stdout().writeString(txt);
	}
	
	
	public   void writeStderr(java.lang.String txt)
	{
		haxe.root.Sys.stderr().writeString(txt);
	}
	
	
	public   int command(java.lang.String cmd, haxe.root.Array<java.lang.String> args)
	{
		try 
		{
			return haxe.root.Sys.command(cmd, args);
		}
		catch (java.lang.Throwable __temp_catchallException266)
		{
			java.lang.Object __temp_catchall267 = __temp_catchallException266;
			if (( __temp_catchall267 instanceof haxe.lang.HaxeException )) 
			{
				__temp_catchall267 = ((haxe.lang.HaxeException) (__temp_catchallException266) ).obj;
			}
			
			{
				java.lang.Object e = __temp_catchall267;
				return 1;
			}
			
		}
		
		
	}
	
	
	public   boolean async()
	{
		return false;
	}
	
	
	public   boolean exists(java.lang.String path)
	{
		return sys.FileSystem.exists(path);
	}
	
	
	public   coopy.SqlDatabase openSqliteDatabase(java.lang.String path)
	{
		return null;
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef268 = true;
			switch (field.hashCode())
			{
				case -1834077551:
				{
					if (field.equals("openSqliteDatabase")) 
					{
						__temp_executeDef268 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("openSqliteDatabase"))) );
					}
					
					break;
				}
				
				
				case 1988390979:
				{
					if (field.equals("getContent")) 
					{
						__temp_executeDef268 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getContent"))) );
					}
					
					break;
				}
				
				
				case -1289358244:
				{
					if (field.equals("exists")) 
					{
						__temp_executeDef268 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("exists"))) );
					}
					
					break;
				}
				
				
				case 1642189884:
				{
					if (field.equals("saveContent")) 
					{
						__temp_executeDef268 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("saveContent"))) );
					}
					
					break;
				}
				
				
				case 93127292:
				{
					if (field.equals("async")) 
					{
						__temp_executeDef268 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("async"))) );
					}
					
					break;
				}
				
				
				case 3002589:
				{
					if (field.equals("args")) 
					{
						__temp_executeDef268 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("args"))) );
					}
					
					break;
				}
				
				
				case 950394699:
				{
					if (field.equals("command")) 
					{
						__temp_executeDef268 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("command"))) );
					}
					
					break;
				}
				
				
				case 1411824394:
				{
					if (field.equals("writeStdout")) 
					{
						__temp_executeDef268 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("writeStdout"))) );
					}
					
					break;
				}
				
				
				case 1411814689:
				{
					if (field.equals("writeStderr")) 
					{
						__temp_executeDef268 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("writeStderr"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef268) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef269 = true;
			switch (field.hashCode())
			{
				case -1834077551:
				{
					if (field.equals("openSqliteDatabase")) 
					{
						__temp_executeDef269 = false;
						return this.openSqliteDatabase(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 1988390979:
				{
					if (field.equals("getContent")) 
					{
						__temp_executeDef269 = false;
						return this.getContent(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -1289358244:
				{
					if (field.equals("exists")) 
					{
						__temp_executeDef269 = false;
						return this.exists(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 1642189884:
				{
					if (field.equals("saveContent")) 
					{
						__temp_executeDef269 = false;
						return this.saveContent(haxe.lang.Runtime.toString(dynargs.__get(0)), haxe.lang.Runtime.toString(dynargs.__get(1)));
					}
					
					break;
				}
				
				
				case 93127292:
				{
					if (field.equals("async")) 
					{
						__temp_executeDef269 = false;
						return this.async();
					}
					
					break;
				}
				
				
				case 3002589:
				{
					if (field.equals("args")) 
					{
						__temp_executeDef269 = false;
						return this.args();
					}
					
					break;
				}
				
				
				case 950394699:
				{
					if (field.equals("command")) 
					{
						__temp_executeDef269 = false;
						return this.command(haxe.lang.Runtime.toString(dynargs.__get(0)), ((haxe.root.Array<java.lang.String>) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case 1411824394:
				{
					if (field.equals("writeStdout")) 
					{
						__temp_executeDef269 = false;
						this.writeStdout(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 1411814689:
				{
					if (field.equals("writeStderr")) 
					{
						__temp_executeDef269 = false;
						this.writeStderr(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef269) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
}



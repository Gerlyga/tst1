package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Unit extends haxe.lang.HxObject
{
	public    Unit(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Unit(java.lang.Object l, java.lang.Object r, java.lang.Object p)
	{
		coopy.Unit.__hx_ctor_coopy_Unit(this, l, r, p);
	}
	
	
	public static   void __hx_ctor_coopy_Unit(coopy.Unit __temp_me50, java.lang.Object l, java.lang.Object r, java.lang.Object p)
	{
		int __temp_p49 = ( (( p == null )) ? (((int) (-2) )) : (((int) (haxe.lang.Runtime.toInt(p)) )) );
		int __temp_r48 = ( (( r == null )) ? (((int) (-2) )) : (((int) (haxe.lang.Runtime.toInt(r)) )) );
		int __temp_l47 = ( (( l == null )) ? (((int) (-2) )) : (((int) (haxe.lang.Runtime.toInt(l)) )) );
		__temp_me50.l = __temp_l47;
		__temp_me50.r = __temp_r48;
		__temp_me50.p = __temp_p49;
	}
	
	
	public static   java.lang.String describe(int i)
	{
		if (( i >= 0 )) 
		{
			return ( "" + i );
		}
		 else 
		{
			return "-";
		}
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.Unit(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.Unit(((java.lang.Object) (arr.__get(0)) ), ((java.lang.Object) (arr.__get(1)) ), ((java.lang.Object) (arr.__get(2)) ));
	}
	
	
	public  int l;
	
	public  int r;
	
	public  int p;
	
	public   int lp()
	{
		if (( this.p == -2 )) 
		{
			return this.l;
		}
		 else 
		{
			return this.p;
		}
		
	}
	
	
	@Override public   java.lang.String toString()
	{
		if (( this.p >= -1 )) 
		{
			return ( ( ( ( coopy.Unit.describe(this.p) + "|" ) + coopy.Unit.describe(this.l) ) + ":" ) + coopy.Unit.describe(this.r) );
		}
		
		return ( ( coopy.Unit.describe(this.l) + ":" ) + coopy.Unit.describe(this.r) );
	}
	
	
	public   boolean fromString(java.lang.String txt)
	{
		txt += "]";
		int at = 0;
		{
			int _g1 = 0;
			int _g = txt.length();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				int ch = ((int) (haxe.lang.Runtime.toInt(haxe.lang.StringExt.charCodeAt(txt, i))) );
				if (( ( ch >= 48 ) && ( ch <= 57 ) )) 
				{
					at *= 10;
					at += ( ch - 48 );
				}
				 else 
				{
					if (( ch == 45 )) 
					{
						at = -1;
					}
					 else 
					{
						if (( ch == 124 )) 
						{
							this.p = at;
							at = 0;
						}
						 else 
						{
							if (( ch == 58 )) 
							{
								this.l = at;
								at = 0;
							}
							 else 
							{
								if (( ch == 93 )) 
								{
									this.r = at;
									return true;
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		return false;
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef276 = true;
			switch (field.hashCode())
			{
				case 112:
				{
					if (field.equals("p")) 
					{
						__temp_executeDef276 = false;
						this.p = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 108:
				{
					if (field.equals("l")) 
					{
						__temp_executeDef276 = false;
						this.l = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 114:
				{
					if (field.equals("r")) 
					{
						__temp_executeDef276 = false;
						this.r = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef276) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef277 = true;
			switch (field.hashCode())
			{
				case 112:
				{
					if (field.equals("p")) 
					{
						__temp_executeDef277 = false;
						this.p = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 108:
				{
					if (field.equals("l")) 
					{
						__temp_executeDef277 = false;
						this.l = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 114:
				{
					if (field.equals("r")) 
					{
						__temp_executeDef277 = false;
						this.r = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef277) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef278 = true;
			switch (field.hashCode())
			{
				case -2136966053:
				{
					if (field.equals("fromString")) 
					{
						__temp_executeDef278 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("fromString"))) );
					}
					
					break;
				}
				
				
				case 108:
				{
					if (field.equals("l")) 
					{
						__temp_executeDef278 = false;
						return this.l;
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef278 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 114:
				{
					if (field.equals("r")) 
					{
						__temp_executeDef278 = false;
						return this.r;
					}
					
					break;
				}
				
				
				case 3460:
				{
					if (field.equals("lp")) 
					{
						__temp_executeDef278 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("lp"))) );
					}
					
					break;
				}
				
				
				case 112:
				{
					if (field.equals("p")) 
					{
						__temp_executeDef278 = false;
						return this.p;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef278) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef279 = true;
			switch (field.hashCode())
			{
				case 112:
				{
					if (field.equals("p")) 
					{
						__temp_executeDef279 = false;
						return ((double) (this.p) );
					}
					
					break;
				}
				
				
				case 108:
				{
					if (field.equals("l")) 
					{
						__temp_executeDef279 = false;
						return ((double) (this.l) );
					}
					
					break;
				}
				
				
				case 114:
				{
					if (field.equals("r")) 
					{
						__temp_executeDef279 = false;
						return ((double) (this.r) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef279) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef280 = true;
			switch (field.hashCode())
			{
				case -2136966053:
				{
					if (field.equals("fromString")) 
					{
						__temp_executeDef280 = false;
						return this.fromString(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 3460:
				{
					if (field.equals("lp")) 
					{
						__temp_executeDef280 = false;
						return this.lp();
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef280 = false;
						return this.toString();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef280) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("p");
		baseArr.push("r");
		baseArr.push("l");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



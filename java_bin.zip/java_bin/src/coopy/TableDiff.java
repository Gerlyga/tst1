package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class TableDiff extends haxe.lang.HxObject
{
	public    TableDiff(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    TableDiff(coopy.Alignment align, coopy.CompareFlags flags)
	{
		coopy.TableDiff.__hx_ctor_coopy_TableDiff(this, align, flags);
	}
	
	
	public static   void __hx_ctor_coopy_TableDiff(coopy.TableDiff __temp_me43, coopy.Alignment align, coopy.CompareFlags flags)
	{
		__temp_me43.align = align;
		__temp_me43.flags = flags;
		__temp_me43.builder = null;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.TableDiff(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.TableDiff(((coopy.Alignment) (arr.__get(0)) ), ((coopy.CompareFlags) (arr.__get(1)) ));
	}
	
	
	public  coopy.Alignment align;
	
	public  coopy.CompareFlags flags;
	
	public  coopy.CellBuilder builder;
	
	public   void setCellBuilder(coopy.CellBuilder builder)
	{
		this.builder = builder;
	}
	
	
	public   java.lang.String getSeparator(coopy.Table t, coopy.Table t2, java.lang.String root)
	{
		java.lang.String sep = root;
		int w = t.get_width();
		int h = t.get_height();
		coopy.View view = t.getCellView();
		{
			int _g = 0;
			while (( _g < h ))
			{
				int y = _g++;
				{
					int _g1 = 0;
					while (( _g1 < w ))
					{
						int x = _g1++;
						java.lang.String txt = view.toString(t.getCell(x, y));
						if (( txt == null )) 
						{
							continue;
						}
						
						while (( haxe.lang.StringExt.indexOf(txt, sep, null) >= 0 ))
						{
							sep = ( "-" + sep );
						}
						
					}
					
				}
				
			}
			
		}
		
		if (( t2 != null )) 
		{
			w = t2.get_width();
			h = t2.get_height();
			{
				int _g2 = 0;
				while (( _g2 < h ))
				{
					int y1 = _g2++;
					{
						int _g11 = 0;
						while (( _g11 < w ))
						{
							int x1 = _g11++;
							java.lang.String txt1 = view.toString(t2.getCell(x1, y1));
							if (( txt1 == null )) 
							{
								continue;
							}
							
							while (( haxe.lang.StringExt.indexOf(txt1, sep, null) >= 0 ))
							{
								sep = ( "-" + sep );
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		return sep;
	}
	
	
	public   java.lang.String quoteForDiff(coopy.View v, java.lang.Object d)
	{
		java.lang.String nil = "NULL";
		if (v.equals(d, null)) 
		{
			return nil;
		}
		
		java.lang.String str = v.toString(d);
		int score = 0;
		{
			int _g1 = 0;
			int _g = str.length();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				if (( ! (haxe.lang.Runtime.eq(haxe.lang.StringExt.charCodeAt(str, score), 95)) )) 
				{
					break;
				}
				
				score++;
			}
			
		}
		
		if (haxe.lang.Runtime.valEq(haxe.lang.StringExt.substr(str, score, null), nil)) 
		{
			str = ( "_" + str );
		}
		
		return str;
	}
	
	
	public   boolean isReordered(haxe.ds.IntMap<coopy.Unit> m, int ct)
	{
		boolean reordered = false;
		int l = -1;
		int r = -1;
		{
			int _g = 0;
			while (( _g < ct ))
			{
				int i = _g++;
				coopy.Unit unit = m.get(((int) (i) ));
				if (( unit == null )) 
				{
					continue;
				}
				
				if (( unit.l >= 0 )) 
				{
					if (( unit.l < l )) 
					{
						reordered = true;
						break;
					}
					
					l = unit.l;
				}
				
				if (( unit.r >= 0 )) 
				{
					if (( unit.r < r )) 
					{
						reordered = true;
						break;
					}
					
					r = unit.r;
				}
				
			}
			
		}
		
		return reordered;
	}
	
	
	public   void spreadContext(haxe.root.Array<coopy.Unit> units, int del, haxe.root.Array<java.lang.Object> active)
	{
		if (( ( del > 0 ) && ( active != null ) )) 
		{
			int mark = (  - (del)  - 1 );
			int skips = 0;
			{
				int _g1 = 0;
				int _g = units.length;
				while (( _g1 < _g ))
				{
					int i = _g1++;
					if (( ((int) (haxe.lang.Runtime.toInt(active.__get(i))) ) == -3 )) 
					{
						skips++;
						continue;
					}
					
					if (( ( ((int) (haxe.lang.Runtime.toInt(active.__get(i))) ) == 0 ) || ( ((int) (haxe.lang.Runtime.toInt(active.__get(i))) ) == 3 ) )) 
					{
						if (( ( i - mark ) <= ( del + skips ) )) 
						{
							active.__set(i, 2);
						}
						 else 
						{
							if (( ( i - mark ) == ( ( del + 1 ) + skips ) )) 
							{
								active.__set(i, 3);
							}
							
						}
						
					}
					 else 
					{
						if (( ((int) (haxe.lang.Runtime.toInt(active.__get(i))) ) == 1 )) 
						{
							mark = i;
							skips = 0;
						}
						
					}
					
				}
				
			}
			
			mark = ( ( units.length + del ) + 1 );
			skips = 0;
			{
				int _g11 = 0;
				int _g2 = units.length;
				while (( _g11 < _g2 ))
				{
					int j = _g11++;
					int i1 = ( ( units.length - 1 ) - j );
					if (( ((int) (haxe.lang.Runtime.toInt(active.__get(i1))) ) == -3 )) 
					{
						skips++;
						continue;
					}
					
					if (( ( ((int) (haxe.lang.Runtime.toInt(active.__get(i1))) ) == 0 ) || ( ((int) (haxe.lang.Runtime.toInt(active.__get(i1))) ) == 3 ) )) 
					{
						if (( ( mark - i1 ) <= ( del + skips ) )) 
						{
							active.__set(i1, 2);
						}
						 else 
						{
							if (( ( mark - i1 ) == ( ( del + 1 ) + skips ) )) 
							{
								active.__set(i1, 3);
							}
							
						}
						
					}
					 else 
					{
						if (( ((int) (haxe.lang.Runtime.toInt(active.__get(i1))) ) == 1 )) 
						{
							mark = i1;
							skips = 0;
						}
						
					}
					
				}
				
			}
			
		}
		
	}
	
	
	public   void setIgnore(haxe.ds.StringMap<java.lang.Object> ignore, haxe.ds.IntMap<java.lang.Object> idx_ignore, coopy.Table tab, int r_header)
	{
		coopy.View v = tab.getCellView();
		if (( tab.get_height() >= r_header )) 
		{
			int _g1 = 0;
			int _g = tab.get_width();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				java.lang.String name = v.toString(tab.getCell(i, r_header));
				if ( ! (ignore.exists(name)) ) 
				{
					continue;
				}
				
				idx_ignore.set(i, true);
			}
			
		}
		
	}
	
	
	public   int countActive(haxe.root.Array<java.lang.Object> active)
	{
		int ct = 0;
		boolean showed_dummy = false;
		{
			int _g1 = 0;
			int _g = active.length;
			while (( _g1 < _g ))
			{
				int i = _g1++;
				boolean publish = ( ((int) (haxe.lang.Runtime.toInt(active.__get(i))) ) > 0 );
				boolean dummy = ( ((int) (haxe.lang.Runtime.toInt(active.__get(i))) ) == 3 );
				if (( dummy && showed_dummy )) 
				{
					continue;
				}
				
				if ( ! (publish) ) 
				{
					continue;
				}
				
				showed_dummy = dummy;
				ct++;
			}
			
		}
		
		return ct;
	}
	
	
	public   boolean hilite(coopy.Table output)
	{
		if ( ! (output.isResizable()) ) 
		{
			return false;
		}
		
		if (( this.builder == null )) 
		{
			if (this.flags.allow_nested_cells) 
			{
				this.builder = new coopy.NestedCellBuilder();
			}
			 else 
			{
				this.builder = new coopy.FlatCellBuilder();
			}
			
		}
		
		output.resize(0, 0);
		output.clear();
		haxe.ds.IntMap<coopy.Unit> row_map = new haxe.ds.IntMap<coopy.Unit>();
		haxe.ds.IntMap<coopy.Unit> col_map = new haxe.ds.IntMap<coopy.Unit>();
		coopy.Ordering order = this.align.toOrder();
		haxe.root.Array<coopy.Unit> units = order.getList();
		boolean has_parent = ( this.align.reference != null );
		coopy.Table a = null;
		coopy.Table b = null;
		coopy.Table p = null;
		int rp_header = 0;
		int ra_header = 0;
		int rb_header = 0;
		haxe.ds.IntMap<java.lang.Object> is_index_p = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> is_index_a = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> is_index_b = new haxe.ds.IntMap<java.lang.Object>();
		if (has_parent) 
		{
			p = this.align.getSource();
			a = this.align.reference.getTarget();
			b = this.align.getTarget();
			rp_header = this.align.reference.meta.getSourceHeader();
			ra_header = this.align.reference.meta.getTargetHeader();
			rb_header = this.align.meta.getTargetHeader();
			if (( this.align.getIndexColumns() != null )) 
			{
				int _g = 0;
				haxe.root.Array<coopy.Unit> _g1 = this.align.getIndexColumns();
				while (( _g < _g1.length ))
				{
					coopy.Unit p2b = _g1.__get(_g);
					 ++ _g;
					if (( p2b.l >= 0 )) 
					{
						is_index_p.set(p2b.l, true);
					}
					
					if (( p2b.r >= 0 )) 
					{
						is_index_b.set(p2b.r, true);
					}
					
				}
				
			}
			
			if (( this.align.reference.getIndexColumns() != null )) 
			{
				int _g2 = 0;
				haxe.root.Array<coopy.Unit> _g11 = this.align.reference.getIndexColumns();
				while (( _g2 < _g11.length ))
				{
					coopy.Unit p2a = _g11.__get(_g2);
					 ++ _g2;
					if (( p2a.l >= 0 )) 
					{
						is_index_p.set(p2a.l, true);
					}
					
					if (( p2a.r >= 0 )) 
					{
						is_index_a.set(p2a.r, true);
					}
					
				}
				
			}
			
		}
		 else 
		{
			a = this.align.getSource();
			b = this.align.getTarget();
			p = a;
			ra_header = this.align.meta.getSourceHeader();
			rp_header = ra_header;
			rb_header = this.align.meta.getTargetHeader();
			if (( this.align.getIndexColumns() != null )) 
			{
				int _g3 = 0;
				haxe.root.Array<coopy.Unit> _g12 = this.align.getIndexColumns();
				while (( _g3 < _g12.length ))
				{
					coopy.Unit a2b = _g12.__get(_g3);
					 ++ _g3;
					if (( a2b.l >= 0 )) 
					{
						is_index_a.set(a2b.l, true);
					}
					
					if (( a2b.r >= 0 )) 
					{
						is_index_b.set(a2b.r, true);
					}
					
				}
				
			}
			
		}
		
		coopy.Ordering column_order = this.align.meta.toOrder();
		haxe.root.Array<coopy.Unit> column_units = column_order.getList();
		haxe.ds.IntMap<java.lang.Object> p_ignore = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> a_ignore = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> b_ignore = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.StringMap<java.lang.Object> ignore = this.flags.getIgnoredColumns();
		if (( ignore != null )) 
		{
			this.setIgnore(ignore, p_ignore, p, rp_header);
			this.setIgnore(ignore, a_ignore, a, ra_header);
			this.setIgnore(ignore, b_ignore, b, rb_header);
			haxe.root.Array<coopy.Unit> ncolumn_units = new haxe.root.Array<coopy.Unit>();
			{
				int _g13 = 0;
				int _g4 = column_units.length;
				while (( _g13 < _g4 ))
				{
					int j = _g13++;
					coopy.Unit cunit = column_units.__get(j);
					if (( ( p_ignore.exists(cunit.p) || a_ignore.exists(cunit.l) ) || b_ignore.exists(cunit.r) )) 
					{
						continue;
					}
					
					ncolumn_units.push(cunit);
				}
				
			}
			
			column_units = ncolumn_units;
		}
		
		boolean show_rc_numbers = false;
		haxe.ds.IntMap<java.lang.Object> row_moves = null;
		haxe.ds.IntMap<java.lang.Object> col_moves = null;
		if (this.flags.ordered) 
		{
			row_moves = new haxe.ds.IntMap<java.lang.Object>();
			haxe.root.Array<java.lang.Object> moves = coopy.Mover.moveUnits(units);
			{
				int _g14 = 0;
				int _g5 = moves.length;
				while (( _g14 < _g5 ))
				{
					int i = _g14++;
					{
						row_moves.set(((int) (haxe.lang.Runtime.toInt(moves.__get(i))) ), i);
						int __temp_expr261 = i;
					}
					
				}
				
			}
			
			col_moves = new haxe.ds.IntMap<java.lang.Object>();
			moves = coopy.Mover.moveUnits(column_units);
			{
				int _g15 = 0;
				int _g6 = moves.length;
				while (( _g15 < _g6 ))
				{
					int i1 = _g15++;
					{
						col_moves.set(((int) (haxe.lang.Runtime.toInt(moves.__get(i1))) ), i1);
						int __temp_expr262 = i1;
					}
					
				}
				
			}
			
		}
		
		haxe.root.Array<java.lang.Object> active = new haxe.root.Array<java.lang.Object>();
		haxe.root.Array<java.lang.Object> active_column = null;
		if ( ! (this.flags.show_unchanged) ) 
		{
			int _g16 = 0;
			int _g7 = units.length;
			while (( _g16 < _g7 ))
			{
				int i2 = _g16++;
				active.__set(( ( units.length - 1 ) - i2 ), 0);
			}
			
		}
		
		boolean allow_insert = this.flags.allowInsert();
		boolean allow_delete = this.flags.allowDelete();
		boolean allow_update = this.flags.allowUpdate();
		if ( ! (this.flags.show_unchanged_columns) ) 
		{
			active_column = new haxe.root.Array<java.lang.Object>();
			{
				int _g17 = 0;
				int _g8 = column_units.length;
				while (( _g17 < _g8 ))
				{
					int i3 = _g17++;
					int v = 0;
					coopy.Unit unit = column_units.__get(i3);
					if (( haxe.lang.Runtime.toBool(( unit.l >= 0 )) && haxe.lang.Runtime.toBool(is_index_a.get(((int) (unit.l) ))) )) 
					{
						v = 1;
					}
					
					if (( haxe.lang.Runtime.toBool(( unit.r >= 0 )) && haxe.lang.Runtime.toBool(is_index_b.get(((int) (unit.r) ))) )) 
					{
						v = 1;
					}
					
					if (( haxe.lang.Runtime.toBool(( unit.p >= 0 )) && haxe.lang.Runtime.toBool(is_index_p.get(((int) (unit.p) ))) )) 
					{
						v = 1;
					}
					
					active_column.__set(i3, v);
				}
				
			}
			
		}
		
		coopy.View v1 = a.getCellView();
		this.builder.setView(v1);
		int outer_reps_needed = 0;
		if (( this.flags.show_unchanged && this.flags.show_unchanged_columns )) 
		{
			outer_reps_needed = 1;
		}
		 else 
		{
			outer_reps_needed = 2;
		}
		
		java.lang.String sep = "";
		java.lang.String conflict_sep = "";
		haxe.root.Array<java.lang.String> schema = new haxe.root.Array<java.lang.String>();
		boolean have_schema = false;
		{
			int _g18 = 0;
			int _g9 = column_units.length;
			while (( _g18 < _g9 ))
			{
				int j1 = _g18++;
				coopy.Unit cunit1 = column_units.__get(j1);
				boolean reordered = false;
				if (this.flags.ordered) 
				{
					if (col_moves.exists(j1)) 
					{
						reordered = true;
					}
					
					if (reordered) 
					{
						show_rc_numbers = true;
					}
					
				}
				
				java.lang.String act = "";
				if (( ( cunit1.r >= 0 ) && ( cunit1.lp() == -1 ) )) 
				{
					have_schema = true;
					act = "+++";
					if (( active_column != null )) 
					{
						if (allow_update) 
						{
							active_column.__set(j1, 1);
						}
						
					}
					
				}
				
				if (( ( cunit1.r < 0 ) && ( cunit1.lp() >= 0 ) )) 
				{
					have_schema = true;
					act = "---";
					if (( active_column != null )) 
					{
						if (allow_update) 
						{
							active_column.__set(j1, 1);
						}
						
					}
					
				}
				
				if (( ( cunit1.r >= 0 ) && ( cunit1.lp() >= 0 ) )) 
				{
					if (( ( p.get_height() >= rp_header ) && ( b.get_height() >= rb_header ) )) 
					{
						java.lang.Object pp = p.getCell(cunit1.lp(), rp_header);
						java.lang.Object bb = b.getCell(cunit1.r, rb_header);
						if ( ! (v1.equals(pp, bb)) ) 
						{
							have_schema = true;
							act = "(";
							act += v1.toString(pp);
							act += ")";
							if (( active_column != null )) 
							{
								active_column.__set(j1, 1);
							}
							
						}
						
					}
					
				}
				
				if (reordered) 
				{
					act = ( ":" + act );
					have_schema = true;
					if (( active_column != null )) 
					{
						active_column = null;
					}
					
				}
				
				schema.push(act);
			}
			
		}
		
		if (have_schema) 
		{
			int at = output.get_height();
			output.resize(( column_units.length + 1 ), ( at + 1 ));
			output.setCell(0, at, this.builder.marker("!"));
			{
				int _g19 = 0;
				int _g10 = column_units.length;
				while (( _g19 < _g10 ))
				{
					int j2 = _g19++;
					output.setCell(( j2 + 1 ), at, v1.toDatum(schema.__get(j2)));
				}
				
			}
			
		}
		
		boolean top_line_done = false;
		if (this.flags.always_show_header) 
		{
			int at1 = output.get_height();
			output.resize(( column_units.length + 1 ), ( at1 + 1 ));
			output.setCell(0, at1, this.builder.marker("@@"));
			{
				int _g110 = 0;
				int _g20 = column_units.length;
				while (( _g110 < _g20 ))
				{
					int j3 = _g110++;
					coopy.Unit cunit2 = column_units.__get(j3);
					if (( cunit2.r >= 0 )) 
					{
						if (( b.get_height() != 0 )) 
						{
							output.setCell(( j3 + 1 ), at1, b.getCell(cunit2.r, rb_header));
						}
						
					}
					 else 
					{
						if (( cunit2.lp() >= 0 )) 
						{
							if (( p.get_height() != 0 )) 
							{
								output.setCell(( j3 + 1 ), at1, p.getCell(cunit2.lp(), rp_header));
							}
							
						}
						
					}
					
					col_map.set(( j3 + 1 ), cunit2);
				}
				
			}
			
			top_line_done = true;
		}
		
		int output_height = output.get_height();
		int output_height_init = output.get_height();
		{
			int _g21 = 0;
			while (( _g21 < outer_reps_needed ))
			{
				int out = _g21++;
				if (( out == 1 )) 
				{
					this.spreadContext(units, this.flags.unchanged_context, active);
					this.spreadContext(column_units, this.flags.unchanged_column_context, active_column);
					if (( active_column != null )) 
					{
						int _g22 = 0;
						int _g111 = column_units.length;
						while (( _g22 < _g111 ))
						{
							int i4 = _g22++;
							if (( ((int) (haxe.lang.Runtime.toInt(active_column.__get(i4))) ) == 3 )) 
							{
								active_column.__set(i4, 0);
							}
							
						}
						
					}
					
					int rows = ( this.countActive(active) + output_height_init );
					if (top_line_done) 
					{
						rows--;
					}
					
					output_height = output_height_init;
					if (( rows > output.get_height() )) 
					{
						output.resize(( column_units.length + 1 ), rows);
					}
					
				}
				
				boolean showed_dummy = false;
				int l = -1;
				int r = -1;
				{
					int _g23 = 0;
					int _g112 = units.length;
					while (( _g23 < _g112 ))
					{
						int i5 = _g23++;
						coopy.Unit unit1 = units.__get(i5);
						boolean reordered1 = false;
						if (this.flags.ordered) 
						{
							if (row_moves.exists(i5)) 
							{
								reordered1 = true;
							}
							
							if (reordered1) 
							{
								show_rc_numbers = true;
							}
							
						}
						
						if (( ( unit1.r < 0 ) && ( unit1.l < 0 ) )) 
						{
							continue;
						}
						
						if (( ( ( unit1.r == 0 ) && ( unit1.lp() == 0 ) ) && top_line_done )) 
						{
							continue;
						}
						
						java.lang.String act1 = "";
						if (reordered1) 
						{
							act1 = ":";
						}
						
						boolean publish = this.flags.show_unchanged;
						boolean dummy = false;
						if (( out == 1 )) 
						{
							publish = ( ((int) (haxe.lang.Runtime.toInt(active.__get(i5))) ) > 0 );
							dummy = ( ((int) (haxe.lang.Runtime.toInt(active.__get(i5))) ) == 3 );
							if (( dummy && showed_dummy )) 
							{
								continue;
							}
							
							if ( ! (publish) ) 
							{
								continue;
							}
							
						}
						
						if ( ! (dummy) ) 
						{
							showed_dummy = false;
						}
						
						int at2 = output_height;
						if (publish) 
						{
							output_height++;
							if (( output.get_height() < output_height )) 
							{
								output.resize(( column_units.length + 1 ), output_height);
							}
							
						}
						
						if (dummy) 
						{
							{
								int _g41 = 0;
								int _g31 = ( column_units.length + 1 );
								while (( _g41 < _g31 ))
								{
									int j4 = _g41++;
									output.setCell(j4, at2, v1.toDatum("..."));
								}
								
							}
							
							showed_dummy = true;
							continue;
						}
						
						boolean have_addition = false;
						boolean skip = false;
						if (( ( ( unit1.p < 0 ) && ( unit1.l < 0 ) ) && ( unit1.r >= 0 ) )) 
						{
							if ( ! (allow_insert) ) 
							{
								skip = true;
							}
							
							act1 = "+++";
						}
						
						if (( ( (( ( unit1.p >= 0 ) ||  ! (has_parent)  )) && ( unit1.l >= 0 ) ) && ( unit1.r < 0 ) )) 
						{
							if ( ! (allow_delete) ) 
							{
								skip = true;
							}
							
							act1 = "---";
						}
						
						if (skip) 
						{
							if ( ! (publish) ) 
							{
								if (( active != null )) 
								{
									active.__set(i5, -3);
								}
								
							}
							
							continue;
						}
						
						{
							int _g42 = 0;
							int _g32 = column_units.length;
							while (( _g42 < _g32 ))
							{
								int j5 = _g42++;
								coopy.Unit cunit3 = column_units.__get(j5);
								java.lang.Object pp1 = null;
								java.lang.Object ll = null;
								java.lang.Object rr = null;
								java.lang.Object dd = null;
								java.lang.Object dd_to = null;
								boolean have_dd_to = false;
								java.lang.Object dd_to_alt = null;
								boolean have_dd_to_alt = false;
								boolean have_pp = false;
								boolean have_ll = false;
								boolean have_rr = false;
								if (( ( cunit3.p >= 0 ) && ( unit1.p >= 0 ) )) 
								{
									pp1 = p.getCell(cunit3.p, unit1.p);
									have_pp = true;
								}
								
								if (( ( cunit3.l >= 0 ) && ( unit1.l >= 0 ) )) 
								{
									ll = a.getCell(cunit3.l, unit1.l);
									have_ll = true;
								}
								
								if (( ( cunit3.r >= 0 ) && ( unit1.r >= 0 ) )) 
								{
									rr = b.getCell(cunit3.r, unit1.r);
									have_rr = true;
									if (( (( (have_pp) ? (cunit3.p) : (cunit3.l) )) < 0 )) 
									{
										if (( ! (( rr == null )) )) 
										{
											if ( ! (haxe.lang.Runtime.valEq(v1.toString(rr), "")) ) 
											{
												if (this.flags.allowUpdate()) 
												{
													have_addition = true;
												}
												
											}
											
										}
										
									}
									
								}
								
								if (have_pp) 
								{
									if ( ! (have_rr) ) 
									{
										dd = pp1;
									}
									 else 
									{
										if (v1.equals(pp1, rr)) 
										{
											dd = pp1;
										}
										 else 
										{
											dd = pp1;
											dd_to = rr;
											have_dd_to = true;
											if ( ! (v1.equals(pp1, ll)) ) 
											{
												if ( ! (v1.equals(pp1, rr)) ) 
												{
													dd_to_alt = ll;
													have_dd_to_alt = true;
												}
												
											}
											
										}
										
									}
									
								}
								 else 
								{
									if (have_ll) 
									{
										if ( ! (have_rr) ) 
										{
											dd = ll;
										}
										 else 
										{
											if (v1.equals(ll, rr)) 
											{
												dd = ll;
											}
											 else 
											{
												dd = ll;
												dd_to = rr;
												have_dd_to = true;
											}
											
										}
										
									}
									 else 
									{
										dd = rr;
									}
									
								}
								
								java.lang.Object cell = dd;
								if (( have_dd_to && allow_update )) 
								{
									if (( active_column != null )) 
									{
										active_column.__set(j5, 1);
									}
									
									if (haxe.lang.Runtime.valEq(sep, "")) 
									{
										if (this.builder.needSeparator()) 
										{
											sep = this.getSeparator(a, b, "->");
											this.builder.setSeparator(sep);
										}
										 else 
										{
											sep = "->";
										}
										
									}
									
									boolean is_conflict = false;
									if (have_dd_to_alt) 
									{
										if ( ! (v1.equals(dd_to, dd_to_alt)) ) 
										{
											is_conflict = true;
										}
										
									}
									
									if ( ! (is_conflict) ) 
									{
										cell = this.builder.update(dd, dd_to);
										if (( sep.length() > act1.length() )) 
										{
											act1 = sep;
										}
										
									}
									 else 
									{
										if (haxe.lang.Runtime.valEq(conflict_sep, "")) 
										{
											if (this.builder.needSeparator()) 
											{
												conflict_sep = ( this.getSeparator(p, a, "!") + sep );
												this.builder.setConflictSeparator(conflict_sep);
											}
											 else 
											{
												conflict_sep = "!->";
											}
											
										}
										
										cell = this.builder.conflict(dd, dd_to_alt, dd_to);
										act1 = conflict_sep;
									}
									
								}
								
								if (( haxe.lang.Runtime.valEq(act1, "") && have_addition )) 
								{
									act1 = "+";
								}
								
								if (haxe.lang.Runtime.valEq(act1, "+++")) 
								{
									if (have_rr) 
									{
										if (( active_column != null )) 
										{
											active_column.__set(j5, 1);
										}
										
									}
									
								}
								
								if (publish) 
								{
									if (( ( active_column == null ) || ( ((int) (haxe.lang.Runtime.toInt(active_column.__get(j5))) ) > 0 ) )) 
									{
										output.setCell(( j5 + 1 ), at2, cell);
									}
									
								}
								
							}
							
						}
						
						if (publish) 
						{
							output.setCell(0, at2, this.builder.marker(act1));
							row_map.set(at2, unit1);
						}
						
						if ( ! (haxe.lang.Runtime.valEq(act1, "")) ) 
						{
							if ( ! (publish) ) 
							{
								if (( active != null )) 
								{
									active.__set(i5, 1);
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		if ( ! (show_rc_numbers) ) 
		{
			if (this.flags.always_show_order) 
			{
				show_rc_numbers = true;
			}
			 else 
			{
				if (this.flags.ordered) 
				{
					show_rc_numbers = this.isReordered(row_map, output.get_height());
					if ( ! (show_rc_numbers) ) 
					{
						show_rc_numbers = this.isReordered(col_map, output.get_width());
					}
					
				}
				
			}
			
		}
		
		int admin_w = 1;
		if (( show_rc_numbers &&  ! (this.flags.never_show_order)  )) 
		{
			admin_w++;
			haxe.root.Array<java.lang.Object> target = new haxe.root.Array<java.lang.Object>();
			{
				int _g113 = 0;
				int _g24 = output.get_width();
				while (( _g113 < _g24 ))
				{
					int i6 = _g113++;
					target.push(( i6 + 1 ));
				}
				
			}
			
			output.insertOrDeleteColumns(target, ( output.get_width() + 1 ));
			{
				int _g114 = 0;
				int _g25 = output.get_height();
				while (( _g114 < _g25 ))
				{
					int i7 = _g114++;
					coopy.Unit unit2 = row_map.get(((int) (i7) ));
					if (( unit2 == null )) 
					{
						output.setCell(0, i7, "");
						continue;
					}
					
					output.setCell(0, i7, this.builder.links(unit2));
				}
				
			}
			
			target = new haxe.root.Array<java.lang.Object>();
			{
				int _g115 = 0;
				int _g26 = output.get_height();
				while (( _g115 < _g26 ))
				{
					int i8 = _g115++;
					target.push(( i8 + 1 ));
				}
				
			}
			
			output.insertOrDeleteRows(target, ( output.get_height() + 1 ));
			{
				int _g116 = 1;
				int _g27 = output.get_width();
				while (( _g116 < _g27 ))
				{
					int i9 = _g116++;
					coopy.Unit unit3 = col_map.get(((int) (( i9 - 1 )) ));
					if (( unit3 == null )) 
					{
						output.setCell(i9, 0, "");
						continue;
					}
					
					output.setCell(i9, 0, this.builder.links(unit3));
				}
				
			}
			
			output.setCell(0, 0, this.builder.marker("@:@"));
		}
		
		if (( active_column != null )) 
		{
			boolean all_active = true;
			{
				int _g117 = 0;
				int _g28 = active_column.length;
				while (( _g117 < _g28 ))
				{
					int i10 = _g117++;
					if (( ((int) (haxe.lang.Runtime.toInt(active_column.__get(i10))) ) == 0 )) 
					{
						all_active = false;
						break;
					}
					
				}
				
			}
			
			if ( ! (all_active) ) 
			{
				haxe.root.Array<java.lang.Object> fate = new haxe.root.Array<java.lang.Object>();
				{
					int _g29 = 0;
					while (( _g29 < admin_w ))
					{
						int i11 = _g29++;
						fate.push(i11);
					}
					
				}
				
				int at3 = admin_w;
				int ct = 0;
				haxe.root.Array<java.lang.Object> dots = new haxe.root.Array<java.lang.Object>();
				{
					int _g118 = 0;
					int _g30 = active_column.length;
					while (( _g118 < _g30 ))
					{
						int i12 = _g118++;
						boolean off = ( ((int) (haxe.lang.Runtime.toInt(active_column.__get(i12))) ) == 0 );
						if (off) 
						{
							ct = ( ct + 1 );
						}
						 else 
						{
							ct = 0;
						}
						
						if (( off && ( ct > 1 ) )) 
						{
							fate.push(-1);
						}
						 else 
						{
							if (off) 
							{
								dots.push(at3);
							}
							
							fate.push(at3);
							at3++;
						}
						
					}
					
				}
				
				output.insertOrDeleteColumns(fate, at3);
				{
					int _g33 = 0;
					while (( _g33 < dots.length ))
					{
						int d = ((int) (haxe.lang.Runtime.toInt(dots.__get(_g33))) );
						 ++ _g33;
						{
							int _g210 = 0;
							int _g119 = output.get_height();
							while (( _g210 < _g119 ))
							{
								int j6 = _g210++;
								output.setCell(d, j6, this.builder.marker("..."));
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		return true;
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef263 = true;
			switch (field.hashCode())
			{
				case 230944667:
				{
					if (field.equals("builder")) 
					{
						__temp_executeDef263 = false;
						this.builder = ((coopy.CellBuilder) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 92903173:
				{
					if (field.equals("align")) 
					{
						__temp_executeDef263 = false;
						this.align = ((coopy.Alignment) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 97513095:
				{
					if (field.equals("flags")) 
					{
						__temp_executeDef263 = false;
						this.flags = ((coopy.CompareFlags) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef263) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef264 = true;
			switch (field.hashCode())
			{
				case -1217243857:
				{
					if (field.equals("hilite")) 
					{
						__temp_executeDef264 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("hilite"))) );
					}
					
					break;
				}
				
				
				case 92903173:
				{
					if (field.equals("align")) 
					{
						__temp_executeDef264 = false;
						return this.align;
					}
					
					break;
				}
				
				
				case 1396208885:
				{
					if (field.equals("countActive")) 
					{
						__temp_executeDef264 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("countActive"))) );
					}
					
					break;
				}
				
				
				case 97513095:
				{
					if (field.equals("flags")) 
					{
						__temp_executeDef264 = false;
						return this.flags;
					}
					
					break;
				}
				
				
				case 291001556:
				{
					if (field.equals("setIgnore")) 
					{
						__temp_executeDef264 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setIgnore"))) );
					}
					
					break;
				}
				
				
				case 230944667:
				{
					if (field.equals("builder")) 
					{
						__temp_executeDef264 = false;
						return this.builder;
					}
					
					break;
				}
				
				
				case -1892096836:
				{
					if (field.equals("spreadContext")) 
					{
						__temp_executeDef264 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("spreadContext"))) );
					}
					
					break;
				}
				
				
				case 914408983:
				{
					if (field.equals("setCellBuilder")) 
					{
						__temp_executeDef264 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setCellBuilder"))) );
					}
					
					break;
				}
				
				
				case 10116304:
				{
					if (field.equals("isReordered")) 
					{
						__temp_executeDef264 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("isReordered"))) );
					}
					
					break;
				}
				
				
				case 1723225135:
				{
					if (field.equals("getSeparator")) 
					{
						__temp_executeDef264 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getSeparator"))) );
					}
					
					break;
				}
				
				
				case -1016736174:
				{
					if (field.equals("quoteForDiff")) 
					{
						__temp_executeDef264 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("quoteForDiff"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef264) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef265 = true;
			switch (field.hashCode())
			{
				case -1217243857:
				{
					if (field.equals("hilite")) 
					{
						__temp_executeDef265 = false;
						return this.hilite(((coopy.Table) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case 914408983:
				{
					if (field.equals("setCellBuilder")) 
					{
						__temp_executeDef265 = false;
						this.setCellBuilder(((coopy.CellBuilder) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case 1396208885:
				{
					if (field.equals("countActive")) 
					{
						__temp_executeDef265 = false;
						return this.countActive(((haxe.root.Array<java.lang.Object>) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case 1723225135:
				{
					if (field.equals("getSeparator")) 
					{
						__temp_executeDef265 = false;
						return this.getSeparator(((coopy.Table) (dynargs.__get(0)) ), ((coopy.Table) (dynargs.__get(1)) ), haxe.lang.Runtime.toString(dynargs.__get(2)));
					}
					
					break;
				}
				
				
				case 291001556:
				{
					if (field.equals("setIgnore")) 
					{
						__temp_executeDef265 = false;
						this.setIgnore(((haxe.ds.StringMap<java.lang.Object>) (dynargs.__get(0)) ), ((haxe.ds.IntMap<java.lang.Object>) (dynargs.__get(1)) ), ((coopy.Table) (dynargs.__get(2)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(3))) ));
					}
					
					break;
				}
				
				
				case -1016736174:
				{
					if (field.equals("quoteForDiff")) 
					{
						__temp_executeDef265 = false;
						return this.quoteForDiff(((coopy.View) (dynargs.__get(0)) ), dynargs.__get(1));
					}
					
					break;
				}
				
				
				case -1892096836:
				{
					if (field.equals("spreadContext")) 
					{
						__temp_executeDef265 = false;
						this.spreadContext(((haxe.root.Array<coopy.Unit>) (dynargs.__get(0)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), ((haxe.root.Array<java.lang.Object>) (dynargs.__get(2)) ));
					}
					
					break;
				}
				
				
				case 10116304:
				{
					if (field.equals("isReordered")) 
					{
						__temp_executeDef265 = false;
						return this.isReordered(((haxe.ds.IntMap<coopy.Unit>) (dynargs.__get(0)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef265) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("builder");
		baseArr.push("flags");
		baseArr.push("align");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



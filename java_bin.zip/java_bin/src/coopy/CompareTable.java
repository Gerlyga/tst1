package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class CompareTable extends haxe.lang.HxObject
{
	public    CompareTable(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    CompareTable(coopy.TableComparisonState comp)
	{
		coopy.CompareTable.__hx_ctor_coopy_CompareTable(this, comp);
	}
	
	
	public static   void __hx_ctor_coopy_CompareTable(coopy.CompareTable __temp_me15, coopy.TableComparisonState comp)
	{
		__temp_me15.comp = comp;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.CompareTable(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.CompareTable(((coopy.TableComparisonState) (arr.__get(0)) ));
	}
	
	
	public  coopy.TableComparisonState comp;
	
	public  haxe.root.Array<coopy.IndexPair> indexes;
	
	public   boolean run()
	{
		boolean more = this.compareCore();
		while (( more && this.comp.run_to_completion ))
		{
			more = this.compareCore();
		}
		
		return  ! (more) ;
	}
	
	
	public   coopy.Alignment align()
	{
		while ( ! (this.comp.completed) )
		{
			this.run();
		}
		
		coopy.Alignment alignment = new coopy.Alignment();
		this.alignCore(alignment);
		return alignment;
	}
	
	
	public   coopy.TableComparisonState getComparisonState()
	{
		return this.comp;
	}
	
	
	public   void alignCore(coopy.Alignment align)
	{
		if (( this.comp.p == null )) 
		{
			this.alignCore2(align, this.comp.a, this.comp.b);
			return ;
		}
		
		align.reference = new coopy.Alignment();
		this.alignCore2(align, this.comp.p, this.comp.b);
		this.alignCore2(align.reference, this.comp.p, this.comp.a);
		align.meta.reference = align.reference.meta;
	}
	
	
	public   void alignCore2(coopy.Alignment align, coopy.Table a, coopy.Table b)
	{
		if (( align.meta == null )) 
		{
			align.meta = new coopy.Alignment();
		}
		
		this.alignColumns(align.meta, a, b);
		coopy.Ordering column_order = align.meta.toOrder();
		align.range(a.get_height(), b.get_height());
		align.tables(a, b);
		align.setRowlike(true);
		int w = a.get_width();
		int ha = a.get_height();
		int hb = b.get_height();
		coopy.View av = a.getCellView();
		haxe.root.Array<java.lang.String> ids = null;
		haxe.ds.StringMap<java.lang.Object> ignore = null;
		if (( this.comp.compare_flags != null )) 
		{
			ids = this.comp.compare_flags.ids;
			ignore = this.comp.compare_flags.getIgnoredColumns();
		}
		
		haxe.root.Array<coopy.Unit> common_units = new haxe.root.Array<coopy.Unit>();
		int ra_header = align.getSourceHeader();
		int rb_header = align.getSourceHeader();
		{
			int _g = 0;
			haxe.root.Array<coopy.Unit> _g1 = column_order.getList();
			while (( _g < _g1.length ))
			{
				coopy.Unit unit = _g1.__get(_g);
				 ++ _g;
				if (( ( ( unit.l >= 0 ) && ( unit.r >= 0 ) ) && ( unit.p != -1 ) )) 
				{
					if (( ignore != null )) 
					{
						if (( ( ( unit.l >= 0 ) && ( ra_header >= 0 ) ) && ( ra_header < a.get_height() ) )) 
						{
							java.lang.String name = av.toString(a.getCell(unit.l, ra_header));
							if (ignore.exists(name)) 
							{
								continue;
							}
							
						}
						
						if (( ( ( unit.r >= 0 ) && ( rb_header >= 0 ) ) && ( rb_header < b.get_height() ) )) 
						{
							java.lang.String name1 = av.toString(b.getCell(unit.r, rb_header));
							if (ignore.exists(name1)) 
							{
								continue;
							}
							
						}
						
					}
					
					common_units.push(unit);
				}
				
			}
			
		}
		
		if (( ids != null )) 
		{
			coopy.IndexPair index = new coopy.IndexPair();
			haxe.ds.StringMap<java.lang.Object> ids_as_map = new haxe.ds.StringMap<java.lang.Object>();
			{
				int _g2 = 0;
				while (( _g2 < ids.length ))
				{
					java.lang.String id = ids.__get(_g2);
					 ++ _g2;
					{
						ids_as_map.set(id, true);
						boolean __temp_expr143 = true;
					}
					
				}
				
			}
			
			{
				int _g3 = 0;
				while (( _g3 < common_units.length ))
				{
					coopy.Unit unit1 = common_units.__get(_g3);
					 ++ _g3;
					java.lang.String na = av.toString(a.getCell(unit1.l, 0));
					java.lang.String nb = av.toString(b.getCell(unit1.r, 0));
					if (( ids_as_map.exists(na) || ids_as_map.exists(nb) )) 
					{
						index.addColumns(unit1.l, unit1.r);
						align.addIndexColumns(unit1);
					}
					
				}
				
			}
			
			index.indexTables(a, b);
			if (( this.indexes != null )) 
			{
				this.indexes.push(index);
			}
			
			{
				int _g4 = 0;
				while (( _g4 < ha ))
				{
					int j = _g4++;
					coopy.CrossMatch cross = index.queryLocal(j);
					int spot_a = cross.spot_a;
					int spot_b = cross.spot_b;
					if (( ( spot_a != 1 ) || ( spot_b != 1 ) )) 
					{
						continue;
					}
					
					align.link(j, ((int) (haxe.lang.Runtime.toInt(cross.item_b.lst.__get(0))) ));
				}
				
			}
			
		}
		 else 
		{
			int N = 5;
			haxe.root.Array<java.lang.Object> columns = new haxe.root.Array<java.lang.Object>();
			if (( common_units.length > N )) 
			{
				haxe.root.Array<haxe.root.Array> columns_eval = new haxe.root.Array<haxe.root.Array>();
				{
					int _g11 = 0;
					int _g5 = common_units.length;
					while (( _g11 < _g5 ))
					{
						int i = _g11++;
						int ct = 0;
						haxe.ds.StringMap<java.lang.Object> mem = new haxe.ds.StringMap<java.lang.Object>();
						haxe.ds.StringMap<java.lang.Object> mem2 = new haxe.ds.StringMap<java.lang.Object>();
						int ca = common_units.__get(i).l;
						int cb = common_units.__get(i).r;
						{
							int _g21 = 0;
							while (( _g21 < ha ))
							{
								int j1 = _g21++;
								java.lang.String key = av.toString(a.getCell(ca, j1));
								if ( ! (mem.exists(key)) ) 
								{
									mem.set(key, 1);
									ct++;
								}
								
							}
							
						}
						
						{
							int _g22 = 0;
							while (( _g22 < hb ))
							{
								int j2 = _g22++;
								java.lang.String key1 = av.toString(b.getCell(cb, j2));
								if ( ! (mem2.exists(key1)) ) 
								{
									mem2.set(key1, 1);
									ct++;
								}
								
							}
							
						}
						
						columns_eval.push(((haxe.root.Array) (new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{i, ct})) ));
					}
					
				}
				
				haxe.lang.Function sorter = ( (( coopy.CompareTable_alignCore2_187__Fun.__hx_current != null )) ? (coopy.CompareTable_alignCore2_187__Fun.__hx_current) : (coopy.CompareTable_alignCore2_187__Fun.__hx_current = ((coopy.CompareTable_alignCore2_187__Fun) (new coopy.CompareTable_alignCore2_187__Fun()) )) );
				columns_eval.sort(sorter);
				columns = ((haxe.root.Array<java.lang.Object>) (((haxe.root.Array) (haxe.root.Lambda.array(((haxe.root.List<java.lang.Object>) (((haxe.root.List) (haxe.root.Lambda.map(columns_eval, ( (( coopy.CompareTable_alignCore2_195__Fun.__hx_current != null )) ? (coopy.CompareTable_alignCore2_195__Fun.__hx_current) : (coopy.CompareTable_alignCore2_195__Fun.__hx_current = ((coopy.CompareTable_alignCore2_195__Fun) (new coopy.CompareTable_alignCore2_195__Fun()) )) ))) )) ))) )) );
				columns = ((haxe.root.Array<java.lang.Object>) (((haxe.root.Array) (columns.slice(0, N)) )) );
			}
			 else 
			{
				int _g12 = 0;
				int _g6 = common_units.length;
				while (( _g12 < _g6 ))
				{
					int i1 = _g12++;
					columns.push(i1);
				}
				
			}
			
			int top = ((int) (java.lang.Math.round(java.lang.Math.pow(((double) (2) ), ((double) (columns.length) )))) );
			haxe.ds.IntMap<java.lang.Object> pending = new haxe.ds.IntMap<java.lang.Object>();
			{
				int _g7 = 0;
				while (( _g7 < ha ))
				{
					int j3 = _g7++;
					pending.set(j3, j3);
				}
				
			}
			
			int pending_ct = ha;
			haxe.ds.IntMap<java.lang.Object> added_columns = new haxe.ds.IntMap<java.lang.Object>();
			int index_ct = 0;
			coopy.IndexPair index_top = null;
			{
				int _g8 = 0;
				while (( _g8 < top ))
				{
					int k = _g8++;
					if (( k == 0 )) 
					{
						continue;
					}
					
					if (( pending_ct == 0 )) 
					{
						break;
					}
					
					haxe.root.Array<java.lang.Object> active_columns = new haxe.root.Array<java.lang.Object>();
					int kk = k;
					int at = 0;
					while (( kk > 0 ))
					{
						if (( ( kk % 2 ) == 1 )) 
						{
							active_columns.push(((int) (haxe.lang.Runtime.toInt(columns.__get(at))) ));
						}
						
						kk >>= 1;
						at++;
					}
					
					coopy.IndexPair index1 = new coopy.IndexPair();
					{
						int _g23 = 0;
						int _g13 = active_columns.length;
						while (( _g23 < _g13 ))
						{
							int k1 = _g23++;
							int col = ((int) (haxe.lang.Runtime.toInt(active_columns.__get(k1))) );
							coopy.Unit unit2 = common_units.__get(col);
							index1.addColumns(unit2.l, unit2.r);
							if ( ! (added_columns.exists(col)) ) 
							{
								align.addIndexColumns(unit2);
								added_columns.set(col, true);
							}
							
						}
						
					}
					
					index1.indexTables(a, b);
					if (( k == ( top - 1 ) )) 
					{
						index_top = index1;
					}
					
					int h = a.get_height();
					if (( b.get_height() > h )) 
					{
						h = b.get_height();
					}
					
					if (( h < 1 )) 
					{
						h = 1;
					}
					
					int wide_top_freq = index1.getTopFreq();
					double ratio = ((double) (wide_top_freq) );
					ratio /= ((double) (( h + 20 )) );
					if (( ratio >= 0.1 )) 
					{
						if (( ( index_ct > 0 ) || ( k < ( top - 1 ) ) )) 
						{
							continue;
						}
						
					}
					
					index_ct++;
					if (( this.indexes != null )) 
					{
						this.indexes.push(index1);
					}
					
					haxe.root.Array<java.lang.Object> fixed = new haxe.root.Array<java.lang.Object>();
					{
						java.lang.Object __temp_iterator84 = pending.keys();
						while (haxe.lang.Runtime.toBool(haxe.lang.Runtime.callField(__temp_iterator84, "hasNext", null)))
						{
							int j4 = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.callField(__temp_iterator84, "next", null))) );
							coopy.CrossMatch cross1 = index1.queryLocal(j4);
							int spot_a1 = cross1.spot_a;
							int spot_b1 = cross1.spot_b;
							if (( ( spot_a1 != 1 ) || ( spot_b1 != 1 ) )) 
							{
								continue;
							}
							
							fixed.push(j4);
							align.link(j4, ((int) (haxe.lang.Runtime.toInt(cross1.item_b.lst.__get(0))) ));
						}
						
					}
					
					{
						int _g24 = 0;
						int _g14 = fixed.length;
						while (( _g24 < _g14 ))
						{
							int j5 = _g24++;
							pending.remove(((int) (haxe.lang.Runtime.toInt(fixed.__get(j5))) ));
							pending_ct--;
						}
						
					}
					
				}
				
			}
			
			if (( index_top != null )) 
			{
				int offset = 0;
				int scale = 1;
				{
					int _g9 = 0;
					while (( _g9 < 2 ))
					{
						int sgn = _g9++;
						if (( pending_ct > 0 )) 
						{
							java.lang.Object xb = null;
							if (( ( scale == -1 ) && ( hb > 0 ) )) 
							{
								xb = ( hb - 1 );
							}
							
							{
								int _g15 = 0;
								while (( _g15 < ha ))
								{
									int xa0 = _g15++;
									int xa = ( ( xa0 * scale ) + offset );
									java.lang.Object xb2 = align.a2b(xa);
									if (( ! (( xb2 == null )) )) 
									{
										xb = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.plus(xb2, scale))) );
										if (( ( haxe.lang.Runtime.compare(xb, hb) >= 0 ) || ( haxe.lang.Runtime.compare(xb, 0) < 0 ) )) 
										{
											break;
										}
										
										continue;
									}
									
									if (( xb == null )) 
									{
										continue;
									}
									
									java.lang.String ka = index_top.localKey(xa);
									java.lang.String kb = index_top.remoteKey(((int) (haxe.lang.Runtime.toInt(xb)) ));
									if ( ! (haxe.lang.Runtime.valEq(ka, kb)) ) 
									{
										continue;
									}
									
									align.link(xa, ((int) (haxe.lang.Runtime.toInt(xb)) ));
									pending_ct--;
									xb = ((java.lang.Object) (haxe.lang.Runtime.plus(xb, scale)) );
									if (( ( haxe.lang.Runtime.compare(xb, hb) >= 0 ) || ( haxe.lang.Runtime.compare(xb, 0) < 0 ) )) 
									{
										break;
									}
									
									if (( pending_ct == 0 )) 
									{
										break;
									}
									
								}
								
							}
							
						}
						
						offset = ( ha - 1 );
						scale = -1;
					}
					
				}
				
			}
			
		}
		
		if (( ( ha > 0 ) && ( hb > 0 ) )) 
		{
			align.link(0, 0);
		}
		
	}
	
	
	public   void alignColumns(coopy.Alignment align, coopy.Table a, coopy.Table b)
	{
		align.range(a.get_width(), b.get_width());
		align.tables(a, b);
		align.setRowlike(false);
		int slop = 5;
		coopy.View va = a.getCellView();
		coopy.View vb = b.getCellView();
		int ra_best = 0;
		int rb_best = 0;
		int ct_best = -1;
		haxe.ds.StringMap<java.lang.Object> ma_best = null;
		haxe.ds.StringMap<java.lang.Object> mb_best = null;
		int ra_header = 0;
		int rb_header = 0;
		int ra_uniques = 0;
		int rb_uniques = 0;
		{
			int _g = 0;
			while (( _g < slop ))
			{
				int ra = _g++;
				if (( ra >= a.get_height() )) 
				{
					break;
				}
				
				{
					int _g1 = 0;
					while (( _g1 < slop ))
					{
						int rb = _g1++;
						if (( rb >= b.get_height() )) 
						{
							break;
						}
						
						haxe.ds.StringMap<java.lang.Object> ma = new haxe.ds.StringMap<java.lang.Object>();
						haxe.ds.StringMap<java.lang.Object> mb = new haxe.ds.StringMap<java.lang.Object>();
						int ct = 0;
						int uniques = 0;
						{
							int _g3 = 0;
							int _g2 = a.get_width();
							while (( _g3 < _g2 ))
							{
								int ca = _g3++;
								java.lang.String key = va.toString(a.getCell(ca, ra));
								if (ma.exists(key)) 
								{
									ma.set(key, -1);
									uniques--;
								}
								 else 
								{
									ma.set(key, ca);
									uniques++;
								}
								
							}
							
						}
						
						if (( uniques > ra_uniques )) 
						{
							ra_header = ra;
							ra_uniques = uniques;
						}
						
						uniques = 0;
						{
							int _g31 = 0;
							int _g21 = b.get_width();
							while (( _g31 < _g21 ))
							{
								int cb = _g31++;
								java.lang.String key1 = vb.toString(b.getCell(cb, rb));
								if (mb.exists(key1)) 
								{
									mb.set(key1, -1);
									uniques--;
								}
								 else 
								{
									mb.set(key1, cb);
									uniques++;
								}
								
							}
							
						}
						
						if (( uniques > rb_uniques )) 
						{
							rb_header = rb;
							rb_uniques = uniques;
						}
						
						{
							java.lang.Object __temp_iterator85 = ma.keys();
							while (haxe.lang.Runtime.toBool(haxe.lang.Runtime.callField(__temp_iterator85, "hasNext", null)))
							{
								java.lang.String key2 = haxe.lang.Runtime.toString(haxe.lang.Runtime.callField(__temp_iterator85, "next", null));
								int i0 = ((int) (haxe.lang.Runtime.toInt(ma.get(key2))) );
								java.lang.Object i1 = mb.get(key2);
								if (( ! (( i1 == null )) )) 
								{
									if (( ( haxe.lang.Runtime.compare(i1, 0) >= 0 ) && ( i0 >= 0 ) )) 
									{
										ct++;
									}
									
								}
								
							}
							
						}
						
						if (( ct > ct_best )) 
						{
							ct_best = ct;
							ma_best = ma;
							mb_best = mb;
							ra_best = ra;
							rb_best = rb;
						}
						
					}
					
				}
				
			}
			
		}
		
		if (( ma_best == null )) 
		{
			if (( ( a.get_height() > 0 ) && ( b.get_height() == 0 ) )) 
			{
				align.headers(0, -1);
			}
			 else 
			{
				if (( ( a.get_height() == 0 ) && ( b.get_height() > 0 ) )) 
				{
					align.headers(-1, 0);
				}
				
			}
			
			return ;
		}
		
		{
			java.lang.Object __temp_iterator86 = ma_best.keys();
			while (haxe.lang.Runtime.toBool(haxe.lang.Runtime.callField(__temp_iterator86, "hasNext", null)))
			{
				java.lang.String key3 = haxe.lang.Runtime.toString(haxe.lang.Runtime.callField(__temp_iterator86, "next", null));
				java.lang.Object i01 = ma_best.get(key3);
				java.lang.Object i11 = mb_best.get(key3);
				if (( ( ! (( i11 == null )) ) && ( ! (( i01 == null )) ) )) 
				{
					align.link(((int) (haxe.lang.Runtime.toInt(i01)) ), ((int) (haxe.lang.Runtime.toInt(i11)) ));
				}
				
			}
			
		}
		
		align.headers(ra_header, rb_header);
	}
	
	
	public   boolean testHasSameColumns()
	{
		coopy.Table p = this.comp.p;
		coopy.Table a = this.comp.a;
		coopy.Table b = this.comp.b;
		boolean eq = this.hasSameColumns2(a, b);
		if (( eq && ( p != null ) )) 
		{
			eq = this.hasSameColumns2(p, a);
		}
		
		this.comp.has_same_columns = eq;
		this.comp.has_same_columns_known = true;
		return true;
	}
	
	
	public   boolean hasSameColumns2(coopy.Table a, coopy.Table b)
	{
		if (( a.get_width() != b.get_width() )) 
		{
			return false;
		}
		
		if (( ( a.get_height() == 0 ) || ( b.get_height() == 0 ) )) 
		{
			return true;
		}
		
		coopy.View av = a.getCellView();
		{
			int _g1 = 0;
			int _g = a.get_width();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				{
					int _g3 = ( i + 1 );
					int _g2 = a.get_width();
					while (( _g3 < _g2 ))
					{
						int j = _g3++;
						if (av.equals(a.getCell(i, 0), a.getCell(j, 0))) 
						{
							return false;
						}
						
					}
					
				}
				
				if ( ! (av.equals(a.getCell(i, 0), b.getCell(i, 0))) ) 
				{
					return false;
				}
				
			}
			
		}
		
		return true;
	}
	
	
	public   boolean testIsEqual()
	{
		coopy.Table p = this.comp.p;
		coopy.Table a = this.comp.a;
		coopy.Table b = this.comp.b;
		boolean eq = this.isEqual2(a, b);
		if (( eq && ( p != null ) )) 
		{
			eq = this.isEqual2(p, a);
		}
		
		this.comp.is_equal = eq;
		this.comp.is_equal_known = true;
		return true;
	}
	
	
	public   boolean isEqual2(coopy.Table a, coopy.Table b)
	{
		if (( ( a.get_width() != b.get_width() ) || ( a.get_height() != b.get_height() ) )) 
		{
			return false;
		}
		
		coopy.View av = a.getCellView();
		{
			int _g1 = 0;
			int _g = a.get_height();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				{
					int _g3 = 0;
					int _g2 = a.get_width();
					while (( _g3 < _g2 ))
					{
						int j = _g3++;
						if ( ! (av.equals(a.getCell(j, i), b.getCell(j, i))) ) 
						{
							return false;
						}
						
					}
					
				}
				
			}
			
		}
		
		return true;
	}
	
	
	public   boolean compareCore()
	{
		if (this.comp.completed) 
		{
			return false;
		}
		
		if ( ! (this.comp.is_equal_known) ) 
		{
			return this.testIsEqual();
		}
		
		if ( ! (this.comp.has_same_columns_known) ) 
		{
			return this.testHasSameColumns();
		}
		
		this.comp.completed = true;
		return false;
	}
	
	
	public   void storeIndexes()
	{
		this.indexes = new haxe.root.Array<coopy.IndexPair>();
	}
	
	
	public   haxe.root.Array<coopy.IndexPair> getIndexes()
	{
		return this.indexes;
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef144 = true;
			switch (field.hashCode())
			{
				case 1943292160:
				{
					if (field.equals("indexes")) 
					{
						__temp_executeDef144 = false;
						this.indexes = ((haxe.root.Array<coopy.IndexPair>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3059471:
				{
					if (field.equals("comp")) 
					{
						__temp_executeDef144 = false;
						this.comp = ((coopy.TableComparisonState) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef144) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef145 = true;
			switch (field.hashCode())
			{
				case -1314814774:
				{
					if (field.equals("getIndexes")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getIndexes"))) );
					}
					
					break;
				}
				
				
				case 3059471:
				{
					if (field.equals("comp")) 
					{
						__temp_executeDef145 = false;
						return this.comp;
					}
					
					break;
				}
				
				
				case -1314694945:
				{
					if (field.equals("storeIndexes")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("storeIndexes"))) );
					}
					
					break;
				}
				
				
				case 1943292160:
				{
					if (field.equals("indexes")) 
					{
						__temp_executeDef145 = false;
						return this.indexes;
					}
					
					break;
				}
				
				
				case -412850652:
				{
					if (field.equals("compareCore")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("compareCore"))) );
					}
					
					break;
				}
				
				
				case 113291:
				{
					if (field.equals("run")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("run"))) );
					}
					
					break;
				}
				
				
				case -621448888:
				{
					if (field.equals("isEqual2")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("isEqual2"))) );
					}
					
					break;
				}
				
				
				case 92903173:
				{
					if (field.equals("align")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("align"))) );
					}
					
					break;
				}
				
				
				case 1665564472:
				{
					if (field.equals("testIsEqual")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("testIsEqual"))) );
					}
					
					break;
				}
				
				
				case -590489646:
				{
					if (field.equals("getComparisonState")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getComparisonState"))) );
					}
					
					break;
				}
				
				
				case -2059431371:
				{
					if (field.equals("hasSameColumns2")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("hasSameColumns2"))) );
					}
					
					break;
				}
				
				
				case 1766633540:
				{
					if (field.equals("alignCore")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("alignCore"))) );
					}
					
					break;
				}
				
				
				case -626177329:
				{
					if (field.equals("testHasSameColumns")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("testHasSameColumns"))) );
					}
					
					break;
				}
				
				
				case -1068935058:
				{
					if (field.equals("alignCore2")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("alignCore2"))) );
					}
					
					break;
				}
				
				
				case -754411240:
				{
					if (field.equals("alignColumns")) 
					{
						__temp_executeDef145 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("alignColumns"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef145) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef146 = true;
			switch (field.hashCode())
			{
				case -1314814774:
				{
					if (field.equals("getIndexes")) 
					{
						__temp_executeDef146 = false;
						return this.getIndexes();
					}
					
					break;
				}
				
				
				case 113291:
				{
					if (field.equals("run")) 
					{
						__temp_executeDef146 = false;
						return this.run();
					}
					
					break;
				}
				
				
				case -1314694945:
				{
					if (field.equals("storeIndexes")) 
					{
						__temp_executeDef146 = false;
						this.storeIndexes();
					}
					
					break;
				}
				
				
				case 92903173:
				{
					if (field.equals("align")) 
					{
						__temp_executeDef146 = false;
						return this.align();
					}
					
					break;
				}
				
				
				case -412850652:
				{
					if (field.equals("compareCore")) 
					{
						__temp_executeDef146 = false;
						return this.compareCore();
					}
					
					break;
				}
				
				
				case -590489646:
				{
					if (field.equals("getComparisonState")) 
					{
						__temp_executeDef146 = false;
						return this.getComparisonState();
					}
					
					break;
				}
				
				
				case -621448888:
				{
					if (field.equals("isEqual2")) 
					{
						__temp_executeDef146 = false;
						return this.isEqual2(((coopy.Table) (dynargs.__get(0)) ), ((coopy.Table) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case 1766633540:
				{
					if (field.equals("alignCore")) 
					{
						__temp_executeDef146 = false;
						this.alignCore(((coopy.Alignment) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case 1665564472:
				{
					if (field.equals("testIsEqual")) 
					{
						__temp_executeDef146 = false;
						return this.testIsEqual();
					}
					
					break;
				}
				
				
				case -1068935058:
				{
					if (field.equals("alignCore2")) 
					{
						__temp_executeDef146 = false;
						this.alignCore2(((coopy.Alignment) (dynargs.__get(0)) ), ((coopy.Table) (dynargs.__get(1)) ), ((coopy.Table) (dynargs.__get(2)) ));
					}
					
					break;
				}
				
				
				case -2059431371:
				{
					if (field.equals("hasSameColumns2")) 
					{
						__temp_executeDef146 = false;
						return this.hasSameColumns2(((coopy.Table) (dynargs.__get(0)) ), ((coopy.Table) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case -754411240:
				{
					if (field.equals("alignColumns")) 
					{
						__temp_executeDef146 = false;
						this.alignColumns(((coopy.Alignment) (dynargs.__get(0)) ), ((coopy.Table) (dynargs.__get(1)) ), ((coopy.Table) (dynargs.__get(2)) ));
					}
					
					break;
				}
				
				
				case -626177329:
				{
					if (field.equals("testHasSameColumns")) 
					{
						__temp_executeDef146 = false;
						return this.testHasSameColumns();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef146) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("indexes");
		baseArr.push("comp");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



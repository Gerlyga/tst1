package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class TableComparisonState extends haxe.lang.HxObject
{
	public    TableComparisonState(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    TableComparisonState()
	{
		coopy.TableComparisonState.__hx_ctor_coopy_TableComparisonState(this);
	}
	
	
	public static   void __hx_ctor_coopy_TableComparisonState(coopy.TableComparisonState __temp_me42)
	{
		__temp_me42.reset();
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.TableComparisonState(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.TableComparisonState();
	}
	
	
	public  coopy.Table p;
	
	public  coopy.Table a;
	
	public  coopy.Table b;
	
	public  boolean completed;
	
	public  boolean run_to_completion;
	
	public  boolean is_equal;
	
	public  boolean is_equal_known;
	
	public  boolean has_same_columns;
	
	public  boolean has_same_columns_known;
	
	public  coopy.CompareFlags compare_flags;
	
	public   void reset()
	{
		this.completed = false;
		this.run_to_completion = true;
		this.is_equal_known = false;
		this.is_equal = false;
		this.has_same_columns = false;
		this.has_same_columns_known = false;
		this.compare_flags = null;
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef258 = true;
			switch (field.hashCode())
			{
				case -819360083:
				{
					if (field.equals("compare_flags")) 
					{
						__temp_executeDef258 = false;
						this.compare_flags = ((coopy.CompareFlags) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 112:
				{
					if (field.equals("p")) 
					{
						__temp_executeDef258 = false;
						this.p = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 844740109:
				{
					if (field.equals("has_same_columns_known")) 
					{
						__temp_executeDef258 = false;
						this.has_same_columns_known = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 97:
				{
					if (field.equals("a")) 
					{
						__temp_executeDef258 = false;
						this.a = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -812934519:
				{
					if (field.equals("has_same_columns")) 
					{
						__temp_executeDef258 = false;
						this.has_same_columns = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 98:
				{
					if (field.equals("b")) 
					{
						__temp_executeDef258 = false;
						this.b = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1330844387:
				{
					if (field.equals("is_equal_known")) 
					{
						__temp_executeDef258 = false;
						this.is_equal_known = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case -1402931637:
				{
					if (field.equals("completed")) 
					{
						__temp_executeDef258 = false;
						this.completed = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 111726559:
				{
					if (field.equals("is_equal")) 
					{
						__temp_executeDef258 = false;
						this.is_equal = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case -85549716:
				{
					if (field.equals("run_to_completion")) 
					{
						__temp_executeDef258 = false;
						this.run_to_completion = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef258) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef259 = true;
			switch (field.hashCode())
			{
				case 108404047:
				{
					if (field.equals("reset")) 
					{
						__temp_executeDef259 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("reset"))) );
					}
					
					break;
				}
				
				
				case 112:
				{
					if (field.equals("p")) 
					{
						__temp_executeDef259 = false;
						return this.p;
					}
					
					break;
				}
				
				
				case -819360083:
				{
					if (field.equals("compare_flags")) 
					{
						__temp_executeDef259 = false;
						return this.compare_flags;
					}
					
					break;
				}
				
				
				case 97:
				{
					if (field.equals("a")) 
					{
						__temp_executeDef259 = false;
						return this.a;
					}
					
					break;
				}
				
				
				case 844740109:
				{
					if (field.equals("has_same_columns_known")) 
					{
						__temp_executeDef259 = false;
						return this.has_same_columns_known;
					}
					
					break;
				}
				
				
				case 98:
				{
					if (field.equals("b")) 
					{
						__temp_executeDef259 = false;
						return this.b;
					}
					
					break;
				}
				
				
				case -812934519:
				{
					if (field.equals("has_same_columns")) 
					{
						__temp_executeDef259 = false;
						return this.has_same_columns;
					}
					
					break;
				}
				
				
				case -1402931637:
				{
					if (field.equals("completed")) 
					{
						__temp_executeDef259 = false;
						return this.completed;
					}
					
					break;
				}
				
				
				case 1330844387:
				{
					if (field.equals("is_equal_known")) 
					{
						__temp_executeDef259 = false;
						return this.is_equal_known;
					}
					
					break;
				}
				
				
				case -85549716:
				{
					if (field.equals("run_to_completion")) 
					{
						__temp_executeDef259 = false;
						return this.run_to_completion;
					}
					
					break;
				}
				
				
				case 111726559:
				{
					if (field.equals("is_equal")) 
					{
						__temp_executeDef259 = false;
						return this.is_equal;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef259) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef260 = true;
			switch (field.hashCode())
			{
				case 108404047:
				{
					if (field.equals("reset")) 
					{
						__temp_executeDef260 = false;
						this.reset();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef260) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("compare_flags");
		baseArr.push("has_same_columns_known");
		baseArr.push("has_same_columns");
		baseArr.push("is_equal_known");
		baseArr.push("is_equal");
		baseArr.push("run_to_completion");
		baseArr.push("completed");
		baseArr.push("b");
		baseArr.push("a");
		baseArr.push("p");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class SqlCompare extends haxe.lang.HxObject
{
	public    SqlCompare(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    SqlCompare(coopy.SqlDatabase db, coopy.SqlTable local, coopy.SqlTable remote)
	{
		coopy.SqlCompare.__hx_ctor_coopy_SqlCompare(this, db, local, remote);
	}
	
	
	public static   void __hx_ctor_coopy_SqlCompare(coopy.SqlCompare __temp_me38, coopy.SqlDatabase db, coopy.SqlTable local, coopy.SqlTable remote)
	{
		__temp_me38.db = db;
		__temp_me38.local = local;
		__temp_me38.remote = remote;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.SqlCompare(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.SqlCompare(((coopy.SqlDatabase) (arr.__get(0)) ), ((coopy.SqlTable) (arr.__get(1)) ), ((coopy.SqlTable) (arr.__get(2)) ));
	}
	
	
	public  coopy.SqlDatabase db;
	
	public  coopy.SqlTable parent;
	
	public  coopy.SqlTable local;
	
	public  coopy.SqlTable remote;
	
	public  int at0;
	
	public  int at1;
	
	public  coopy.Alignment align;
	
	public   boolean equalArray(haxe.root.Array<java.lang.String> a1, haxe.root.Array<java.lang.String> a2)
	{
		if (( a1.length != a2.length )) 
		{
			return false;
		}
		
		{
			int _g1 = 0;
			int _g = a1.length;
			while (( _g1 < _g ))
			{
				int i = _g1++;
				if ( ! (haxe.lang.Runtime.valEq(a1.__get(i), a2.__get(i))) ) 
				{
					return false;
				}
				
			}
			
		}
		
		return true;
	}
	
	
	public   boolean validateSchema()
	{
		haxe.root.Array<java.lang.String> all_cols1 = this.local.getColumnNames();
		haxe.root.Array<java.lang.String> all_cols2 = this.remote.getColumnNames();
		if ( ! (this.equalArray(all_cols1, all_cols2)) ) 
		{
			return false;
		}
		
		haxe.root.Array<java.lang.String> key_cols1 = this.local.getPrimaryKey();
		haxe.root.Array<java.lang.String> key_cols2 = this.remote.getPrimaryKey();
		if ( ! (this.equalArray(key_cols1, key_cols2)) ) 
		{
			return false;
		}
		
		if (( key_cols1.length == 0 )) 
		{
			return false;
		}
		
		return true;
	}
	
	
	public   int denull(java.lang.Object x)
	{
		if (( x == null )) 
		{
			return -1;
		}
		
		return ((int) (haxe.lang.Runtime.toInt(x)) );
	}
	
	
	public   void link()
	{
		int i0 = this.denull(this.db.get(0));
		int i1 = this.denull(this.db.get(1));
		if (( i0 == -3 )) 
		{
			i0 = this.at0;
			this.at0++;
		}
		
		if (( i1 == -3 )) 
		{
			i1 = this.at1;
			this.at1++;
		}
		
		int factor = 0;
		if (( ( i0 >= 0 ) && ( i1 >= 0 ) )) 
		{
			factor = 2;
		}
		 else 
		{
			factor = 1;
		}
		
		int offset = ( factor - 1 );
		if (( i0 >= 0 )) 
		{
			int _g1 = 0;
			int _g = this.local.get_width();
			while (( _g1 < _g ))
			{
				int x = _g1++;
				this.local.setCellCache(x, i0, this.db.get(( 2 + ( factor * x ) )));
			}
			
		}
		
		if (( i1 >= 0 )) 
		{
			int _g11 = 0;
			int _g2 = this.remote.get_width();
			while (( _g11 < _g2 ))
			{
				int x1 = _g11++;
				this.remote.setCellCache(x1, i1, this.db.get(( ( 2 + ( factor * x1 ) ) + offset )));
			}
			
		}
		
		this.align.link(i0, i1);
		this.align.addToOrder(i0, i1, null);
	}
	
	
	public   void linkQuery(java.lang.String query, haxe.root.Array<java.lang.String> order)
	{
		if (this.db.begin(query, null, order)) 
		{
			while (this.db.read())
			{
				this.link();
			}
			
			this.db.end();
		}
		
	}
	
	
	public   coopy.Alignment apply()
	{
		if (( this.db == null )) 
		{
			return null;
		}
		
		if ( ! (this.validateSchema()) ) 
		{
			return null;
		}
		
		java.lang.String rowid_name = this.db.rowid();
		this.align = new coopy.Alignment();
		haxe.root.Array<java.lang.String> key_cols = this.local.getPrimaryKey();
		haxe.root.Array<java.lang.String> data_cols = this.local.getAllButPrimaryKey();
		haxe.root.Array<java.lang.String> all_cols = this.local.getColumnNames();
		this.align.meta = new coopy.Alignment();
		{
			int _g1 = 0;
			int _g = all_cols.length;
			while (( _g1 < _g ))
			{
				int i = _g1++;
				this.align.meta.link(i, i);
			}
			
		}
		
		this.align.meta.range(all_cols.length, all_cols.length);
		this.align.tables(this.local, this.remote);
		this.align.range(999, 999);
		java.lang.String sql_table1 = this.local.getQuotedTableName();
		java.lang.String sql_table2 = this.remote.getQuotedTableName();
		java.lang.String sql_key_cols = "";
		{
			int _g11 = 0;
			int _g2 = key_cols.length;
			while (( _g11 < _g2 ))
			{
				int i1 = _g11++;
				if (( i1 > 0 )) 
				{
					sql_key_cols += ",";
				}
				
				sql_key_cols += this.local.getQuotedColumnName(key_cols.__get(i1));
			}
			
		}
		
		java.lang.String sql_all_cols = "";
		{
			int _g12 = 0;
			int _g3 = all_cols.length;
			while (( _g12 < _g3 ))
			{
				int i2 = _g12++;
				if (( i2 > 0 )) 
				{
					sql_all_cols += ",";
				}
				
				sql_all_cols += this.local.getQuotedColumnName(all_cols.__get(i2));
			}
			
		}
		
		java.lang.String sql_key_match = "";
		{
			int _g13 = 0;
			int _g4 = key_cols.length;
			while (( _g13 < _g4 ))
			{
				int i3 = _g13++;
				if (( i3 > 0 )) 
				{
					sql_key_match += " AND ";
				}
				
				java.lang.String n = this.local.getQuotedColumnName(key_cols.__get(i3));
				sql_key_match += ( ( ( ( ( ( sql_table1 + "." ) + n ) + " IS " ) + sql_table2 ) + "." ) + n );
			}
			
		}
		
		java.lang.String sql_data_mismatch = "";
		{
			int _g14 = 0;
			int _g5 = data_cols.length;
			while (( _g14 < _g5 ))
			{
				int i4 = _g14++;
				if (( i4 > 0 )) 
				{
					sql_data_mismatch += " OR ";
				}
				
				java.lang.String n1 = this.local.getQuotedColumnName(data_cols.__get(i4));
				sql_data_mismatch += ( ( ( ( ( ( sql_table1 + "." ) + n1 ) + " IS NOT " ) + sql_table2 ) + "." ) + n1 );
			}
			
		}
		
		java.lang.String sql_dbl_cols = "";
		haxe.root.Array<java.lang.String> dbl_cols = new haxe.root.Array<java.lang.String>(new java.lang.String[]{});
		{
			int _g15 = 0;
			int _g6 = all_cols.length;
			while (( _g15 < _g6 ))
			{
				int i5 = _g15++;
				if (( i5 > 0 )) 
				{
					sql_dbl_cols += ",";
				}
				
				java.lang.String n2 = this.local.getQuotedColumnName(all_cols.__get(i5));
				java.lang.String buf = ( "__coopy_" + i5 );
				sql_dbl_cols += ( ( ( ( sql_table1 + "." ) + n2 ) + " AS " ) + buf );
				dbl_cols.push(buf);
				sql_dbl_cols += ",";
				sql_dbl_cols += ( ( ( ( ( sql_table2 + "." ) + n2 ) + " AS " ) + buf ) + "b" );
				dbl_cols.push(( buf + "b" ));
			}
			
		}
		
		java.lang.String sql_order = "";
		{
			int _g16 = 0;
			int _g7 = key_cols.length;
			while (( _g16 < _g7 ))
			{
				int i6 = _g16++;
				if (( i6 > 0 )) 
				{
					sql_order += ",";
				}
				
				java.lang.String n3 = this.local.getQuotedColumnName(key_cols.__get(i6));
				sql_order += n3;
			}
			
		}
		
		java.lang.String sql_dbl_order = "";
		{
			int _g17 = 0;
			int _g8 = key_cols.length;
			while (( _g17 < _g8 ))
			{
				int i7 = _g17++;
				if (( i7 > 0 )) 
				{
					sql_dbl_order += ",";
				}
				
				java.lang.String n4 = this.local.getQuotedColumnName(key_cols.__get(i7));
				sql_dbl_order += ( ( sql_table1 + "." ) + n4 );
			}
			
		}
		
		java.lang.String rowid = "-3";
		java.lang.String rowid1 = "-3";
		java.lang.String rowid2 = "-3";
		if (( rowid_name != null )) 
		{
			rowid = rowid_name;
			rowid1 = ( ( sql_table1 + "." ) + rowid_name );
			rowid2 = ( ( sql_table2 + "." ) + rowid_name );
		}
		
		java.lang.String sql_inserts = ( ( ( ( ( ( ( ( ( ( "SELECT DISTINCT NULL, " + rowid ) + " AS rowid, " ) + sql_all_cols ) + " FROM " ) + sql_table2 ) + " WHERE NOT EXISTS (SELECT 1 FROM " ) + sql_table1 ) + " WHERE " ) + sql_key_match ) + ")" );
		haxe.root.Array<java.lang.String> sql_inserts_order = new haxe.root.Array<java.lang.String>(new java.lang.String[]{"NULL", "rowid"}).concat(all_cols);
		java.lang.String sql_updates = ( ( ( ( ( ( ( ( ( ( ( ( ( "SELECT DISTINCT " + rowid1 ) + " AS __coopy_rowid0, " ) + rowid2 ) + " AS __coopy_rowid1, " ) + sql_dbl_cols ) + " FROM " ) + sql_table1 ) + " INNER JOIN " ) + sql_table2 ) + " ON " ) + sql_key_match ) + " WHERE " ) + sql_data_mismatch );
		haxe.root.Array<java.lang.String> sql_updates_order = new haxe.root.Array<java.lang.String>(new java.lang.String[]{"__coopy_rowid0", "__coopy_rowid1"}).concat(dbl_cols);
		java.lang.String sql_deletes = ( ( ( ( ( ( ( ( ( ( "SELECT DISTINCT " + rowid ) + " AS rowid, NULL, " ) + sql_all_cols ) + " FROM " ) + sql_table1 ) + " WHERE NOT EXISTS (SELECT 1 FROM " ) + sql_table2 ) + " WHERE " ) + sql_key_match ) + ")" );
		haxe.root.Array<java.lang.String> sql_deletes_order = new haxe.root.Array<java.lang.String>(new java.lang.String[]{"rowid", "NULL"}).concat(all_cols);
		this.at0 = 1;
		this.at1 = 1;
		this.linkQuery(sql_inserts, sql_inserts_order);
		this.linkQuery(sql_updates, sql_updates_order);
		this.linkQuery(sql_deletes, sql_deletes_order);
		return this.align;
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef239 = true;
			switch (field.hashCode())
			{
				case 96862:
				{
					if (field.equals("at1")) 
					{
						__temp_executeDef239 = false;
						this.at1 = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 96861:
				{
					if (field.equals("at0")) 
					{
						__temp_executeDef239 = false;
						this.at0 = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef239) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef240 = true;
			switch (field.hashCode())
			{
				case 92903173:
				{
					if (field.equals("align")) 
					{
						__temp_executeDef240 = false;
						this.align = ((coopy.Alignment) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3198:
				{
					if (field.equals("db")) 
					{
						__temp_executeDef240 = false;
						this.db = ((coopy.SqlDatabase) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 96862:
				{
					if (field.equals("at1")) 
					{
						__temp_executeDef240 = false;
						this.at1 = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case -995424086:
				{
					if (field.equals("parent")) 
					{
						__temp_executeDef240 = false;
						this.parent = ((coopy.SqlTable) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 96861:
				{
					if (field.equals("at0")) 
					{
						__temp_executeDef240 = false;
						this.at0 = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 103145323:
				{
					if (field.equals("local")) 
					{
						__temp_executeDef240 = false;
						this.local = ((coopy.SqlTable) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -934610874:
				{
					if (field.equals("remote")) 
					{
						__temp_executeDef240 = false;
						this.remote = ((coopy.SqlTable) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef240) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef241 = true;
			switch (field.hashCode())
			{
				case 93029230:
				{
					if (field.equals("apply")) 
					{
						__temp_executeDef241 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("apply"))) );
					}
					
					break;
				}
				
				
				case 3198:
				{
					if (field.equals("db")) 
					{
						__temp_executeDef241 = false;
						return this.db;
					}
					
					break;
				}
				
				
				case -1637194514:
				{
					if (field.equals("linkQuery")) 
					{
						__temp_executeDef241 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("linkQuery"))) );
					}
					
					break;
				}
				
				
				case -995424086:
				{
					if (field.equals("parent")) 
					{
						__temp_executeDef241 = false;
						return this.parent;
					}
					
					break;
				}
				
				
				case 3321850:
				{
					if (field.equals("link")) 
					{
						__temp_executeDef241 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("link"))) );
					}
					
					break;
				}
				
				
				case 103145323:
				{
					if (field.equals("local")) 
					{
						__temp_executeDef241 = false;
						return this.local;
					}
					
					break;
				}
				
				
				case -1335383672:
				{
					if (field.equals("denull")) 
					{
						__temp_executeDef241 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("denull"))) );
					}
					
					break;
				}
				
				
				case -934610874:
				{
					if (field.equals("remote")) 
					{
						__temp_executeDef241 = false;
						return this.remote;
					}
					
					break;
				}
				
				
				case -345927081:
				{
					if (field.equals("validateSchema")) 
					{
						__temp_executeDef241 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("validateSchema"))) );
					}
					
					break;
				}
				
				
				case 96861:
				{
					if (field.equals("at0")) 
					{
						__temp_executeDef241 = false;
						return this.at0;
					}
					
					break;
				}
				
				
				case 342457221:
				{
					if (field.equals("equalArray")) 
					{
						__temp_executeDef241 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("equalArray"))) );
					}
					
					break;
				}
				
				
				case 96862:
				{
					if (field.equals("at1")) 
					{
						__temp_executeDef241 = false;
						return this.at1;
					}
					
					break;
				}
				
				
				case 92903173:
				{
					if (field.equals("align")) 
					{
						__temp_executeDef241 = false;
						return this.align;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef241) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef242 = true;
			switch (field.hashCode())
			{
				case 96862:
				{
					if (field.equals("at1")) 
					{
						__temp_executeDef242 = false;
						return ((double) (this.at1) );
					}
					
					break;
				}
				
				
				case 96861:
				{
					if (field.equals("at0")) 
					{
						__temp_executeDef242 = false;
						return ((double) (this.at0) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef242) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef243 = true;
			switch (field.hashCode())
			{
				case 93029230:
				{
					if (field.equals("apply")) 
					{
						__temp_executeDef243 = false;
						return this.apply();
					}
					
					break;
				}
				
				
				case 342457221:
				{
					if (field.equals("equalArray")) 
					{
						__temp_executeDef243 = false;
						return this.equalArray(((haxe.root.Array<java.lang.String>) (dynargs.__get(0)) ), ((haxe.root.Array<java.lang.String>) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case -1637194514:
				{
					if (field.equals("linkQuery")) 
					{
						__temp_executeDef243 = false;
						this.linkQuery(haxe.lang.Runtime.toString(dynargs.__get(0)), ((haxe.root.Array<java.lang.String>) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case -345927081:
				{
					if (field.equals("validateSchema")) 
					{
						__temp_executeDef243 = false;
						return this.validateSchema();
					}
					
					break;
				}
				
				
				case 3321850:
				{
					if (field.equals("link")) 
					{
						__temp_executeDef243 = false;
						this.link();
					}
					
					break;
				}
				
				
				case -1335383672:
				{
					if (field.equals("denull")) 
					{
						__temp_executeDef243 = false;
						return this.denull(dynargs.__get(0));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef243) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("align");
		baseArr.push("at1");
		baseArr.push("at0");
		baseArr.push("remote");
		baseArr.push("local");
		baseArr.push("parent");
		baseArr.push("db");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



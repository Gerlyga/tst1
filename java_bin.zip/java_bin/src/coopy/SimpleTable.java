package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class SimpleTable extends haxe.lang.HxObject implements coopy.Table
{
	public    SimpleTable(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    SimpleTable(int w, int h)
	{
		coopy.SimpleTable.__hx_ctor_coopy_SimpleTable(this, w, h);
	}
	
	
	public static   void __hx_ctor_coopy_SimpleTable(coopy.SimpleTable __temp_me34, int w, int h)
	{
		__temp_me34.data = new haxe.ds.IntMap();
		__temp_me34.w = w;
		__temp_me34.h = h;
	}
	
	
	public static   java.lang.String tableToString(coopy.Table tab)
	{
		java.lang.String x = "";
		{
			int _g1 = 0;
			int _g = tab.get_height();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				{
					int _g3 = 0;
					int _g2 = tab.get_width();
					while (( _g3 < _g2 ))
					{
						int j = _g3++;
						if (( j > 0 )) 
						{
							x += " ";
						}
						
						x += haxe.root.Std.string(tab.getCell(j, i));
					}
					
				}
				
				x += "\n";
			}
			
		}
		
		return x;
	}
	
	
	public static   boolean tableIsSimilar(coopy.Table tab1, coopy.Table tab2)
	{
		if (( tab1.get_width() != tab2.get_width() )) 
		{
			return false;
		}
		
		if (( tab1.get_height() != tab2.get_height() )) 
		{
			return false;
		}
		
		coopy.View v = tab1.getCellView();
		{
			int _g1 = 0;
			int _g = tab1.get_height();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				{
					int _g3 = 0;
					int _g2 = tab1.get_width();
					while (( _g3 < _g2 ))
					{
						int j = _g3++;
						if ( ! (v.equals(tab1.getCell(j, i), tab2.getCell(j, i))) ) 
						{
							return false;
						}
						
					}
					
				}
				
			}
			
		}
		
		return true;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.SimpleTable(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.SimpleTable(((int) (haxe.lang.Runtime.toInt(arr.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(arr.__get(1))) ));
	}
	
	
	public  haxe.ds.IntMap data;
	
	public  int w;
	
	public  int h;
	
	public   coopy.Table getTable()
	{
		return this;
	}
	
	
	
	
	
	
	public   int get_width()
	{
		return this.w;
	}
	
	
	public   int get_height()
	{
		return this.h;
	}
	
	
	public   java.lang.Object getCell(int x, int y)
	{
		return this.data.get(((int) (( x + ( y * this.w ) )) ));
	}
	
	
	public   void setCell(int x, int y, java.lang.Object c)
	{
		java.lang.Object value = c;
		this.data.set(( x + ( y * this.w ) ), value);
	}
	
	
	@Override public   java.lang.String toString()
	{
		return coopy.SimpleTable.tableToString(this);
	}
	
	
	public   coopy.View getCellView()
	{
		return new coopy.SimpleView();
	}
	
	
	public   boolean isResizable()
	{
		return true;
	}
	
	
	public   boolean resize(int w, int h)
	{
		this.w = w;
		this.h = h;
		return true;
	}
	
	
	public   void clear()
	{
		this.data = new haxe.ds.IntMap();
	}
	
	
	public   boolean insertOrDeleteRows(haxe.root.Array<java.lang.Object> fate, int hfate)
	{
		haxe.ds.IntMap data2 = new haxe.ds.IntMap();
		{
			int _g1 = 0;
			int _g = fate.length;
			while (( _g1 < _g ))
			{
				int i = _g1++;
				int j = ((int) (haxe.lang.Runtime.toInt(fate.__get(i))) );
				if (( j != -1 )) 
				{
					int _g3 = 0;
					int _g2 = this.w;
					while (( _g3 < _g2 ))
					{
						int c = _g3++;
						int idx = ( ( i * this.w ) + c );
						if (this.data.exists(idx)) 
						{
							java.lang.Object value = this.data.get(((int) (idx) ));
							data2.set(( ( j * this.w ) + c ), value);
						}
						
					}
					
				}
				
			}
			
		}
		
		this.h = hfate;
		this.data = data2;
		return true;
	}
	
	
	public   boolean insertOrDeleteColumns(haxe.root.Array<java.lang.Object> fate, int wfate)
	{
		haxe.ds.IntMap data2 = new haxe.ds.IntMap();
		{
			int _g1 = 0;
			int _g = fate.length;
			while (( _g1 < _g ))
			{
				int i = _g1++;
				int j = ((int) (haxe.lang.Runtime.toInt(fate.__get(i))) );
				if (( j != -1 )) 
				{
					int _g3 = 0;
					int _g2 = this.h;
					while (( _g3 < _g2 ))
					{
						int r = _g3++;
						int idx = ( ( r * this.w ) + i );
						if (this.data.exists(idx)) 
						{
							java.lang.Object value = this.data.get(((int) (idx) ));
							data2.set(( ( r * wfate ) + j ), value);
						}
						
					}
					
				}
				
			}
			
		}
		
		this.w = wfate;
		this.data = data2;
		return true;
	}
	
	
	public   boolean trimBlank()
	{
		if (( this.h == 0 )) 
		{
			return true;
		}
		
		int h_test = this.h;
		if (( h_test >= 3 )) 
		{
			h_test = 3;
		}
		
		coopy.View view = this.getCellView();
		java.lang.Object space = view.toDatum("");
		boolean more = true;
		while (more)
		{
			{
				int _g1 = 0;
				int _g = this.get_width();
				while (( _g1 < _g ))
				{
					int i = _g1++;
					java.lang.Object c = this.getCell(i, ( this.h - 1 ));
					if ( ! ((( view.equals(c, space) || ( c == null ) ))) ) 
					{
						more = false;
						break;
					}
					
				}
				
			}
			
			if (more) 
			{
				this.h--;
			}
			
		}
		
		more = true;
		int nw = this.w;
		while (more)
		{
			if (( this.w == 0 )) 
			{
				break;
			}
			
			{
				int _g2 = 0;
				while (( _g2 < h_test ))
				{
					int i1 = _g2++;
					java.lang.Object c1 = this.getCell(( nw - 1 ), i1);
					if ( ! ((( view.equals(c1, space) || ( c1 == null ) ))) ) 
					{
						more = false;
						break;
					}
					
				}
				
			}
			
			if (more) 
			{
				nw--;
			}
			
		}
		
		if (( nw == this.w )) 
		{
			return true;
		}
		
		haxe.ds.IntMap data2 = new haxe.ds.IntMap();
		{
			int _g3 = 0;
			while (( _g3 < nw ))
			{
				int i2 = _g3++;
				{
					int _g21 = 0;
					int _g11 = this.h;
					while (( _g21 < _g11 ))
					{
						int r = _g21++;
						int idx = ( ( r * this.w ) + i2 );
						if (this.data.exists(idx)) 
						{
							java.lang.Object value = this.data.get(((int) (idx) ));
							data2.set(( ( r * nw ) + i2 ), value);
						}
						
					}
					
				}
				
			}
			
		}
		
		this.w = nw;
		this.data = data2;
		return true;
	}
	
	
	public   java.lang.Object getData()
	{
		return null;
	}
	
	
	public   coopy.Table clone()
	{
		coopy.SimpleTable result = new coopy.SimpleTable(((int) (this.get_width()) ), ((int) (this.get_height()) ));
		{
			int _g1 = 0;
			int _g = this.get_height();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				{
					int _g3 = 0;
					int _g2 = this.get_width();
					while (( _g3 < _g2 ))
					{
						int j = _g3++;
						result.setCell(j, i, this.getCell(j, i));
					}
					
				}
				
			}
			
		}
		
		return result;
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef224 = true;
			switch (field.hashCode())
			{
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef224 = false;
						this.h = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 119:
				{
					if (field.equals("w")) 
					{
						__temp_executeDef224 = false;
						this.w = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef224) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef225 = true;
			switch (field.hashCode())
			{
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef225 = false;
						this.h = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 3076010:
				{
					if (field.equals("data")) 
					{
						__temp_executeDef225 = false;
						this.data = ((haxe.ds.IntMap) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 119:
				{
					if (field.equals("w")) 
					{
						__temp_executeDef225 = false;
						this.w = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef225) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef226 = true;
			switch (field.hashCode())
			{
				case 94756189:
				{
					if (field.equals("clone")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("clone"))) );
					}
					
					break;
				}
				
				
				case 3076010:
				{
					if (field.equals("data")) 
					{
						__temp_executeDef226 = false;
						return this.data;
					}
					
					break;
				}
				
				
				case -75605984:
				{
					if (field.equals("getData")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getData"))) );
					}
					
					break;
				}
				
				
				case 119:
				{
					if (field.equals("w")) 
					{
						__temp_executeDef226 = false;
						return this.w;
					}
					
					break;
				}
				
				
				case -510954926:
				{
					if (field.equals("trimBlank")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("trimBlank"))) );
					}
					
					break;
				}
				
				
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef226 = false;
						return this.h;
					}
					
					break;
				}
				
				
				case 1889278614:
				{
					if (field.equals("insertOrDeleteColumns")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("insertOrDeleteColumns"))) );
					}
					
					break;
				}
				
				
				case 1965941272:
				{
					if (field.equals("getTable")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getTable"))) );
					}
					
					break;
				}
				
				
				case 1186308544:
				{
					if (field.equals("insertOrDeleteRows")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("insertOrDeleteRows"))) );
					}
					
					break;
				}
				
				
				case -1221029593:
				{
					if (field.equals("height")) 
					{
						__temp_executeDef226 = false;
						return this.get_height();
					}
					
					break;
				}
				
				
				case 94746189:
				{
					if (field.equals("clear")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("clear"))) );
					}
					
					break;
				}
				
				
				case 113126854:
				{
					if (field.equals("width")) 
					{
						__temp_executeDef226 = false;
						return this.get_width();
					}
					
					break;
				}
				
				
				case -934437708:
				{
					if (field.equals("resize")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("resize"))) );
					}
					
					break;
				}
				
				
				case 1150076829:
				{
					if (field.equals("get_width")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("get_width"))) );
					}
					
					break;
				}
				
				
				case -972315487:
				{
					if (field.equals("isResizable")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("isResizable"))) );
					}
					
					break;
				}
				
				
				case 859648560:
				{
					if (field.equals("get_height")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("get_height"))) );
					}
					
					break;
				}
				
				
				case 1160377501:
				{
					if (field.equals("getCellView")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getCellView"))) );
					}
					
					break;
				}
				
				
				case -75632168:
				{
					if (field.equals("getCell")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getCell"))) );
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 1984477412:
				{
					if (field.equals("setCell")) 
					{
						__temp_executeDef226 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setCell"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef226) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef227 = true;
			switch (field.hashCode())
			{
				case 113126854:
				{
					if (field.equals("width")) 
					{
						__temp_executeDef227 = false;
						return ((double) (this.get_width()) );
					}
					
					break;
				}
				
				
				case 119:
				{
					if (field.equals("w")) 
					{
						__temp_executeDef227 = false;
						return ((double) (this.w) );
					}
					
					break;
				}
				
				
				case -1221029593:
				{
					if (field.equals("height")) 
					{
						__temp_executeDef227 = false;
						return ((double) (this.get_height()) );
					}
					
					break;
				}
				
				
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef227 = false;
						return ((double) (this.h) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef227) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef228 = true;
			switch (field.hashCode())
			{
				case 94756189:
				{
					if (field.equals("clone")) 
					{
						__temp_executeDef228 = false;
						return this.clone();
					}
					
					break;
				}
				
				
				case 1965941272:
				{
					if (field.equals("getTable")) 
					{
						__temp_executeDef228 = false;
						return this.getTable();
					}
					
					break;
				}
				
				
				case -75605984:
				{
					if (field.equals("getData")) 
					{
						__temp_executeDef228 = false;
						return this.getData();
					}
					
					break;
				}
				
				
				case 1150076829:
				{
					if (field.equals("get_width")) 
					{
						__temp_executeDef228 = false;
						return this.get_width();
					}
					
					break;
				}
				
				
				case -510954926:
				{
					if (field.equals("trimBlank")) 
					{
						__temp_executeDef228 = false;
						return this.trimBlank();
					}
					
					break;
				}
				
				
				case 859648560:
				{
					if (field.equals("get_height")) 
					{
						__temp_executeDef228 = false;
						return this.get_height();
					}
					
					break;
				}
				
				
				case 1889278614:
				{
					if (field.equals("insertOrDeleteColumns")) 
					{
						__temp_executeDef228 = false;
						return this.insertOrDeleteColumns(((haxe.root.Array<java.lang.Object>) (dynargs.__get(0)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case -75632168:
				{
					if (field.equals("getCell")) 
					{
						__temp_executeDef228 = false;
						return this.getCell(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case 1186308544:
				{
					if (field.equals("insertOrDeleteRows")) 
					{
						__temp_executeDef228 = false;
						return this.insertOrDeleteRows(((haxe.root.Array<java.lang.Object>) (dynargs.__get(0)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case 1984477412:
				{
					if (field.equals("setCell")) 
					{
						__temp_executeDef228 = false;
						this.setCell(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), dynargs.__get(2));
					}
					
					break;
				}
				
				
				case 94746189:
				{
					if (field.equals("clear")) 
					{
						__temp_executeDef228 = false;
						this.clear();
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef228 = false;
						return this.toString();
					}
					
					break;
				}
				
				
				case -934437708:
				{
					if (field.equals("resize")) 
					{
						__temp_executeDef228 = false;
						return this.resize(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case 1160377501:
				{
					if (field.equals("getCellView")) 
					{
						__temp_executeDef228 = false;
						return this.getCellView();
					}
					
					break;
				}
				
				
				case -972315487:
				{
					if (field.equals("isResizable")) 
					{
						__temp_executeDef228 = false;
						return this.isResizable();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef228) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("width");
		baseArr.push("height");
		baseArr.push("h");
		baseArr.push("w");
		baseArr.push("data");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



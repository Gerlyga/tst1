package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class CrossMatch extends haxe.lang.HxObject
{
	public    CrossMatch(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    CrossMatch()
	{
		coopy.CrossMatch.__hx_ctor_coopy_CrossMatch(this);
	}
	
	
	public static   void __hx_ctor_coopy_CrossMatch(coopy.CrossMatch __temp_me17)
	{
		{
		}
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.CrossMatch(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.CrossMatch();
	}
	
	
	public  int spot_a;
	
	public  int spot_b;
	
	public  coopy.IndexItem item_a;
	
	public  coopy.IndexItem item_b;
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef155 = true;
			switch (field.hashCode())
			{
				case -895759259:
				{
					if (field.equals("spot_b")) 
					{
						__temp_executeDef155 = false;
						this.spot_b = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -895759260:
				{
					if (field.equals("spot_a")) 
					{
						__temp_executeDef155 = false;
						this.spot_a = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef155) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef156 = true;
			switch (field.hashCode())
			{
				case -1178661322:
				{
					if (field.equals("item_b")) 
					{
						__temp_executeDef156 = false;
						this.item_b = ((coopy.IndexItem) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -895759260:
				{
					if (field.equals("spot_a")) 
					{
						__temp_executeDef156 = false;
						this.spot_a = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case -1178661323:
				{
					if (field.equals("item_a")) 
					{
						__temp_executeDef156 = false;
						this.item_a = ((coopy.IndexItem) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -895759259:
				{
					if (field.equals("spot_b")) 
					{
						__temp_executeDef156 = false;
						this.spot_b = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef156) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef157 = true;
			switch (field.hashCode())
			{
				case -1178661322:
				{
					if (field.equals("item_b")) 
					{
						__temp_executeDef157 = false;
						return this.item_b;
					}
					
					break;
				}
				
				
				case -895759260:
				{
					if (field.equals("spot_a")) 
					{
						__temp_executeDef157 = false;
						return this.spot_a;
					}
					
					break;
				}
				
				
				case -1178661323:
				{
					if (field.equals("item_a")) 
					{
						__temp_executeDef157 = false;
						return this.item_a;
					}
					
					break;
				}
				
				
				case -895759259:
				{
					if (field.equals("spot_b")) 
					{
						__temp_executeDef157 = false;
						return this.spot_b;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef157) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef158 = true;
			switch (field.hashCode())
			{
				case -895759259:
				{
					if (field.equals("spot_b")) 
					{
						__temp_executeDef158 = false;
						return ((double) (this.spot_b) );
					}
					
					break;
				}
				
				
				case -895759260:
				{
					if (field.equals("spot_a")) 
					{
						__temp_executeDef158 = false;
						return ((double) (this.spot_a) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef158) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("item_b");
		baseArr.push("item_a");
		baseArr.push("spot_b");
		baseArr.push("spot_a");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



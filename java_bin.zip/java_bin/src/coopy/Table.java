package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  interface Table extends haxe.lang.IHxObject
{
	   java.lang.Object getCell(int x, int y);
	
	   void setCell(int x, int y, java.lang.Object c);
	
	   coopy.View getCellView();
	
	   boolean isResizable();
	
	   boolean resize(int w, int h);
	
	   void clear();
	
	   boolean insertOrDeleteRows(haxe.root.Array<java.lang.Object> fate, int hfate);
	
	   boolean insertOrDeleteColumns(haxe.root.Array<java.lang.Object> fate, int wfate);
	
	   boolean trimBlank();
	
	   int get_width();
	
	   int get_height();
	
	   java.lang.Object getData();
	
	   coopy.Table clone();
	
}



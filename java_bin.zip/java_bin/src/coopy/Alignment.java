package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Alignment extends haxe.lang.HxObject
{
	public    Alignment(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Alignment()
	{
		coopy.Alignment.__hx_ctor_coopy_Alignment(this);
	}
	
	
	public static   void __hx_ctor_coopy_Alignment(coopy.Alignment __temp_me12)
	{
		__temp_me12.map_a2b = new haxe.ds.IntMap<java.lang.Object>();
		__temp_me12.map_b2a = new haxe.ds.IntMap<java.lang.Object>();
		__temp_me12.ha = __temp_me12.hb = 0;
		__temp_me12.map_count = 0;
		__temp_me12.reference = null;
		__temp_me12.meta = null;
		__temp_me12.order_cache_has_reference = false;
		__temp_me12.ia = -1;
		__temp_me12.ib = -1;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.Alignment(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.Alignment();
	}
	
	
	public  haxe.ds.IntMap<java.lang.Object> map_a2b;
	
	public  haxe.ds.IntMap<java.lang.Object> map_b2a;
	
	public  int ha;
	
	public  int hb;
	
	public  coopy.Table ta;
	
	public  coopy.Table tb;
	
	public  int ia;
	
	public  int ib;
	
	public  int map_count;
	
	public  coopy.Ordering order_cache;
	
	public  boolean order_cache_has_reference;
	
	public  haxe.root.Array<coopy.Unit> index_columns;
	
	public  coopy.Alignment reference;
	
	public  coopy.Alignment meta;
	
	public   void range(int ha, int hb)
	{
		this.ha = ha;
		this.hb = hb;
	}
	
	
	public   void tables(coopy.Table ta, coopy.Table tb)
	{
		this.ta = ta;
		this.tb = tb;
	}
	
	
	public   void headers(int ia, int ib)
	{
		this.ia = ia;
		this.ib = ib;
	}
	
	
	public   void setRowlike(boolean flag)
	{
		{
		}
		
	}
	
	
	public   void link(int a, int b)
	{
		this.map_a2b.set(a, b);
		this.map_b2a.set(b, a);
		this.map_count++;
	}
	
	
	public   void addIndexColumns(coopy.Unit unit)
	{
		if (( this.index_columns == null )) 
		{
			this.index_columns = new haxe.root.Array<coopy.Unit>();
		}
		
		this.index_columns.push(unit);
	}
	
	
	public   haxe.root.Array<coopy.Unit> getIndexColumns()
	{
		return this.index_columns;
	}
	
	
	public   java.lang.Object a2b(int a)
	{
		return this.map_a2b.get(((int) (a) ));
	}
	
	
	public   java.lang.Object b2a(int b)
	{
		return this.map_b2a.get(((int) (b) ));
	}
	
	
	public   int count()
	{
		return this.map_count;
	}
	
	
	@Override public   java.lang.String toString()
	{
		return ( "" + this.map_a2b.toString() );
	}
	
	
	public   coopy.Ordering toOrder()
	{
		if (( this.order_cache != null )) 
		{
			if (( this.reference != null )) 
			{
				if ( ! (this.order_cache_has_reference) ) 
				{
					this.order_cache = null;
				}
				
			}
			
		}
		
		if (( this.order_cache == null )) 
		{
			this.order_cache = this.toOrder3();
		}
		
		if (( this.reference != null )) 
		{
			this.order_cache_has_reference = true;
		}
		
		return this.order_cache;
	}
	
	
	public   void addToOrder(int l, int r, java.lang.Object p)
	{
		java.lang.Object __temp_p11 = ( (( p == null )) ? (((java.lang.Object) (-2) )) : (((java.lang.Object) (p) )) );
		if (( this.order_cache == null )) 
		{
			this.order_cache = new coopy.Ordering();
		}
		
		this.order_cache.add(l, r, __temp_p11);
		this.order_cache_has_reference = ( ! (haxe.lang.Runtime.eq(__temp_p11, -2)) );
	}
	
	
	public   coopy.Table getSource()
	{
		return this.ta;
	}
	
	
	public   coopy.Table getTarget()
	{
		return this.tb;
	}
	
	
	public   int getSourceHeader()
	{
		return this.ia;
	}
	
	
	public   int getTargetHeader()
	{
		return this.ib;
	}
	
	
	public   coopy.Ordering toOrder3()
	{
		coopy.Alignment ref = this.reference;
		if (( ref == null )) 
		{
			ref = new coopy.Alignment();
			ref.range(this.ha, this.ha);
			ref.tables(this.ta, this.ta);
			{
				int _g1 = 0;
				int _g = this.ha;
				while (( _g1 < _g ))
				{
					int i = _g1++;
					ref.link(i, i);
				}
				
			}
			
		}
		
		coopy.Ordering order = new coopy.Ordering();
		if (( this.reference == null )) 
		{
			order.ignoreParent();
		}
		
		int xp = 0;
		int xl = 0;
		int xr = 0;
		int hp = this.ha;
		int hl = ref.hb;
		int hr = this.hb;
		haxe.ds.IntMap<java.lang.Object> vp = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> vl = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> vr = new haxe.ds.IntMap<java.lang.Object>();
		{
			int _g2 = 0;
			while (( _g2 < hp ))
			{
				int i1 = _g2++;
				vp.set(i1, i1);
			}
			
		}
		
		{
			int _g3 = 0;
			while (( _g3 < hl ))
			{
				int i2 = _g3++;
				vl.set(i2, i2);
			}
			
		}
		
		{
			int _g4 = 0;
			while (( _g4 < hr ))
			{
				int i3 = _g4++;
				vr.set(i3, i3);
			}
			
		}
		
		int ct_vp = hp;
		int ct_vl = hl;
		int ct_vr = hr;
		int prev = -1;
		int ct = 0;
		int max_ct = ( (( ( hp + hl ) + hr )) * 10 );
		while (( ( ( ct_vp > 0 ) || ( ct_vl > 0 ) ) || ( ct_vr > 0 ) ))
		{
			ct++;
			if (( ct > max_ct )) 
			{
				haxe.Log.trace.__hx_invoke2_o(0.0, "Ordering took too long, something went wrong", 0.0, new haxe.lang.DynamicObject(new haxe.root.Array<java.lang.String>(new java.lang.String[]{"className", "fileName", "methodName"}), new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{"coopy.Alignment", "Alignment.hx", "toOrder3"}), new haxe.root.Array<java.lang.String>(new java.lang.String[]{"lineNumber"}), new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{((java.lang.Object) (((double) (277) )) )})));
				break;
			}
			
			if (( xp >= hp )) 
			{
				xp = 0;
			}
			
			if (( xl >= hl )) 
			{
				xl = 0;
			}
			
			if (( xr >= hr )) 
			{
				xr = 0;
			}
			
			if (( ( xp < hp ) && ( ct_vp > 0 ) )) 
			{
				if (( ( this.a2b(xp) == null ) && ( ref.a2b(xp) == null ) )) 
				{
					if (vp.exists(xp)) 
					{
						order.add(-1, -1, xp);
						prev = xp;
						vp.remove(xp);
						ct_vp--;
					}
					
					xp++;
					continue;
				}
				
			}
			
			java.lang.Object zl = null;
			java.lang.Object zr = null;
			if (( ( xl < hl ) && ( ct_vl > 0 ) )) 
			{
				zl = ref.b2a(xl);
				if (( zl == null )) 
				{
					if (vl.exists(xl)) 
					{
						order.add(xl, -1, -1);
						vl.remove(xl);
						ct_vl--;
					}
					
					xl++;
					continue;
				}
				
			}
			
			if (( ( xr < hr ) && ( ct_vr > 0 ) )) 
			{
				zr = this.b2a(xr);
				if (( zr == null )) 
				{
					if (vr.exists(xr)) 
					{
						order.add(-1, xr, -1);
						vr.remove(xr);
						ct_vr--;
					}
					
					xr++;
					continue;
				}
				
			}
			
			if (( ! (( zl == null )) )) 
			{
				if (( this.a2b(((int) (haxe.lang.Runtime.toInt(zl)) )) == null )) 
				{
					if (vl.exists(xl)) 
					{
						order.add(xl, -1, zl);
						prev = ((int) (haxe.lang.Runtime.toInt(zl)) );
						vp.remove(((int) (haxe.lang.Runtime.toInt(zl)) ));
						ct_vp--;
						vl.remove(xl);
						ct_vl--;
						xp = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.plus(zl, 1))) );
					}
					
					xl++;
					continue;
				}
				
			}
			
			if (( ! (( zr == null )) )) 
			{
				if (( ref.a2b(((int) (haxe.lang.Runtime.toInt(zr)) )) == null )) 
				{
					if (vr.exists(xr)) 
					{
						order.add(-1, xr, zr);
						prev = ((int) (haxe.lang.Runtime.toInt(zr)) );
						vp.remove(((int) (haxe.lang.Runtime.toInt(zr)) ));
						ct_vp--;
						vr.remove(xr);
						ct_vr--;
						xp = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.plus(zr, 1))) );
					}
					
					xr++;
					continue;
				}
				
			}
			
			if (( ( ( ( ! (( zl == null )) ) && ( ! (( zr == null )) ) ) && ( ! (( this.a2b(((int) (haxe.lang.Runtime.toInt(zl)) )) == null )) ) ) && ( ! (( ref.a2b(((int) (haxe.lang.Runtime.toInt(zr)) )) == null )) ) )) 
			{
				if (( haxe.lang.Runtime.eq(zl, ( prev + 1 )) || ( ! (haxe.lang.Runtime.eq(zr, ( prev + 1 ))) ) )) 
				{
					if (vr.exists(xr)) 
					{
						order.add(((int) (haxe.lang.Runtime.toInt(ref.a2b(((int) (haxe.lang.Runtime.toInt(zr)) )))) ), xr, zr);
						prev = ((int) (haxe.lang.Runtime.toInt(zr)) );
						vp.remove(((int) (haxe.lang.Runtime.toInt(zr)) ));
						ct_vp--;
						{
							int key = ((int) (haxe.lang.Runtime.toInt(ref.a2b(((int) (haxe.lang.Runtime.toInt(zr)) )))) );
							vl.remove(key);
						}
						
						ct_vl--;
						vr.remove(xr);
						ct_vr--;
						xp = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.plus(zr, 1))) );
						xl = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.plus(ref.a2b(((int) (haxe.lang.Runtime.toInt(zr)) )), 1))) );
					}
					
					xr++;
					continue;
				}
				 else 
				{
					if (vl.exists(xl)) 
					{
						order.add(xl, ((int) (haxe.lang.Runtime.toInt(this.a2b(((int) (haxe.lang.Runtime.toInt(zl)) )))) ), zl);
						prev = ((int) (haxe.lang.Runtime.toInt(zl)) );
						vp.remove(((int) (haxe.lang.Runtime.toInt(zl)) ));
						ct_vp--;
						vl.remove(xl);
						ct_vl--;
						{
							int key1 = ((int) (haxe.lang.Runtime.toInt(this.a2b(((int) (haxe.lang.Runtime.toInt(zl)) )))) );
							vr.remove(key1);
						}
						
						ct_vr--;
						xp = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.plus(zl, 1))) );
						xr = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.plus(this.a2b(((int) (haxe.lang.Runtime.toInt(zl)) )), 1))) );
					}
					
					xl++;
					continue;
				}
				
			}
			
			xp++;
			xl++;
			xr++;
		}
		
		return order;
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef128 = true;
			switch (field.hashCode())
			{
				case 1240654956:
				{
					if (field.equals("map_count")) 
					{
						__temp_executeDef128 = false;
						this.map_count = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3321:
				{
					if (field.equals("ha")) 
					{
						__temp_executeDef128 = false;
						this.ha = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3353:
				{
					if (field.equals("ib")) 
					{
						__temp_executeDef128 = false;
						this.ib = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3322:
				{
					if (field.equals("hb")) 
					{
						__temp_executeDef128 = false;
						this.hb = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3352:
				{
					if (field.equals("ia")) 
					{
						__temp_executeDef128 = false;
						this.ia = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef128) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef129 = true;
			switch (field.hashCode())
			{
				case 3347973:
				{
					if (field.equals("meta")) 
					{
						__temp_executeDef129 = false;
						this.meta = ((coopy.Alignment) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 837040430:
				{
					if (field.equals("map_a2b")) 
					{
						__temp_executeDef129 = false;
						this.map_a2b = ((haxe.ds.IntMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -925155509:
				{
					if (field.equals("reference")) 
					{
						__temp_executeDef129 = false;
						this.reference = ((coopy.Alignment) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 837041390:
				{
					if (field.equals("map_b2a")) 
					{
						__temp_executeDef129 = false;
						this.map_b2a = ((haxe.ds.IntMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -241076880:
				{
					if (field.equals("index_columns")) 
					{
						__temp_executeDef129 = false;
						this.index_columns = ((haxe.root.Array<coopy.Unit>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3321:
				{
					if (field.equals("ha")) 
					{
						__temp_executeDef129 = false;
						this.ha = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 1766878072:
				{
					if (field.equals("order_cache_has_reference")) 
					{
						__temp_executeDef129 = false;
						this.order_cache_has_reference = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 3322:
				{
					if (field.equals("hb")) 
					{
						__temp_executeDef129 = false;
						this.hb = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 1957914449:
				{
					if (field.equals("order_cache")) 
					{
						__temp_executeDef129 = false;
						this.order_cache = ((coopy.Ordering) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3693:
				{
					if (field.equals("ta")) 
					{
						__temp_executeDef129 = false;
						this.ta = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1240654956:
				{
					if (field.equals("map_count")) 
					{
						__temp_executeDef129 = false;
						this.map_count = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 3694:
				{
					if (field.equals("tb")) 
					{
						__temp_executeDef129 = false;
						this.tb = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3353:
				{
					if (field.equals("ib")) 
					{
						__temp_executeDef129 = false;
						this.ib = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 3352:
				{
					if (field.equals("ia")) 
					{
						__temp_executeDef129 = false;
						this.ia = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef129) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef130 = true;
			switch (field.hashCode())
			{
				case -1893706496:
				{
					if (field.equals("toOrder3")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toOrder3"))) );
					}
					
					break;
				}
				
				
				case 837040430:
				{
					if (field.equals("map_a2b")) 
					{
						__temp_executeDef130 = false;
						return this.map_a2b;
					}
					
					break;
				}
				
				
				case 756654580:
				{
					if (field.equals("getTargetHeader")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getTargetHeader"))) );
					}
					
					break;
				}
				
				
				case 837041390:
				{
					if (field.equals("map_b2a")) 
					{
						__temp_executeDef130 = false;
						return this.map_b2a;
					}
					
					break;
				}
				
				
				case -1669920514:
				{
					if (field.equals("getSourceHeader")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getSourceHeader"))) );
					}
					
					break;
				}
				
				
				case 3321:
				{
					if (field.equals("ha")) 
					{
						__temp_executeDef130 = false;
						return this.ha;
					}
					
					break;
				}
				
				
				case 815109255:
				{
					if (field.equals("getTarget")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getTarget"))) );
					}
					
					break;
				}
				
				
				case 3322:
				{
					if (field.equals("hb")) 
					{
						__temp_executeDef130 = false;
						return this.hb;
					}
					
					break;
				}
				
				
				case 799509265:
				{
					if (field.equals("getSource")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getSource"))) );
					}
					
					break;
				}
				
				
				case 3693:
				{
					if (field.equals("ta")) 
					{
						__temp_executeDef130 = false;
						return this.ta;
					}
					
					break;
				}
				
				
				case 738768306:
				{
					if (field.equals("addToOrder")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("addToOrder"))) );
					}
					
					break;
				}
				
				
				case 3694:
				{
					if (field.equals("tb")) 
					{
						__temp_executeDef130 = false;
						return this.tb;
					}
					
					break;
				}
				
				
				case -1169465965:
				{
					if (field.equals("toOrder")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toOrder"))) );
					}
					
					break;
				}
				
				
				case 3352:
				{
					if (field.equals("ia")) 
					{
						__temp_executeDef130 = false;
						return this.ia;
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 3353:
				{
					if (field.equals("ib")) 
					{
						__temp_executeDef130 = false;
						return this.ib;
					}
					
					break;
				}
				
				
				case 94851343:
				{
					if (field.equals("count")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("count"))) );
					}
					
					break;
				}
				
				
				case 1240654956:
				{
					if (field.equals("map_count")) 
					{
						__temp_executeDef130 = false;
						return this.map_count;
					}
					
					break;
				}
				
				
				case 95825:
				{
					if (field.equals("b2a")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("b2a"))) );
					}
					
					break;
				}
				
				
				case 1957914449:
				{
					if (field.equals("order_cache")) 
					{
						__temp_executeDef130 = false;
						return this.order_cache;
					}
					
					break;
				}
				
				
				case 94865:
				{
					if (field.equals("a2b")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("a2b"))) );
					}
					
					break;
				}
				
				
				case 1766878072:
				{
					if (field.equals("order_cache_has_reference")) 
					{
						__temp_executeDef130 = false;
						return this.order_cache_has_reference;
					}
					
					break;
				}
				
				
				case -1138398943:
				{
					if (field.equals("getIndexColumns")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getIndexColumns"))) );
					}
					
					break;
				}
				
				
				case -241076880:
				{
					if (field.equals("index_columns")) 
					{
						__temp_executeDef130 = false;
						return this.index_columns;
					}
					
					break;
				}
				
				
				case -688735764:
				{
					if (field.equals("addIndexColumns")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("addIndexColumns"))) );
					}
					
					break;
				}
				
				
				case -925155509:
				{
					if (field.equals("reference")) 
					{
						__temp_executeDef130 = false;
						return this.reference;
					}
					
					break;
				}
				
				
				case 3321850:
				{
					if (field.equals("link")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("link"))) );
					}
					
					break;
				}
				
				
				case 3347973:
				{
					if (field.equals("meta")) 
					{
						__temp_executeDef130 = false;
						return this.meta;
					}
					
					break;
				}
				
				
				case 65959343:
				{
					if (field.equals("setRowlike")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setRowlike"))) );
					}
					
					break;
				}
				
				
				case 108280125:
				{
					if (field.equals("range")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("range"))) );
					}
					
					break;
				}
				
				
				case 795307910:
				{
					if (field.equals("headers")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("headers"))) );
					}
					
					break;
				}
				
				
				case -881377691:
				{
					if (field.equals("tables")) 
					{
						__temp_executeDef130 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("tables"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef130) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef131 = true;
			switch (field.hashCode())
			{
				case 1240654956:
				{
					if (field.equals("map_count")) 
					{
						__temp_executeDef131 = false;
						return ((double) (this.map_count) );
					}
					
					break;
				}
				
				
				case 3321:
				{
					if (field.equals("ha")) 
					{
						__temp_executeDef131 = false;
						return ((double) (this.ha) );
					}
					
					break;
				}
				
				
				case 3353:
				{
					if (field.equals("ib")) 
					{
						__temp_executeDef131 = false;
						return ((double) (this.ib) );
					}
					
					break;
				}
				
				
				case 3322:
				{
					if (field.equals("hb")) 
					{
						__temp_executeDef131 = false;
						return ((double) (this.hb) );
					}
					
					break;
				}
				
				
				case 3352:
				{
					if (field.equals("ia")) 
					{
						__temp_executeDef131 = false;
						return ((double) (this.ia) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef131) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef132 = true;
			switch (field.hashCode())
			{
				case -1893706496:
				{
					if (field.equals("toOrder3")) 
					{
						__temp_executeDef132 = false;
						return this.toOrder3();
					}
					
					break;
				}
				
				
				case 108280125:
				{
					if (field.equals("range")) 
					{
						__temp_executeDef132 = false;
						this.range(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case 756654580:
				{
					if (field.equals("getTargetHeader")) 
					{
						__temp_executeDef132 = false;
						return this.getTargetHeader();
					}
					
					break;
				}
				
				
				case -881377691:
				{
					if (field.equals("tables")) 
					{
						__temp_executeDef132 = false;
						this.tables(((coopy.Table) (dynargs.__get(0)) ), ((coopy.Table) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case -1669920514:
				{
					if (field.equals("getSourceHeader")) 
					{
						__temp_executeDef132 = false;
						return this.getSourceHeader();
					}
					
					break;
				}
				
				
				case 795307910:
				{
					if (field.equals("headers")) 
					{
						__temp_executeDef132 = false;
						this.headers(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case 815109255:
				{
					if (field.equals("getTarget")) 
					{
						__temp_executeDef132 = false;
						return this.getTarget();
					}
					
					break;
				}
				
				
				case 65959343:
				{
					if (field.equals("setRowlike")) 
					{
						__temp_executeDef132 = false;
						this.setRowlike(haxe.lang.Runtime.toBool(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 799509265:
				{
					if (field.equals("getSource")) 
					{
						__temp_executeDef132 = false;
						return this.getSource();
					}
					
					break;
				}
				
				
				case 3321850:
				{
					if (field.equals("link")) 
					{
						__temp_executeDef132 = false;
						this.link(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case 738768306:
				{
					if (field.equals("addToOrder")) 
					{
						__temp_executeDef132 = false;
						this.addToOrder(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), dynargs.__get(2));
					}
					
					break;
				}
				
				
				case -688735764:
				{
					if (field.equals("addIndexColumns")) 
					{
						__temp_executeDef132 = false;
						this.addIndexColumns(((coopy.Unit) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case -1169465965:
				{
					if (field.equals("toOrder")) 
					{
						__temp_executeDef132 = false;
						return this.toOrder();
					}
					
					break;
				}
				
				
				case -1138398943:
				{
					if (field.equals("getIndexColumns")) 
					{
						__temp_executeDef132 = false;
						return this.getIndexColumns();
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef132 = false;
						return this.toString();
					}
					
					break;
				}
				
				
				case 94865:
				{
					if (field.equals("a2b")) 
					{
						__temp_executeDef132 = false;
						return this.a2b(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case 94851343:
				{
					if (field.equals("count")) 
					{
						__temp_executeDef132 = false;
						return this.count();
					}
					
					break;
				}
				
				
				case 95825:
				{
					if (field.equals("b2a")) 
					{
						__temp_executeDef132 = false;
						return this.b2a(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef132) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("meta");
		baseArr.push("reference");
		baseArr.push("index_columns");
		baseArr.push("order_cache_has_reference");
		baseArr.push("order_cache");
		baseArr.push("map_count");
		baseArr.push("ib");
		baseArr.push("ia");
		baseArr.push("tb");
		baseArr.push("ta");
		baseArr.push("hb");
		baseArr.push("ha");
		baseArr.push("map_b2a");
		baseArr.push("map_a2b");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



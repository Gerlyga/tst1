package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  interface SqlDatabase extends haxe.lang.IHxObject
{
	   haxe.root.Array<coopy.SqlColumn> getColumns(coopy.SqlTableName name);
	
	   java.lang.String getQuotedTableName(coopy.SqlTableName name);
	
	   java.lang.String getQuotedColumnName(java.lang.String name);
	
	   boolean begin(java.lang.String query, haxe.root.Array args, haxe.root.Array<java.lang.String> order);
	
	   boolean beginRow(coopy.SqlTableName name, int row, haxe.root.Array<java.lang.String> order);
	
	   boolean read();
	
	   java.lang.Object get(int index);
	
	   boolean end();
	
	   int width();
	
	   java.lang.String rowid();
	
}



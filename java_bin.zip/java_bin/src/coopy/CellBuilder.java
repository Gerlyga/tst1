package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  interface CellBuilder extends haxe.lang.IHxObject
{
	   boolean needSeparator();
	
	   void setSeparator(java.lang.String separator);
	
	   void setConflictSeparator(java.lang.String separator);
	
	   void setView(coopy.View view);
	
	   java.lang.Object update(java.lang.Object local, java.lang.Object remote);
	
	   java.lang.Object conflict(java.lang.Object parent, java.lang.Object local, java.lang.Object remote);
	
	   java.lang.Object marker(java.lang.String label);
	
	   java.lang.Object links(coopy.Unit unit);
	
}



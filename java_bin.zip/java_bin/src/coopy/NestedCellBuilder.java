package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class NestedCellBuilder extends haxe.lang.HxObject implements coopy.CellBuilder
{
	public    NestedCellBuilder(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    NestedCellBuilder()
	{
		coopy.NestedCellBuilder.__hx_ctor_coopy_NestedCellBuilder(this);
	}
	
	
	public static   void __hx_ctor_coopy_NestedCellBuilder(coopy.NestedCellBuilder __temp_me31)
	{
		{
		}
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.NestedCellBuilder(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.NestedCellBuilder();
	}
	
	
	public  coopy.View view;
	
	public   boolean needSeparator()
	{
		return false;
	}
	
	
	public   void setSeparator(java.lang.String separator)
	{
		{
		}
		
	}
	
	
	public   void setConflictSeparator(java.lang.String separator)
	{
		{
		}
		
	}
	
	
	public   void setView(coopy.View view)
	{
		this.view = view;
	}
	
	
	public   java.lang.Object update(java.lang.Object local, java.lang.Object remote)
	{
		java.lang.Object h = this.view.makeHash();
		this.view.hashSet(h, "before", local);
		this.view.hashSet(h, "after", remote);
		return h;
	}
	
	
	public   java.lang.Object conflict(java.lang.Object parent, java.lang.Object local, java.lang.Object remote)
	{
		java.lang.Object h = this.view.makeHash();
		this.view.hashSet(h, "before", parent);
		this.view.hashSet(h, "ours", local);
		this.view.hashSet(h, "theirs", remote);
		return h;
	}
	
	
	public   java.lang.Object marker(java.lang.String label)
	{
		return this.view.toDatum(label);
	}
	
	
	public   java.lang.Object negToNull(int x)
	{
		if (( x < 0 )) 
		{
			return null;
		}
		
		return x;
	}
	
	
	public   java.lang.Object links(coopy.Unit unit)
	{
		java.lang.Object h = this.view.makeHash();
		if (( unit.p >= -1 )) 
		{
			this.view.hashSet(h, "before", this.negToNull(unit.p));
			this.view.hashSet(h, "ours", this.negToNull(unit.l));
			this.view.hashSet(h, "theirs", this.negToNull(unit.r));
			return h;
		}
		
		this.view.hashSet(h, "before", this.negToNull(unit.l));
		this.view.hashSet(h, "after", this.negToNull(unit.r));
		return h;
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef218 = true;
			switch (field.hashCode())
			{
				case 3619493:
				{
					if (field.equals("view")) 
					{
						__temp_executeDef218 = false;
						this.view = ((coopy.View) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef218) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef219 = true;
			switch (field.hashCode())
			{
				case 102977465:
				{
					if (field.equals("links")) 
					{
						__temp_executeDef219 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("links"))) );
					}
					
					break;
				}
				
				
				case 3619493:
				{
					if (field.equals("view")) 
					{
						__temp_executeDef219 = false;
						return this.view;
					}
					
					break;
				}
				
				
				case -1887912878:
				{
					if (field.equals("negToNull")) 
					{
						__temp_executeDef219 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("negToNull"))) );
					}
					
					break;
				}
				
				
				case -1895251217:
				{
					if (field.equals("needSeparator")) 
					{
						__temp_executeDef219 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("needSeparator"))) );
					}
					
					break;
				}
				
				
				case -1081306054:
				{
					if (field.equals("marker")) 
					{
						__temp_executeDef219 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("marker"))) );
					}
					
					break;
				}
				
				
				case -1022749533:
				{
					if (field.equals("setSeparator")) 
					{
						__temp_executeDef219 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setSeparator"))) );
					}
					
					break;
				}
				
				
				case -580047918:
				{
					if (field.equals("conflict")) 
					{
						__temp_executeDef219 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("conflict"))) );
					}
					
					break;
				}
				
				
				case -1258842383:
				{
					if (field.equals("setConflictSeparator")) 
					{
						__temp_executeDef219 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setConflictSeparator"))) );
					}
					
					break;
				}
				
				
				case -838846263:
				{
					if (field.equals("update")) 
					{
						__temp_executeDef219 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("update"))) );
					}
					
					break;
				}
				
				
				case 1985047079:
				{
					if (field.equals("setView")) 
					{
						__temp_executeDef219 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setView"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef219) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef220 = true;
			switch (field.hashCode())
			{
				case 102977465:
				{
					if (field.equals("links")) 
					{
						__temp_executeDef220 = false;
						return this.links(((coopy.Unit) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case -1895251217:
				{
					if (field.equals("needSeparator")) 
					{
						__temp_executeDef220 = false;
						return this.needSeparator();
					}
					
					break;
				}
				
				
				case -1887912878:
				{
					if (field.equals("negToNull")) 
					{
						__temp_executeDef220 = false;
						return this.negToNull(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case -1022749533:
				{
					if (field.equals("setSeparator")) 
					{
						__temp_executeDef220 = false;
						this.setSeparator(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -1081306054:
				{
					if (field.equals("marker")) 
					{
						__temp_executeDef220 = false;
						return this.marker(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -1258842383:
				{
					if (field.equals("setConflictSeparator")) 
					{
						__temp_executeDef220 = false;
						this.setConflictSeparator(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -580047918:
				{
					if (field.equals("conflict")) 
					{
						__temp_executeDef220 = false;
						return this.conflict(dynargs.__get(0), dynargs.__get(1), dynargs.__get(2));
					}
					
					break;
				}
				
				
				case 1985047079:
				{
					if (field.equals("setView")) 
					{
						__temp_executeDef220 = false;
						this.setView(((coopy.View) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case -838846263:
				{
					if (field.equals("update")) 
					{
						__temp_executeDef220 = false;
						return this.update(dynargs.__get(0), dynargs.__get(1));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef220) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("view");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class SqliteHelper extends haxe.lang.HxObject implements coopy.SqlHelper
{
	public    SqliteHelper(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    SqliteHelper()
	{
		coopy.SqliteHelper.__hx_ctor_coopy_SqliteHelper(this);
	}
	
	
	public static   void __hx_ctor_coopy_SqliteHelper(coopy.SqliteHelper __temp_me41)
	{
		{
		}
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.SqliteHelper(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.SqliteHelper();
	}
	
	
	public   haxe.root.Array<java.lang.String> getTableNames(coopy.SqlDatabase db)
	{
		java.lang.String q = "SELECT name FROM sqlite_master WHERE type=\'table\' ORDER BY name";
		if ( ! (db.begin(q, null, new haxe.root.Array<java.lang.String>(new java.lang.String[]{"name"}))) ) 
		{
			return null;
		}
		
		haxe.root.Array<java.lang.String> names = new haxe.root.Array<java.lang.String>();
		while (db.read())
		{
			names.push(haxe.lang.Runtime.toString(db.get(0)));
		}
		
		db.end();
		return names;
	}
	
	
	public   int countRows(coopy.SqlDatabase db, coopy.SqlTableName name)
	{
		java.lang.String q = ( "SELECT COUNT(*) AS ct FROM " + db.getQuotedTableName(name) );
		if ( ! (db.begin(q, null, new haxe.root.Array<java.lang.String>(new java.lang.String[]{"ct"}))) ) 
		{
			return -1;
		}
		
		int ct = -1;
		while (db.read())
		{
			ct = ((int) (haxe.lang.Runtime.toInt(db.get(0))) );
		}
		
		db.end();
		return ct;
	}
	
	
	public   haxe.root.Array<java.lang.Object> getRowIDs(coopy.SqlDatabase db, coopy.SqlTableName name)
	{
		haxe.root.Array<java.lang.Object> result = new haxe.root.Array<java.lang.Object>();
		java.lang.String q = ( ( "SELECT ROWID AS r FROM " + db.getQuotedTableName(name) ) + " ORDER BY ROWID" );
		if ( ! (db.begin(q, null, new haxe.root.Array<java.lang.String>(new java.lang.String[]{"r"}))) ) 
		{
			return null;
		}
		
		while (db.read())
		{
			int c = ((int) (haxe.lang.Runtime.toInt(db.get(0))) );
			result.push(c);
		}
		
		db.end();
		return result;
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef256 = true;
			switch (field.hashCode())
			{
				case 770899348:
				{
					if (field.equals("getRowIDs")) 
					{
						__temp_executeDef256 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getRowIDs"))) );
					}
					
					break;
				}
				
				
				case -1818455024:
				{
					if (field.equals("getTableNames")) 
					{
						__temp_executeDef256 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getTableNames"))) );
					}
					
					break;
				}
				
				
				case 1351690120:
				{
					if (field.equals("countRows")) 
					{
						__temp_executeDef256 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("countRows"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef256) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef257 = true;
			switch (field.hashCode())
			{
				case 770899348:
				{
					if (field.equals("getRowIDs")) 
					{
						__temp_executeDef257 = false;
						return this.getRowIDs(((coopy.SqlDatabase) (dynargs.__get(0)) ), ((coopy.SqlTableName) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case -1818455024:
				{
					if (field.equals("getTableNames")) 
					{
						__temp_executeDef257 = false;
						return this.getTableNames(((coopy.SqlDatabase) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case 1351690120:
				{
					if (field.equals("countRows")) 
					{
						__temp_executeDef257 = false;
						return this.countRows(((coopy.SqlDatabase) (dynargs.__get(0)) ), ((coopy.SqlTableName) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef257) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
}



package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class FlatCellBuilder extends haxe.lang.HxObject implements coopy.CellBuilder
{
	public    FlatCellBuilder(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    FlatCellBuilder()
	{
		coopy.FlatCellBuilder.__hx_ctor_coopy_FlatCellBuilder(this);
	}
	
	
	public static   void __hx_ctor_coopy_FlatCellBuilder(coopy.FlatCellBuilder __temp_me21)
	{
		{
		}
		
	}
	
	
	public static   java.lang.String quoteForDiff(coopy.View v, java.lang.Object d)
	{
		java.lang.String nil = "NULL";
		if (v.equals(d, null)) 
		{
			return nil;
		}
		
		java.lang.String str = v.toString(d);
		int score = 0;
		{
			int _g1 = 0;
			int _g = str.length();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				if (( ! (haxe.lang.Runtime.eq(haxe.lang.StringExt.charCodeAt(str, score), 95)) )) 
				{
					break;
				}
				
				score++;
			}
			
		}
		
		if (haxe.lang.Runtime.valEq(haxe.lang.StringExt.substr(str, score, null), nil)) 
		{
			str = ( "_" + str );
		}
		
		return str;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.FlatCellBuilder(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.FlatCellBuilder();
	}
	
	
	public  coopy.View view;
	
	public  java.lang.String separator;
	
	public  java.lang.String conflict_separator;
	
	public   boolean needSeparator()
	{
		return true;
	}
	
	
	public   void setSeparator(java.lang.String separator)
	{
		this.separator = separator;
	}
	
	
	public   void setConflictSeparator(java.lang.String separator)
	{
		this.conflict_separator = separator;
	}
	
	
	public   void setView(coopy.View view)
	{
		this.view = view;
	}
	
	
	public   java.lang.Object update(java.lang.Object local, java.lang.Object remote)
	{
		return this.view.toDatum(( ( coopy.FlatCellBuilder.quoteForDiff(this.view, local) + this.separator ) + coopy.FlatCellBuilder.quoteForDiff(this.view, remote) ));
	}
	
	
	public   java.lang.Object conflict(java.lang.Object parent, java.lang.Object local, java.lang.Object remote)
	{
		return ( ( ( ( this.view.toString(parent) + this.conflict_separator ) + this.view.toString(local) ) + this.conflict_separator ) + this.view.toString(remote) );
	}
	
	
	public   java.lang.Object marker(java.lang.String label)
	{
		return this.view.toDatum(label);
	}
	
	
	public   java.lang.Object links(coopy.Unit unit)
	{
		return this.view.toDatum(unit.toString());
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef167 = true;
			switch (field.hashCode())
			{
				case 1431825080:
				{
					if (field.equals("conflict_separator")) 
					{
						__temp_executeDef167 = false;
						this.conflict_separator = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 3619493:
				{
					if (field.equals("view")) 
					{
						__temp_executeDef167 = false;
						this.view = ((coopy.View) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1732829925:
				{
					if (field.equals("separator")) 
					{
						__temp_executeDef167 = false;
						this.separator = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef167) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef168 = true;
			switch (field.hashCode())
			{
				case 102977465:
				{
					if (field.equals("links")) 
					{
						__temp_executeDef168 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("links"))) );
					}
					
					break;
				}
				
				
				case 3619493:
				{
					if (field.equals("view")) 
					{
						__temp_executeDef168 = false;
						return this.view;
					}
					
					break;
				}
				
				
				case -1081306054:
				{
					if (field.equals("marker")) 
					{
						__temp_executeDef168 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("marker"))) );
					}
					
					break;
				}
				
				
				case 1732829925:
				{
					if (field.equals("separator")) 
					{
						__temp_executeDef168 = false;
						return this.separator;
					}
					
					break;
				}
				
				
				case -580047918:
				{
					if (field.equals("conflict")) 
					{
						__temp_executeDef168 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("conflict"))) );
					}
					
					break;
				}
				
				
				case 1431825080:
				{
					if (field.equals("conflict_separator")) 
					{
						__temp_executeDef168 = false;
						return this.conflict_separator;
					}
					
					break;
				}
				
				
				case -838846263:
				{
					if (field.equals("update")) 
					{
						__temp_executeDef168 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("update"))) );
					}
					
					break;
				}
				
				
				case -1895251217:
				{
					if (field.equals("needSeparator")) 
					{
						__temp_executeDef168 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("needSeparator"))) );
					}
					
					break;
				}
				
				
				case 1985047079:
				{
					if (field.equals("setView")) 
					{
						__temp_executeDef168 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setView"))) );
					}
					
					break;
				}
				
				
				case -1022749533:
				{
					if (field.equals("setSeparator")) 
					{
						__temp_executeDef168 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setSeparator"))) );
					}
					
					break;
				}
				
				
				case -1258842383:
				{
					if (field.equals("setConflictSeparator")) 
					{
						__temp_executeDef168 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setConflictSeparator"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef168) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef169 = true;
			switch (field.hashCode())
			{
				case 102977465:
				{
					if (field.equals("links")) 
					{
						__temp_executeDef169 = false;
						return this.links(((coopy.Unit) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case -1895251217:
				{
					if (field.equals("needSeparator")) 
					{
						__temp_executeDef169 = false;
						return this.needSeparator();
					}
					
					break;
				}
				
				
				case -1081306054:
				{
					if (field.equals("marker")) 
					{
						__temp_executeDef169 = false;
						return this.marker(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -1022749533:
				{
					if (field.equals("setSeparator")) 
					{
						__temp_executeDef169 = false;
						this.setSeparator(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -580047918:
				{
					if (field.equals("conflict")) 
					{
						__temp_executeDef169 = false;
						return this.conflict(dynargs.__get(0), dynargs.__get(1), dynargs.__get(2));
					}
					
					break;
				}
				
				
				case -1258842383:
				{
					if (field.equals("setConflictSeparator")) 
					{
						__temp_executeDef169 = false;
						this.setConflictSeparator(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -838846263:
				{
					if (field.equals("update")) 
					{
						__temp_executeDef169 = false;
						return this.update(dynargs.__get(0), dynargs.__get(1));
					}
					
					break;
				}
				
				
				case 1985047079:
				{
					if (field.equals("setView")) 
					{
						__temp_executeDef169 = false;
						this.setView(((coopy.View) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef169) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("conflict_separator");
		baseArr.push("separator");
		baseArr.push("view");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



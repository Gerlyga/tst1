package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Coopy extends haxe.lang.HxObject
{
	public static void main(String[] args)
	{
		Sys._args = args;
		main();
	}
	static 
	{
		coopy.Coopy.VERSION = "1.2.6";
	}
	public    Coopy(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Coopy()
	{
		coopy.Coopy.__hx_ctor_coopy_Coopy(this);
	}
	
	
	public static   void __hx_ctor_coopy_Coopy(coopy.Coopy __temp_me16)
	{
		__temp_me16.extern_preference = false;
		__temp_me16.format_preference = null;
		__temp_me16.delim_preference = null;
		__temp_me16.output_format = "copy";
		__temp_me16.nested_output = false;
		__temp_me16.order_set = false;
		__temp_me16.order_preference = false;
	}
	
	
	public static  java.lang.String VERSION;
	
	public static   coopy.CompareTable compareTables(coopy.Table local, coopy.Table remote, coopy.CompareFlags flags)
	{
		coopy.TableComparisonState comp = new coopy.TableComparisonState();
		comp.a = local;
		comp.b = remote;
		comp.compare_flags = flags;
		coopy.CompareTable ct = new coopy.CompareTable(((coopy.TableComparisonState) (comp) ));
		return ct;
	}
	
	
	public static   coopy.CompareTable compareTables3(coopy.Table parent, coopy.Table local, coopy.Table remote, coopy.CompareFlags flags)
	{
		coopy.TableComparisonState comp = new coopy.TableComparisonState();
		comp.p = parent;
		comp.a = local;
		comp.b = remote;
		comp.compare_flags = flags;
		coopy.CompareTable ct = new coopy.CompareTable(((coopy.TableComparisonState) (comp) ));
		return ct;
	}
	
	
	public static   int keepAround()
	{
		coopy.SimpleTable st = new coopy.SimpleTable(((int) (1) ), ((int) (1) ));
		coopy.Viterbi v = new coopy.Viterbi();
		coopy.TableDiff td = new coopy.TableDiff(((coopy.Alignment) (null) ), ((coopy.CompareFlags) (null) ));
		coopy.Index idx = new coopy.Index();
		coopy.DiffRender dr = new coopy.DiffRender();
		coopy.CompareFlags cf = new coopy.CompareFlags();
		coopy.HighlightPatch hp = new coopy.HighlightPatch(((coopy.Table) (null) ), ((coopy.Table) (null) ));
		coopy.Csv csv = new coopy.Csv(haxe.lang.Runtime.toString(null));
		coopy.TableModifier tm = new coopy.TableModifier(((coopy.Table) (null) ));
		coopy.SqlCompare sc = new coopy.SqlCompare(((coopy.SqlDatabase) (null) ), ((coopy.SqlTable) (null) ), ((coopy.SqlTable) (null) ));
		return 0;
	}
	
	
	public static   java.lang.Object cellFor(java.lang.Object x)
	{
		return x;
	}
	
	
	public static   coopy.Table jsonToTable(java.lang.Object json)
	{
		coopy.Table output = null;
		{
			int _g = 0;
			haxe.root.Array<java.lang.String> _g1 = haxe.root.Reflect.fields(json);
			while (( _g < _g1.length ))
			{
				java.lang.String name = _g1.__get(_g);
				 ++ _g;
				java.lang.Object t = haxe.root.Reflect.field(json, name);
				haxe.root.Array<java.lang.String> columns = ((haxe.root.Array<java.lang.String>) (haxe.lang.Runtime.getField(t, "columns", false)) );
				if (( columns == null )) 
				{
					continue;
				}
				
				haxe.root.Array rows = ((haxe.root.Array) (haxe.lang.Runtime.getField(t, "rows", false)) );
				if (( rows == null )) 
				{
					continue;
				}
				
				output = new coopy.SimpleTable(((int) (columns.length) ), ((int) (rows.length) ));
				boolean has_hash = false;
				boolean has_hash_known = false;
				{
					int _g3 = 0;
					int _g2 = rows.length;
					while (( _g3 < _g2 ))
					{
						int i = _g3++;
						java.lang.Object row = rows.__get(i);
						if ( ! (has_hash_known) ) 
						{
							if (( haxe.root.Reflect.fields(row).length == columns.length )) 
							{
								has_hash = true;
							}
							
							has_hash_known = true;
						}
						
						if ( ! (has_hash) ) 
						{
							haxe.root.Array lst = ((haxe.root.Array) (row) );
							{
								int _g5 = 0;
								int _g4 = columns.length;
								while (( _g5 < _g4 ))
								{
									int j = _g5++;
									java.lang.Object val = lst.__get(j);
									output.setCell(j, i, coopy.Coopy.cellFor(val));
								}
								
							}
							
						}
						 else 
						{
							int _g51 = 0;
							int _g41 = columns.length;
							while (( _g51 < _g41 ))
							{
								int j1 = _g51++;
								java.lang.Object val1 = haxe.root.Reflect.field(row, columns.__get(j1));
								output.setCell(j1, i, coopy.Coopy.cellFor(val1));
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		if (( output != null )) 
		{
			output.trimBlank();
		}
		
		return output;
	}
	
	
	public static   int main()
	{
		coopy.TableIO io = new coopy.TableIO();
		coopy.Coopy coopy1 = new coopy.Coopy();
		return coopy1.coopyhx(io);
	}
	
	
	public static   void show(coopy.Table t)
	{
		int w = t.get_width();
		int h = t.get_height();
		java.lang.String txt = "";
		{
			int _g = 0;
			while (( _g < h ))
			{
				int y = _g++;
				{
					int _g1 = 0;
					while (( _g1 < w ))
					{
						int x = _g1++;
						txt += haxe.root.Std.string(t.getCell(x, y));
						txt += " ";
					}
					
				}
				
				txt += "\n";
			}
			
		}
		
		haxe.Log.trace.__hx_invoke2_o(0.0, txt, 0.0, new haxe.lang.DynamicObject(new haxe.root.Array<java.lang.String>(new java.lang.String[]{"className", "fileName", "methodName"}), new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{"coopy.Coopy", "Coopy.hx", "show"}), new haxe.root.Array<java.lang.String>(new java.lang.String[]{"lineNumber"}), new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{((java.lang.Object) (((double) (794) )) )})));
	}
	
	
	public static   java.lang.Object jsonify(coopy.Table t)
	{
		haxe.ds.StringMap workbook = new haxe.ds.StringMap();
		haxe.root.Array<haxe.root.Array> sheet = new haxe.root.Array<haxe.root.Array>();
		int w = t.get_width();
		int h = t.get_height();
		java.lang.String txt = "";
		{
			int _g = 0;
			while (( _g < h ))
			{
				int y = _g++;
				haxe.root.Array row = new haxe.root.Array();
				{
					int _g1 = 0;
					while (( _g1 < w ))
					{
						int x = _g1++;
						java.lang.Object v = t.getCell(x, y);
						row.push(v);
					}
					
				}
				
				sheet.push(row);
			}
			
		}
		
		workbook.set("sheet", sheet);
		return workbook;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.Coopy(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.Coopy();
	}
	
	
	public  java.lang.String format_preference;
	
	public  java.lang.String delim_preference;
	
	public  boolean extern_preference;
	
	public  java.lang.String output_format;
	
	public  boolean nested_output;
	
	public  boolean order_set;
	
	public  boolean order_preference;
	
	public  coopy.TableIO io;
	
	public  coopy.Mover mv;
	
	public   java.lang.String checkFormat(java.lang.String name)
	{
		if (this.extern_preference) 
		{
			return this.format_preference;
		}
		
		java.lang.String ext = "";
		int pt = haxe.lang.StringExt.lastIndexOf(name, ".", null);
		if (( pt >= 0 )) 
		{
			ext = haxe.lang.StringExt.substr(name, ( pt + 1 ), null).toLowerCase();
			{
				java.lang.String __temp_svar147 = (ext);
				boolean __temp_executeDef148 = true;
				switch (__temp_svar147.hashCode())
				{
					case 3271912:
					{
						if (__temp_svar147.equals("json")) 
						{
							__temp_executeDef148 = false;
							this.format_preference = "json";
						}
						
						break;
					}
					
					
					case -894935028:
					{
						if (__temp_svar147.equals("sqlite")) 
						{
							__temp_executeDef148 = false;
							this.format_preference = "sqlite";
						}
						
						break;
					}
					
					
					case -1050136674:
					{
						if (__temp_svar147.equals("ndjson")) 
						{
							__temp_executeDef148 = false;
							this.format_preference = "ndjson";
						}
						
						break;
					}
					
					
					case -1973182041:
					{
						if (__temp_svar147.equals("sqlite3")) 
						{
							__temp_executeDef148 = false;
							this.format_preference = "sqlite";
						}
						
						break;
					}
					
					
					case 98822:
					{
						if (__temp_svar147.equals("csv")) 
						{
							__temp_executeDef148 = false;
							this.format_preference = "csv";
							this.delim_preference = ",";
						}
						
						break;
					}
					
					
					case 114198:
					{
						if (__temp_svar147.equals("ssv")) 
						{
							__temp_executeDef148 = false;
							this.format_preference = "csv";
							this.delim_preference = ";";
						}
						
						break;
					}
					
					
					case 115159:
					{
						if (__temp_svar147.equals("tsv")) 
						{
							__temp_executeDef148 = false;
							this.format_preference = "csv";
							this.delim_preference = "\t";
						}
						
						break;
					}
					
					
				}
				
				if (__temp_executeDef148) 
				{
					ext = "";
				}
				
			}
			
		}
		
		this.nested_output = ( haxe.lang.Runtime.valEq(this.format_preference, "json") || haxe.lang.Runtime.valEq(this.format_preference, "ndjson") );
		this.order_preference =  ! (this.nested_output) ;
		return ext;
	}
	
	
	public   void setFormat(java.lang.String name)
	{
		this.extern_preference = false;
		this.checkFormat(( "." + name ));
		this.extern_preference = true;
	}
	
	
	public   boolean saveTable(java.lang.String name, coopy.Table t)
	{
		if ( ! (haxe.lang.Runtime.valEq(this.output_format, "copy")) ) 
		{
			this.setFormat(this.output_format);
		}
		
		java.lang.String txt = "";
		this.checkFormat(name);
		if (haxe.lang.Runtime.valEq(this.format_preference, "csv")) 
		{
			coopy.Csv csv = new coopy.Csv(haxe.lang.Runtime.toString(this.delim_preference));
			txt = csv.renderTable(t);
		}
		 else 
		{
			if (haxe.lang.Runtime.valEq(this.format_preference, "ndjson")) 
			{
				txt = new coopy.Ndjson(((coopy.Table) (t) )).render();
			}
			 else 
			{
				if (haxe.lang.Runtime.valEq(this.format_preference, "sqlite")) 
				{
					this.io.writeStderr("! Cannot yet output to sqlite, aborting\n");
					return false;
				}
				 else 
				{
					java.lang.Object value = coopy.Coopy.jsonify(t);
					txt = haxe.format.JsonPrinter.print(value, null, "  ");
				}
				
			}
			
		}
		
		return this.saveText(name, txt);
	}
	
	
	public   boolean saveText(java.lang.String name, java.lang.String txt)
	{
		if ( ! (haxe.lang.Runtime.valEq(name, "-")) ) 
		{
			this.io.saveContent(name, txt);
		}
		 else 
		{
			this.io.writeStdout(txt);
		}
		
		return true;
	}
	
	
	public   coopy.Table loadTable(java.lang.String name)
	{
		java.lang.String txt = this.io.getContent(name);
		java.lang.String ext = this.checkFormat(name);
		if (haxe.lang.Runtime.valEq(ext, "sqlite")) 
		{
			coopy.SqlDatabase sql = this.io.openSqliteDatabase(name);
			if (( sql == null )) 
			{
				this.io.writeStderr("! Cannot open database, aborting\n");
				return null;
			}
			
			coopy.SqliteHelper helper = new coopy.SqliteHelper();
			haxe.root.Array<java.lang.String> names = helper.getTableNames(sql);
			if (( names == null )) 
			{
				this.io.writeStderr("! Cannot find database tables, aborting\n");
				return null;
			}
			
			if (( names.length == 0 )) 
			{
				this.io.writeStderr("! No tables in database, aborting\n");
				return null;
			}
			
			coopy.SqlTable tab = new coopy.SqlTable(((coopy.SqlDatabase) (sql) ), ((coopy.SqlTableName) (new coopy.SqlTableName(haxe.lang.Runtime.toString(names.__get(0)), haxe.lang.Runtime.toString(null))) ), ((coopy.SqlHelper) (helper) ));
			return tab;
		}
		
		if (haxe.lang.Runtime.valEq(ext, "ndjson")) 
		{
			coopy.Table t = new coopy.SimpleTable(((int) (0) ), ((int) (0) ));
			coopy.Ndjson ndjson = new coopy.Ndjson(((coopy.Table) (t) ));
			ndjson.parse(txt);
			return t;
		}
		
		if (( haxe.lang.Runtime.valEq(ext, "json") || haxe.lang.Runtime.valEq(ext, "") )) 
		{
			try 
			{
				java.lang.Object json = new haxe.format.JsonParser(haxe.lang.Runtime.toString(txt)).parseRec();
				this.format_preference = "json";
				coopy.Table t1 = coopy.Coopy.jsonToTable(json);
				if (( t1 == null )) 
				{
					throw haxe.lang.HaxeException.wrap("JSON failed");
				}
				
				return t1;
			}
			catch (java.lang.Throwable __temp_catchallException149)
			{
				java.lang.Object __temp_catchall150 = __temp_catchallException149;
				if (( __temp_catchall150 instanceof haxe.lang.HaxeException )) 
				{
					__temp_catchall150 = ((haxe.lang.HaxeException) (__temp_catchallException149) ).obj;
				}
				
				{
					java.lang.Object e = __temp_catchall150;
					if (haxe.lang.Runtime.valEq(ext, "json")) 
					{
						throw haxe.lang.HaxeException.wrap(e);
					}
					
				}
				
			}
			
			
		}
		
		this.format_preference = "csv";
		coopy.Csv csv = new coopy.Csv(haxe.lang.Runtime.toString(this.delim_preference));
		coopy.SimpleTable output = new coopy.SimpleTable(((int) (0) ), ((int) (0) ));
		csv.parseTable(txt, output);
		if (( output != null )) 
		{
			output.trimBlank();
		}
		
		return output;
	}
	
	
	public  haxe.ds.StringMap<java.lang.Object> status;
	
	public  java.lang.String daff_cmd;
	
	public   int command(coopy.TableIO io, java.lang.String cmd, haxe.root.Array<java.lang.String> args)
	{
		int r = 0;
		if (io.async()) 
		{
			r = io.command(cmd, args);
		}
		
		if (( r != 999 )) 
		{
			io.writeStdout(( "$ " + cmd ));
			{
				int _g = 0;
				while (( _g < args.length ))
				{
					java.lang.String arg = args.__get(_g);
					 ++ _g;
					io.writeStdout(" ");
					boolean spaced = ( haxe.lang.StringExt.indexOf(arg, " ", null) >= 0 );
					if (spaced) 
					{
						io.writeStdout("\"");
					}
					
					io.writeStdout(arg);
					if (spaced) 
					{
						io.writeStdout("\"");
					}
					
				}
				
			}
			
			io.writeStdout("\n");
		}
		
		if ( ! (io.async()) ) 
		{
			r = io.command(cmd, args);
		}
		
		return r;
	}
	
	
	public   int installGitDriver(coopy.TableIO io, haxe.root.Array<java.lang.String> formats)
	{
		int r = 0;
		if (( this.status == null )) 
		{
			this.status = new haxe.ds.StringMap<java.lang.Object>();
			this.daff_cmd = "";
		}
		
		java.lang.String key = "hello";
		if ( ! (this.status.exists(key)) ) 
		{
			io.writeStdout("Setting up git to use daff on");
			{
				int _g = 0;
				while (( _g < formats.length ))
				{
					java.lang.String format = formats.__get(_g);
					 ++ _g;
					io.writeStdout(( " *." + format ));
				}
				
			}
			
			io.writeStdout(" files\n");
			this.status.set(key, r);
		}
		
		key = "can_run_git";
		if ( ! (this.status.exists(key)) ) 
		{
			r = this.command(io, "git", new haxe.root.Array<java.lang.String>(new java.lang.String[]{"--version"}));
			if (( r == 999 )) 
			{
				return r;
			}
			
			this.status.set(key, r);
			if (( r != 0 )) 
			{
				io.writeStderr("! Cannot run git, aborting\n");
				return 1;
			}
			
			io.writeStdout("- Can run git\n");
		}
		
		haxe.root.Array<java.lang.String> daffs = new haxe.root.Array<java.lang.String>(new java.lang.String[]{"daff", "daff.rb", "daff.py"});
		if (haxe.lang.Runtime.valEq(this.daff_cmd, "")) 
		{
			{
				int _g1 = 0;
				while (( _g1 < daffs.length ))
				{
					java.lang.String daff = daffs.__get(_g1);
					 ++ _g1;
					java.lang.String key1 = ( "can_run_" + daff );
					if ( ! (this.status.exists(key1)) ) 
					{
						r = this.command(io, daff, new haxe.root.Array<java.lang.String>(new java.lang.String[]{"version"}));
						if (( r == 999 )) 
						{
							return r;
						}
						
						this.status.set(key1, r);
						if (( r == 0 )) 
						{
							this.daff_cmd = daff;
							io.writeStdout(( ( ( ( "- Can run " + daff ) + " as \"" ) + daff ) + "\"\n" ));
							break;
						}
						
					}
					
				}
				
			}
			
			if (haxe.lang.Runtime.valEq(this.daff_cmd, "")) 
			{
				io.writeStderr("! Cannot find daff, is it in your path?\n");
				return 1;
			}
			
		}
		
		{
			int _g2 = 0;
			while (( _g2 < formats.length ))
			{
				java.lang.String format1 = formats.__get(_g2);
				 ++ _g2;
				key = ( "have_diff_driver_" + format1 );
				if ( ! (this.status.exists(key)) ) 
				{
					r = this.command(io, "git", new haxe.root.Array<java.lang.String>(new java.lang.String[]{"config", "--global", "--get", ( ( "diff.daff-" + format1 ) + ".command" )}));
					if (( r == 999 )) 
					{
						return r;
					}
					
					this.status.set(key, r);
				}
				
				boolean have_diff_driver = haxe.lang.Runtime.eq(this.status.get(key), 0);
				key = ( "add_diff_driver_" + format1 );
				if ( ! (this.status.exists(key)) ) 
				{
					if ( ! (have_diff_driver) ) 
					{
						r = this.command(io, "git", new haxe.root.Array<java.lang.String>(new java.lang.String[]{"config", "--global", ( ( "diff.daff-" + format1 ) + ".command" ), ( this.daff_cmd + " diff --color --git" )}));
						if (( r == 999 )) 
						{
							return r;
						}
						
						io.writeStdout(( ( "- Added diff driver for " + format1 ) + "\n" ));
					}
					 else 
					{
						r = 0;
						io.writeStdout(( ( "- Already have diff driver for " + format1 ) + ", not touching it\n" ));
					}
					
					this.status.set(key, r);
				}
				
				key = ( "have_merge_driver_" + format1 );
				if ( ! (this.status.exists(key)) ) 
				{
					r = this.command(io, "git", new haxe.root.Array<java.lang.String>(new java.lang.String[]{"config", "--global", "--get", ( ( "merge.daff-" + format1 ) + ".driver" )}));
					if (( r == 999 )) 
					{
						return r;
					}
					
					this.status.set(key, r);
				}
				
				boolean have_merge_driver = haxe.lang.Runtime.eq(this.status.get(key), 0);
				key = ( "name_merge_driver_" + format1 );
				if ( ! (this.status.exists(key)) ) 
				{
					if ( ! (have_merge_driver) ) 
					{
						r = this.command(io, "git", new haxe.root.Array<java.lang.String>(new java.lang.String[]{"config", "--global", ( ( "merge.daff-" + format1 ) + ".name" ), ( ( "daff tabular " + format1 ) + " merge" )}));
						if (( r == 999 )) 
						{
							return r;
						}
						
					}
					 else 
					{
						r = 0;
					}
					
					this.status.set(key, r);
				}
				
				key = ( "add_merge_driver_" + format1 );
				if ( ! (this.status.exists(key)) ) 
				{
					if ( ! (have_merge_driver) ) 
					{
						r = this.command(io, "git", new haxe.root.Array<java.lang.String>(new java.lang.String[]{"config", "--global", ( ( "merge.daff-" + format1 ) + ".driver" ), ( this.daff_cmd + " merge --output %A %O %A %B" )}));
						if (( r == 999 )) 
						{
							return r;
						}
						
						io.writeStdout(( ( "- Added merge driver for " + format1 ) + "\n" ));
					}
					 else 
					{
						r = 0;
						io.writeStdout(( ( "- Already have merge driver for " + format1 ) + ", not touching it\n" ));
					}
					
					this.status.set(key, r);
				}
				
			}
			
		}
		
		if ( ! (io.exists(".git/config")) ) 
		{
			io.writeStderr("! This next part needs to happen in a git repository.\n");
			io.writeStderr("! Please run again from the root of a git repository.\n");
			return 1;
		}
		
		java.lang.String attr = ".gitattributes";
		java.lang.String txt = "";
		java.lang.String post = "";
		if ( ! (io.exists(attr)) ) 
		{
			io.writeStdout("- No .gitattributes file\n");
		}
		 else 
		{
			io.writeStdout("- You have a .gitattributes file\n");
			txt = io.getContent(attr);
		}
		
		boolean need_update = false;
		{
			int _g3 = 0;
			while (( _g3 < formats.length ))
			{
				java.lang.String format2 = formats.__get(_g3);
				 ++ _g3;
				if (( haxe.lang.StringExt.indexOf(txt, ( "*." + format2 ), null) >= 0 )) 
				{
					io.writeStderr(( ( "- Your .gitattributes file already mentions *." + format2 ) + "\n" ));
				}
				 else 
				{
					post += ( ( ( ( "*." + format2 ) + " diff=daff-" ) + format2 ) + "\n" );
					post += ( ( ( ( "*." + format2 ) + " merge=daff-" ) + format2 ) + "\n" );
					io.writeStdout("- Placing the following lines in .gitattributes:\n");
					io.writeStdout(post);
					if ((  ! (haxe.lang.Runtime.valEq(txt, ""))  &&  ! (need_update)  )) 
					{
						txt += "\n";
					}
					
					txt += post;
					need_update = true;
				}
				
			}
			
		}
		
		if (need_update) 
		{
			io.saveContent(attr, txt);
		}
		
		io.writeStdout("- Done!\n");
		return 0;
	}
	
	
	public   int coopyhx(coopy.TableIO io)
	{
		haxe.root.Array<java.lang.String> args = io.args();
		if (haxe.lang.Runtime.valEq(args.__get(0), "--keep")) 
		{
			return coopy.Coopy.keepAround();
		}
		
		boolean more = true;
		java.lang.String output = null;
		java.lang.String css_output = null;
		boolean fragment = false;
		boolean pretty = true;
		boolean inplace = false;
		boolean git = false;
		boolean color = false;
		coopy.CompareFlags flags = new coopy.CompareFlags();
		flags.always_show_header = true;
		while (more)
		{
			more = false;
			{
				int _g1 = 0;
				int _g = args.length;
				while (( _g1 < _g ))
				{
					int i = _g1++;
					java.lang.String tag = args.__get(i);
					if (haxe.lang.Runtime.valEq(tag, "--output")) 
					{
						more = true;
						output = args.__get(( i + 1 ));
						args.splice(i, 2);
						break;
					}
					 else 
					{
						if (haxe.lang.Runtime.valEq(tag, "--css")) 
						{
							more = true;
							fragment = true;
							css_output = args.__get(( i + 1 ));
							args.splice(i, 2);
							break;
						}
						 else 
						{
							if (haxe.lang.Runtime.valEq(tag, "--fragment")) 
							{
								more = true;
								fragment = true;
								args.splice(i, 1);
								break;
							}
							 else 
							{
								if (haxe.lang.Runtime.valEq(tag, "--plain")) 
								{
									more = true;
									pretty = false;
									args.splice(i, 1);
									break;
								}
								 else 
								{
									if (haxe.lang.Runtime.valEq(tag, "--all")) 
									{
										more = true;
										flags.show_unchanged = true;
										args.splice(i, 1);
										break;
									}
									 else 
									{
										if (haxe.lang.Runtime.valEq(tag, "--act")) 
										{
											more = true;
											if (( flags.acts == null )) 
											{
												flags.acts = new haxe.ds.StringMap<java.lang.Object>();
											}
											
											{
												flags.acts.set(args.__get(( i + 1 )), true);
												boolean __temp_expr151 = true;
											}
											
											args.splice(i, 2);
											break;
										}
										 else 
										{
											if (haxe.lang.Runtime.valEq(tag, "--context")) 
											{
												more = true;
												int context = ((int) (haxe.lang.Runtime.toInt(haxe.root.Std.parseInt(args.__get(( i + 1 ))))) );
												if (( context >= 0 )) 
												{
													flags.unchanged_context = context;
												}
												
												args.splice(i, 2);
												break;
											}
											 else 
											{
												if (haxe.lang.Runtime.valEq(tag, "--inplace")) 
												{
													more = true;
													inplace = true;
													args.splice(i, 1);
													break;
												}
												 else 
												{
													if (haxe.lang.Runtime.valEq(tag, "--git")) 
													{
														more = true;
														git = true;
														args.splice(i, 1);
														break;
													}
													 else 
													{
														if (haxe.lang.Runtime.valEq(tag, "--unordered")) 
														{
															more = true;
															flags.ordered = false;
															flags.unchanged_context = 0;
															this.order_set = true;
															args.splice(i, 1);
															break;
														}
														 else 
														{
															if (haxe.lang.Runtime.valEq(tag, "--ordered")) 
															{
																more = true;
																flags.ordered = true;
																this.order_set = true;
																args.splice(i, 1);
																break;
															}
															 else 
															{
																if (haxe.lang.Runtime.valEq(tag, "--color")) 
																{
																	more = true;
																	color = true;
																	args.splice(i, 1);
																	break;
																}
																 else 
																{
																	if (haxe.lang.Runtime.valEq(tag, "--input-format")) 
																	{
																		more = true;
																		this.setFormat(args.__get(( i + 1 )));
																		args.splice(i, 2);
																		break;
																	}
																	 else 
																	{
																		if (haxe.lang.Runtime.valEq(tag, "--output-format")) 
																		{
																			more = true;
																			this.output_format = args.__get(( i + 1 ));
																			args.splice(i, 2);
																			break;
																		}
																		 else 
																		{
																			if (haxe.lang.Runtime.valEq(tag, "--id")) 
																			{
																				more = true;
																				if (( flags.ids == null )) 
																				{
																					flags.ids = new haxe.root.Array<java.lang.String>();
																				}
																				
																				flags.ids.push(args.__get(( i + 1 )));
																				args.splice(i, 2);
																				break;
																			}
																			 else 
																			{
																				if (haxe.lang.Runtime.valEq(tag, "--ignore")) 
																				{
																					more = true;
																					if (( flags.columns_to_ignore == null )) 
																					{
																						flags.columns_to_ignore = new haxe.root.Array<java.lang.String>();
																					}
																					
																					flags.columns_to_ignore.push(args.__get(( i + 1 )));
																					args.splice(i, 2);
																					break;
																				}
																				 else 
																				{
																					if (haxe.lang.Runtime.valEq(tag, "--index")) 
																					{
																						more = true;
																						flags.always_show_order = true;
																						flags.never_show_order = false;
																						args.splice(i, 1);
																						break;
																					}
																					
																				}
																				
																			}
																			
																		}
																		
																	}
																	
																}
																
															}
															
														}
														
													}
													
												}
												
											}
											
										}
										
									}
									
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		java.lang.String cmd = args.__get(0);
		if (( args.length < 2 )) 
		{
			if (haxe.lang.Runtime.valEq(cmd, "version")) 
			{
				io.writeStdout(( coopy.Coopy.VERSION + "\n" ));
				return 0;
			}
			
			if (haxe.lang.Runtime.valEq(cmd, "git")) 
			{
				io.writeStdout("You can use daff to improve git\'s handling of csv files, by using it as a\ndiff driver (for showing what has changed) and as a merge driver (for merging\nchanges between multiple versions).\n");
				io.writeStdout("\n");
				io.writeStdout("Automatic setup\n");
				io.writeStdout("---------------\n\n");
				io.writeStdout("Run:\n");
				io.writeStdout("  daff git csv\n");
				io.writeStdout("\n");
				io.writeStdout("Manual setup\n");
				io.writeStdout("------------\n\n");
				io.writeStdout("Create and add a file called .gitattributes in the root directory of your\nrepository, containing:\n\n");
				io.writeStdout("  *.csv diff=daff-csv\n");
				io.writeStdout("  *.csv merge=daff-csv\n");
				io.writeStdout("\nCreate a file called .gitconfig in your home directory (or alternatively\nopen .git/config for a particular repository) and add:\n\n");
				io.writeStdout("  [diff \"daff-csv\"]\n");
				io.writeStdout("  command = daff diff --color --git\n");
				io.writeStderr("\n");
				io.writeStdout("  [merge \"daff-csv\"]\n");
				io.writeStdout("  name = daff tabular merge\n");
				io.writeStdout("  driver = daff merge --output %A %O %A %B\n\n");
				io.writeStderr("Make sure you can run daff from the command-line as just \"daff\" - if not,\nreplace \"daff\" in the driver and command lines above with the correct way\nto call it. Omit --color if your terminal does not support ANSI colors.");
				io.writeStderr("\n");
				return 0;
			}
			
			io.writeStderr("daff can produce and apply tabular diffs.\n");
			io.writeStderr("Call as:\n");
			io.writeStderr("  daff [--color] [--output OUTPUT.csv] a.csv b.csv\n");
			io.writeStderr("  daff [--output OUTPUT.csv] parent.csv a.csv b.csv\n");
			io.writeStderr("  daff [--output OUTPUT.ndjson] a.ndjson b.ndjson\n");
			io.writeStderr("  daff patch [--inplace] [--output OUTPUT.csv] a.csv patch.csv\n");
			io.writeStderr("  daff merge [--inplace] [--output OUTPUT.csv] parent.csv a.csv b.csv\n");
			io.writeStderr("  daff trim [--output OUTPUT.csv] source.csv\n");
			io.writeStderr("  daff render [--output OUTPUT.html] diff.csv\n");
			io.writeStderr("  daff copy in.csv out.tsv\n");
			io.writeStderr("  daff git\n");
			io.writeStderr("  daff version\n");
			io.writeStderr("\n");
			io.writeStderr("The --inplace option to patch and merge will result in modification of a.csv.\n");
			io.writeStderr("\n");
			io.writeStderr("If you need more control, here is the full list of flags:\n");
			io.writeStderr("  daff diff [--output OUTPUT.csv] [--context NUM] [--all] [--act ACT] a.csv b.csv\n");
			io.writeStderr("     --act ACT:     show only a certain kind of change (update, insert, delete)\n");
			io.writeStderr("     --all:         do not prune unchanged rows\n");
			io.writeStderr("     --color:       highlight changes with terminal colors\n");
			io.writeStderr("     --context NUM: show NUM rows of context\n");
			io.writeStderr("     --id:          specify column to use as primary key (repeat for multi-column key)\n");
			io.writeStderr("     --ignore:      specify column to ignore completely (can repeat)\n");
			io.writeStderr("     --input-format [csv|tsv|ssv|json]: set format to expect for input\n");
			io.writeStderr("     --ordered:     assume row order is meaningful (default for CSV)\n");
			io.writeStderr("     --output-format [csv|tsv|ssv|json|copy]: set format for output\n");
			io.writeStderr("     --unordered:   assume row order is meaningless (default for json formats)\n");
			io.writeStderr("\n");
			io.writeStderr("  daff diff --git path old-file old-hex old-mode new-file new-hex new-mode\n");
			io.writeStderr("     --git:         process arguments provided by git to diff drivers\n");
			io.writeStderr("     --index:       include row/columns numbers from orginal tables\n");
			io.writeStderr("\n");
			io.writeStderr("  daff render [--output OUTPUT.html] [--css CSS.css] [--fragment] [--plain] diff.csv\n");
			io.writeStderr("     --css CSS.css: generate a suitable css file to go with the html\n");
			io.writeStderr("     --fragment:    generate just a html fragment rather than a page\n");
			io.writeStderr("     --plain:       do not use fancy utf8 characters to make arrows prettier\n");
			return 1;
		}
		
		java.lang.String cmd1 = args.__get(0);
		int offset = 1;
		if ( ! (haxe.root.Lambda.has(new haxe.root.Array<java.lang.String>(new java.lang.String[]{"diff", "patch", "merge", "trim", "render", "git", "version", "copy"}), cmd1)) ) 
		{
			if (( ( haxe.lang.StringExt.indexOf(cmd1, ".", null) != -1 ) || ( haxe.lang.StringExt.indexOf(cmd1, "--", null) == 0 ) )) 
			{
				cmd1 = "diff";
				offset = 0;
			}
			
		}
		
		if (haxe.lang.Runtime.valEq(cmd1, "git")) 
		{
			haxe.root.Array<java.lang.String> types = args.splice(offset, ( args.length - offset ));
			return this.installGitDriver(io, types);
		}
		
		if (git) 
		{
			int ct = ( args.length - offset );
			if (( ct != 7 )) 
			{
				io.writeStderr(( ( "Expected 7 parameters from git, but got " + ct ) + "\n" ));
				return 1;
			}
			
			haxe.root.Array<java.lang.String> git_args = args.splice(offset, ct);
			args.splice(0, args.length);
			offset = 0;
			java.lang.String path = git_args.__get(0);
			java.lang.String old_file = git_args.__get(1);
			java.lang.String new_file = git_args.__get(4);
			io.writeStdout(( ( "--- a/" + path ) + "\n" ));
			io.writeStdout(( ( "+++ b/" + path ) + "\n" ));
			args.push(old_file);
			args.push(new_file);
		}
		
		coopy.Coopy tool = this;
		tool.io = io;
		coopy.Table parent = null;
		if (( ( args.length - offset ) >= 3 )) 
		{
			parent = tool.loadTable(args.__get(offset));
			offset++;
		}
		
		java.lang.String aname = args.__get(offset);
		coopy.Table a = tool.loadTable(aname);
		coopy.Table b = null;
		if (( ( args.length - offset ) >= 2 )) 
		{
			if ( ! (haxe.lang.Runtime.valEq(cmd1, "copy")) ) 
			{
				b = tool.loadTable(args.__get(( 1 + offset )));
			}
			 else 
			{
				output = args.__get(( 1 + offset ));
			}
			
		}
		
		if (inplace) 
		{
			if (( output != null )) 
			{
				io.writeStderr("Please do not use --inplace when specifying an output.\n");
			}
			
			output = aname;
			return 1;
		}
		
		if (( output == null )) 
		{
			output = "-";
		}
		
		boolean ok = true;
		if (haxe.lang.Runtime.valEq(cmd1, "diff")) 
		{
			if ( ! (this.order_set) ) 
			{
				flags.ordered = this.order_preference;
				if ( ! (flags.ordered) ) 
				{
					flags.unchanged_context = 0;
				}
				
			}
			
			flags.allow_nested_cells = this.nested_output;
			coopy.CompareTable ct1 = coopy.Coopy.compareTables3(parent, a, b, flags);
			coopy.Alignment align = ct1.align();
			coopy.TableDiff td = new coopy.TableDiff(((coopy.Alignment) (align) ), ((coopy.CompareFlags) (flags) ));
			coopy.SimpleTable o = new coopy.SimpleTable(((int) (0) ), ((int) (0) ));
			td.hilite(o);
			if (color) 
			{
				coopy.TerminalDiffRender render = new coopy.TerminalDiffRender();
				tool.saveText(output, render.render(o));
			}
			 else 
			{
				tool.saveTable(output, o);
			}
			
		}
		 else 
		{
			if (haxe.lang.Runtime.valEq(cmd1, "patch")) 
			{
				coopy.HighlightPatch patcher = new coopy.HighlightPatch(((coopy.Table) (a) ), ((coopy.Table) (b) ));
				patcher.apply();
				tool.saveTable(output, a);
			}
			 else 
			{
				if (haxe.lang.Runtime.valEq(cmd1, "merge")) 
				{
					coopy.Merger merger = new coopy.Merger(((coopy.Table) (parent) ), ((coopy.Table) (a) ), ((coopy.Table) (b) ), ((coopy.CompareFlags) (flags) ));
					int conflicts = merger.apply();
					ok = ( conflicts == 0 );
					if (( conflicts > 0 )) 
					{
						io.writeStderr(( ( ( conflicts + " conflict" ) + (( (( conflicts > 1 )) ? ("s") : ("") )) ) + "\n" ));
					}
					
					tool.saveTable(output, a);
				}
				 else 
				{
					if (haxe.lang.Runtime.valEq(cmd1, "trim")) 
					{
						tool.saveTable(output, a);
					}
					 else 
					{
						if (haxe.lang.Runtime.valEq(cmd1, "render")) 
						{
							coopy.DiffRender renderer = new coopy.DiffRender();
							renderer.usePrettyArrows(pretty);
							renderer.render(a);
							if ( ! (fragment) ) 
							{
								renderer.completeHtml();
							}
							
							tool.saveText(output, renderer.html());
							if (( css_output != null )) 
							{
								tool.saveText(css_output, renderer.sampleCss());
							}
							
						}
						 else 
						{
							if (haxe.lang.Runtime.valEq(cmd1, "copy")) 
							{
								tool.saveTable(output, a);
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		if (ok) 
		{
			return 0;
		}
		 else 
		{
			return 1;
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef152 = true;
			switch (field.hashCode())
			{
				case 1393186808:
				{
					if (field.equals("daff_cmd")) 
					{
						__temp_executeDef152 = false;
						this.daff_cmd = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case -418297309:
				{
					if (field.equals("format_preference")) 
					{
						__temp_executeDef152 = false;
						this.format_preference = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case -892481550:
				{
					if (field.equals("status")) 
					{
						__temp_executeDef152 = false;
						this.status = ((haxe.ds.StringMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -564605781:
				{
					if (field.equals("delim_preference")) 
					{
						__temp_executeDef152 = false;
						this.delim_preference = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 3497:
				{
					if (field.equals("mv")) 
					{
						__temp_executeDef152 = false;
						this.mv = ((coopy.Mover) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -774222118:
				{
					if (field.equals("extern_preference")) 
					{
						__temp_executeDef152 = false;
						this.extern_preference = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 3366:
				{
					if (field.equals("io")) 
					{
						__temp_executeDef152 = false;
						this.io = ((coopy.TableIO) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1910630645:
				{
					if (field.equals("output_format")) 
					{
						__temp_executeDef152 = false;
						this.output_format = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 2101317228:
				{
					if (field.equals("order_preference")) 
					{
						__temp_executeDef152 = false;
						this.order_preference = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case -1847787191:
				{
					if (field.equals("nested_output")) 
					{
						__temp_executeDef152 = false;
						this.nested_output = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case -391242767:
				{
					if (field.equals("order_set")) 
					{
						__temp_executeDef152 = false;
						this.order_set = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef152) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef153 = true;
			switch (field.hashCode())
			{
				case 952354012:
				{
					if (field.equals("coopyhx")) 
					{
						__temp_executeDef153 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("coopyhx"))) );
					}
					
					break;
				}
				
				
				case -418297309:
				{
					if (field.equals("format_preference")) 
					{
						__temp_executeDef153 = false;
						return this.format_preference;
					}
					
					break;
				}
				
				
				case -1576171713:
				{
					if (field.equals("installGitDriver")) 
					{
						__temp_executeDef153 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("installGitDriver"))) );
					}
					
					break;
				}
				
				
				case -564605781:
				{
					if (field.equals("delim_preference")) 
					{
						__temp_executeDef153 = false;
						return this.delim_preference;
					}
					
					break;
				}
				
				
				case 950394699:
				{
					if (field.equals("command")) 
					{
						__temp_executeDef153 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("command"))) );
					}
					
					break;
				}
				
				
				case -774222118:
				{
					if (field.equals("extern_preference")) 
					{
						__temp_executeDef153 = false;
						return this.extern_preference;
					}
					
					break;
				}
				
				
				case 1393186808:
				{
					if (field.equals("daff_cmd")) 
					{
						__temp_executeDef153 = false;
						return this.daff_cmd;
					}
					
					break;
				}
				
				
				case 1910630645:
				{
					if (field.equals("output_format")) 
					{
						__temp_executeDef153 = false;
						return this.output_format;
					}
					
					break;
				}
				
				
				case -892481550:
				{
					if (field.equals("status")) 
					{
						__temp_executeDef153 = false;
						return this.status;
					}
					
					break;
				}
				
				
				case -1847787191:
				{
					if (field.equals("nested_output")) 
					{
						__temp_executeDef153 = false;
						return this.nested_output;
					}
					
					break;
				}
				
				
				case 1378854536:
				{
					if (field.equals("loadTable")) 
					{
						__temp_executeDef153 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("loadTable"))) );
					}
					
					break;
				}
				
				
				case -391242767:
				{
					if (field.equals("order_set")) 
					{
						__temp_executeDef153 = false;
						return this.order_set;
					}
					
					break;
				}
				
				
				case -2072611766:
				{
					if (field.equals("saveText")) 
					{
						__temp_executeDef153 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("saveText"))) );
					}
					
					break;
				}
				
				
				case 2101317228:
				{
					if (field.equals("order_preference")) 
					{
						__temp_executeDef153 = false;
						return this.order_preference;
					}
					
					break;
				}
				
				
				case 173404241:
				{
					if (field.equals("saveTable")) 
					{
						__temp_executeDef153 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("saveTable"))) );
					}
					
					break;
				}
				
				
				case 3366:
				{
					if (field.equals("io")) 
					{
						__temp_executeDef153 = false;
						return this.io;
					}
					
					break;
				}
				
				
				case 212619001:
				{
					if (field.equals("setFormat")) 
					{
						__temp_executeDef153 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setFormat"))) );
					}
					
					break;
				}
				
				
				case 3497:
				{
					if (field.equals("mv")) 
					{
						__temp_executeDef153 = false;
						return this.mv;
					}
					
					break;
				}
				
				
				case 391832351:
				{
					if (field.equals("checkFormat")) 
					{
						__temp_executeDef153 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("checkFormat"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef153) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef154 = true;
			switch (field.hashCode())
			{
				case 952354012:
				{
					if (field.equals("coopyhx")) 
					{
						__temp_executeDef154 = false;
						return this.coopyhx(((coopy.TableIO) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case 391832351:
				{
					if (field.equals("checkFormat")) 
					{
						__temp_executeDef154 = false;
						return this.checkFormat(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -1576171713:
				{
					if (field.equals("installGitDriver")) 
					{
						__temp_executeDef154 = false;
						return this.installGitDriver(((coopy.TableIO) (dynargs.__get(0)) ), ((haxe.root.Array<java.lang.String>) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case 212619001:
				{
					if (field.equals("setFormat")) 
					{
						__temp_executeDef154 = false;
						this.setFormat(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 950394699:
				{
					if (field.equals("command")) 
					{
						__temp_executeDef154 = false;
						return this.command(((coopy.TableIO) (dynargs.__get(0)) ), haxe.lang.Runtime.toString(dynargs.__get(1)), ((haxe.root.Array<java.lang.String>) (dynargs.__get(2)) ));
					}
					
					break;
				}
				
				
				case 173404241:
				{
					if (field.equals("saveTable")) 
					{
						__temp_executeDef154 = false;
						return this.saveTable(haxe.lang.Runtime.toString(dynargs.__get(0)), ((coopy.Table) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case 1378854536:
				{
					if (field.equals("loadTable")) 
					{
						__temp_executeDef154 = false;
						return this.loadTable(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -2072611766:
				{
					if (field.equals("saveText")) 
					{
						__temp_executeDef154 = false;
						return this.saveText(haxe.lang.Runtime.toString(dynargs.__get(0)), haxe.lang.Runtime.toString(dynargs.__get(1)));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef154) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("daff_cmd");
		baseArr.push("status");
		baseArr.push("mv");
		baseArr.push("io");
		baseArr.push("order_preference");
		baseArr.push("order_set");
		baseArr.push("nested_output");
		baseArr.push("output_format");
		baseArr.push("extern_preference");
		baseArr.push("delim_preference");
		baseArr.push("format_preference");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



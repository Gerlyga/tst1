package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class CellInfo extends haxe.lang.HxObject
{
	public    CellInfo(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    CellInfo()
	{
		coopy.CellInfo.__hx_ctor_coopy_CellInfo(this);
	}
	
	
	public static   void __hx_ctor_coopy_CellInfo(coopy.CellInfo __temp_me13)
	{
		{
		}
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.CellInfo(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.CellInfo();
	}
	
	
	public  java.lang.Object raw;
	
	public  java.lang.String value;
	
	public  java.lang.String pretty_value;
	
	public  java.lang.String category;
	
	public  java.lang.String category_given_tr;
	
	public  java.lang.String separator;
	
	public  java.lang.String pretty_separator;
	
	public  boolean updated;
	
	public  boolean conflicted;
	
	public  java.lang.String pvalue;
	
	public  java.lang.String lvalue;
	
	public  java.lang.String rvalue;
	
	@Override public   java.lang.String toString()
	{
		if ( ! (this.updated) ) 
		{
			return this.value;
		}
		
		if ( ! (this.conflicted) ) 
		{
			return ( ( this.lvalue + "::" ) + this.rvalue );
		}
		
		return ( ( ( ( this.pvalue + "||" ) + this.lvalue ) + "::" ) + this.rvalue );
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef133 = true;
			switch (field.hashCode())
			{
				case 112680:
				{
					if (field.equals("raw")) 
					{
						__temp_executeDef133 = false;
						this.raw = ((java.lang.Object) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef133) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef134 = true;
			switch (field.hashCode())
			{
				case -919271361:
				{
					if (field.equals("rvalue")) 
					{
						__temp_executeDef134 = false;
						this.rvalue = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 112680:
				{
					if (field.equals("raw")) 
					{
						__temp_executeDef134 = false;
						this.raw = ((java.lang.Object) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1091046267:
				{
					if (field.equals("lvalue")) 
					{
						__temp_executeDef134 = false;
						this.lvalue = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 111972721:
				{
					if (field.equals("value")) 
					{
						__temp_executeDef134 = false;
						this.value = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case -976529663:
				{
					if (field.equals("pvalue")) 
					{
						__temp_executeDef134 = false;
						this.pvalue = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case -147903384:
				{
					if (field.equals("pretty_value")) 
					{
						__temp_executeDef134 = false;
						this.pretty_value = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 919702513:
				{
					if (field.equals("conflicted")) 
					{
						__temp_executeDef134 = false;
						this.conflicted = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 50511102:
				{
					if (field.equals("category")) 
					{
						__temp_executeDef134 = false;
						this.category = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case -234430277:
				{
					if (field.equals("updated")) 
					{
						__temp_executeDef134 = false;
						this.updated = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case -507895647:
				{
					if (field.equals("category_given_tr")) 
					{
						__temp_executeDef134 = false;
						this.category_given_tr = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case -830002596:
				{
					if (field.equals("pretty_separator")) 
					{
						__temp_executeDef134 = false;
						this.pretty_separator = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 1732829925:
				{
					if (field.equals("separator")) 
					{
						__temp_executeDef134 = false;
						this.separator = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef134) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef135 = true;
			switch (field.hashCode())
			{
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef135 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 112680:
				{
					if (field.equals("raw")) 
					{
						__temp_executeDef135 = false;
						return this.raw;
					}
					
					break;
				}
				
				
				case -919271361:
				{
					if (field.equals("rvalue")) 
					{
						__temp_executeDef135 = false;
						return this.rvalue;
					}
					
					break;
				}
				
				
				case 111972721:
				{
					if (field.equals("value")) 
					{
						__temp_executeDef135 = false;
						return this.value;
					}
					
					break;
				}
				
				
				case -1091046267:
				{
					if (field.equals("lvalue")) 
					{
						__temp_executeDef135 = false;
						return this.lvalue;
					}
					
					break;
				}
				
				
				case -147903384:
				{
					if (field.equals("pretty_value")) 
					{
						__temp_executeDef135 = false;
						return this.pretty_value;
					}
					
					break;
				}
				
				
				case -976529663:
				{
					if (field.equals("pvalue")) 
					{
						__temp_executeDef135 = false;
						return this.pvalue;
					}
					
					break;
				}
				
				
				case 50511102:
				{
					if (field.equals("category")) 
					{
						__temp_executeDef135 = false;
						return this.category;
					}
					
					break;
				}
				
				
				case 919702513:
				{
					if (field.equals("conflicted")) 
					{
						__temp_executeDef135 = false;
						return this.conflicted;
					}
					
					break;
				}
				
				
				case -507895647:
				{
					if (field.equals("category_given_tr")) 
					{
						__temp_executeDef135 = false;
						return this.category_given_tr;
					}
					
					break;
				}
				
				
				case -234430277:
				{
					if (field.equals("updated")) 
					{
						__temp_executeDef135 = false;
						return this.updated;
					}
					
					break;
				}
				
				
				case 1732829925:
				{
					if (field.equals("separator")) 
					{
						__temp_executeDef135 = false;
						return this.separator;
					}
					
					break;
				}
				
				
				case -830002596:
				{
					if (field.equals("pretty_separator")) 
					{
						__temp_executeDef135 = false;
						return this.pretty_separator;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef135) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef136 = true;
			switch (field.hashCode())
			{
				case 112680:
				{
					if (field.equals("raw")) 
					{
						__temp_executeDef136 = false;
						return ((double) (haxe.lang.Runtime.toDouble(this.raw)) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef136) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef137 = true;
			switch (field.hashCode())
			{
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef137 = false;
						return this.toString();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef137) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("rvalue");
		baseArr.push("lvalue");
		baseArr.push("pvalue");
		baseArr.push("conflicted");
		baseArr.push("updated");
		baseArr.push("pretty_separator");
		baseArr.push("separator");
		baseArr.push("category_given_tr");
		baseArr.push("category");
		baseArr.push("pretty_value");
		baseArr.push("value");
		baseArr.push("raw");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



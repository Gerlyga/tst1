package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class IndexPair extends haxe.lang.HxObject
{
	public    IndexPair(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    IndexPair()
	{
		coopy.IndexPair.__hx_ctor_coopy_IndexPair(this);
	}
	
	
	public static   void __hx_ctor_coopy_IndexPair(coopy.IndexPair __temp_me27)
	{
		__temp_me27.ia = new coopy.Index();
		__temp_me27.ib = new coopy.Index();
		__temp_me27.quality = ((double) (0) );
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.IndexPair(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.IndexPair();
	}
	
	
	public  coopy.Index ia;
	
	public  coopy.Index ib;
	
	public  double quality;
	
	public   void addColumns(int ca, int cb)
	{
		this.ia.addColumn(ca);
		this.ib.addColumn(cb);
	}
	
	
	public   void indexTables(coopy.Table a, coopy.Table b)
	{
		this.ia.indexTable(a);
		this.ib.indexTable(b);
		int good = 0;
		{
			java.lang.Object __temp_iterator89 = this.ia.items.keys();
			while (haxe.lang.Runtime.toBool(haxe.lang.Runtime.callField(__temp_iterator89, "hasNext", null)))
			{
				java.lang.String key = haxe.lang.Runtime.toString(haxe.lang.Runtime.callField(__temp_iterator89, "next", null));
				coopy.IndexItem item_a = this.ia.items.get(key);
				int spot_a = item_a.lst.length;
				coopy.IndexItem item_b = this.ib.items.get(key);
				int spot_b = 0;
				if (( item_b != null )) 
				{
					spot_b = item_b.lst.length;
				}
				
				if (( ( spot_a == 1 ) && ( spot_b == 1 ) )) 
				{
					good++;
				}
				
			}
			
		}
		
		this.quality = ( good / java.lang.Math.max(1.0, ((double) (a.get_height()) )) );
	}
	
	
	public   coopy.CrossMatch queryByKey(java.lang.String ka)
	{
		coopy.CrossMatch result = new coopy.CrossMatch();
		result.item_a = this.ia.items.get(ka);
		result.item_b = this.ib.items.get(ka);
		result.spot_a = result.spot_b = 0;
		if ( ! (haxe.lang.Runtime.valEq(ka, "")) ) 
		{
			if (( result.item_a != null )) 
			{
				result.spot_a = result.item_a.lst.length;
			}
			
			if (( result.item_b != null )) 
			{
				result.spot_b = result.item_b.lst.length;
			}
			
		}
		
		return result;
	}
	
	
	public   coopy.CrossMatch queryByContent(coopy.Row row)
	{
		coopy.CrossMatch result = new coopy.CrossMatch();
		java.lang.String ka = this.ia.toKeyByContent(row);
		return this.queryByKey(ka);
	}
	
	
	public   coopy.CrossMatch queryLocal(int row)
	{
		java.lang.String ka = this.ia.toKey(this.ia.getTable(), row);
		return this.queryByKey(ka);
	}
	
	
	public   java.lang.String localKey(int row)
	{
		return this.ia.toKey(this.ia.getTable(), row);
	}
	
	
	public   java.lang.String remoteKey(int row)
	{
		return this.ib.toKey(this.ib.getTable(), row);
	}
	
	
	public   int getTopFreq()
	{
		if (( this.ib.top_freq > this.ia.top_freq )) 
		{
			return this.ib.top_freq;
		}
		
		return this.ia.top_freq;
	}
	
	
	public   double getQuality()
	{
		return this.quality;
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef195 = true;
			switch (field.hashCode())
			{
				case 651215103:
				{
					if (field.equals("quality")) 
					{
						__temp_executeDef195 = false;
						this.quality = ((double) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef195) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef196 = true;
			switch (field.hashCode())
			{
				case 651215103:
				{
					if (field.equals("quality")) 
					{
						__temp_executeDef196 = false;
						this.quality = ((double) (haxe.lang.Runtime.toDouble(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 3352:
				{
					if (field.equals("ia")) 
					{
						__temp_executeDef196 = false;
						this.ia = ((coopy.Index) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3353:
				{
					if (field.equals("ib")) 
					{
						__temp_executeDef196 = false;
						this.ib = ((coopy.Index) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef196) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef197 = true;
			switch (field.hashCode())
			{
				case 1688075465:
				{
					if (field.equals("getQuality")) 
					{
						__temp_executeDef197 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getQuality"))) );
					}
					
					break;
				}
				
				
				case 3352:
				{
					if (field.equals("ia")) 
					{
						__temp_executeDef197 = false;
						return this.ia;
					}
					
					break;
				}
				
				
				case -103426761:
				{
					if (field.equals("getTopFreq")) 
					{
						__temp_executeDef197 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getTopFreq"))) );
					}
					
					break;
				}
				
				
				case 3353:
				{
					if (field.equals("ib")) 
					{
						__temp_executeDef197 = false;
						return this.ib;
					}
					
					break;
				}
				
				
				case 1280507961:
				{
					if (field.equals("remoteKey")) 
					{
						__temp_executeDef197 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("remoteKey"))) );
					}
					
					break;
				}
				
				
				case 651215103:
				{
					if (field.equals("quality")) 
					{
						__temp_executeDef197 = false;
						return this.quality;
					}
					
					break;
				}
				
				
				case 1900776180:
				{
					if (field.equals("localKey")) 
					{
						__temp_executeDef197 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("localKey"))) );
					}
					
					break;
				}
				
				
				case -1437011972:
				{
					if (field.equals("addColumns")) 
					{
						__temp_executeDef197 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("addColumns"))) );
					}
					
					break;
				}
				
				
				case -185855101:
				{
					if (field.equals("queryLocal")) 
					{
						__temp_executeDef197 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("queryLocal"))) );
					}
					
					break;
				}
				
				
				case 1354100183:
				{
					if (field.equals("indexTables")) 
					{
						__temp_executeDef197 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("indexTables"))) );
					}
					
					break;
				}
				
				
				case 1903093818:
				{
					if (field.equals("queryByContent")) 
					{
						__temp_executeDef197 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("queryByContent"))) );
					}
					
					break;
				}
				
				
				case -194815328:
				{
					if (field.equals("queryByKey")) 
					{
						__temp_executeDef197 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("queryByKey"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef197) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef198 = true;
			switch (field.hashCode())
			{
				case 651215103:
				{
					if (field.equals("quality")) 
					{
						__temp_executeDef198 = false;
						return this.quality;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef198) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef199 = true;
			switch (field.hashCode())
			{
				case 1688075465:
				{
					if (field.equals("getQuality")) 
					{
						__temp_executeDef199 = false;
						return this.getQuality();
					}
					
					break;
				}
				
				
				case -1437011972:
				{
					if (field.equals("addColumns")) 
					{
						__temp_executeDef199 = false;
						this.addColumns(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case -103426761:
				{
					if (field.equals("getTopFreq")) 
					{
						__temp_executeDef199 = false;
						return this.getTopFreq();
					}
					
					break;
				}
				
				
				case 1354100183:
				{
					if (field.equals("indexTables")) 
					{
						__temp_executeDef199 = false;
						this.indexTables(((coopy.Table) (dynargs.__get(0)) ), ((coopy.Table) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case 1280507961:
				{
					if (field.equals("remoteKey")) 
					{
						__temp_executeDef199 = false;
						return this.remoteKey(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case -194815328:
				{
					if (field.equals("queryByKey")) 
					{
						__temp_executeDef199 = false;
						return this.queryByKey(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 1900776180:
				{
					if (field.equals("localKey")) 
					{
						__temp_executeDef199 = false;
						return this.localKey(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case 1903093818:
				{
					if (field.equals("queryByContent")) 
					{
						__temp_executeDef199 = false;
						return this.queryByContent(((coopy.Row) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case -185855101:
				{
					if (field.equals("queryLocal")) 
					{
						__temp_executeDef199 = false;
						return this.queryLocal(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef199) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("quality");
		baseArr.push("ib");
		baseArr.push("ia");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



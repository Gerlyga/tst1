package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class SqlTable extends haxe.lang.HxObject implements coopy.Table
{
	public    SqlTable(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    SqlTable(coopy.SqlDatabase db, coopy.SqlTableName name, coopy.SqlHelper helper)
	{
		coopy.SqlTable.__hx_ctor_coopy_SqlTable(this, db, name, helper);
	}
	
	
	public static   void __hx_ctor_coopy_SqlTable(coopy.SqlTable __temp_me39, coopy.SqlDatabase db, coopy.SqlTableName name, coopy.SqlHelper helper)
	{
		__temp_me39.db = db;
		__temp_me39.name = name;
		__temp_me39.helper = helper;
		__temp_me39.cache = new haxe.ds.IntMap<haxe.ds.IntMap>();
		__temp_me39.h = -1;
		__temp_me39.id2rid = null;
		__temp_me39.getColumns();
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.SqlTable(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.SqlTable(((coopy.SqlDatabase) (arr.__get(0)) ), ((coopy.SqlTableName) (arr.__get(1)) ), ((coopy.SqlHelper) (arr.__get(2)) ));
	}
	
	
	public  coopy.SqlDatabase db;
	
	public  haxe.root.Array<coopy.SqlColumn> columns;
	
	public  coopy.SqlTableName name;
	
	public  java.lang.String quotedTableName;
	
	public  haxe.ds.IntMap<haxe.ds.IntMap> cache;
	
	public  haxe.root.Array<java.lang.String> columnNames;
	
	public  int h;
	
	public  coopy.SqlHelper helper;
	
	public  haxe.root.Array<java.lang.Object> id2rid;
	
	public   void getColumns()
	{
		if (( this.columns != null )) 
		{
			return ;
		}
		
		if (( this.db == null )) 
		{
			return ;
		}
		
		this.columns = this.db.getColumns(this.name);
		this.columnNames = new haxe.root.Array<java.lang.String>();
		{
			int _g = 0;
			haxe.root.Array<coopy.SqlColumn> _g1 = this.columns;
			while (( _g < _g1.length ))
			{
				coopy.SqlColumn col = _g1.__get(_g);
				 ++ _g;
				this.columnNames.push(col.getName());
			}
			
		}
		
	}
	
	
	public   haxe.root.Array<java.lang.String> getPrimaryKey()
	{
		this.getColumns();
		haxe.root.Array<java.lang.String> result = new haxe.root.Array<java.lang.String>();
		{
			int _g = 0;
			haxe.root.Array<coopy.SqlColumn> _g1 = this.columns;
			while (( _g < _g1.length ))
			{
				coopy.SqlColumn col = _g1.__get(_g);
				 ++ _g;
				if ( ! (col.isPrimaryKey()) ) 
				{
					continue;
				}
				
				result.push(col.getName());
			}
			
		}
		
		return result;
	}
	
	
	public   haxe.root.Array<java.lang.String> getAllButPrimaryKey()
	{
		this.getColumns();
		haxe.root.Array<java.lang.String> result = new haxe.root.Array<java.lang.String>();
		{
			int _g = 0;
			haxe.root.Array<coopy.SqlColumn> _g1 = this.columns;
			while (( _g < _g1.length ))
			{
				coopy.SqlColumn col = _g1.__get(_g);
				 ++ _g;
				if (col.isPrimaryKey()) 
				{
					continue;
				}
				
				result.push(col.getName());
			}
			
		}
		
		return result;
	}
	
	
	public   haxe.root.Array<java.lang.String> getColumnNames()
	{
		this.getColumns();
		return this.columnNames;
	}
	
	
	public   java.lang.String getQuotedTableName()
	{
		if (( this.quotedTableName != null )) 
		{
			return this.quotedTableName;
		}
		
		this.quotedTableName = this.db.getQuotedTableName(this.name);
		return this.quotedTableName;
	}
	
	
	public   java.lang.String getQuotedColumnName(java.lang.String name)
	{
		return this.db.getQuotedColumnName(name);
	}
	
	
	public   java.lang.Object getCell(int x, int y)
	{
		if (( this.h >= 0 )) 
		{
			y = ( y - 1 );
			if (( y >= 0 )) 
			{
				y = ((int) (haxe.lang.Runtime.toInt(this.id2rid.__get(y))) );
			}
			
		}
		
		if (( y < 0 )) 
		{
			this.getColumns();
			return this.columns.__get(x).name;
		}
		
		haxe.ds.IntMap row = this.cache.get(((int) (y) ));
		if (( row == null )) 
		{
			row = new haxe.ds.IntMap();
			this.getColumns();
			this.db.beginRow(this.name, y, this.columnNames);
			while (this.db.read())
			{
				int _g1 = 0;
				int _g = this.get_width();
				while (( _g1 < _g ))
				{
					int i = _g1++;
					{
						java.lang.Object v = this.db.get(i);
						row.set(i, v);
						java.lang.Object __temp_expr244 = v;
					}
					
				}
				
			}
			
			this.db.end();
			{
				this.cache.set(y, row);
				haxe.ds.IntMap __temp_expr245 = row;
			}
			
		}
		
		{
			haxe.root.IMap this1 = this.cache.get(((int) (y) ));
			return this1.get(x);
		}
		
	}
	
	
	public   void setCellCache(int x, int y, java.lang.Object c)
	{
		haxe.ds.IntMap row = this.cache.get(((int) (y) ));
		if (( row == null )) 
		{
			row = new haxe.ds.IntMap();
			this.getColumns();
			{
				this.cache.set(y, row);
				haxe.ds.IntMap __temp_expr246 = row;
			}
			
		}
		
		{
			java.lang.Object v = c;
			row.set(x, v);
			java.lang.Object __temp_expr247 = v;
		}
		
	}
	
	
	public   void setCell(int x, int y, java.lang.Object c)
	{
		haxe.Log.trace.__hx_invoke2_o(0.0, "SqlTable cannot set cells yet", 0.0, new haxe.lang.DynamicObject(new haxe.root.Array<java.lang.String>(new java.lang.String[]{"className", "fileName", "methodName"}), new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{"coopy.SqlTable", "SqlTable.hx", "setCell"}), new haxe.root.Array<java.lang.String>(new java.lang.String[]{"lineNumber"}), new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{((java.lang.Object) (((double) (112) )) )})));
	}
	
	
	public   coopy.View getCellView()
	{
		return new coopy.SimpleView();
	}
	
	
	public   boolean isResizable()
	{
		return false;
	}
	
	
	public   boolean resize(int w, int h)
	{
		return false;
	}
	
	
	public   void clear()
	{
		{
		}
		
	}
	
	
	public   boolean insertOrDeleteRows(haxe.root.Array<java.lang.Object> fate, int hfate)
	{
		return false;
	}
	
	
	public   boolean insertOrDeleteColumns(haxe.root.Array<java.lang.Object> fate, int wfate)
	{
		return false;
	}
	
	
	public   boolean trimBlank()
	{
		return false;
	}
	
	
	
	
	
	
	public   int get_width()
	{
		this.getColumns();
		return this.columns.length;
	}
	
	
	public   int get_height()
	{
		if (( this.h >= 0 )) 
		{
			return this.h;
		}
		
		if (( this.helper == null )) 
		{
			return -1;
		}
		
		this.id2rid = this.helper.getRowIDs(this.db, this.name);
		this.h = ( this.id2rid.length + 1 );
		return this.h;
	}
	
	
	public   java.lang.Object getData()
	{
		return null;
	}
	
	
	public   coopy.Table clone()
	{
		return null;
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef248 = true;
			switch (field.hashCode())
			{
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef248 = false;
						this.h = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef248) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef249 = true;
			switch (field.hashCode())
			{
				case -1194951882:
				{
					if (field.equals("id2rid")) 
					{
						__temp_executeDef249 = false;
						this.id2rid = ((haxe.root.Array<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3198:
				{
					if (field.equals("db")) 
					{
						__temp_executeDef249 = false;
						this.db = ((coopy.SqlDatabase) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1220931666:
				{
					if (field.equals("helper")) 
					{
						__temp_executeDef249 = false;
						this.helper = ((coopy.SqlHelper) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 949721053:
				{
					if (field.equals("columns")) 
					{
						__temp_executeDef249 = false;
						this.columns = ((haxe.root.Array<coopy.SqlColumn>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef249 = false;
						this.h = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 3373707:
				{
					if (field.equals("name")) 
					{
						__temp_executeDef249 = false;
						this.name = ((coopy.SqlTableName) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -851002990:
				{
					if (field.equals("columnNames")) 
					{
						__temp_executeDef249 = false;
						this.columnNames = ((haxe.root.Array<java.lang.String>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -145148175:
				{
					if (field.equals("quotedTableName")) 
					{
						__temp_executeDef249 = false;
						this.quotedTableName = haxe.lang.Runtime.toString(value);
						return value;
					}
					
					break;
				}
				
				
				case 94416770:
				{
					if (field.equals("cache")) 
					{
						__temp_executeDef249 = false;
						this.cache = ((haxe.ds.IntMap<haxe.ds.IntMap>) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef249) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef250 = true;
			switch (field.hashCode())
			{
				case 94756189:
				{
					if (field.equals("clone")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("clone"))) );
					}
					
					break;
				}
				
				
				case 3198:
				{
					if (field.equals("db")) 
					{
						__temp_executeDef250 = false;
						return this.db;
					}
					
					break;
				}
				
				
				case -75605984:
				{
					if (field.equals("getData")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getData"))) );
					}
					
					break;
				}
				
				
				case 949721053:
				{
					if (field.equals("columns")) 
					{
						__temp_executeDef250 = false;
						return this.columns;
					}
					
					break;
				}
				
				
				case 859648560:
				{
					if (field.equals("get_height")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("get_height"))) );
					}
					
					break;
				}
				
				
				case 3373707:
				{
					if (field.equals("name")) 
					{
						__temp_executeDef250 = false;
						return this.name;
					}
					
					break;
				}
				
				
				case 1150076829:
				{
					if (field.equals("get_width")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("get_width"))) );
					}
					
					break;
				}
				
				
				case -145148175:
				{
					if (field.equals("quotedTableName")) 
					{
						__temp_executeDef250 = false;
						return this.quotedTableName;
					}
					
					break;
				}
				
				
				case 113126854:
				{
					if (field.equals("width")) 
					{
						__temp_executeDef250 = false;
						return this.get_width();
					}
					
					break;
				}
				
				
				case 94416770:
				{
					if (field.equals("cache")) 
					{
						__temp_executeDef250 = false;
						return this.cache;
					}
					
					break;
				}
				
				
				case -1221029593:
				{
					if (field.equals("height")) 
					{
						__temp_executeDef250 = false;
						return this.get_height();
					}
					
					break;
				}
				
				
				case -851002990:
				{
					if (field.equals("columnNames")) 
					{
						__temp_executeDef250 = false;
						return this.columnNames;
					}
					
					break;
				}
				
				
				case -510954926:
				{
					if (field.equals("trimBlank")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("trimBlank"))) );
					}
					
					break;
				}
				
				
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef250 = false;
						return this.h;
					}
					
					break;
				}
				
				
				case 1889278614:
				{
					if (field.equals("insertOrDeleteColumns")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("insertOrDeleteColumns"))) );
					}
					
					break;
				}
				
				
				case -1220931666:
				{
					if (field.equals("helper")) 
					{
						__temp_executeDef250 = false;
						return this.helper;
					}
					
					break;
				}
				
				
				case 1186308544:
				{
					if (field.equals("insertOrDeleteRows")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("insertOrDeleteRows"))) );
					}
					
					break;
				}
				
				
				case -1194951882:
				{
					if (field.equals("id2rid")) 
					{
						__temp_executeDef250 = false;
						return this.id2rid;
					}
					
					break;
				}
				
				
				case 94746189:
				{
					if (field.equals("clear")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("clear"))) );
					}
					
					break;
				}
				
				
				case 1986581415:
				{
					if (field.equals("getColumns")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getColumns"))) );
					}
					
					break;
				}
				
				
				case -934437708:
				{
					if (field.equals("resize")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("resize"))) );
					}
					
					break;
				}
				
				
				case -1572669197:
				{
					if (field.equals("getPrimaryKey")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getPrimaryKey"))) );
					}
					
					break;
				}
				
				
				case -972315487:
				{
					if (field.equals("isResizable")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("isResizable"))) );
					}
					
					break;
				}
				
				
				case -156452429:
				{
					if (field.equals("getAllButPrimaryKey")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getAllButPrimaryKey"))) );
					}
					
					break;
				}
				
				
				case 1160377501:
				{
					if (field.equals("getCellView")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getCellView"))) );
					}
					
					break;
				}
				
				
				case -1491271588:
				{
					if (field.equals("getColumnNames")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getColumnNames"))) );
					}
					
					break;
				}
				
				
				case 1984477412:
				{
					if (field.equals("setCell")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setCell"))) );
					}
					
					break;
				}
				
				
				case -608499525:
				{
					if (field.equals("getQuotedTableName")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getQuotedTableName"))) );
					}
					
					break;
				}
				
				
				case -1151798018:
				{
					if (field.equals("setCellCache")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("setCellCache"))) );
					}
					
					break;
				}
				
				
				case 2026396159:
				{
					if (field.equals("getQuotedColumnName")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getQuotedColumnName"))) );
					}
					
					break;
				}
				
				
				case -75632168:
				{
					if (field.equals("getCell")) 
					{
						__temp_executeDef250 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getCell"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef250) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef251 = true;
			switch (field.hashCode())
			{
				case 113126854:
				{
					if (field.equals("width")) 
					{
						__temp_executeDef251 = false;
						return ((double) (this.get_width()) );
					}
					
					break;
				}
				
				
				case 104:
				{
					if (field.equals("h")) 
					{
						__temp_executeDef251 = false;
						return ((double) (this.h) );
					}
					
					break;
				}
				
				
				case -1221029593:
				{
					if (field.equals("height")) 
					{
						__temp_executeDef251 = false;
						return ((double) (this.get_height()) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef251) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef252 = true;
			switch (field.hashCode())
			{
				case 94756189:
				{
					if (field.equals("clone")) 
					{
						__temp_executeDef252 = false;
						return this.clone();
					}
					
					break;
				}
				
				
				case 1986581415:
				{
					if (field.equals("getColumns")) 
					{
						__temp_executeDef252 = false;
						this.getColumns();
					}
					
					break;
				}
				
				
				case -75605984:
				{
					if (field.equals("getData")) 
					{
						__temp_executeDef252 = false;
						return this.getData();
					}
					
					break;
				}
				
				
				case -1572669197:
				{
					if (field.equals("getPrimaryKey")) 
					{
						__temp_executeDef252 = false;
						return this.getPrimaryKey();
					}
					
					break;
				}
				
				
				case 859648560:
				{
					if (field.equals("get_height")) 
					{
						__temp_executeDef252 = false;
						return this.get_height();
					}
					
					break;
				}
				
				
				case -156452429:
				{
					if (field.equals("getAllButPrimaryKey")) 
					{
						__temp_executeDef252 = false;
						return this.getAllButPrimaryKey();
					}
					
					break;
				}
				
				
				case 1150076829:
				{
					if (field.equals("get_width")) 
					{
						__temp_executeDef252 = false;
						return this.get_width();
					}
					
					break;
				}
				
				
				case -1491271588:
				{
					if (field.equals("getColumnNames")) 
					{
						__temp_executeDef252 = false;
						return this.getColumnNames();
					}
					
					break;
				}
				
				
				case -510954926:
				{
					if (field.equals("trimBlank")) 
					{
						__temp_executeDef252 = false;
						return this.trimBlank();
					}
					
					break;
				}
				
				
				case -608499525:
				{
					if (field.equals("getQuotedTableName")) 
					{
						__temp_executeDef252 = false;
						return this.getQuotedTableName();
					}
					
					break;
				}
				
				
				case 1889278614:
				{
					if (field.equals("insertOrDeleteColumns")) 
					{
						__temp_executeDef252 = false;
						return this.insertOrDeleteColumns(((haxe.root.Array<java.lang.Object>) (dynargs.__get(0)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case 2026396159:
				{
					if (field.equals("getQuotedColumnName")) 
					{
						__temp_executeDef252 = false;
						return this.getQuotedColumnName(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 1186308544:
				{
					if (field.equals("insertOrDeleteRows")) 
					{
						__temp_executeDef252 = false;
						return this.insertOrDeleteRows(((haxe.root.Array<java.lang.Object>) (dynargs.__get(0)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case -75632168:
				{
					if (field.equals("getCell")) 
					{
						__temp_executeDef252 = false;
						return this.getCell(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case 94746189:
				{
					if (field.equals("clear")) 
					{
						__temp_executeDef252 = false;
						this.clear();
					}
					
					break;
				}
				
				
				case -1151798018:
				{
					if (field.equals("setCellCache")) 
					{
						__temp_executeDef252 = false;
						this.setCellCache(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), dynargs.__get(2));
					}
					
					break;
				}
				
				
				case -934437708:
				{
					if (field.equals("resize")) 
					{
						__temp_executeDef252 = false;
						return this.resize(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ));
					}
					
					break;
				}
				
				
				case 1984477412:
				{
					if (field.equals("setCell")) 
					{
						__temp_executeDef252 = false;
						this.setCell(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), dynargs.__get(2));
					}
					
					break;
				}
				
				
				case -972315487:
				{
					if (field.equals("isResizable")) 
					{
						__temp_executeDef252 = false;
						return this.isResizable();
					}
					
					break;
				}
				
				
				case 1160377501:
				{
					if (field.equals("getCellView")) 
					{
						__temp_executeDef252 = false;
						return this.getCellView();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef252) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("width");
		baseArr.push("height");
		baseArr.push("id2rid");
		baseArr.push("helper");
		baseArr.push("h");
		baseArr.push("columnNames");
		baseArr.push("cache");
		baseArr.push("quotedTableName");
		baseArr.push("name");
		baseArr.push("columns");
		baseArr.push("db");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



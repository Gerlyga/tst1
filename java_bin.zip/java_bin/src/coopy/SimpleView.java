package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class SimpleView extends haxe.lang.HxObject implements coopy.View
{
	public    SimpleView(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    SimpleView()
	{
		coopy.SimpleView.__hx_ctor_coopy_SimpleView(this);
	}
	
	
	public static   void __hx_ctor_coopy_SimpleView(coopy.SimpleView __temp_me35)
	{
		{
		}
		
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.SimpleView(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.SimpleView();
	}
	
	
	public   java.lang.String toString(java.lang.Object d)
	{
		if (( d == null )) 
		{
			return null;
		}
		
		return ( "" + haxe.root.Std.string(d) );
	}
	
	
	public   boolean equals(java.lang.Object d1, java.lang.Object d2)
	{
		if (( ( d1 == null ) && ( d2 == null ) )) 
		{
			return true;
		}
		
		if (( ( d1 == null ) && haxe.lang.Runtime.valEq(( "" + haxe.root.Std.string(d2) ), "") )) 
		{
			return true;
		}
		
		if (( haxe.lang.Runtime.valEq(( "" + haxe.root.Std.string(d1) ), "") && ( d2 == null ) )) 
		{
			return true;
		}
		
		return haxe.lang.Runtime.valEq(( "" + haxe.root.Std.string(d1) ), ( "" + haxe.root.Std.string(d2) ));
	}
	
	
	public   java.lang.Object toDatum(java.lang.String str)
	{
		return ((java.lang.Object) (this.toDatum(((java.lang.Object) (str) ))) );
	}
	
	
	public   java.lang.Object toDatum(java.lang.Object x)
	{
		return x;
	}
	
	
	public   java.lang.Object makeHash()
	{
		return new haxe.ds.StringMap();
	}
	
	
	public   void hashSet(java.lang.Object h, java.lang.String str, java.lang.Object d)
	{
		haxe.ds.StringMap hh = ((haxe.ds.StringMap) (h) );
		{
			java.lang.Object value = d;
			hh.set(str, value);
		}
		
	}
	
	
	public   boolean hashExists(java.lang.Object h, java.lang.String str)
	{
		haxe.ds.StringMap hh = ((haxe.ds.StringMap) (h) );
		return hh.exists(str);
	}
	
	
	public   java.lang.Object hashGet(java.lang.Object h, java.lang.String str)
	{
		haxe.ds.StringMap hh = ((haxe.ds.StringMap) (h) );
		return hh.get(str);
	}
	
	
	public   boolean isHash(java.lang.Object h)
	{
		return ( h instanceof haxe.ds.StringMap );
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef229 = true;
			switch (field.hashCode())
			{
				case -1180459688:
				{
					if (field.equals("isHash")) 
					{
						__temp_executeDef229 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("isHash"))) );
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef229 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 697504616:
				{
					if (field.equals("hashGet")) 
					{
						__temp_executeDef229 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("hashGet"))) );
					}
					
					break;
				}
				
				
				case -1295482945:
				{
					if (field.equals("equals")) 
					{
						__temp_executeDef229 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("equals"))) );
					}
					
					break;
				}
				
				
				case 268312330:
				{
					if (field.equals("hashExists")) 
					{
						__temp_executeDef229 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("hashExists"))) );
					}
					
					break;
				}
				
				
				case -1180115276:
				{
					if (field.equals("toDatum")) 
					{
						__temp_executeDef229 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toDatum"))) );
					}
					
					break;
				}
				
				
				case 697516148:
				{
					if (field.equals("hashSet")) 
					{
						__temp_executeDef229 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("hashSet"))) );
					}
					
					break;
				}
				
				
				case 40145948:
				{
					if (field.equals("makeHash")) 
					{
						__temp_executeDef229 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("makeHash"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef229) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef230 = true;
			switch (field.hashCode())
			{
				case -1180459688:
				{
					if (field.equals("isHash")) 
					{
						__temp_executeDef230 = false;
						return this.isHash(dynargs.__get(0));
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef230 = false;
						return this.toString(dynargs.__get(0));
					}
					
					break;
				}
				
				
				case 697504616:
				{
					if (field.equals("hashGet")) 
					{
						__temp_executeDef230 = false;
						return this.hashGet(dynargs.__get(0), haxe.lang.Runtime.toString(dynargs.__get(1)));
					}
					
					break;
				}
				
				
				case -1295482945:
				{
					if (field.equals("equals")) 
					{
						__temp_executeDef230 = false;
						return this.equals(dynargs.__get(0), dynargs.__get(1));
					}
					
					break;
				}
				
				
				case 268312330:
				{
					if (field.equals("hashExists")) 
					{
						__temp_executeDef230 = false;
						return this.hashExists(dynargs.__get(0), haxe.lang.Runtime.toString(dynargs.__get(1)));
					}
					
					break;
				}
				
				
				case -1180115276:
				{
					if (field.equals("toDatum")) 
					{
						__temp_executeDef230 = false;
						return this.toDatum(((java.lang.Object) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case 697516148:
				{
					if (field.equals("hashSet")) 
					{
						__temp_executeDef230 = false;
						this.hashSet(dynargs.__get(0), haxe.lang.Runtime.toString(dynargs.__get(1)), dynargs.__get(2));
					}
					
					break;
				}
				
				
				case 40145948:
				{
					if (field.equals("makeHash")) 
					{
						__temp_executeDef230 = false;
						return this.makeHash();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef230) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
}



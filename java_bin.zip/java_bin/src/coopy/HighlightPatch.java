package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class HighlightPatch extends haxe.lang.HxObject implements coopy.Row
{
	public    HighlightPatch(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    HighlightPatch(coopy.Table source, coopy.Table patch)
	{
		coopy.HighlightPatch.__hx_ctor_coopy_HighlightPatch(this, source, patch);
	}
	
	
	public static   void __hx_ctor_coopy_HighlightPatch(coopy.HighlightPatch __temp_me23, coopy.Table source, coopy.Table patch)
	{
		__temp_me23.source = source;
		__temp_me23.patch = patch;
		__temp_me23.view = patch.getCellView();
		__temp_me23.sourceView = source.getCellView();
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.HighlightPatch(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.HighlightPatch(((coopy.Table) (arr.__get(0)) ), ((coopy.Table) (arr.__get(1)) ));
	}
	
	
	public  coopy.Table source;
	
	public  coopy.Table patch;
	
	public  coopy.View view;
	
	public  coopy.View sourceView;
	
	public  coopy.Csv csv;
	
	public  haxe.ds.IntMap<java.lang.String> header;
	
	public  haxe.ds.StringMap<java.lang.Object> headerPre;
	
	public  haxe.ds.StringMap<java.lang.Object> headerPost;
	
	public  haxe.ds.StringMap<java.lang.String> headerRename;
	
	public  haxe.ds.StringMap<java.lang.Object> headerMove;
	
	public  haxe.ds.IntMap<java.lang.String> modifier;
	
	public  int currentRow;
	
	public  int payloadCol;
	
	public  int payloadTop;
	
	public  haxe.root.Array<coopy.HighlightPatchUnit> mods;
	
	public  haxe.root.Array<coopy.HighlightPatchUnit> cmods;
	
	public  coopy.CellInfo rowInfo;
	
	public  coopy.CellInfo cellInfo;
	
	public  int rcOffset;
	
	public  haxe.root.Array<coopy.IndexPair> indexes;
	
	public  haxe.ds.IntMap<java.lang.Object> sourceInPatchCol;
	
	public  haxe.ds.IntMap<java.lang.Object> patchInSourceCol;
	
	public  haxe.ds.IntMap<java.lang.Object> patchInSourceRow;
	
	public  int lastSourceRow;
	
	public  haxe.root.Array<java.lang.String> actions;
	
	public  haxe.root.Array<java.lang.Object> rowPermutation;
	
	public  haxe.root.Array<java.lang.Object> rowPermutationRev;
	
	public  haxe.root.Array<java.lang.Object> colPermutation;
	
	public  haxe.root.Array<java.lang.Object> colPermutationRev;
	
	public  boolean haveDroppedColumns;
	
	public   void reset()
	{
		this.header = new haxe.ds.IntMap<java.lang.String>();
		this.headerPre = new haxe.ds.StringMap<java.lang.Object>();
		this.headerPost = new haxe.ds.StringMap<java.lang.Object>();
		this.headerRename = new haxe.ds.StringMap<java.lang.String>();
		this.headerMove = null;
		this.modifier = new haxe.ds.IntMap<java.lang.String>();
		this.mods = new haxe.root.Array<coopy.HighlightPatchUnit>();
		this.cmods = new haxe.root.Array<coopy.HighlightPatchUnit>();
		this.csv = new coopy.Csv(haxe.lang.Runtime.toString(null));
		this.rcOffset = 0;
		this.currentRow = -1;
		this.rowInfo = new coopy.CellInfo();
		this.cellInfo = new coopy.CellInfo();
		this.sourceInPatchCol = this.patchInSourceCol = null;
		this.patchInSourceRow = new haxe.ds.IntMap<java.lang.Object>();
		this.indexes = null;
		this.lastSourceRow = -1;
		this.actions = new haxe.root.Array<java.lang.String>();
		this.rowPermutation = null;
		this.rowPermutationRev = null;
		this.colPermutation = null;
		this.colPermutationRev = null;
		this.haveDroppedColumns = false;
	}
	
	
	public   boolean apply()
	{
		this.reset();
		if (( this.patch.get_width() < 2 )) 
		{
			return true;
		}
		
		if (( this.patch.get_height() < 1 )) 
		{
			return true;
		}
		
		this.payloadCol = ( 1 + this.rcOffset );
		this.payloadTop = this.patch.get_width();
		java.lang.String corner = this.patch.getCellView().toString(this.patch.getCell(0, 0));
		if (haxe.lang.Runtime.valEq(corner, "@:@")) 
		{
			this.rcOffset = 1;
		}
		 else 
		{
			this.rcOffset = 0;
		}
		
		{
			int _g1 = 0;
			int _g = this.patch.get_height();
			while (( _g1 < _g ))
			{
				int r = _g1++;
				java.lang.String str = this.view.toString(this.patch.getCell(this.rcOffset, r));
				this.actions.push(( (( str != null )) ? (str) : ("") ));
			}
			
		}
		
		{
			int _g11 = 0;
			int _g2 = this.patch.get_height();
			while (( _g11 < _g2 ))
			{
				int r1 = _g11++;
				this.applyRow(r1);
			}
			
		}
		
		this.finishRows();
		this.finishColumns();
		return true;
	}
	
	
	public   void needSourceColumns()
	{
		if (( this.sourceInPatchCol != null )) 
		{
			return ;
		}
		
		this.sourceInPatchCol = new haxe.ds.IntMap<java.lang.Object>();
		this.patchInSourceCol = new haxe.ds.IntMap<java.lang.Object>();
		coopy.View av = this.source.getCellView();
		{
			int _g1 = 0;
			int _g = this.source.get_width();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				java.lang.String name = av.toString(this.source.getCell(i, 0));
				java.lang.Object at = this.headerPre.get(name);
				if (( at == null )) 
				{
					continue;
				}
				
				this.sourceInPatchCol.set(i, at);
				this.patchInSourceCol.set(((int) (haxe.lang.Runtime.toInt(at)) ), i);
			}
			
		}
		
	}
	
	
	public   void needSourceIndex()
	{
		if (( this.indexes != null )) 
		{
			return ;
		}
		
		coopy.TableComparisonState state = new coopy.TableComparisonState();
		state.a = this.source;
		state.b = this.source;
		coopy.CompareTable comp = new coopy.CompareTable(((coopy.TableComparisonState) (state) ));
		comp.storeIndexes();
		comp.run();
		comp.align();
		this.indexes = comp.getIndexes();
		this.needSourceColumns();
	}
	
	
	public   void applyRow(int r)
	{
		this.currentRow = r;
		java.lang.String code = this.actions.__get(r);
		if (( ( r == 0 ) && ( this.rcOffset > 0 ) )) 
		{
			{
			}
			
		}
		 else 
		{
			if (haxe.lang.Runtime.valEq(code, "@@")) 
			{
				this.applyHeader();
				this.applyAction("@@");
			}
			 else 
			{
				if (haxe.lang.Runtime.valEq(code, "!")) 
				{
					this.applyMeta();
				}
				 else 
				{
					if (haxe.lang.Runtime.valEq(code, "+++")) 
					{
						this.applyAction(code);
					}
					 else 
					{
						if (haxe.lang.Runtime.valEq(code, "---")) 
						{
							this.applyAction(code);
						}
						 else 
						{
							if (( haxe.lang.Runtime.valEq(code, "+") || haxe.lang.Runtime.valEq(code, ":") )) 
							{
								this.applyAction(code);
							}
							 else 
							{
								if (( haxe.lang.StringExt.indexOf(code, "->", null) >= 0 )) 
								{
									this.applyAction("->");
								}
								 else 
								{
									this.lastSourceRow = -1;
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
	}
	
	
	public   java.lang.Object getDatum(int c)
	{
		return this.patch.getCell(c, this.currentRow);
	}
	
	
	public   java.lang.String getString(int c)
	{
		return this.view.toString(this.getDatum(c));
	}
	
	
	public   void applyMeta()
	{
		int _g1 = this.payloadCol;
		int _g = this.payloadTop;
		while (( _g1 < _g ))
		{
			int i = _g1++;
			java.lang.String name = this.getString(i);
			if (haxe.lang.Runtime.valEq(name, "")) 
			{
				continue;
			}
			
			this.modifier.set(i, name);
		}
		
	}
	
	
	public   void applyHeader()
	{
		{
			int _g1 = this.payloadCol;
			int _g = this.payloadTop;
			while (( _g1 < _g ))
			{
				int i = _g1++;
				java.lang.String name = this.getString(i);
				if (haxe.lang.Runtime.valEq(name, "...")) 
				{
					this.modifier.set(i, "...");
					this.haveDroppedColumns = true;
					continue;
				}
				
				java.lang.String mod = this.modifier.get(((int) (i) ));
				boolean move = false;
				if (( mod != null )) 
				{
					if (haxe.lang.Runtime.eq(haxe.lang.StringExt.charCodeAt(mod, 0), 58)) 
					{
						move = true;
						mod = haxe.lang.StringExt.substr(mod, 1, mod.length());
					}
					
				}
				
				this.header.set(i, name);
				if (( mod != null )) 
				{
					if (haxe.lang.Runtime.eq(haxe.lang.StringExt.charCodeAt(mod, 0), 40)) 
					{
						java.lang.String prev_name = haxe.lang.StringExt.substr(mod, 1, ( mod.length() - 2 ));
						this.headerPre.set(prev_name, i);
						this.headerPost.set(name, i);
						this.headerRename.set(prev_name, name);
						continue;
					}
					
				}
				
				if ( ! (haxe.lang.Runtime.valEq(mod, "+++")) ) 
				{
					this.headerPre.set(name, i);
				}
				
				if ( ! (haxe.lang.Runtime.valEq(mod, "---")) ) 
				{
					this.headerPost.set(name, i);
				}
				
				if (move) 
				{
					if (( this.headerMove == null )) 
					{
						this.headerMove = new haxe.ds.StringMap<java.lang.Object>();
					}
					
					this.headerMove.set(name, 1);
				}
				
			}
			
		}
		
		if (( this.source.get_height() == 0 )) 
		{
			this.applyAction("+++");
		}
		
	}
	
	
	public   int lookUp(java.lang.Object del)
	{
		int __temp_del22 = ( (( del == null )) ? (((int) (0) )) : (((int) (haxe.lang.Runtime.toInt(del)) )) );
		java.lang.Object at = this.patchInSourceRow.get(((int) (( this.currentRow + __temp_del22 )) ));
		if (( ! (( at == null )) )) 
		{
			return ((int) (haxe.lang.Runtime.toInt(at)) );
		}
		
		int result = -1;
		this.currentRow += __temp_del22;
		if (( ( this.currentRow >= 0 ) && ( this.currentRow < this.patch.get_height() ) )) 
		{
			int _g = 0;
			haxe.root.Array<coopy.IndexPair> _g1 = this.indexes;
			while (( _g < _g1.length ))
			{
				coopy.IndexPair idx = _g1.__get(_g);
				 ++ _g;
				coopy.CrossMatch match = idx.queryByContent(this);
				if (( match.spot_a != 1 )) 
				{
					continue;
				}
				
				result = ((int) (haxe.lang.Runtime.toInt(match.item_a.lst.__get(0))) );
				break;
			}
			
		}
		
		{
			this.patchInSourceRow.set(this.currentRow, result);
			int __temp_expr170 = result;
		}
		
		this.currentRow -= __temp_del22;
		return result;
	}
	
	
	public   void applyAction(java.lang.String code)
	{
		coopy.HighlightPatchUnit mod = new coopy.HighlightPatchUnit();
		mod.code = code;
		mod.add = haxe.lang.Runtime.valEq(code, "+++");
		mod.rem = haxe.lang.Runtime.valEq(code, "---");
		mod.update = haxe.lang.Runtime.valEq(code, "->");
		this.needSourceIndex();
		if (( this.lastSourceRow == -1 )) 
		{
			this.lastSourceRow = this.lookUp(-1);
		}
		
		mod.sourcePrevRow = this.lastSourceRow;
		java.lang.String nextAct = this.actions.__get(( this.currentRow + 1 ));
		if ((  ! (haxe.lang.Runtime.valEq(nextAct, "+++"))  &&  ! (haxe.lang.Runtime.valEq(nextAct, "..."))  )) 
		{
			mod.sourceNextRow = this.lookUp(1);
		}
		
		if (mod.add) 
		{
			if ( ! (haxe.lang.Runtime.valEq(this.actions.__get(( this.currentRow - 1 )), "+++")) ) 
			{
				mod.sourcePrevRow = this.lookUp(-1);
			}
			
			mod.sourceRow = mod.sourcePrevRow;
			if (( mod.sourceRow != -1 )) 
			{
				mod.sourceRowOffset = 1;
			}
			
		}
		 else 
		{
			mod.sourceRow = this.lastSourceRow = this.lookUp(null);
		}
		
		if (haxe.lang.Runtime.valEq(this.actions.__get(( this.currentRow + 1 )), "")) 
		{
			this.lastSourceRow = mod.sourceNextRow;
		}
		
		mod.patchRow = this.currentRow;
		if (haxe.lang.Runtime.valEq(code, "@@")) 
		{
			mod.sourceRow = 0;
		}
		
		this.mods.push(mod);
	}
	
	
	public   void checkAct()
	{
		java.lang.String act = this.getString(this.rcOffset);
		if ( ! (haxe.lang.Runtime.valEq(this.rowInfo.value, act)) ) 
		{
			coopy.DiffRender.examineCell(0, 0, this.view, act, "", act, "", this.rowInfo, null);
		}
		
	}
	
	
	public   java.lang.String getPreString(java.lang.String txt)
	{
		this.checkAct();
		if ( ! (this.rowInfo.updated) ) 
		{
			return txt;
		}
		
		coopy.DiffRender.examineCell(0, 0, this.view, txt, "", this.rowInfo.value, "", this.cellInfo, null);
		if ( ! (this.cellInfo.updated) ) 
		{
			return txt;
		}
		
		return this.cellInfo.lvalue;
	}
	
	
	public   java.lang.String getRowString(int c)
	{
		java.lang.Object at = this.sourceInPatchCol.get(((int) (c) ));
		if (( at == null )) 
		{
			return "NOT_FOUND";
		}
		
		return this.getPreString(this.getString(((int) (haxe.lang.Runtime.toInt(at)) )));
	}
	
	
	public   int sortMods(coopy.HighlightPatchUnit a, coopy.HighlightPatchUnit b)
	{
		if (( haxe.lang.Runtime.valEq(b.code, "@@") &&  ! (haxe.lang.Runtime.valEq(a.code, "@@"))  )) 
		{
			return 1;
		}
		
		if (( haxe.lang.Runtime.valEq(a.code, "@@") &&  ! (haxe.lang.Runtime.valEq(b.code, "@@"))  )) 
		{
			return -1;
		}
		
		if (( ( ( a.sourceRow == -1 ) &&  ! (a.add)  ) && ( b.sourceRow != -1 ) )) 
		{
			return 1;
		}
		
		if (( ( ( a.sourceRow != -1 ) &&  ! (b.add)  ) && ( b.sourceRow == -1 ) )) 
		{
			return -1;
		}
		
		if (( ( a.sourceRow + a.sourceRowOffset ) > ( b.sourceRow + b.sourceRowOffset ) )) 
		{
			return 1;
		}
		
		if (( ( a.sourceRow + a.sourceRowOffset ) < ( b.sourceRow + b.sourceRowOffset ) )) 
		{
			return -1;
		}
		
		if (( a.patchRow > b.patchRow )) 
		{
			return 1;
		}
		
		if (( a.patchRow < b.patchRow )) 
		{
			return -1;
		}
		
		return 0;
	}
	
	
	public   int processMods(haxe.root.Array<coopy.HighlightPatchUnit> rmods, haxe.root.Array<java.lang.Object> fate, int len)
	{
		rmods.sort(((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("sortMods"))) ));
		int offset = 0;
		int last = -1;
		int target = 0;
		if (( rmods.length > 0 )) 
		{
			if (( rmods.__get(0).sourcePrevRow == -1 )) 
			{
				last = 0;
			}
			
		}
		
		{
			int _g = 0;
			while (( _g < rmods.length ))
			{
				coopy.HighlightPatchUnit mod = rmods.__get(_g);
				 ++ _g;
				if (( last != -1 )) 
				{
					int _g2 = last;
					int _g1 = ( mod.sourceRow + mod.sourceRowOffset );
					while (( _g2 < _g1 ))
					{
						int i = _g2++;
						fate.push(( i + offset ));
						target++;
						last++;
					}
					
				}
				
				if (mod.rem) 
				{
					fate.push(-1);
					offset--;
				}
				 else 
				{
					if (mod.add) 
					{
						mod.destRow = target;
						target++;
						offset++;
					}
					 else 
					{
						mod.destRow = target;
					}
					
				}
				
				if (( mod.sourceRow >= 0 )) 
				{
					last = ( mod.sourceRow + mod.sourceRowOffset );
					if (mod.rem) 
					{
						last++;
					}
					
				}
				 else 
				{
					last = -1;
				}
				
			}
			
		}
		
		if (( last != -1 )) 
		{
			int _g3 = last;
			while (( _g3 < len ))
			{
				int i1 = _g3++;
				fate.push(( i1 + offset ));
				target++;
				last++;
			}
			
		}
		
		return ( len + offset );
	}
	
	
	public   void computeOrdering(haxe.root.Array<coopy.HighlightPatchUnit> mods, haxe.root.Array<java.lang.Object> permutation, haxe.root.Array<java.lang.Object> permutationRev, int dim)
	{
		haxe.ds.IntMap<java.lang.Object> to_unit = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> from_unit = new haxe.ds.IntMap<java.lang.Object>();
		haxe.ds.IntMap<java.lang.Object> meta_from_unit = new haxe.ds.IntMap<java.lang.Object>();
		int ct = 0;
		{
			int _g = 0;
			while (( _g < mods.length ))
			{
				coopy.HighlightPatchUnit mod = mods.__get(_g);
				 ++ _g;
				if (( mod.add || mod.rem )) 
				{
					continue;
				}
				
				if (( mod.sourceRow < 0 )) 
				{
					continue;
				}
				
				if (( mod.sourcePrevRow >= 0 )) 
				{
					{
						int v = mod.sourceRow;
						to_unit.set(mod.sourcePrevRow, v);
						int __temp_expr171 = v;
					}
					
					{
						int v1 = mod.sourcePrevRow;
						from_unit.set(mod.sourceRow, v1);
						int __temp_expr172 = v1;
					}
					
					if (( ( mod.sourcePrevRow + 1 ) != mod.sourceRow )) 
					{
						ct++;
					}
					
				}
				
				if (( mod.sourceNextRow >= 0 )) 
				{
					{
						int v2 = mod.sourceNextRow;
						to_unit.set(mod.sourceRow, v2);
						int __temp_expr173 = v2;
					}
					
					{
						int v3 = mod.sourceRow;
						from_unit.set(mod.sourceNextRow, v3);
						int __temp_expr174 = v3;
					}
					
					if (( ( mod.sourceRow + 1 ) != mod.sourceNextRow )) 
					{
						ct++;
					}
					
				}
				
			}
			
		}
		
		if (( ct > 0 )) 
		{
			java.lang.Object cursor = null;
			java.lang.Object logical = null;
			haxe.root.Array<java.lang.Object> starts = new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{});
			{
				int _g1 = 0;
				while (( _g1 < dim ))
				{
					int i = _g1++;
					java.lang.Object u = from_unit.get(((int) (i) ));
					if (( ! (( u == null )) )) 
					{
						meta_from_unit.set(((int) (haxe.lang.Runtime.toInt(u)) ), i);
						int __temp_expr175 = i;
					}
					 else 
					{
						starts.push(i);
					}
					
				}
				
			}
			
			haxe.ds.IntMap<java.lang.Object> used = new haxe.ds.IntMap<java.lang.Object>();
			int len = 0;
			{
				int _g2 = 0;
				while (( _g2 < dim ))
				{
					int i1 = _g2++;
					if (meta_from_unit.exists(((int) (haxe.lang.Runtime.toInt(logical)) ))) 
					{
						cursor = meta_from_unit.get(((int) (haxe.lang.Runtime.toInt(logical)) ));
					}
					 else 
					{
						cursor = null;
					}
					
					if (( cursor == null )) 
					{
						int v4 = ((int) (haxe.lang.Runtime.toInt(starts.shift())) );
						cursor = v4;
						logical = v4;
					}
					
					if (( cursor == null )) 
					{
						cursor = 0;
					}
					
					while (used.exists(((int) (haxe.lang.Runtime.toInt(cursor)) )))
					{
						cursor = ( (((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.plus(cursor, 1))) )) % dim );
					}
					
					logical = cursor;
					permutationRev.push(cursor);
					{
						used.set(((int) (haxe.lang.Runtime.toInt(cursor)) ), 1);
						int __temp_expr176 = 1;
					}
					
				}
				
			}
			
			{
				int _g11 = 0;
				int _g3 = permutationRev.length;
				while (( _g11 < _g3 ))
				{
					int i2 = _g11++;
					permutation.__set(i2, -1);
				}
				
			}
			
			{
				int _g12 = 0;
				int _g4 = permutation.length;
				while (( _g12 < _g4 ))
				{
					int i3 = _g12++;
					permutation.__set(((int) (haxe.lang.Runtime.toInt(permutationRev.__get(i3))) ), i3);
				}
				
			}
			
		}
		
	}
	
	
	public   void permuteRows()
	{
		this.rowPermutation = new haxe.root.Array<java.lang.Object>();
		this.rowPermutationRev = new haxe.root.Array<java.lang.Object>();
		this.computeOrdering(this.mods, this.rowPermutation, this.rowPermutationRev, this.source.get_height());
	}
	
	
	public   void finishRows()
	{
		haxe.root.Array<java.lang.Object> fate = new haxe.root.Array<java.lang.Object>();
		this.permuteRows();
		if (( this.rowPermutation.length > 0 )) 
		{
			int _g = 0;
			haxe.root.Array<coopy.HighlightPatchUnit> _g1 = this.mods;
			while (( _g < _g1.length ))
			{
				coopy.HighlightPatchUnit mod = _g1.__get(_g);
				 ++ _g;
				if (( mod.sourceRow >= 0 )) 
				{
					mod.sourceRow = ((int) (haxe.lang.Runtime.toInt(this.rowPermutation.__get(mod.sourceRow))) );
				}
				
			}
			
		}
		
		if (( this.rowPermutation.length > 0 )) 
		{
			this.source.insertOrDeleteRows(this.rowPermutation, this.rowPermutation.length);
		}
		
		int len = this.processMods(this.mods, fate, this.source.get_height());
		this.source.insertOrDeleteRows(fate, len);
		{
			int _g2 = 0;
			haxe.root.Array<coopy.HighlightPatchUnit> _g11 = this.mods;
			while (( _g2 < _g11.length ))
			{
				coopy.HighlightPatchUnit mod1 = _g11.__get(_g2);
				 ++ _g2;
				if ( ! (mod1.rem) ) 
				{
					if (mod1.add) 
					{
						{
							java.lang.Object __temp_iterator87 = this.headerPost.iterator();
							while (haxe.lang.Runtime.toBool(haxe.lang.Runtime.callField(__temp_iterator87, "hasNext", null)))
							{
								int c = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.callField(__temp_iterator87, "next", null))) );
								java.lang.Object offset = this.patchInSourceCol.get(((int) (c) ));
								if (( ( ! (( offset == null )) ) && ( haxe.lang.Runtime.compare(offset, 0) >= 0 ) )) 
								{
									this.source.setCell(((int) (haxe.lang.Runtime.toInt(offset)) ), mod1.destRow, this.patch.getCell(c, mod1.patchRow));
								}
								
							}
							
						}
						
					}
					 else 
					{
						if (mod1.update) 
						{
							this.currentRow = mod1.patchRow;
							this.checkAct();
							if ( ! (this.rowInfo.updated) ) 
							{
								continue;
							}
							
							{
								java.lang.Object __temp_iterator88 = this.headerPre.iterator();
								while (haxe.lang.Runtime.toBool(haxe.lang.Runtime.callField(__temp_iterator88, "hasNext", null)))
								{
									int c1 = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.callField(__temp_iterator88, "next", null))) );
									java.lang.String txt = this.view.toString(this.patch.getCell(c1, mod1.patchRow));
									coopy.DiffRender.examineCell(0, 0, this.view, txt, "", this.rowInfo.value, "", this.cellInfo, null);
									if ( ! (this.cellInfo.updated) ) 
									{
										continue;
									}
									
									if (this.cellInfo.conflicted) 
									{
										continue;
									}
									
									java.lang.Object d = this.view.toDatum(this.csv.parseCell(this.cellInfo.rvalue));
									this.source.setCell(((int) (haxe.lang.Runtime.toInt(this.patchInSourceCol.get(((int) (c1) )))) ), mod1.destRow, d);
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
	}
	
	
	public   void permuteColumns()
	{
		if (( this.headerMove == null )) 
		{
			return ;
		}
		
		this.colPermutation = new haxe.root.Array<java.lang.Object>();
		this.colPermutationRev = new haxe.root.Array<java.lang.Object>();
		this.computeOrdering(this.cmods, this.colPermutation, this.colPermutationRev, this.source.get_width());
		if (( this.colPermutation.length == 0 )) 
		{
			return ;
		}
		
	}
	
	
	public   void finishColumns()
	{
		this.needSourceColumns();
		{
			int _g1 = this.payloadCol;
			int _g = this.payloadTop;
			while (( _g1 < _g ))
			{
				int i = _g1++;
				java.lang.String act = this.modifier.get(((int) (i) ));
				java.lang.String hdr = this.header.get(((int) (i) ));
				if (( act == null )) 
				{
					act = "";
				}
				
				if (haxe.lang.Runtime.valEq(act, "---")) 
				{
					int at = ((int) (haxe.lang.Runtime.toInt(this.patchInSourceCol.get(((int) (i) )))) );
					coopy.HighlightPatchUnit mod = new coopy.HighlightPatchUnit();
					mod.code = act;
					mod.rem = true;
					mod.sourceRow = at;
					mod.patchRow = i;
					this.cmods.push(mod);
				}
				 else 
				{
					if (haxe.lang.Runtime.valEq(act, "+++")) 
					{
						coopy.HighlightPatchUnit mod1 = new coopy.HighlightPatchUnit();
						mod1.code = act;
						mod1.add = true;
						int prev = -1;
						boolean cont = false;
						mod1.sourceRow = -1;
						if (( this.cmods.length > 0 )) 
						{
							mod1.sourceRow = this.cmods.__get(( this.cmods.length - 1 )).sourceRow;
						}
						
						if (( mod1.sourceRow != -1 )) 
						{
							mod1.sourceRowOffset = 1;
						}
						
						mod1.patchRow = i;
						this.cmods.push(mod1);
					}
					 else 
					{
						if ( ! (haxe.lang.Runtime.valEq(act, "...")) ) 
						{
							coopy.HighlightPatchUnit mod2 = new coopy.HighlightPatchUnit();
							mod2.code = act;
							mod2.patchRow = i;
							mod2.sourceRow = ((int) (haxe.lang.Runtime.toInt(this.patchInSourceCol.get(((int) (i) )))) );
							this.cmods.push(mod2);
						}
						
					}
					
				}
				
			}
			
		}
		
		int at1 = -1;
		int rat = -1;
		{
			int _g11 = 0;
			int _g2 = ( this.cmods.length - 1 );
			while (( _g11 < _g2 ))
			{
				int i1 = _g11++;
				java.lang.String icode = this.cmods.__get(i1).code;
				if ((  ! (haxe.lang.Runtime.valEq(icode, "+++"))  &&  ! (haxe.lang.Runtime.valEq(icode, "---"))  )) 
				{
					at1 = this.cmods.__get(i1).sourceRow;
				}
				
				this.cmods.__get(( i1 + 1 )).sourcePrevRow = at1;
				int j = ( ( this.cmods.length - 1 ) - i1 );
				java.lang.String jcode = this.cmods.__get(j).code;
				if ((  ! (haxe.lang.Runtime.valEq(jcode, "+++"))  &&  ! (haxe.lang.Runtime.valEq(jcode, "---"))  )) 
				{
					rat = this.cmods.__get(j).sourceRow;
				}
				
				this.cmods.__get(( j - 1 )).sourceNextRow = rat;
			}
			
		}
		
		haxe.root.Array<java.lang.Object> fate = new haxe.root.Array<java.lang.Object>();
		this.permuteColumns();
		if (( this.headerMove != null )) 
		{
			if (( this.colPermutation.length > 0 )) 
			{
				{
					int _g3 = 0;
					haxe.root.Array<coopy.HighlightPatchUnit> _g12 = this.cmods;
					while (( _g3 < _g12.length ))
					{
						coopy.HighlightPatchUnit mod3 = _g12.__get(_g3);
						 ++ _g3;
						if (( mod3.sourceRow >= 0 )) 
						{
							mod3.sourceRow = ((int) (haxe.lang.Runtime.toInt(this.colPermutation.__get(mod3.sourceRow))) );
						}
						
					}
					
				}
				
				this.source.insertOrDeleteColumns(this.colPermutation, this.colPermutation.length);
			}
			
		}
		
		int len = this.processMods(this.cmods, fate, this.source.get_width());
		this.source.insertOrDeleteColumns(fate, len);
		{
			int _g4 = 0;
			haxe.root.Array<coopy.HighlightPatchUnit> _g13 = this.cmods;
			while (( _g4 < _g13.length ))
			{
				coopy.HighlightPatchUnit cmod = _g13.__get(_g4);
				 ++ _g4;
				if ( ! (cmod.rem) ) 
				{
					if (cmod.add) 
					{
						{
							int _g21 = 0;
							haxe.root.Array<coopy.HighlightPatchUnit> _g31 = this.mods;
							while (( _g21 < _g31.length ))
							{
								coopy.HighlightPatchUnit mod4 = _g31.__get(_g21);
								 ++ _g21;
								if (( ( mod4.patchRow != -1 ) && ( mod4.destRow != -1 ) )) 
								{
									java.lang.Object d = this.patch.getCell(cmod.patchRow, mod4.patchRow);
									this.source.setCell(cmod.destRow, mod4.destRow, d);
								}
								
							}
							
						}
						
						java.lang.String hdr1 = this.header.get(((int) (cmod.patchRow) ));
						this.source.setCell(cmod.destRow, 0, this.view.toDatum(hdr1));
					}
					
				}
				
			}
			
		}
		
		{
			int _g14 = 0;
			int _g5 = this.source.get_width();
			while (( _g14 < _g5 ))
			{
				int i2 = _g14++;
				java.lang.String name = this.view.toString(this.source.getCell(i2, 0));
				java.lang.String next_name = this.headerRename.get(name);
				if (( next_name == null )) 
				{
					continue;
				}
				
				this.source.setCell(i2, 0, this.view.toDatum(next_name));
			}
			
		}
		
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef177 = true;
			switch (field.hashCode())
			{
				case 802174409:
				{
					if (field.equals("lastSourceRow")) 
					{
						__temp_executeDef177 = false;
						this.lastSourceRow = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1088985695:
				{
					if (field.equals("currentRow")) 
					{
						__temp_executeDef177 = false;
						this.currentRow = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1139488292:
				{
					if (field.equals("rcOffset")) 
					{
						__temp_executeDef177 = false;
						this.rcOffset = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 999167250:
				{
					if (field.equals("payloadCol")) 
					{
						__temp_executeDef177 = false;
						this.payloadCol = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 999183591:
				{
					if (field.equals("payloadTop")) 
					{
						__temp_executeDef177 = false;
						this.payloadTop = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef177) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef178 = true;
			switch (field.hashCode())
			{
				case 380667781:
				{
					if (field.equals("haveDroppedColumns")) 
					{
						__temp_executeDef178 = false;
						this.haveDroppedColumns = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case -896505829:
				{
					if (field.equals("source")) 
					{
						__temp_executeDef178 = false;
						this.source = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1286691229:
				{
					if (field.equals("colPermutationRev")) 
					{
						__temp_executeDef178 = false;
						this.colPermutationRev = ((haxe.root.Array<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 106438728:
				{
					if (field.equals("patch")) 
					{
						__temp_executeDef178 = false;
						this.patch = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 621415718:
				{
					if (field.equals("colPermutation")) 
					{
						__temp_executeDef178 = false;
						this.colPermutation = ((haxe.root.Array<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3619493:
				{
					if (field.equals("view")) 
					{
						__temp_executeDef178 = false;
						this.view = ((coopy.View) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -485299081:
				{
					if (field.equals("rowPermutationRev")) 
					{
						__temp_executeDef178 = false;
						this.rowPermutationRev = ((haxe.root.Array<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1111387808:
				{
					if (field.equals("sourceView")) 
					{
						__temp_executeDef178 = false;
						this.sourceView = ((coopy.View) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1247086452:
				{
					if (field.equals("rowPermutation")) 
					{
						__temp_executeDef178 = false;
						this.rowPermutation = ((haxe.root.Array<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 98822:
				{
					if (field.equals("csv")) 
					{
						__temp_executeDef178 = false;
						this.csv = ((coopy.Csv) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1161803523:
				{
					if (field.equals("actions")) 
					{
						__temp_executeDef178 = false;
						this.actions = ((haxe.root.Array<java.lang.String>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1221270899:
				{
					if (field.equals("header")) 
					{
						__temp_executeDef178 = false;
						this.header = ((haxe.ds.IntMap<java.lang.String>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 802174409:
				{
					if (field.equals("lastSourceRow")) 
					{
						__temp_executeDef178 = false;
						this.lastSourceRow = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case -213307178:
				{
					if (field.equals("headerPre")) 
					{
						__temp_executeDef178 = false;
						this.headerPre = ((haxe.ds.StringMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -263833934:
				{
					if (field.equals("patchInSourceRow")) 
					{
						__temp_executeDef178 = false;
						this.patchInSourceRow = ((haxe.ds.IntMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1977409741:
				{
					if (field.equals("headerPost")) 
					{
						__temp_executeDef178 = false;
						this.headerPost = ((haxe.ds.StringMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -263848360:
				{
					if (field.equals("patchInSourceCol")) 
					{
						__temp_executeDef178 = false;
						this.patchInSourceCol = ((haxe.ds.IntMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1963075627:
				{
					if (field.equals("headerRename")) 
					{
						__temp_executeDef178 = false;
						this.headerRename = ((haxe.ds.StringMap<java.lang.String>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 517357272:
				{
					if (field.equals("sourceInPatchCol")) 
					{
						__temp_executeDef178 = false;
						this.sourceInPatchCol = ((haxe.ds.IntMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1977320446:
				{
					if (field.equals("headerMove")) 
					{
						__temp_executeDef178 = false;
						this.headerMove = ((haxe.ds.StringMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1943292160:
				{
					if (field.equals("indexes")) 
					{
						__temp_executeDef178 = false;
						this.indexes = ((haxe.root.Array<coopy.IndexPair>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -615513385:
				{
					if (field.equals("modifier")) 
					{
						__temp_executeDef178 = false;
						this.modifier = ((haxe.ds.IntMap<java.lang.String>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 1139488292:
				{
					if (field.equals("rcOffset")) 
					{
						__temp_executeDef178 = false;
						this.rcOffset = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case -1088985695:
				{
					if (field.equals("currentRow")) 
					{
						__temp_executeDef178 = false;
						this.currentRow = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case -917905104:
				{
					if (field.equals("cellInfo")) 
					{
						__temp_executeDef178 = false;
						this.cellInfo = ((coopy.CellInfo) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 999167250:
				{
					if (field.equals("payloadCol")) 
					{
						__temp_executeDef178 = false;
						this.payloadCol = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 1386223016:
				{
					if (field.equals("rowInfo")) 
					{
						__temp_executeDef178 = false;
						this.rowInfo = ((coopy.CellInfo) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 999183591:
				{
					if (field.equals("payloadTop")) 
					{
						__temp_executeDef178 = false;
						this.payloadTop = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case 94785684:
				{
					if (field.equals("cmods")) 
					{
						__temp_executeDef178 = false;
						this.cmods = ((haxe.root.Array<coopy.HighlightPatchUnit>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 3357105:
				{
					if (field.equals("mods")) 
					{
						__temp_executeDef178 = false;
						this.mods = ((haxe.root.Array<coopy.HighlightPatchUnit>) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef178) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef179 = true;
			switch (field.hashCode())
			{
				case -964565046:
				{
					if (field.equals("finishColumns")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("finishColumns"))) );
					}
					
					break;
				}
				
				
				case -896505829:
				{
					if (field.equals("source")) 
					{
						__temp_executeDef179 = false;
						return this.source;
					}
					
					break;
				}
				
				
				case 695429703:
				{
					if (field.equals("permuteColumns")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("permuteColumns"))) );
					}
					
					break;
				}
				
				
				case 106438728:
				{
					if (field.equals("patch")) 
					{
						__temp_executeDef179 = false;
						return this.patch;
					}
					
					break;
				}
				
				
				case 1151467788:
				{
					if (field.equals("finishRows")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("finishRows"))) );
					}
					
					break;
				}
				
				
				case 3619493:
				{
					if (field.equals("view")) 
					{
						__temp_executeDef179 = false;
						return this.view;
					}
					
					break;
				}
				
				
				case -1086138449:
				{
					if (field.equals("permuteRows")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("permuteRows"))) );
					}
					
					break;
				}
				
				
				case -1111387808:
				{
					if (field.equals("sourceView")) 
					{
						__temp_executeDef179 = false;
						return this.sourceView;
					}
					
					break;
				}
				
				
				case 616557355:
				{
					if (field.equals("computeOrdering")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("computeOrdering"))) );
					}
					
					break;
				}
				
				
				case 98822:
				{
					if (field.equals("csv")) 
					{
						__temp_executeDef179 = false;
						return this.csv;
					}
					
					break;
				}
				
				
				case 202308800:
				{
					if (field.equals("processMods")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("processMods"))) );
					}
					
					break;
				}
				
				
				case -1221270899:
				{
					if (field.equals("header")) 
					{
						__temp_executeDef179 = false;
						return this.header;
					}
					
					break;
				}
				
				
				case 1661641839:
				{
					if (field.equals("sortMods")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("sortMods"))) );
					}
					
					break;
				}
				
				
				case -213307178:
				{
					if (field.equals("headerPre")) 
					{
						__temp_executeDef179 = false;
						return this.headerPre;
					}
					
					break;
				}
				
				
				case 1003039701:
				{
					if (field.equals("getRowString")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getRowString"))) );
					}
					
					break;
				}
				
				
				case 1977409741:
				{
					if (field.equals("headerPost")) 
					{
						__temp_executeDef179 = false;
						return this.headerPost;
					}
					
					break;
				}
				
				
				case -1833719330:
				{
					if (field.equals("getPreString")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getPreString"))) );
					}
					
					break;
				}
				
				
				case 1963075627:
				{
					if (field.equals("headerRename")) 
					{
						__temp_executeDef179 = false;
						return this.headerRename;
					}
					
					break;
				}
				
				
				case 1536859754:
				{
					if (field.equals("checkAct")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("checkAct"))) );
					}
					
					break;
				}
				
				
				case 1977320446:
				{
					if (field.equals("headerMove")) 
					{
						__temp_executeDef179 = false;
						return this.headerMove;
					}
					
					break;
				}
				
				
				case 1897866052:
				{
					if (field.equals("applyAction")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("applyAction"))) );
					}
					
					break;
				}
				
				
				case -615513385:
				{
					if (field.equals("modifier")) 
					{
						__temp_executeDef179 = false;
						return this.modifier;
					}
					
					break;
				}
				
				
				case -1097095782:
				{
					if (field.equals("lookUp")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("lookUp"))) );
					}
					
					break;
				}
				
				
				case -1088985695:
				{
					if (field.equals("currentRow")) 
					{
						__temp_executeDef179 = false;
						return this.currentRow;
					}
					
					break;
				}
				
				
				case 2099546011:
				{
					if (field.equals("applyHeader")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("applyHeader"))) );
					}
					
					break;
				}
				
				
				case 999167250:
				{
					if (field.equals("payloadCol")) 
					{
						__temp_executeDef179 = false;
						return this.payloadCol;
					}
					
					break;
				}
				
				
				case -2075875693:
				{
					if (field.equals("applyMeta")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("applyMeta"))) );
					}
					
					break;
				}
				
				
				case 999183591:
				{
					if (field.equals("payloadTop")) 
					{
						__temp_executeDef179 = false;
						return this.payloadTop;
					}
					
					break;
				}
				
				
				case 804029191:
				{
					if (field.equals("getString")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getString"))) );
					}
					
					break;
				}
				
				
				case 3357105:
				{
					if (field.equals("mods")) 
					{
						__temp_executeDef179 = false;
						return this.mods;
					}
					
					break;
				}
				
				
				case 1951182521:
				{
					if (field.equals("getDatum")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getDatum"))) );
					}
					
					break;
				}
				
				
				case 94785684:
				{
					if (field.equals("cmods")) 
					{
						__temp_executeDef179 = false;
						return this.cmods;
					}
					
					break;
				}
				
				
				case 1179967372:
				{
					if (field.equals("applyRow")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("applyRow"))) );
					}
					
					break;
				}
				
				
				case 1386223016:
				{
					if (field.equals("rowInfo")) 
					{
						__temp_executeDef179 = false;
						return this.rowInfo;
					}
					
					break;
				}
				
				
				case 822324993:
				{
					if (field.equals("needSourceIndex")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("needSourceIndex"))) );
					}
					
					break;
				}
				
				
				case -917905104:
				{
					if (field.equals("cellInfo")) 
					{
						__temp_executeDef179 = false;
						return this.cellInfo;
					}
					
					break;
				}
				
				
				case -1013232052:
				{
					if (field.equals("needSourceColumns")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("needSourceColumns"))) );
					}
					
					break;
				}
				
				
				case 1139488292:
				{
					if (field.equals("rcOffset")) 
					{
						__temp_executeDef179 = false;
						return this.rcOffset;
					}
					
					break;
				}
				
				
				case 93029230:
				{
					if (field.equals("apply")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("apply"))) );
					}
					
					break;
				}
				
				
				case 1943292160:
				{
					if (field.equals("indexes")) 
					{
						__temp_executeDef179 = false;
						return this.indexes;
					}
					
					break;
				}
				
				
				case 108404047:
				{
					if (field.equals("reset")) 
					{
						__temp_executeDef179 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("reset"))) );
					}
					
					break;
				}
				
				
				case 517357272:
				{
					if (field.equals("sourceInPatchCol")) 
					{
						__temp_executeDef179 = false;
						return this.sourceInPatchCol;
					}
					
					break;
				}
				
				
				case 380667781:
				{
					if (field.equals("haveDroppedColumns")) 
					{
						__temp_executeDef179 = false;
						return this.haveDroppedColumns;
					}
					
					break;
				}
				
				
				case -263848360:
				{
					if (field.equals("patchInSourceCol")) 
					{
						__temp_executeDef179 = false;
						return this.patchInSourceCol;
					}
					
					break;
				}
				
				
				case 1286691229:
				{
					if (field.equals("colPermutationRev")) 
					{
						__temp_executeDef179 = false;
						return this.colPermutationRev;
					}
					
					break;
				}
				
				
				case -263833934:
				{
					if (field.equals("patchInSourceRow")) 
					{
						__temp_executeDef179 = false;
						return this.patchInSourceRow;
					}
					
					break;
				}
				
				
				case 621415718:
				{
					if (field.equals("colPermutation")) 
					{
						__temp_executeDef179 = false;
						return this.colPermutation;
					}
					
					break;
				}
				
				
				case 802174409:
				{
					if (field.equals("lastSourceRow")) 
					{
						__temp_executeDef179 = false;
						return this.lastSourceRow;
					}
					
					break;
				}
				
				
				case -485299081:
				{
					if (field.equals("rowPermutationRev")) 
					{
						__temp_executeDef179 = false;
						return this.rowPermutationRev;
					}
					
					break;
				}
				
				
				case -1161803523:
				{
					if (field.equals("actions")) 
					{
						__temp_executeDef179 = false;
						return this.actions;
					}
					
					break;
				}
				
				
				case -1247086452:
				{
					if (field.equals("rowPermutation")) 
					{
						__temp_executeDef179 = false;
						return this.rowPermutation;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef179) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef180 = true;
			switch (field.hashCode())
			{
				case 802174409:
				{
					if (field.equals("lastSourceRow")) 
					{
						__temp_executeDef180 = false;
						return ((double) (this.lastSourceRow) );
					}
					
					break;
				}
				
				
				case -1088985695:
				{
					if (field.equals("currentRow")) 
					{
						__temp_executeDef180 = false;
						return ((double) (this.currentRow) );
					}
					
					break;
				}
				
				
				case 1139488292:
				{
					if (field.equals("rcOffset")) 
					{
						__temp_executeDef180 = false;
						return ((double) (this.rcOffset) );
					}
					
					break;
				}
				
				
				case 999167250:
				{
					if (field.equals("payloadCol")) 
					{
						__temp_executeDef180 = false;
						return ((double) (this.payloadCol) );
					}
					
					break;
				}
				
				
				case 999183591:
				{
					if (field.equals("payloadTop")) 
					{
						__temp_executeDef180 = false;
						return ((double) (this.payloadTop) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef180) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef181 = true;
			switch (field.hashCode())
			{
				case -964565046:
				{
					if (field.equals("finishColumns")) 
					{
						__temp_executeDef181 = false;
						this.finishColumns();
					}
					
					break;
				}
				
				
				case 108404047:
				{
					if (field.equals("reset")) 
					{
						__temp_executeDef181 = false;
						this.reset();
					}
					
					break;
				}
				
				
				case 695429703:
				{
					if (field.equals("permuteColumns")) 
					{
						__temp_executeDef181 = false;
						this.permuteColumns();
					}
					
					break;
				}
				
				
				case 93029230:
				{
					if (field.equals("apply")) 
					{
						__temp_executeDef181 = false;
						return this.apply();
					}
					
					break;
				}
				
				
				case 1151467788:
				{
					if (field.equals("finishRows")) 
					{
						__temp_executeDef181 = false;
						this.finishRows();
					}
					
					break;
				}
				
				
				case -1013232052:
				{
					if (field.equals("needSourceColumns")) 
					{
						__temp_executeDef181 = false;
						this.needSourceColumns();
					}
					
					break;
				}
				
				
				case -1086138449:
				{
					if (field.equals("permuteRows")) 
					{
						__temp_executeDef181 = false;
						this.permuteRows();
					}
					
					break;
				}
				
				
				case 822324993:
				{
					if (field.equals("needSourceIndex")) 
					{
						__temp_executeDef181 = false;
						this.needSourceIndex();
					}
					
					break;
				}
				
				
				case 616557355:
				{
					if (field.equals("computeOrdering")) 
					{
						__temp_executeDef181 = false;
						this.computeOrdering(((haxe.root.Array<coopy.HighlightPatchUnit>) (dynargs.__get(0)) ), ((haxe.root.Array<java.lang.Object>) (dynargs.__get(1)) ), ((haxe.root.Array<java.lang.Object>) (dynargs.__get(2)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(3))) ));
					}
					
					break;
				}
				
				
				case 1179967372:
				{
					if (field.equals("applyRow")) 
					{
						__temp_executeDef181 = false;
						this.applyRow(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case 202308800:
				{
					if (field.equals("processMods")) 
					{
						__temp_executeDef181 = false;
						return this.processMods(((haxe.root.Array<coopy.HighlightPatchUnit>) (dynargs.__get(0)) ), ((haxe.root.Array<java.lang.Object>) (dynargs.__get(1)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(2))) ));
					}
					
					break;
				}
				
				
				case 1951182521:
				{
					if (field.equals("getDatum")) 
					{
						__temp_executeDef181 = false;
						return this.getDatum(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case 1661641839:
				{
					if (field.equals("sortMods")) 
					{
						__temp_executeDef181 = false;
						return this.sortMods(((coopy.HighlightPatchUnit) (dynargs.__get(0)) ), ((coopy.HighlightPatchUnit) (dynargs.__get(1)) ));
					}
					
					break;
				}
				
				
				case 804029191:
				{
					if (field.equals("getString")) 
					{
						__temp_executeDef181 = false;
						return this.getString(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case 1003039701:
				{
					if (field.equals("getRowString")) 
					{
						__temp_executeDef181 = false;
						return this.getRowString(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
				case -2075875693:
				{
					if (field.equals("applyMeta")) 
					{
						__temp_executeDef181 = false;
						this.applyMeta();
					}
					
					break;
				}
				
				
				case -1833719330:
				{
					if (field.equals("getPreString")) 
					{
						__temp_executeDef181 = false;
						return this.getPreString(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case 2099546011:
				{
					if (field.equals("applyHeader")) 
					{
						__temp_executeDef181 = false;
						this.applyHeader();
					}
					
					break;
				}
				
				
				case 1536859754:
				{
					if (field.equals("checkAct")) 
					{
						__temp_executeDef181 = false;
						this.checkAct();
					}
					
					break;
				}
				
				
				case -1097095782:
				{
					if (field.equals("lookUp")) 
					{
						__temp_executeDef181 = false;
						return this.lookUp(dynargs.__get(0));
					}
					
					break;
				}
				
				
				case 1897866052:
				{
					if (field.equals("applyAction")) 
					{
						__temp_executeDef181 = false;
						this.applyAction(haxe.lang.Runtime.toString(dynargs.__get(0)));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef181) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("haveDroppedColumns");
		baseArr.push("colPermutationRev");
		baseArr.push("colPermutation");
		baseArr.push("rowPermutationRev");
		baseArr.push("rowPermutation");
		baseArr.push("actions");
		baseArr.push("lastSourceRow");
		baseArr.push("patchInSourceRow");
		baseArr.push("patchInSourceCol");
		baseArr.push("sourceInPatchCol");
		baseArr.push("indexes");
		baseArr.push("rcOffset");
		baseArr.push("cellInfo");
		baseArr.push("rowInfo");
		baseArr.push("cmods");
		baseArr.push("mods");
		baseArr.push("payloadTop");
		baseArr.push("payloadCol");
		baseArr.push("currentRow");
		baseArr.push("modifier");
		baseArr.push("headerMove");
		baseArr.push("headerRename");
		baseArr.push("headerPost");
		baseArr.push("headerPre");
		baseArr.push("header");
		baseArr.push("csv");
		baseArr.push("sourceView");
		baseArr.push("view");
		baseArr.push("patch");
		baseArr.push("source");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



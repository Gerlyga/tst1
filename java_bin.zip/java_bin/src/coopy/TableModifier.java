package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class TableModifier extends haxe.lang.HxObject
{
	public    TableModifier(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    TableModifier(coopy.Table t)
	{
		coopy.TableModifier.__hx_ctor_coopy_TableModifier(this, t);
	}
	
	
	public static   void __hx_ctor_coopy_TableModifier(coopy.TableModifier __temp_me45, coopy.Table t)
	{
		__temp_me45.t = t;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.TableModifier(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.TableModifier(((coopy.Table) (arr.__get(0)) ));
	}
	
	
	public  coopy.Table t;
	
	public   boolean removeColumn(int at)
	{
		haxe.root.Array<java.lang.Object> fate = new haxe.root.Array<java.lang.Object>(new java.lang.Object[]{});
		{
			int _g1 = 0;
			int _g = this.t.get_width();
			while (( _g1 < _g ))
			{
				int i = _g1++;
				if (( i < at )) 
				{
					fate.push(i);
				}
				 else 
				{
					if (( i > at )) 
					{
						fate.push(( i - 1 ));
					}
					 else 
					{
						fate.push(-1);
					}
					
				}
				
			}
			
		}
		
		return this.t.insertOrDeleteColumns(fate, ( this.t.get_width() - 1 ));
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef270 = true;
			switch (field.hashCode())
			{
				case 116:
				{
					if (field.equals("t")) 
					{
						__temp_executeDef270 = false;
						this.t = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef270) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef271 = true;
			switch (field.hashCode())
			{
				case -1316272902:
				{
					if (field.equals("removeColumn")) 
					{
						__temp_executeDef271 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("removeColumn"))) );
					}
					
					break;
				}
				
				
				case 116:
				{
					if (field.equals("t")) 
					{
						__temp_executeDef271 = false;
						return this.t;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef271) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef272 = true;
			switch (field.hashCode())
			{
				case -1316272902:
				{
					if (field.equals("removeColumn")) 
					{
						__temp_executeDef272 = false;
						return this.removeColumn(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef272) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("t");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



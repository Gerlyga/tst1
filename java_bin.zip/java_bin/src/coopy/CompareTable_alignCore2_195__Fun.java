package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class CompareTable_alignCore2_195__Fun extends haxe.lang.Function
{
	public    CompareTable_alignCore2_195__Fun()
	{
		super(1, 1);
	}
	
	
	public static  coopy.CompareTable_alignCore2_195__Fun __hx_current;
	
	@Override public   double __hx_invoke1_f(double __fn_float1, java.lang.Object __fn_dyn1)
	{
		haxe.root.Array<java.lang.Object> v = ( (( __fn_dyn1 == haxe.lang.Runtime.undefined )) ? (((haxe.root.Array<java.lang.Object>) (((java.lang.Object) (__fn_float1) )) )) : (((haxe.root.Array<java.lang.Object>) (__fn_dyn1) )) );
		return ((double) (((int) (haxe.lang.Runtime.toInt(v.__get(0))) )) );
	}
	
	
}



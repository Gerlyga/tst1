package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Merger extends haxe.lang.HxObject
{
	public    Merger(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Merger(coopy.Table parent, coopy.Table local, coopy.Table remote, coopy.CompareFlags flags)
	{
		coopy.Merger.__hx_ctor_coopy_Merger(this, parent, local, remote, flags);
	}
	
	
	public static   void __hx_ctor_coopy_Merger(coopy.Merger __temp_me28, coopy.Table parent, coopy.Table local, coopy.Table remote, coopy.CompareFlags flags)
	{
		__temp_me28.parent = parent;
		__temp_me28.local = local;
		__temp_me28.remote = remote;
		__temp_me28.flags = flags;
	}
	
	
	public static   java.lang.Object makeConflictedCell(coopy.View view, java.lang.Object pcell, java.lang.Object lcell, java.lang.Object rcell)
	{
		return view.toDatum(( ( ( ( ( "((( " + view.toString(pcell) ) + " ))) " ) + view.toString(lcell) ) + " /// " ) + view.toString(rcell) ));
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.Merger(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.Merger(((coopy.Table) (arr.__get(0)) ), ((coopy.Table) (arr.__get(1)) ), ((coopy.Table) (arr.__get(2)) ), ((coopy.CompareFlags) (arr.__get(3)) ));
	}
	
	
	public  coopy.Table parent;
	
	public  coopy.Table local;
	
	public  coopy.Table remote;
	
	public  coopy.CompareFlags flags;
	
	public  coopy.Ordering order;
	
	public  haxe.root.Array<coopy.Unit> units;
	
	public  coopy.Ordering column_order;
	
	public  haxe.root.Array<coopy.Unit> column_units;
	
	public  haxe.ds.IntMap<java.lang.Object> row_mix_local;
	
	public  haxe.ds.IntMap<java.lang.Object> row_mix_remote;
	
	public  haxe.ds.IntMap<java.lang.Object> column_mix_local;
	
	public  haxe.ds.IntMap<java.lang.Object> column_mix_remote;
	
	public  int conflicts;
	
	public   int shuffleDimension(haxe.root.Array<coopy.Unit> dim_units, int len, haxe.root.Array<java.lang.Object> fate, haxe.ds.IntMap<java.lang.Object> cl, haxe.ds.IntMap<java.lang.Object> cr)
	{
		int at = 0;
		{
			int _g = 0;
			while (( _g < dim_units.length ))
			{
				coopy.Unit cunit = dim_units.__get(_g);
				 ++ _g;
				if (( cunit.p < 0 )) 
				{
					if (( cunit.l < 0 )) 
					{
						if (( cunit.r >= 0 )) 
						{
							{
								cr.set(cunit.r, at);
								int __temp_expr202 = at;
							}
							
							at++;
						}
						
					}
					 else 
					{
						{
							cl.set(cunit.l, at);
							int __temp_expr201 = at;
						}
						
						at++;
					}
					
				}
				 else 
				{
					if (( cunit.l >= 0 )) 
					{
						if (( cunit.r < 0 )) 
						{
							{
							}
							
						}
						 else 
						{
							{
								cl.set(cunit.l, at);
								int __temp_expr200 = at;
							}
							
							at++;
						}
						
					}
					
				}
				
			}
			
		}
		
		{
			int _g1 = 0;
			while (( _g1 < len ))
			{
				int x = _g1++;
				java.lang.Object idx = cl.get(((int) (x) ));
				if (( idx == null )) 
				{
					fate.push(-1);
				}
				 else 
				{
					fate.push(idx);
				}
				
			}
			
		}
		
		return at;
	}
	
	
	public   void shuffleColumns()
	{
		this.column_mix_local = new haxe.ds.IntMap<java.lang.Object>();
		this.column_mix_remote = new haxe.ds.IntMap<java.lang.Object>();
		haxe.root.Array<java.lang.Object> fate = new haxe.root.Array<java.lang.Object>();
		int wfate = this.shuffleDimension(this.column_units, this.local.get_width(), fate, this.column_mix_local, this.column_mix_remote);
		this.local.insertOrDeleteColumns(fate, wfate);
	}
	
	
	public   void shuffleRows()
	{
		this.row_mix_local = new haxe.ds.IntMap<java.lang.Object>();
		this.row_mix_remote = new haxe.ds.IntMap<java.lang.Object>();
		haxe.root.Array<java.lang.Object> fate = new haxe.root.Array<java.lang.Object>();
		int hfate = this.shuffleDimension(this.units, this.local.get_height(), fate, this.row_mix_local, this.row_mix_remote);
		this.local.insertOrDeleteRows(fate, hfate);
	}
	
	
	public   int apply()
	{
		this.conflicts = 0;
		coopy.CompareTable ct = coopy.Coopy.compareTables3(this.parent, this.local, this.remote, null);
		coopy.Alignment align = ct.align();
		this.order = align.toOrder();
		this.units = this.order.getList();
		this.column_order = align.meta.toOrder();
		this.column_units = this.column_order.getList();
		boolean allow_insert = this.flags.allowInsert();
		boolean allow_delete = this.flags.allowDelete();
		boolean allow_update = this.flags.allowUpdate();
		coopy.View view = this.parent.getCellView();
		{
			int _g = 0;
			haxe.root.Array<coopy.Unit> _g1 = this.units;
			while (( _g < _g1.length ))
			{
				coopy.Unit row = _g1.__get(_g);
				 ++ _g;
				if (( ( ( row.l >= 0 ) && ( row.r >= 0 ) ) && ( row.p >= 0 ) )) 
				{
					int _g2 = 0;
					haxe.root.Array<coopy.Unit> _g3 = this.column_units;
					while (( _g2 < _g3.length ))
					{
						coopy.Unit col = _g3.__get(_g2);
						 ++ _g2;
						if (( ( ( col.l >= 0 ) && ( col.r >= 0 ) ) && ( col.p >= 0 ) )) 
						{
							java.lang.Object pcell = this.parent.getCell(col.p, row.p);
							java.lang.Object rcell = this.remote.getCell(col.r, row.r);
							if ( ! (view.equals(pcell, rcell)) ) 
							{
								java.lang.Object lcell = this.local.getCell(col.l, row.l);
								if (view.equals(pcell, lcell)) 
								{
									this.local.setCell(col.l, row.l, rcell);
								}
								 else 
								{
									this.local.setCell(col.l, row.l, coopy.Merger.makeConflictedCell(view, pcell, lcell, rcell));
									this.conflicts++;
								}
								
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		this.shuffleColumns();
		this.shuffleRows();
		{
			java.lang.Object __temp_iterator90 = this.column_mix_remote.keys();
			while (haxe.lang.Runtime.toBool(haxe.lang.Runtime.callField(__temp_iterator90, "hasNext", null)))
			{
				int x = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.callField(__temp_iterator90, "next", null))) );
				java.lang.Object x2 = this.column_mix_remote.get(((int) (x) ));
				{
					int _g4 = 0;
					haxe.root.Array<coopy.Unit> _g11 = this.units;
					while (( _g4 < _g11.length ))
					{
						coopy.Unit unit = _g11.__get(_g4);
						 ++ _g4;
						if (( ( unit.l >= 0 ) && ( unit.r >= 0 ) )) 
						{
							this.local.setCell(((int) (haxe.lang.Runtime.toInt(x2)) ), ((int) (haxe.lang.Runtime.toInt(this.row_mix_local.get(((int) (unit.l) )))) ), this.remote.getCell(x, unit.r));
						}
						 else 
						{
							if (( ( unit.p < 0 ) && ( unit.r >= 0 ) )) 
							{
								this.local.setCell(((int) (haxe.lang.Runtime.toInt(x2)) ), ((int) (haxe.lang.Runtime.toInt(this.row_mix_remote.get(((int) (unit.r) )))) ), this.remote.getCell(x, unit.r));
							}
							
						}
						
					}
					
				}
				
			}
			
		}
		
		{
			java.lang.Object __temp_iterator91 = this.row_mix_remote.keys();
			while (haxe.lang.Runtime.toBool(haxe.lang.Runtime.callField(__temp_iterator91, "hasNext", null)))
			{
				int y = ((int) (haxe.lang.Runtime.toInt(haxe.lang.Runtime.callField(__temp_iterator91, "next", null))) );
				java.lang.Object y2 = this.row_mix_remote.get(((int) (y) ));
				{
					int _g5 = 0;
					haxe.root.Array<coopy.Unit> _g12 = this.column_units;
					while (( _g5 < _g12.length ))
					{
						coopy.Unit unit1 = _g12.__get(_g5);
						 ++ _g5;
						if (( ( unit1.l >= 0 ) && ( unit1.r >= 0 ) )) 
						{
							this.local.setCell(((int) (haxe.lang.Runtime.toInt(this.column_mix_local.get(((int) (unit1.l) )))) ), ((int) (haxe.lang.Runtime.toInt(y2)) ), this.remote.getCell(unit1.r, y));
						}
						
					}
					
				}
				
			}
			
		}
		
		return this.conflicts;
	}
	
	
	@Override public   double __hx_setField_f(java.lang.String field, double value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef203 = true;
			switch (field.hashCode())
			{
				case -801616159:
				{
					if (field.equals("conflicts")) 
					{
						__temp_executeDef203 = false;
						this.conflicts = ((int) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef203) 
			{
				return super.__hx_setField_f(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef204 = true;
			switch (field.hashCode())
			{
				case -801616159:
				{
					if (field.equals("conflicts")) 
					{
						__temp_executeDef204 = false;
						this.conflicts = ((int) (haxe.lang.Runtime.toInt(value)) );
						return value;
					}
					
					break;
				}
				
				
				case -995424086:
				{
					if (field.equals("parent")) 
					{
						__temp_executeDef204 = false;
						this.parent = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 779739154:
				{
					if (field.equals("column_mix_remote")) 
					{
						__temp_executeDef204 = false;
						this.column_mix_remote = ((haxe.ds.IntMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 103145323:
				{
					if (field.equals("local")) 
					{
						__temp_executeDef204 = false;
						this.local = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1781215713:
				{
					if (field.equals("column_mix_local")) 
					{
						__temp_executeDef204 = false;
						this.column_mix_local = ((haxe.ds.IntMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -934610874:
				{
					if (field.equals("remote")) 
					{
						__temp_executeDef204 = false;
						this.remote = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1029406962:
				{
					if (field.equals("row_mix_remote")) 
					{
						__temp_executeDef204 = false;
						this.row_mix_remote = ((haxe.ds.IntMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 97513095:
				{
					if (field.equals("flags")) 
					{
						__temp_executeDef204 = false;
						this.flags = ((coopy.CompareFlags) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -1701027933:
				{
					if (field.equals("row_mix_local")) 
					{
						__temp_executeDef204 = false;
						this.row_mix_local = ((haxe.ds.IntMap<java.lang.Object>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 106006350:
				{
					if (field.equals("order")) 
					{
						__temp_executeDef204 = false;
						this.order = ((coopy.Ordering) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -106089146:
				{
					if (field.equals("column_units")) 
					{
						__temp_executeDef204 = false;
						this.column_units = ((haxe.root.Array<coopy.Unit>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 111433583:
				{
					if (field.equals("units")) 
					{
						__temp_executeDef204 = false;
						this.units = ((haxe.root.Array<coopy.Unit>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case -111516379:
				{
					if (field.equals("column_order")) 
					{
						__temp_executeDef204 = false;
						this.column_order = ((coopy.Ordering) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef204) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef205 = true;
			switch (field.hashCode())
			{
				case 93029230:
				{
					if (field.equals("apply")) 
					{
						__temp_executeDef205 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("apply"))) );
					}
					
					break;
				}
				
				
				case -995424086:
				{
					if (field.equals("parent")) 
					{
						__temp_executeDef205 = false;
						return this.parent;
					}
					
					break;
				}
				
				
				case 424548466:
				{
					if (field.equals("shuffleRows")) 
					{
						__temp_executeDef205 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("shuffleRows"))) );
					}
					
					break;
				}
				
				
				case 103145323:
				{
					if (field.equals("local")) 
					{
						__temp_executeDef205 = false;
						return this.local;
					}
					
					break;
				}
				
				
				case -1392980316:
				{
					if (field.equals("shuffleColumns")) 
					{
						__temp_executeDef205 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("shuffleColumns"))) );
					}
					
					break;
				}
				
				
				case -934610874:
				{
					if (field.equals("remote")) 
					{
						__temp_executeDef205 = false;
						return this.remote;
					}
					
					break;
				}
				
				
				case -1868165523:
				{
					if (field.equals("shuffleDimension")) 
					{
						__temp_executeDef205 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("shuffleDimension"))) );
					}
					
					break;
				}
				
				
				case 97513095:
				{
					if (field.equals("flags")) 
					{
						__temp_executeDef205 = false;
						return this.flags;
					}
					
					break;
				}
				
				
				case -801616159:
				{
					if (field.equals("conflicts")) 
					{
						__temp_executeDef205 = false;
						return this.conflicts;
					}
					
					break;
				}
				
				
				case 106006350:
				{
					if (field.equals("order")) 
					{
						__temp_executeDef205 = false;
						return this.order;
					}
					
					break;
				}
				
				
				case 779739154:
				{
					if (field.equals("column_mix_remote")) 
					{
						__temp_executeDef205 = false;
						return this.column_mix_remote;
					}
					
					break;
				}
				
				
				case 111433583:
				{
					if (field.equals("units")) 
					{
						__temp_executeDef205 = false;
						return this.units;
					}
					
					break;
				}
				
				
				case -1781215713:
				{
					if (field.equals("column_mix_local")) 
					{
						__temp_executeDef205 = false;
						return this.column_mix_local;
					}
					
					break;
				}
				
				
				case -111516379:
				{
					if (field.equals("column_order")) 
					{
						__temp_executeDef205 = false;
						return this.column_order;
					}
					
					break;
				}
				
				
				case -1029406962:
				{
					if (field.equals("row_mix_remote")) 
					{
						__temp_executeDef205 = false;
						return this.row_mix_remote;
					}
					
					break;
				}
				
				
				case -106089146:
				{
					if (field.equals("column_units")) 
					{
						__temp_executeDef205 = false;
						return this.column_units;
					}
					
					break;
				}
				
				
				case -1701027933:
				{
					if (field.equals("row_mix_local")) 
					{
						__temp_executeDef205 = false;
						return this.row_mix_local;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef205) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   double __hx_getField_f(java.lang.String field, boolean throwErrors, boolean handleProperties)
	{
		{
			boolean __temp_executeDef206 = true;
			switch (field.hashCode())
			{
				case -801616159:
				{
					if (field.equals("conflicts")) 
					{
						__temp_executeDef206 = false;
						return ((double) (this.conflicts) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef206) 
			{
				return super.__hx_getField_f(field, throwErrors, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef207 = true;
			switch (field.hashCode())
			{
				case 93029230:
				{
					if (field.equals("apply")) 
					{
						__temp_executeDef207 = false;
						return this.apply();
					}
					
					break;
				}
				
				
				case -1868165523:
				{
					if (field.equals("shuffleDimension")) 
					{
						__temp_executeDef207 = false;
						return this.shuffleDimension(((haxe.root.Array<coopy.Unit>) (dynargs.__get(0)) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), ((haxe.root.Array<java.lang.Object>) (dynargs.__get(2)) ), ((haxe.ds.IntMap<java.lang.Object>) (dynargs.__get(3)) ), ((haxe.ds.IntMap<java.lang.Object>) (dynargs.__get(4)) ));
					}
					
					break;
				}
				
				
				case 424548466:
				{
					if (field.equals("shuffleRows")) 
					{
						__temp_executeDef207 = false;
						this.shuffleRows();
					}
					
					break;
				}
				
				
				case -1392980316:
				{
					if (field.equals("shuffleColumns")) 
					{
						__temp_executeDef207 = false;
						this.shuffleColumns();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef207) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("conflicts");
		baseArr.push("column_mix_remote");
		baseArr.push("column_mix_local");
		baseArr.push("row_mix_remote");
		baseArr.push("row_mix_local");
		baseArr.push("column_units");
		baseArr.push("column_order");
		baseArr.push("units");
		baseArr.push("order");
		baseArr.push("flags");
		baseArr.push("remote");
		baseArr.push("local");
		baseArr.push("parent");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



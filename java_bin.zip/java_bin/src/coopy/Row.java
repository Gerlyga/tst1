package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  interface Row extends haxe.lang.IHxObject
{
	   java.lang.String getRowString(int c);
	
}



package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class TerminalDiffRender extends haxe.lang.HxObject
{
	public    TerminalDiffRender(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    TerminalDiffRender()
	{
		coopy.TerminalDiffRender.__hx_ctor_coopy_TerminalDiffRender(this);
	}
	
	
	public static   void __hx_ctor_coopy_TerminalDiffRender(coopy.TerminalDiffRender __temp_me46)
	{
		__temp_me46.align_columns = true;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.TerminalDiffRender(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.TerminalDiffRender();
	}
	
	
	public  haxe.ds.StringMap<java.lang.String> codes;
	
	public  coopy.Table t;
	
	public  coopy.Csv csv;
	
	public  coopy.View v;
	
	public  boolean align_columns;
	
	public   void alignColumns(boolean enable)
	{
		this.align_columns = enable;
	}
	
	
	public   java.lang.String render(coopy.Table t)
	{
		this.csv = new coopy.Csv(haxe.lang.Runtime.toString(null));
		java.lang.String result = "";
		int w = t.get_width();
		int h = t.get_height();
		java.lang.String txt = "";
		this.t = t;
		this.v = t.getCellView();
		this.codes = new haxe.ds.StringMap<java.lang.String>();
		this.codes.set("header", "\u001b[0;1m");
		this.codes.set("spec", "\u001b[35;1m");
		this.codes.set("add", "\u001b[32;1m");
		this.codes.set("conflict", "\u001b[33;1m");
		this.codes.set("modify", "\u001b[34;1m");
		this.codes.set("remove", "\u001b[31;1m");
		this.codes.set("minor", "\u001b[2m");
		this.codes.set("done", "\u001b[0m");
		haxe.root.Array<java.lang.Object> sizes = null;
		if (this.align_columns) 
		{
			sizes = this.pickSizes(t);
		}
		
		{
			int _g = 0;
			while (( _g < h ))
			{
				int y = _g++;
				{
					int _g1 = 0;
					while (( _g1 < w ))
					{
						int x = _g1++;
						if (( x > 0 )) 
						{
							txt += ( ( this.codes.get("minor") + "," ) + this.codes.get("done") );
						}
						
						txt += this.getText(x, y, true);
						if (( sizes != null )) 
						{
							java.lang.String bit = this.getText(x, y, false);
							{
								int _g3 = 0;
								int _g2 = ( ((int) (haxe.lang.Runtime.toInt(sizes.__get(x))) ) - bit.length() );
								while (( _g3 < _g2 ))
								{
									int i = _g3++;
									txt += " ";
								}
								
							}
							
						}
						
					}
					
				}
				
				txt += "\r\n";
			}
			
		}
		
		this.t = null;
		this.v = null;
		this.csv = null;
		this.codes = null;
		return txt;
	}
	
	
	public   java.lang.String getText(int x, int y, boolean color)
	{
		java.lang.Object val = this.t.getCell(x, y);
		coopy.CellInfo cell = coopy.DiffRender.renderCell(this.t, this.v, x, y);
		if (color) 
		{
			java.lang.String code = null;
			if (( cell.category != null )) 
			{
				code = this.codes.get(cell.category);
			}
			
			if (( cell.category_given_tr != null )) 
			{
				java.lang.String code_tr = this.codes.get(cell.category_given_tr);
				if (( code_tr != null )) 
				{
					code = code_tr;
				}
				
			}
			
			if (( code != null )) 
			{
				if (( cell.rvalue != null )) 
				{
					val = ( ( ( ( ( ( this.codes.get("remove") + cell.lvalue ) + this.codes.get("modify") ) + cell.pretty_separator ) + this.codes.get("add") ) + cell.rvalue ) + this.codes.get("done") );
					if (( cell.pvalue != null )) 
					{
						val = ( ( ( ( this.codes.get("conflict") + cell.pvalue ) + this.codes.get("modify") ) + cell.pretty_separator ) + haxe.root.Std.string(val) );
					}
					
				}
				 else 
				{
					val = cell.pretty_value;
					val = ( ( code + haxe.root.Std.string(val) ) + this.codes.get("done") );
				}
				
			}
			
		}
		 else 
		{
			val = cell.pretty_value;
		}
		
		return this.csv.renderCell(this.v, val);
	}
	
	
	public   haxe.root.Array<java.lang.Object> pickSizes(coopy.Table t)
	{
		int w = t.get_width();
		int h = t.get_height();
		coopy.View v = t.getCellView();
		coopy.Csv csv = new coopy.Csv(haxe.lang.Runtime.toString(null));
		haxe.root.Array<java.lang.Object> sizes = new haxe.root.Array<java.lang.Object>();
		int row = -1;
		int total = ( w - 1 );
		{
			int _g = 0;
			while (( _g < w ))
			{
				int x = _g++;
				double m = ((double) (0) );
				double m2 = ((double) (0) );
				int mmax = 0;
				int mmostmax = 0;
				int mmin = -1;
				{
					int _g1 = 0;
					while (( _g1 < h ))
					{
						int y = _g1++;
						java.lang.String txt = this.getText(x, y, false);
						if (( haxe.lang.Runtime.valEq(txt, "@@") && ( row == -1 ) )) 
						{
							row = y;
						}
						
						int len = txt.length();
						if (( y == row )) 
						{
							mmin = len;
						}
						
						m += ((double) (len) );
						m2 += ((double) (( len * len )) );
						if (( len > mmax )) 
						{
							mmax = len;
						}
						
					}
					
				}
				
				double mean = ( m / h );
				double stddev = java.lang.Math.sqrt(( ( m2 / h ) - ( mean * mean ) ));
				int most = ((int) (( ( mean + ( stddev * 2 ) ) + 0.5 )) );
				{
					int _g11 = 0;
					while (( _g11 < h ))
					{
						int y1 = _g11++;
						java.lang.String txt1 = this.getText(x, y1, false);
						int len1 = txt1.length();
						if (( len1 <= most )) 
						{
							if (( len1 > mmostmax )) 
							{
								mmostmax = len1;
							}
							
						}
						
					}
					
				}
				
				int full = mmax;
				most = mmostmax;
				if (( mmin != -1 )) 
				{
					if (( most < mmin )) 
					{
						most = mmin;
					}
					
				}
				
				sizes.push(most);
				total += most;
			}
			
		}
		
		if (( total > 130 )) 
		{
			return null;
		}
		
		return sizes;
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef273 = true;
			switch (field.hashCode())
			{
				case 1954807971:
				{
					if (field.equals("align_columns")) 
					{
						__temp_executeDef273 = false;
						this.align_columns = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 94834726:
				{
					if (field.equals("codes")) 
					{
						__temp_executeDef273 = false;
						this.codes = ((haxe.ds.StringMap<java.lang.String>) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 118:
				{
					if (field.equals("v")) 
					{
						__temp_executeDef273 = false;
						this.v = ((coopy.View) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 116:
				{
					if (field.equals("t")) 
					{
						__temp_executeDef273 = false;
						this.t = ((coopy.Table) (value) );
						return value;
					}
					
					break;
				}
				
				
				case 98822:
				{
					if (field.equals("csv")) 
					{
						__temp_executeDef273 = false;
						this.csv = ((coopy.Csv) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef273) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef274 = true;
			switch (field.hashCode())
			{
				case -1448174351:
				{
					if (field.equals("pickSizes")) 
					{
						__temp_executeDef274 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("pickSizes"))) );
					}
					
					break;
				}
				
				
				case 94834726:
				{
					if (field.equals("codes")) 
					{
						__temp_executeDef274 = false;
						return this.codes;
					}
					
					break;
				}
				
				
				case -75125341:
				{
					if (field.equals("getText")) 
					{
						__temp_executeDef274 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getText"))) );
					}
					
					break;
				}
				
				
				case 116:
				{
					if (field.equals("t")) 
					{
						__temp_executeDef274 = false;
						return this.t;
					}
					
					break;
				}
				
				
				case -934592106:
				{
					if (field.equals("render")) 
					{
						__temp_executeDef274 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("render"))) );
					}
					
					break;
				}
				
				
				case 98822:
				{
					if (field.equals("csv")) 
					{
						__temp_executeDef274 = false;
						return this.csv;
					}
					
					break;
				}
				
				
				case -754411240:
				{
					if (field.equals("alignColumns")) 
					{
						__temp_executeDef274 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("alignColumns"))) );
					}
					
					break;
				}
				
				
				case 118:
				{
					if (field.equals("v")) 
					{
						__temp_executeDef274 = false;
						return this.v;
					}
					
					break;
				}
				
				
				case 1954807971:
				{
					if (field.equals("align_columns")) 
					{
						__temp_executeDef274 = false;
						return this.align_columns;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef274) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef275 = true;
			switch (field.hashCode())
			{
				case -1448174351:
				{
					if (field.equals("pickSizes")) 
					{
						__temp_executeDef275 = false;
						return this.pickSizes(((coopy.Table) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
				case -754411240:
				{
					if (field.equals("alignColumns")) 
					{
						__temp_executeDef275 = false;
						this.alignColumns(haxe.lang.Runtime.toBool(dynargs.__get(0)));
					}
					
					break;
				}
				
				
				case -75125341:
				{
					if (field.equals("getText")) 
					{
						__temp_executeDef275 = false;
						return this.getText(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), haxe.lang.Runtime.toBool(dynargs.__get(2)));
					}
					
					break;
				}
				
				
				case -934592106:
				{
					if (field.equals("render")) 
					{
						__temp_executeDef275 = false;
						return this.render(((coopy.Table) (dynargs.__get(0)) ));
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef275) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("align_columns");
		baseArr.push("v");
		baseArr.push("csv");
		baseArr.push("t");
		baseArr.push("codes");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}



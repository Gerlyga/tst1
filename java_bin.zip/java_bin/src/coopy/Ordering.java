package coopy;
import haxe.root.*;

@SuppressWarnings(value={"rawtypes", "unchecked"})
public  class Ordering extends haxe.lang.HxObject
{
	public    Ordering(haxe.lang.EmptyObject empty)
	{
		{
		}
		
	}
	
	
	public    Ordering()
	{
		coopy.Ordering.__hx_ctor_coopy_Ordering(this);
	}
	
	
	public static   void __hx_ctor_coopy_Ordering(coopy.Ordering __temp_me33)
	{
		__temp_me33.order = new haxe.root.Array<coopy.Unit>();
		__temp_me33.ignore_parent = false;
	}
	
	
	public static   java.lang.Object __hx_createEmpty()
	{
		return new coopy.Ordering(((haxe.lang.EmptyObject) (haxe.lang.EmptyObject.EMPTY) ));
	}
	
	
	public static   java.lang.Object __hx_create(haxe.root.Array arr)
	{
		return new coopy.Ordering();
	}
	
	
	public  haxe.root.Array<coopy.Unit> order;
	
	public  boolean ignore_parent;
	
	public   void add(int l, int r, java.lang.Object p)
	{
		int __temp_p32 = ( (( p == null )) ? (((int) (-2) )) : (((int) (haxe.lang.Runtime.toInt(p)) )) );
		if (this.ignore_parent) 
		{
			__temp_p32 = -2;
		}
		
		this.order.push(new coopy.Unit(((java.lang.Object) (l) ), ((java.lang.Object) (r) ), ((java.lang.Object) (__temp_p32) )));
	}
	
	
	public   haxe.root.Array<coopy.Unit> getList()
	{
		return this.order;
	}
	
	
	@Override public   java.lang.String toString()
	{
		java.lang.String txt = "";
		{
			int _g1 = 0;
			int _g = this.order.length;
			while (( _g1 < _g ))
			{
				int i = _g1++;
				if (( i > 0 )) 
				{
					txt += ", ";
				}
				
				txt += haxe.root.Std.string(this.order.__get(i));
			}
			
		}
		
		return txt;
	}
	
	
	public   void ignoreParent()
	{
		this.ignore_parent = true;
	}
	
	
	@Override public   java.lang.Object __hx_setField(java.lang.String field, java.lang.Object value, boolean handleProperties)
	{
		{
			boolean __temp_executeDef221 = true;
			switch (field.hashCode())
			{
				case 985610167:
				{
					if (field.equals("ignore_parent")) 
					{
						__temp_executeDef221 = false;
						this.ignore_parent = haxe.lang.Runtime.toBool(value);
						return value;
					}
					
					break;
				}
				
				
				case 106006350:
				{
					if (field.equals("order")) 
					{
						__temp_executeDef221 = false;
						this.order = ((haxe.root.Array<coopy.Unit>) (value) );
						return value;
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef221) 
			{
				return super.__hx_setField(field, value, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_getField(java.lang.String field, boolean throwErrors, boolean isCheck, boolean handleProperties)
	{
		{
			boolean __temp_executeDef222 = true;
			switch (field.hashCode())
			{
				case 4640028:
				{
					if (field.equals("ignoreParent")) 
					{
						__temp_executeDef222 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("ignoreParent"))) );
					}
					
					break;
				}
				
				
				case 106006350:
				{
					if (field.equals("order")) 
					{
						__temp_executeDef222 = false;
						return this.order;
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef222 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("toString"))) );
					}
					
					break;
				}
				
				
				case 985610167:
				{
					if (field.equals("ignore_parent")) 
					{
						__temp_executeDef222 = false;
						return this.ignore_parent;
					}
					
					break;
				}
				
				
				case -75359980:
				{
					if (field.equals("getList")) 
					{
						__temp_executeDef222 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("getList"))) );
					}
					
					break;
				}
				
				
				case 96417:
				{
					if (field.equals("add")) 
					{
						__temp_executeDef222 = false;
						return ((haxe.lang.Function) (new haxe.lang.Closure(((java.lang.Object) (this) ), haxe.lang.Runtime.toString("add"))) );
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef222) 
			{
				return super.__hx_getField(field, throwErrors, isCheck, handleProperties);
			}
			 else 
			{
				throw null;
			}
			
		}
		
	}
	
	
	@Override public   java.lang.Object __hx_invokeField(java.lang.String field, haxe.root.Array dynargs)
	{
		{
			boolean __temp_executeDef223 = true;
			switch (field.hashCode())
			{
				case 4640028:
				{
					if (field.equals("ignoreParent")) 
					{
						__temp_executeDef223 = false;
						this.ignoreParent();
					}
					
					break;
				}
				
				
				case 96417:
				{
					if (field.equals("add")) 
					{
						__temp_executeDef223 = false;
						this.add(((int) (haxe.lang.Runtime.toInt(dynargs.__get(0))) ), ((int) (haxe.lang.Runtime.toInt(dynargs.__get(1))) ), dynargs.__get(2));
					}
					
					break;
				}
				
				
				case -1776922004:
				{
					if (field.equals("toString")) 
					{
						__temp_executeDef223 = false;
						return this.toString();
					}
					
					break;
				}
				
				
				case -75359980:
				{
					if (field.equals("getList")) 
					{
						__temp_executeDef223 = false;
						return this.getList();
					}
					
					break;
				}
				
				
			}
			
			if (__temp_executeDef223) 
			{
				return super.__hx_invokeField(field, dynargs);
			}
			
		}
		
		return null;
	}
	
	
	@Override public   void __hx_getFields(haxe.root.Array<java.lang.String> baseArr)
	{
		baseArr.push("ignore_parent");
		baseArr.push("order");
		{
			super.__hx_getFields(baseArr);
		}
		
	}
	
	
}


